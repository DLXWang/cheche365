-- MySQL dump 10.13  Distrib 5.7.16, for osx10.11 (x86_64)
--
-- Host: 127.0.0.1    Database: cheche_production
-- ------------------------------------------------------
-- Server version	5.7.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `channel`
--

LOCK TABLES `channel` WRITE;
/*!40000 ALTER TABLE `channel` DISABLE KEYS */;
INSERT INTO `channel` (`id`, `name`, `parent`, `api_partner`, `description`, `icon`) VALUES (3,'WE_CHAT',3,NULL,'微信公众号',NULL),(4,'IOS',4,NULL,'IOS相关设备',NULL),(5,'WEB',5,NULL,'PC版应用',NULL),(6,'ANDROID',6,NULL,'ANDROID相关设备',NULL),(8,'WAP',8,NULL,'WAP',NULL),(9,'UNKNOWN',9,NULL,'未知',NULL),(10,'ALIPAY',10,NULL,'支付宝加油服务',NULL),(11,'ORDER_CENTER',11,NULL,'出单中心',NULL),(12,'ORDER_CENTER_ALIPAY',10,NULL,'支付宝加油服务-出单中心','zfb.png'),(13,'PARTNER_AUTOHOME',13,1,'汽车之家','qczj.png'),(15,'PARTNER_BAIDU',15,2,'百度地图','baidu.png'),(16,'ORDER_CENTER_BAIDU',15,2,'百度地图-出单中心','baidu.png'),(17,'ORDER_CENTER_AUTOHOME',13,1,'汽车之家-出单中心','qczj.png'),(18,'ORDER_CENTER_TUHU',203,3,'途虎养车-出单中心','tuhu.png'),(19,'PARTNER_CHEXIANG',19,5,'车享网','chexiang.png'),(20,'ORDER_CENTER_CHEXIANG',19,5,'车享网-出单中心','chexiang.png'),(21,'ALIPAY_FUWUCHUANG',21,NULL,'支付宝服务窗','zfb-fwc.png'),(22,'ORDER_CENTER_ALIPAY_FUWUCHUANG',21,NULL,'支付宝服务窗-出单中心','zfb-fwc.png'),(23,'PARTNER_PICCLIFE',23,6,'人保寿险','picclife.png'),(24,'ORDER_CENTER_PICCLIFE',23,6,'人保寿险-出单中心','picclife.png'),(25,'PARTNER_NCI',25,7,'世纪通保','newchinalife.png'),(26,'ORDER_CENTER_NCI',25,7,'世纪通保-出单中心','newchinalife.png'),(27,'PARTNER_LE_AUTO_LINK',27,8,'乐视车联网','lscl.png'),(28,'ORDER_CENTER_LE_AUTO_LINK',27,8,'乐视车联网-出单中心','lscl.png'),(29,'PARTNER_CHENGNIU',29,9,'橙牛','chengniu.png'),(30,'PARTNER_BXS',30,10,'保险师','bxs.png'),(31,'ORDER_CENTER_BXS',30,10,'保险师-出单中心','bxs.png'),(32,'ORDER_CENTER_CHENGNIU',29,9,'橙牛-出单中心','chengniu.png'),(33,'PARTNER_EPEIT',33,11,'易配通','epeit.png'),(34,'ORDER_CENTER_EPEIT',33,11,'易配通-出单中心','epeit.png'),(35,'PARTNER_XIAOMI',35,12,'小米','xiaomi.png'),(36,'ORDER_CENTER_XIAOMI',35,12,'小米-出单中心','xiaomi.png'),(37,'PARTNER_ETCP',37,13,'ETCP','etcp.png'),(38,'ORDER_CENTER_ETCP',37,13,'ETCP-出单中心','etcp.png'),(39,'WE_CHAT_APP',39,NULL,'微信小程序',NULL),(40,'PARTNER_RRYP',40,14,'人人优品','rryp.png'),(41,'ORDER_CENTER_RRYP',40,14,'人人优品-出单中心','rryp.png'),(203,'PARTNER_TUHU',203,3,'途虎养车','tuhu.png');
/*!40000 ALTER TABLE `channel` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-12-26 17:51:47
