-- MySQL dump 10.13  Distrib 5.7.16, for osx10.11 (x86_64)
--
-- Host: 127.0.0.1    Database: cheche_production
-- ------------------------------------------------------
-- Server version	5.7.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `gift_type`
--

LOCK TABLES `gift_type` WRITE;
/*!40000 ALTER TABLE `gift_type` DISABLE KEYS */;
INSERT INTO `gift_type` (`id`, `name`, `description`, `use_type`, `category`, `category_name`) VALUES (1,'加油卡','加油卡',3,6,'实物礼品'),(2,'微信红包','微信红包',1,1,'代金券'),(3,'代金券','代金券',1,1,'代金券'),(4,'礼品卡','车车赠送，不跟系统任何单据活动关联',1,1,'代金券'),(5,'洗车券','洗车券',3,6,'实物礼品'),(6,'加油券','加油券',3,6,'实物礼品'),(7,'汽车保养券','汽车保养券',3,6,'实物礼品'),(8,'轮胎打折券','轮胎打折券',3,6,'实物礼品'),(9,'车载吸尘器','车载吸尘器',3,6,'实物礼品'),(10,'行车记录仪','行车记录仪',3,6,'实物礼品'),(11,'乐视TV','乐视TV',3,6,'实物礼品'),(12,'iWatch','iWatch',3,6,'实物礼品'),(14,'车载工具箱','车载工具箱',3,6,'实物礼品'),(15,'安全锤','安全锤',3,6,'实物礼品'),(16,'盛夏清凉礼包','盛夏清凉礼包',2,4,'礼包'),(17,'盛夏清爽礼包','盛夏清爽礼包',2,4,'礼包'),(18,'盛夏冰爽礼包','盛夏冰爽礼包',2,4,'礼包'),(19,'盛夏酷爽礼包','盛夏酷爽礼包',2,4,'礼包'),(20,'车船税抵用券','车船税抵用券',1,2,'抵扣券'),(21,'壕礼','满千送百元壕礼&下单可抽奖',2,4,'礼包'),(22,'移动电源','移动电源',3,6,'实物礼品'),(23,'移动硬盘','移动硬盘',3,6,'实物礼品'),(24,'车险大礼包','车险大礼包',2,4,'礼包'),(25,'满千送百元礼包','满千送百元礼包',2,4,'礼包'),(26,'好车主奖金凭证','好车主奖金凭证',4,NULL,'好车主奖金凭证'),(27,'电销促销活动','电销促销活动',1,1,'代金券'),(28,'加油卡','加油卡',3,4,'礼包'),(29,'礼包','礼包',2,4,'礼包'),(30,'京东卡','京东卡',3,4,'礼包'),(31,'小米16000mah移动电源','小米16000mah移动电源',3,6,'实物礼品'),(32,'海尔车载空气净化器','海尔车载空气净化器',3,6,'实物礼品'),(33,'乐视行车记录仪','乐视行车记录仪',3,6,'实物礼品'),(34,'现金','现金',1,1,'代金券'),(35,'京东卡','京东卡',3,6,'实物礼品');
/*!40000 ALTER TABLE `gift_type` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-12-26 17:51:48
