-- MySQL dump 10.13  Distrib 5.7.16, for osx10.11 (x86_64)
--
-- Host: 127.0.0.1    Database: cheche_production
-- ------------------------------------------------------
-- Server version	5.7.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `insurance_company`
--

LOCK TABLES `insurance_company` WRITE;
/*!40000 ALTER TABLE `insurance_company` DISABLE KEYS */;
INSERT INTO `insurance_company` (`id`, `code`, `name`, `logo`, `disable`, `slogan`, `type`, `rank`, `description`, `renew_support`, `alipay_support`, `website_url`, `promote`) VALUES (10000,'PICC','人保财险','picc2.png',0,'多快好省，全国通赔',1,1,'全国通赔、专享电子查勘理赔,5000元以下小额单方事故、极速理赔,50公里内不限次数免费故障车救援服务,万元以下案件一小时通知赔付,全国7X24小时全天候查勘和理赔咨询服务',1,1,'http://www.epicc.com.cn/',0),(15000,'SINOSIG','阳光保险','sinosig2.png',0,'全年无限次非事故道路救援',1,2,'全国通赔、理赔无限制,故障车辆免费救援,5000元以下非人伤免单证24小时赔付,旅行医疗救援服务',0,0,'http://chexian.sinosig.com/',0),(20000,'PINGAN','平安保险','pingan.png',0,'快易免，先赔后修',1,100,'全国通赔、理赔无限制,先赔付再修车、万元以下三天到账,7*24小时、百公里免费非事故道路救援服务,上门代收理赔资料、车险理赔进度实时查询',1,1,'http://insurance.pingan.com/list/chexian/index.shtml?source=index_NEW',1),(25000,'CPIC','太平洋保险','cpic2.png',0,'免费道路救援，全国通赔',1,3,'免费道路救援,车险在线支付、即可享受双重好礼',1,1,'http://www.ecpic.com.cn/',0),(30000,'TAIPING','中国太平','taiping.png',0,NULL,3,4,NULL,0,0,'',0),(35000,'ANBANG','安邦保险','anbang.png',0,NULL,3,5,NULL,0,0,'',0),(40000,'CHINALIFE','国寿财险','chinalife.png',0,'快速理赔，便利贴心',1,6,'电话一拨就通,全国一套标准,赔款一天支付,投诉一站解决,流程一路透明',0,0,'http://www.chinalife-p.com.cn/',0),(45000,'CIC','中华联合','cic.png',0,'全国通赔，上门服务',1,7,'全国通赔、365*7*24不间断服务、故障车辆,免费施救、快速查勘,限时理赔、异地出险,就地服务、投保索赔,上门服务',0,0,'http://e.cic.cn/',0),(50000,'ZHONGAN','保骉车险','zhongan.png',0,'给好用户更好的福利',4,99,'赔款极速到账,简单快赔,电话直赔',0,0,'http://chexian.zhongan.com/open/castle/inputQueryInfo',1),(55000,'AXATP','安盛天平','axatp.png',0,'全球一亿客户的选择',2,8,'全年免费无限次道路救援，万元以下，一天赔付',0,0,'http://www.axatp.com/auto/',0),(60000,'FUNDINS','富德','fundins1.png',0,'诚信、专业、贴心、高效',3,9,'理赔快，网销案件优先处理，服务好，客户特享专属服务',0,0,'',0),(65000,'ANSWERN','安心保险','answern.png',0,'理赔从此简单',1,10,'让大众真正享受保险带来的美好人生，让每一个消费者买保险就是买安心',0,0,'https://www.answern.com/',0),(99999997,'UNKNOWN_3','临时保险公司3','unknown_3.png',1,'UNKNOWN_3',4,100,'UNKNOWN_3',0,0,'https://www.cheche365.com/index.html',0),(99999998,'UNKNOWN_2','临时保险公司2','unknown_2.png',1,'UNKNOWN_2',4,100,'UNKNOWN_2',0,0,'https://www.cheche365.com/index.html',0),(99999999,'UNKNOWN_1','临时保险公司1','unknown_1.png',1,'UNKNOWN_1',4,100,'UNKNOWN_1',0,0,'https://www.cheche365.com/index.html',0);
/*!40000 ALTER TABLE `insurance_company` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-12-26 17:51:48
