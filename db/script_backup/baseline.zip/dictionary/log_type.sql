-- MySQL dump 10.13  Distrib 5.7.16, for osx10.11 (x86_64)
--
-- Host: 127.0.0.1    Database: cheche_production
-- ------------------------------------------------------
-- Server version	5.7.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `log_type`
--

LOCK TABLES `log_type` WRITE;
/*!40000 ALTER TABLE `log_type` DISABLE KEYS */;
INSERT INTO `log_type` (`id`, `name`, `description`) VALUES (1,'核保失败','核保失败'),(2,'微信支付签名失败','微信支付签名验证失败'),(3,'微信支付失败','微信支付失败'),(4,'微信支付成功','微信支付成功'),(5,'微信支付非预期回调状态','微信支付非预期回调状态'),(6,'出单时间','订单出单完成时间'),(9,'重设过期订单状态','重设过期订单状态'),(10,'删除内部用户','删除内部用户'),(11,'银联支付提交表单','银联支付提交表单'),(12,'银联支付前台回调','银联支付前台回调'),(13,'银联支付后台回调','银联支付后台回调'),(14,'银联支付单笔查询','银联支付单笔查询'),(15,'银联支付异常','银联支付异常'),(16,'滴滴专车状态变更','滴滴专车状态变更'),(17,'银联支付APP推送订单','银联支付APP推送订单'),(18,'修改二维码渠道名称','修改二维码渠道名称'),(19,'修改二维码渠道返点金额','修改二维码渠道返点金额'),(20,'订单支付方式变更','订单支付方式变更'),(21,'支付宝付款信息','支付宝付款信息'),(22,'客户预约处理状态变更','客户预约处理状态变更'),(23,'商业险套餐变更','商业险套餐变更'),(24,'交强险套餐变更','交强险套餐变更'),(25,'出单状态变更','出单状态变更'),(26,'众安付款信息','众安付款信息'),(27,'备注信息变更','备注信息变更'),(28,'保单历史记录','保单历史记录'),(29,'银联支付退款交易','银联支付退款交易'),(30,'银联支付撤销交易','银联支付撤销交易'),(31,'存储用户报价过程中填写的车辆信息','存储用户报价过程中填写的车辆信息'),(32,'IDCREDIT','绿湾');
/*!40000 ALTER TABLE `log_type` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-12-26 17:51:49
