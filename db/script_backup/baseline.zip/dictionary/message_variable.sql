-- MySQL dump 10.13  Distrib 5.7.16, for osx10.11 (x86_64)
--
-- Host: 127.0.0.1    Database: cheche_production
-- ------------------------------------------------------
-- Server version	5.7.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `message_variable`
--

LOCK TABLES `message_variable` WRITE;
/*!40000 ALTER TABLE `message_variable` DISABLE KEYS */;
INSERT INTO `message_variable` (`id`, `code`, `name`, `type`, `placeholder`, `length`, `parameter`, `model_class`, `model_method`) VALUES (1,'${Order.OrderNo}','订单号','varchar','请输入订单号',17,'order','com.cheche365.cheche.core.model.PurchaseOrder','getOrderNo'),(2,'${Order.TrackingNo}','快递单号','varchar','请输入快递单号',50,'order','com.cheche365.cheche.core.model.PurchaseOrder','getTrackingNo'),(3,'${Order.Premium}','订单保险总额','number','请输入保险总额',18,'order','com.cheche365.cheche.core.model.PurchaseOrder','getPaidAmount'),(4,'${Order.AutoTax}','订单车船税','number','请输入车船税',18,'autoTax',NULL,NULL),(5,'${Order.EffectiveDate}','保险起始日','date','请输入保险起始日',10,'efdate',NULL,NULL),(6,'${InsuranceCompany.Name}','保险公司名称','varchar','请输入保险公司名称',45,'ic','com.cheche365.cheche.core.model.InsuranceCompany','getName'),(7,'${Auto.LicensePlateNo}','车牌号','varchar','请输入车牌号',7,'auto','com.cheche365.cheche.core.model.Auto','getLicensePlateNo'),(8,'${Auto.Owner}','客户姓名','varchar','请输入客户姓名',45,'auto','com.cheche365.cheche.core.model.Auto','getOwner'),(9,'${Address.Mobile}','客户手机号','varchar','请输入客户手机号',17,'order','com.cheche365.cheche.core.model.Address','getMobile'),(10,'${Order.PayTime}','客户预约收款时间','date','请输入客户预约收款时间',19,'ooi','com.cheche365.cheche.core.model.OrderOperationInfo','getPayTime'),(11,'${Order.SendTime}','客户预约派送时间','date','请输入客户预约派送时间',19,'ooi','com.cheche365.cheche.core.model.OrderOperationInfo','getSendTime'),(12,'${Order.ConfirmNo}','确认单号','varchar','请输入确认单号',20,'ooi','com.cheche365.cheche.core.model.OrderOperationInfo','getConfirmNo'),(13,'${Quote.Premium}','报价总额','number','请输入报价总额',18,'quote','com.cheche365.cheche.core.model.QuoteRecord','getTotalPremium'),(14,'${Quote.CompulsoryPremium}','报价交强险','number','请输入报价交强险',18,'quote','com.cheche365.cheche.core.model.QuoteRecord','getCompulsoryPremium'),(15,'${Quote.CommercialPremium}','报价商业险','number','请输入报价商业险',18,'quote','com.cheche365.cheche.core.model.QuoteRecord','getPremium'),(16,'${Quote.AutoTax}','报价车船税','number','请输入报价车船税',18,'quote','com.cheche365.cheche.core.model.QuoteRecord','getAutoTax'),(17,'${Marketing.Name}','活动名称','varchar','请输入活动名称',45,'marketing','com.cheche365.cheche.core.model.Marketing','getName'),(18,'${Marketing.LandingPage}','活动落地页','varchar','请输入活动落地页',100,'mlp',NULL,NULL),(19,'${Order.PremiumAmount}','保费金额','number','请输入保费金额',18,'pam',NULL,NULL),(20,'${CustomerQuoteDetail}','人工报价详情','varchar','请输入人工报价详情',500,'cqd',NULL,NULL),(21,'${Mobile}','手机号','varchar','请输入手机号',11,'mobile',NULL,NULL),(22,'${VerifyCode}','验证码','varchar','请输入验证码',6,'verifyCode',NULL,NULL),(23,'${Minute}','有效时间','int','请输入有效时间',10,'minute',NULL,NULL),(24,'${MOrderLink}','M站订单链接','varchar','请输入M站订单链接',100,'mol',NULL,NULL),(25,'${MMyCenterLink}','M站我的中心链接','varchar','请输入M站我的中心链接',100,'mmcl',NULL,NULL),(26,'${MHomeLink}','M站首页链接','varchar','请输入M站首页链接',100,'mhl',NULL,NULL),(27,'${DeliveryInsuranceDays}','递出保单工作日','int','请输入递出保单工作日',10,'did',NULL,NULL),(28,'${GiftAmount}','红包金额','number','请输入红包金额',18,'giftAmount',NULL,NULL),(29,'${CodeType}','兑换码类型','varchar','请输入兑换码类型',100,'codeType',NULL,NULL),(30,'${Code}','兑换码','varchar','请输入兑换码',200,'code',NULL,NULL),(31,'${Amount}','金额','number','请输入金额值',18,'amount',NULL,NULL),(32,'${MPaymentLink}','M站支付链接','varchar','请输入M站支付链接',100,'mpl',NULL,NULL),(33,'${Number}','数量','number','请输入数量',10,'number',NULL,NULL),(34,'${ThirdPartnerName}','第三方合作名称','varchar','请输入第三方合作名称',50,'tpn',NULL,NULL),(35,'${ThirdPartnerMobile}','第三方合作电话','varchar','请输入第三方合作电话',30,'tpm',NULL,NULL),(36,'${ParamMobile}','电话参数','varchar','请输入电话',11,'pm',NULL,NULL);
/*!40000 ALTER TABLE `message_variable` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-12-26 17:51:50
