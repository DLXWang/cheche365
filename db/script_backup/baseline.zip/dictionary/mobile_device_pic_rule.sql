-- MySQL dump 10.13  Distrib 5.7.16, for osx10.11 (x86_64)
--
-- Host: 127.0.0.1    Database: cheche_production
-- ------------------------------------------------------
-- Server version	5.7.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `mobile_device_pic_rule`
--

LOCK TABLES `mobile_device_pic_rule` WRITE;
/*!40000 ALTER TABLE `mobile_device_pic_rule` DISABLE KEYS */;
INSERT INTO `mobile_device_pic_rule` (`id`, `message_type`, `client`, `version`, `screen_size`, `image_suffix`, `description`, `order`) VALUES (4,'(10|12)','android','1.4.0-','*','',NULL,4),(5,'(10|12)','ios','1.6.0-','*','',NULL,5),(6,'(10|12)','*','*','*','',NULL,99),(7,'11','*','*','*','',NULL,100),(8,'(131|132|133)','ios','*','(320_480|320_568)','640_170',NULL,200),(9,'(131|132|133)','ios','*','(375_667)','750_200',NULL,201),(10,'(131|132|133)','*','*','*','828_220',NULL,299),(11,'14','*','*','(320_480|320_568|375_667)','192_66',NULL,300),(12,'14','*','*','*','288_99',NULL,399),(13,'(10|12)','(alipay|alipay_fuwuchuang)','*','*','',NULL,7),(14,'(10|12)','(partner_baidu)','*','*','partner_baidu',NULL,8),(15,'(10|12)','(partner_autohome)','*','*','partner_autohome',NULL,9),(16,'(10|12)','(partner_tuhu)','*','*','partner_tuhu',NULL,10),(17,'(10|12)','(partner_chexiang)','*','*','partner_chexiang',NULL,11),(18,'(15|16)','(wap|wechat|partner_chexiang|partner_autohome|partner_ok619|partner_bdmap)','*','*','',NULL,12),(999,'*','*','*','*','','默认设置不改变图片后缀',999),(1000,'(10|12)','android','-1.4.0','*','android1_3',NULL,4),(1001,'(10|12)','ios','-1.6.0','*','ios1_5',NULL,5);
/*!40000 ALTER TABLE `mobile_device_pic_rule` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-12-26 17:51:50
