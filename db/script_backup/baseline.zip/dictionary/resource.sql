-- MySQL dump 10.13  Distrib 5.7.16, for osx10.11 (x86_64)
--
-- Host: 127.0.0.1    Database: cheche_production
-- ------------------------------------------------------
-- Server version	5.7.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `resource`
--

LOCK TABLES `resource` WRITE;
/*!40000 ALTER TABLE `resource` DISABLE KEYS */;
INSERT INTO `resource` (`id`, `name`, `parent`, `resource_type`, `level`) VALUES (1,'运营系统',NULL,1,1),(2,'管理系统',NULL,1,1),(3,'合作商管理',1,1,2),(4,'合作商管理',3,1,3),(5,'商务活动管理',3,1,3),(6,'用户管理',2,1,2),(7,'用户管理',6,1,3),(8,'车辆管理',2,1,2),(9,'车辆管理',8,1,3),(10,'系统账号',2,1,2),(11,'内部账号',10,1,3),(12,'外部账号',10,1,3),(13,'角色管理',2,1,2),(14,'角色属性',13,1,3),(15,'权限条目',13,1,3),(16,'微信后台管理-二维码渠道管理',1,1,2),(17,'临时二维码',16,1,3),(18,'永久二维码',16,1,3),(19,'短信中心',1,1,2),(20,'短信模板管理',19,1,3),(21,'筛选用户功能管理',19,1,3),(22,'条件触发短信',19,1,3),(23,'条件触发短信日志',19,1,3),(24,'主动发送短信',19,1,3),(25,'红包发送审核',1,1,2),(26,'红包发送审核',25,1,3),(27,'出单中心',NULL,1,1),(28,'订单管理',27,1,2),(29,'订单列表',28,1,3),(31,'订单查询',28,1,3),(32,'分配订单',28,1,3),(33,'保单录入',28,1,3),(34,'客户管理',27,1,2),(35,'客户预约',34,1,3),(36,'代理人管理',27,1,2),(38,'代理人列表',36,1,3),(39,'用户管理',27,1,2),(40,'新增用户',39,1,3),(41,'用户列表',39,1,3),(44,'车辆报价',27,1,2),(45,'拍照信息',44,1,3),(46,'电话信息',44,1,3),(47,'电话管理',27,1,2),(48,'意向客户',47,1,3),(49,'工作查看',47,1,3),(50,'全国出单中心',27,1,2),(51,'订单管理-订单总控台',50,1,3),(52,'订单管理-全部订单',50,1,3),(53,'订单管理-订单新建',50,1,3),(54,'订单管理-订单异常',50,1,3),(55,'订单管理-订单退款',50,1,3),(56,'订单管理-已报价待审核',50,1,3),(57,'订单管理-通过审核待结款',50,1,3),(58,'订单管理-结款完成待出单',50,1,3),(59,'订单管理-已出单',50,1,3),(60,'订单管理-订单完成',50,1,3),(61,'订单管理-订单查询',50,1,3),(62,'分站信息管理-分站信息管理',50,1,3),(63,'出单机构管理-出单机构管理',50,1,3),(64,'礼物订单管理',27,1,2),(65,'礼物订单管理',64,1,3),(66,'礼物订单管理-兑换码导入',64,1,3),(67,'中国好车主',27,1,2),(68,'报名列表',67,1,3),(69,'修改指定跟进人',47,1,3),(70,'新建客户',47,1,3),(71,'定时任务管理',2,1,2),(72,'定时任务管理',71,1,3),(73,'订单详情',28,1,3),(74,'活动配置',1,1,2),(75,'活动配置',74,1,3),(76,'险种导入',1,1,2),(77,'阿宝险种导入',76,1,3);
/*!40000 ALTER TABLE `resource` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-12-26 17:51:53
