-- MySQL dump 10.13  Distrib 5.7.16, for osx10.11 (x86_64)
--
-- Host: 127.0.0.1    Database: cheche_production
-- ------------------------------------------------------
-- Server version	5.7.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` (`id`, `description`, `name`, `type`, `disable`, `level`) VALUES (1,NULL,'出单中心出单员',2,0,0),(2,NULL,'出单中心内勤',2,0,0),(3,'','出单中心管理员',2,0,0),(4,NULL,'出单中心CPS',2,1,0),(5,NULL,'出单中心外勤',2,1,0),(6,NULL,'出单中心修改状态',2,1,0),(7,'','出单中心录单员',2,0,0),(8,'','管理员',2,0,0),(9,'测试专用','test',2,1,0),(10,'','运营经理',2,0,0),(11,'','市场总监',2,0,0),(12,'12月05号：使用玉万账号增加了运营中心添加阿保产品的权限','运营总监',2,0,0),(13,'','战略合作总监',2,0,0),(14,'','业务发展部总监',2,0,0),(15,'','业务发展部城市经理',2,0,0),(16,'电话主管','电话主管',2,0,0),(17,'12月19号 使用玉万账号为电话专员添加了查看预约数据的权限','电话专员',2,0,0),(18,'','中国好车主',2,0,0),(19,'','合作伙伴',2,0,0),(20,'可以查看订单费率并修改','财务',2,0,1),(21,'','定时任务',2,0,0),(22,'','佣金管理',2,0,0),(23,'','出单中心新建客户',2,0,0),(24,'','保险师收单',2,0,0),(25,'12月05 此角色仅提供给电销经理郝明','电销经理',2,0,0);
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-12-26 17:51:53
