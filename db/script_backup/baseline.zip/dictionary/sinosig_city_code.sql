-- MySQL dump 10.13  Distrib 5.7.16, for osx10.11 (x86_64)
--
-- Host: 127.0.0.1    Database: cheche_production
-- ------------------------------------------------------
-- Server version	5.7.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `sinosig_city_code`
--

LOCK TABLES `sinosig_city_code` WRITE;
/*!40000 ALTER TABLE `sinosig_city_code` DISABLE KEYS */;
INSERT INTO `sinosig_city_code` (`id`, `city_plate`, `cont_name`, `pro_plate`, `rank`, `spelling`, `spelling_acronym`, `city`, `province`) VALUES ('01',NULL,'北京',NULL,2,NULL,NULL,NULL,NULL),('01500400','京','朝阳区','京',3,'chaoyangqu','cyq','01682900','01'),('01512800','京','中关村','京',3,'zhongguancun','zgc','01682900','01'),('01522800','京','大兴','京',3,'daxing','dx','01682900','01'),('01542800','京','亦庄','京',3,'yizhuang','yz','01682900','01'),('01552800','京','东城','京',3,'dongcheng','dc','01682900','01'),('01562800','京','通州','京',3,'tongzhou','tz','01682900','01'),('01572800','京','房山','京',3,'fangshan','fs','01682900','01'),('01582800','京','平谷','京',3,'pinggu','pg','01682900','01'),('01592800','京','顺义','京',3,'shunyi','sy','01682900','01'),('01602800','京','延庆','京',3,'yanqing','yq','01682900','01'),('01612800','京','昌平','京',3,'changping','cp','01682900','01'),('01682900','京','北京市','京',3,'BeiJingShi','bjs',NULL,'01'),('02',NULL,'山东',NULL,2,NULL,NULL,NULL,NULL),('03',NULL,'江苏',NULL,2,NULL,NULL,NULL,NULL),('04',NULL,'黑龙江',NULL,2,NULL,NULL,NULL,NULL),('05',NULL,'重庆',NULL,2,NULL,NULL,NULL,NULL),('06',NULL,'河南',NULL,2,NULL,NULL,NULL,NULL),('07',NULL,'上海',NULL,2,NULL,NULL,NULL,NULL),('08',NULL,'广东',NULL,2,NULL,NULL,NULL,NULL),('09',NULL,'深圳',NULL,2,NULL,NULL,NULL,NULL),('10',NULL,'天津',NULL,2,NULL,NULL,NULL,NULL),('11',NULL,'青岛',NULL,2,NULL,NULL,NULL,NULL),('11281000','鲁B','青岛市','BU',3,'qingdaoshi','qds',NULL,'11'),('11402000','鲁B','城阳','鲁B',3,'chengyang','cy','11281000','11'),('11412000','鲁B','李沧','鲁B',3,'licang','lc','11281000','11'),('11422000','鲁B','莱西','鲁B',3,'laixi','lx','11281000','11'),('11434000','鲁B','平度','鲁B',3,'pingdu','pd','11281000','11'),('11513000','鲁B','胶州','鲁B',3,'jiaozhou','jz','11281000','11'),('11522000','鲁B','胶南','鲁B',3,'jiaonan','jn','11281000','11'),('11532000','鲁B','青岛开发区','鲁B',3,'qingdaokaifaqu','qdkfq','11281000','11'),('11540300','鲁B','崂山','鲁B',3,'laoshan','ls','11281000','11'),('11606000','鲁B','即墨','鲁B',3,'jimo','jm','11281000','11'),('11800200','鲁B','四方','鲁B',3,'sifang','sf','11281000','11'),('12',NULL,'辽宁',NULL,2,NULL,NULL,NULL,NULL),('15',NULL,'河北',NULL,2,NULL,NULL,NULL,NULL),('16',NULL,'海南',NULL,2,NULL,NULL,NULL,NULL),('17',NULL,'广西',NULL,2,NULL,NULL,NULL,NULL),('18',NULL,'湖南',NULL,2,NULL,NULL,NULL,NULL),('19',NULL,'浙江',NULL,2,NULL,NULL,NULL,NULL),('20',NULL,'贵州',NULL,2,NULL,NULL,NULL,NULL),('21',NULL,'四川',NULL,2,NULL,NULL,NULL,NULL),('23',NULL,'青海',NULL,2,NULL,NULL,NULL,NULL),('24',NULL,'云南',NULL,2,NULL,NULL,NULL,NULL),('25',NULL,'陕西',NULL,2,NULL,NULL,NULL,NULL),('26',NULL,'湖北',NULL,2,NULL,NULL,NULL,NULL),('27',NULL,'吉林',NULL,2,NULL,NULL,NULL,NULL),('28',NULL,'新疆',NULL,2,NULL,NULL,NULL,NULL),('29',NULL,'宁波',NULL,2,NULL,NULL,NULL,NULL),('30',NULL,'山西',NULL,2,NULL,NULL,NULL,NULL),('31',NULL,'大连',NULL,2,NULL,NULL,NULL,NULL),('32',NULL,'甘肃',NULL,2,NULL,NULL,NULL,NULL),('33',NULL,'安徽',NULL,2,NULL,NULL,NULL,NULL),('34',NULL,'江西',NULL,2,NULL,NULL,NULL,NULL),('35',NULL,'福建',NULL,2,NULL,NULL,NULL,NULL),('36',NULL,'内蒙古',NULL,2,NULL,NULL,NULL,NULL),('37',NULL,'厦门',NULL,2,NULL,NULL,NULL,NULL),('38',NULL,'宁夏',NULL,2,NULL,NULL,NULL,NULL),('39',NULL,'西藏',NULL,2,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `sinosig_city_code` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-12-26 17:51:54
