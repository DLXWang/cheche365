-- MySQL dump 10.13  Distrib 5.7.16, for osx10.11 (x86_64)
--
-- Host: 127.0.0.1    Database: cheche_production
-- ------------------------------------------------------
-- Server version	5.7.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `sql_template`
--

LOCK TABLES `sql_template` WRITE;
/*!40000 ALTER TABLE `sql_template` DISABLE KEYS */;
INSERT INTO `sql_template` (`id`, `name`, `content`) VALUES (1,'全体有手机号的用户','select distinct mobile from user where char_length(mobile) = 11'),(2,'领取指定活动优惠券但未使用用户','select distinct mar.mobile from marketing_success mar right join gift gf on mar.id = gf.source where mar.marketing_id in (${Marketing.Multi}) and gf.source_type = 2 and gf.status = 1 and char_length(mar.mobile) = 11'),(3,'车险即将到期用户','select distinct mobile from (select distinct us.* from appointment_insurance ai, user us where ai.user = us.id and char_length(us.mobile) = 11 and ai.expire_before is not null and ai.expire_before >= now() and datediff(DATE_ADD(now(),INTERVAL 90 DAY), ai.expire_before) >= 0 union select distinct us.* from insurance ins, user us where ins.applicant = us.id and char_length(us.mobile) = 11 and ins.expire_date is not null and ins.expire_date >= now() and datediff(DATE_ADD(now(),INTERVAL 90 DAY), ins.expire_date) >= 0 union select distinct us.* from compulsory_insurance cins, user us where cins.applicant = us.id and char_length(us.mobile) = 11 and cins.expire_date is not null and cins.expire_date >= now() and datediff(DATE_ADD(now(),INTERVAL 90 DAY), cins.expire_date) >= 0) user'),(4,'购买过车险用户','select distinct us.mobile from purchase_order po, user us, payment pay, order_operation_info oop where po.applicant = us.id and po.id = pay.purchase_order and po.id = oop.purchase_order and char_length(us.mobile) = 11 and po.status in (3, 4, 5) and po.channel in (1, 2, 3, 4, 5, 6, 7) and pay.status = 2 and pay.channel in (1, 2, 3, 4, 5, 6, 7) and oop.current_status in (7, 8, 9, 10, 11)'),(5,'参与活动或领取优惠券的用户','select distinct mobile from (select distinct mobile from marketing_success ms where char_length(ms.mobile) = 11 union select distinct us.mobile from gift gift, user us where gift.applicant = us.id and char_length(us.mobile) = 11) tab');
/*!40000 ALTER TABLE `sql_template` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-12-26 17:51:54
