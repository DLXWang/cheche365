-- MySQL dump 10.13  Distrib 5.7.16, for osx10.11 (x86_64)
--
-- Host: 127.0.0.1    Database: cheche_production
-- ------------------------------------------------------
-- Server version	5.7.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `sys_version`
--

LOCK TABLES `sys_version` WRITE;
/*!40000 ALTER TABLE `sys_version` DISABLE KEYS */;
INSERT INTO `sys_version` (`id`, `channel`, `version`, `update_advice`, `reason`) VALUES (1,4,'1.0','option','对于非重要升级，我们将列为可选升级'),(2,4,'1.0.1','option','在攻城狮GG的奋斗下，买车险输入更方便，购买更轻松啦。马上升级看看吧~'),(3,4,'1.0.2','option','更新了部分提供服务的保险公司列表'),(4,4,'1.1.0','option','支持北上广深等城市购买车险；车险未到期的支持预约了，还送大礼包；出险用户支持一键理赔服务。'),(5,4,'1.1.1','option','完美适配iOS 9的车车车险上线啦！更加省时、省心、省钱，还能分享给小伙伴，赶快更新吧！'),(6,4,'1.1.2','option','更流畅的新版本发布啦，赶快升级吧~'),(7,4,'1.6.0','required','有新版本啦！\n投保更便捷、还有更多的优惠等着你！'),(8,6,'1.4.0','required','有新版本啦！\n投保更便捷、还有更多的优惠等着你！'),(9,6,'1.4.1','option','有新版本啦！\n投保更便捷、还有更多的优惠等着你！'),(10,6,'1.4.2','required','有新版本啦！\n投保更便捷、还有更多的优惠等着你！'),(11,6,'1.5.0','required','有新版本啦！\n投保更便捷、还有更多的优惠等着你！'),(13,4,'1.6.2','required','有新版本啦！\n投保更便捷、还有更多的优惠等着你！'),(14,4,'1.6.4','option','有新版本啦！\n投保更便捷、还有更多的优惠等着你！'),(15,6,'1.6.0','required','有新版本啦！\n投保更便捷、还有更多的优惠等着你！'),(16,4,'1.7.0','required','有新版本啦！\n投保更便捷、还有更多的优惠等着你！'),(17,6,'1.6.1','option','有新版本啦！\n投保更便捷、还有更多的优惠等着你！'),(18,4,'1.7.1','option','有新版本啦！\n投保更便捷、还有更多的优惠等着你！');
/*!40000 ALTER TABLE `sys_version` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-12-26 17:51:54
