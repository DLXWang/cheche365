-- MySQL dump 10.13  Distrib 5.7.16, for osx10.11 (x86_64)
--
-- Host: 127.0.0.1    Database: cheche_production
-- ------------------------------------------------------
-- Server version	5.7.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `task_import_marketing_success_data`
--

LOCK TABLES `task_import_marketing_success_data` WRITE;
/*!40000 ALTER TABLE `task_import_marketing_success_data` DISABLE KEYS */;
INSERT INTO `task_import_marketing_success_data` (`id`, `cache_key`, `marketing`, `enable`, `priority`, `source`, `channel`) VALUES (1,'task.tel.alipay.autotax.previous.time',38,1,1,112,10),(2,'schedules.task.tel.alipay.autotax.201604002.previous.time',49,1,1,92,10),(3,'schedules.task.tel.baidu.autotax.previous.time',39,1,1,116,15),(4,'schedules.task.tel.autohome.fulldiscount.previous.time',43,1,1,119,13),(5,'schedules.task.tel.beijing.exclusive.use.201605003.previous.time',51,1,1,131,9),(6,'schedules.task.tel.shenzhen.exclusive.use.201605006.previous.time',53,1,1,133,9),(7,'schedules.task.tel.hangzhou.exclusive.use.201605007.previous.time',54,1,1,134,9),(8,'schedules.task.tel.tuhu.direct.discount.previous.time',59,1,1,135,203),(9,'schedules.task.tel.beijing.exclusive.use.201606003.previous.time',61,1,1,136,9),(10,'schedules.task.tel.pingan.exclusive.use.201606004.previous.time',62,1,1,137,9),(11,'schedules.task.tel.autohome.exclusive.use.201606007.previous.time',65,1,1,138,13),(12,'schedules.task.tel.201606005.previous.time',63,1,1,139,9),(13,'schedules.task.tel.201606006.previous.time',64,1,1,140,9),(14,'schedules.task.tel.201607001.previous.time',68,1,1,142,203),(15,'schedules.task.tel.201607002.previous.time',67,1,1,143,9),(16,'schedules.task.tel.201611001.previous.time',71,1,1,146,9),(17,'schedules.task.tel.201612001.previous.time',73,1,1,149,27);
/*!40000 ALTER TABLE `task_import_marketing_success_data` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-12-26 17:51:54
