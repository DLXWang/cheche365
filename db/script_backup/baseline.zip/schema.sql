-- MySQL dump 10.13  Distrib 5.7.16, for osx10.11 (x86_64)
--
-- Host: 127.0.0.1    Database: cheche_production
-- ------------------------------------------------------
-- Server version	5.7.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `access_log`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `access_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `remote_addr` varchar(45) DEFAULT NULL,
  `request_time` datetime DEFAULT NULL,
  `request_type` varchar(10) DEFAULT NULL,
  `url` varchar(500) DEFAULT NULL,
  `auto` bigint(20) DEFAULT NULL,
  `user` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_ACCESS_LOG_REF_AUTO` (`auto`),
  KEY `FK_ACCESS_LOG_REF_USER` (`user`),
  KEY `idx_access_log` (`user`,`auto`),
  CONSTRAINT `FK_ACCESS_LOG_REF_AUTO` FOREIGN KEY (`auto`) REFERENCES `auto` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_ACCESS_LOG_REF_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=7051664 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `access_statistics`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `access_statistics` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `access_count` int(11) DEFAULT NULL,
  `application_instance_id` varchar(100) DEFAULT NULL,
  `duration` int(11) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `function` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_ACCESS_STATISTICS_REF_FUNCTION` (`function`),
  CONSTRAINT `FK_ACCESS_STATISTICS_REF_FUNCTION` FOREIGN KEY (`function`) REFERENCES `function` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `accident_type`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accident_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `activity_area`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activity_area` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `business_activity` bigint(20) DEFAULT NULL COMMENT '商务活动',
  `area` bigint(20) DEFAULT NULL COMMENT '城市',
  PRIMARY KEY (`id`),
  KEY `FK_ACTIVITY_AREA_REF_BUSINESS_ACTIVITY` (`business_activity`),
  KEY `FK_ACTIVITY_AREA_REF_AREA` (`area`),
  CONSTRAINT `FK_ACTIVITY_AREA_REF_AREA` FOREIGN KEY (`area`) REFERENCES `area` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_ACTIVITY_AREA_REF_BUSINESS_ACTIVITY` FOREIGN KEY (`business_activity`) REFERENCES `business_activity` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=10590 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `activity_monitor_data`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activity_monitor_data` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `business_activity` bigint(20) DEFAULT NULL COMMENT '商务活动',
  `monitor_time` datetime DEFAULT NULL COMMENT '监控时间',
  `area` bigint(20) DEFAULT NULL COMMENT '城市',
  `pv` int(8) DEFAULT NULL COMMENT 'PV',
  `uv` int(8) DEFAULT NULL COMMENT 'UV',
  `register` int(8) DEFAULT NULL COMMENT '注册',
  `quote` int(8) DEFAULT NULL COMMENT '试算',
  `submit_count` int(8) DEFAULT NULL COMMENT '提交订单数',
  `submit_amount` decimal(18,2) DEFAULT NULL COMMENT '提交订单总额',
  `payment_count` int(8) DEFAULT NULL COMMENT '支付订单数',
  `payment_amount` decimal(18,2) DEFAULT NULL COMMENT '支付订单总额',
  `special_monitor` int(8) DEFAULT NULL COMMENT '特殊监控',
  `customer_field1` decimal(18,2) DEFAULT NULL COMMENT '自定义字段1值',
  `customer_field2` decimal(18,2) DEFAULT NULL COMMENT '自定义字段2值',
  `customer_field3` decimal(18,2) DEFAULT NULL COMMENT '自定义字段3值',
  `customer_field4` decimal(18,2) DEFAULT NULL COMMENT '自定义字段4值',
  `customer_field5` decimal(18,2) DEFAULT NULL COMMENT '自定义字段5值',
  `no_auto_tax_amount` decimal(18,2) DEFAULT NULL COMMENT '不包含车船税金额',
  PRIMARY KEY (`id`),
  KEY `FK_ACTIVITY_MONITOR_DATA_REF_BUSINESS_ACTIVITY` (`business_activity`),
  KEY `FK_ACTIVITY_MONITOR_DATA_REF_AREA` (`area`),
  KEY `idx_activity_monitor_data_time_area` (`business_activity`,`monitor_time`,`area`),
  CONSTRAINT `FK_ACTIVITY_MONITOR_DATA_REF_AREA` FOREIGN KEY (`area`) REFERENCES `area` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_ACTIVITY_MONITOR_DATA_REF_BUSINESS_ACTIVITY` FOREIGN KEY (`business_activity`) REFERENCES `business_activity` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=179972 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `activity_payment_channel`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activity_payment_channel` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `business_activity` bigint(20) DEFAULT NULL,
  `payment_channel` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_ACTIVITY_PAYMENT_CHANNEL_REF_BUSINESS_ACTIVITY` (`business_activity`),
  KEY `FK_ACTIVITY_PAYMENT_CHANNEL_REF_PAYMENT_CHANNEL` (`payment_channel`),
  CONSTRAINT `FK_ACTIVITY_PAYMENT_CHANNEL_REF_BUSINESS_ACTIVITY` FOREIGN KEY (`business_activity`) REFERENCES `business_activity` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_ACTIVITY_PAYMENT_CHANNEL_REF_PAYMENT_CHANNEL` FOREIGN KEY (`payment_channel`) REFERENCES `payment_channel` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=364 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `activity_type`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activity_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `address`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `address` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `city` varchar(45) DEFAULT NULL,
  `district` varchar(45) DEFAULT NULL,
  `mobile` varchar(45) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  `postalcode` varchar(6) DEFAULT NULL,
  `province` varchar(45) DEFAULT NULL,
  `street` varchar(400) DEFAULT NULL,
  `telephone` varchar(45) DEFAULT NULL,
  `applicant` bigint(20) DEFAULT NULL,
  `area` bigint(20) DEFAULT NULL,
  `disable` tinyint(1) DEFAULT '0',
  `default_address` tinyint(1) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_ADDRESS_REF_USER` (`applicant`),
  KEY `FK_ADDRESS_REF_AREA` (`area`),
  CONSTRAINT `FK_ADDRESS_REF_AREA` FOREIGN KEY (`area`) REFERENCES `area` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_ADDRESS_REF_USER` FOREIGN KEY (`applicant`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=61192 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `adhoc_message`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adhoc_message` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `mobile` varchar(11) DEFAULT NULL COMMENT '用户手机号',
  `filter_user` bigint(20) DEFAULT NULL COMMENT '筛选用户',
  `sms_template` bigint(20) DEFAULT NULL COMMENT '短信模板',
  `parameter` varchar(1000) DEFAULT NULL COMMENT '短信内容参数',
  `send_flag` tinyint(1) DEFAULT NULL COMMENT '发送短信类型，0-立即发送，1-定时发送',
  `send_time` datetime DEFAULT NULL COMMENT '发送短信时间',
  `status` bigint(20) DEFAULT NULL COMMENT '发送状态',
  `comment` varchar(200) DEFAULT NULL COMMENT '备注',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  `operator` bigint(20) DEFAULT NULL COMMENT '操作人',
  `sent_count` int(10) DEFAULT NULL COMMENT '已发送短信数量',
  `total_count` int(10) DEFAULT NULL COMMENT '总发送短信数量',
  PRIMARY KEY (`id`),
  KEY `FK_ADHOC_MESSAGE_REF_FILTER_USER` (`filter_user`),
  KEY `FK_ADHOC_MESSAGE_REF_SMS_TEMPLATE` (`sms_template`),
  KEY `FK_ADHOC_MESSAGE_REF_MESSAGE_STATUS` (`status`),
  KEY `FK_ADHOC_MESSAGE_REF_OPERATOR` (`operator`),
  CONSTRAINT `FK_ADHOC_MESSAGE_REF_FILTER_USER` FOREIGN KEY (`filter_user`) REFERENCES `filter_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_ADHOC_MESSAGE_REF_MESSAGE_STATUS` FOREIGN KEY (`status`) REFERENCES `message_status` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_ADHOC_MESSAGE_REF_OPERATOR` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_ADHOC_MESSAGE_REF_SMS_TEMPLATE` FOREIGN KEY (`sms_template`) REFERENCES `sms_template` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=8001 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agent`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agent` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `mobile` varchar(45) DEFAULT NULL,
  `identity` varchar(45) DEFAULT NULL,
  `identity_type` bigint(20) DEFAULT NULL,
  `user` bigint(20) DEFAULT NULL,
  `card_number` varchar(45) DEFAULT NULL,
  `opening_bank` varchar(200) DEFAULT NULL,
  `bank_account` varchar(45) DEFAULT NULL,
  `comment` varchar(2000) DEFAULT NULL,
  `agent_company` bigint(20) DEFAULT NULL,
  `parent_agent` bigint(20) DEFAULT NULL,
  `bank_branch` varchar(45) DEFAULT NULL,
  `operator` bigint(20) DEFAULT NULL,
  `rebate` decimal(18,2) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `enable` tinyint(1) DEFAULT '0' COMMENT '是否有效',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_agent_mobile` (`mobile`),
  KEY `FK_AGNET_REF_AGENT_COMPANY` (`agent_company`),
  KEY `FK_AGENT_REF_INTERNAL_USER` (`operator`),
  CONSTRAINT `FK_AGENT_REF_INTERNAL_USER` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_AGNET_REF_AGENT_COMPANY` FOREIGN KEY (`agent_company`) REFERENCES `agent_company` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=824 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agent_company`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agent_company` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `comment` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agent_rebate`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agent_rebate` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `area` bigint(20) NOT NULL,
  `insurance_company` bigint(20) NOT NULL,
  `agent` bigint(20) NOT NULL,
  `commercial_rebate` decimal(18,2) DEFAULT NULL,
  `compulsory_rebate` decimal(18,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_AGENT_REBATE_REF_AREA` (`area`),
  KEY `FK_AGENT_REBATE_REF_INSURANCE_COMPANY` (`insurance_company`),
  KEY `FK_AGENT_REBATE_REF_AGENT` (`agent`),
  CONSTRAINT `FK_AGENT_REBATE_REF_AGENT` FOREIGN KEY (`agent`) REFERENCES `agent` (`id`),
  CONSTRAINT `FK_AGENT_REBATE_REF_AREA` FOREIGN KEY (`area`) REFERENCES `area` (`id`),
  CONSTRAINT `FK_AGENT_REBATE_REF_INSURANCE_COMPANY` FOREIGN KEY (`insurance_company`) REFERENCES `insurance_company` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agent_rebate_history`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agent_rebate_history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `agent` bigint(20) NOT NULL,
  `area` bigint(20) NOT NULL,
  `insurance_company` bigint(20) NOT NULL,
  `commercial_rebate` decimal(18,2) NOT NULL,
  `compulsory_rebate` decimal(18,2) NOT NULL,
  `operation` tinyint(1) NOT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime DEFAULT NULL,
  `operator` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_AGENT_REBATE_HISTORY_REF_AGENT` (`agent`),
  KEY `FK_AGENT_REBATE_HISTORY_REF_AREA` (`area`),
  KEY `FK_AGENT_REBATE_HISTORY_REF_INSURANCE_COMPANY` (`insurance_company`),
  KEY `FK_AGENT_REBATE_HISTORY_REF_INTERNAL_USER` (`operator`),
  CONSTRAINT `FK_AGENT_REBATE_HISTORY_REF_AGENT` FOREIGN KEY (`agent`) REFERENCES `agent` (`id`),
  CONSTRAINT `FK_AGENT_REBATE_HISTORY_REF_AREA` FOREIGN KEY (`area`) REFERENCES `area` (`id`),
  CONSTRAINT `FK_AGENT_REBATE_HISTORY_REF_INSURANCE_COMPANY` FOREIGN KEY (`insurance_company`) REFERENCES `insurance_company` (`id`),
  CONSTRAINT `FK_AGENT_REBATE_HISTORY_REF_INTERNAL_USER` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=170 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alipay_user_info`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alipay_user_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user` bigint(20) NOT NULL,
  `open_id` varchar(100) DEFAULT NULL,
  `create_time` date DEFAULT NULL COMMENT '创建时间',
  `user_type_value` varchar(6) DEFAULT NULL COMMENT '用户类型（1/2）。1代表公司账户；2代表个人账户',
  `user_status` varchar(6) DEFAULT NULL COMMENT '用户状态。Q代表快速注册用户;T代表已认证用户;B代表被冻结账户;W代表已注册，未激活的账户;',
  `firm_name` varchar(200) DEFAULT NULL COMMENT '公司名称（用户类型是公司类型时，才有此字段）',
  `real_name` varchar(200) DEFAULT NULL COMMENT '用户的真实姓名',
  `avatar` varchar(200) DEFAULT NULL COMMENT '用户头像',
  `cert_no` varchar(100) DEFAULT NULL COMMENT '证件号码',
  `gender` varchar(6) DEFAULT NULL COMMENT '性别（F：女性；M：男性）',
  `phone` varchar(50) DEFAULT NULL COMMENT '电话号码',
  `mobile` varchar(50) DEFAULT NULL COMMENT '手机号码',
  `is_certified` varchar(6) DEFAULT NULL COMMENT '是否通过实名认证。T是通过；F是没有实名认证',
  `is_student_certified` varchar(6) DEFAULT NULL COMMENT '是否是学生。T表示是学生；F表示不是学生',
  `is_bank_auth` varchar(6) DEFAULT NULL COMMENT 'T为是银行卡认证，F为非银行卡认证',
  `is_id_auth` varchar(6) DEFAULT NULL COMMENT 'T为是身份证认证，F为非身份证认证',
  `is_mobile_auth` varchar(6) DEFAULT NULL COMMENT 'T为是手机认证，F为非手机认证',
  `is_licence_auth` varchar(6) DEFAULT NULL COMMENT 'T为通过营业执照认证，F为没有通过',
  `cert_type_value` varchar(6) DEFAULT NULL COMMENT '0：身份证；1：护照；2：军官证；3：士兵证；4：回乡证；5：临时身份证；6：户口簿；7：警官证；8：台胞证；9：营业执照；10：其它证件',
  `province` varchar(50) DEFAULT NULL COMMENT '省份名称',
  `city` varchar(50) DEFAULT NULL COMMENT '市名称',
  `area` varchar(50) DEFAULT NULL COMMENT '区县名称',
  `address` varchar(500) DEFAULT NULL COMMENT '详细地址',
  `zip` varchar(50) DEFAULT NULL COMMENT '邮政编码',
  `address_code` varchar(6) DEFAULT NULL COMMENT '区域编码，暂时不返回值',
  `follow` tinyint(4) DEFAULT NULL COMMENT '是否关注',
  `follow_time` date DEFAULT NULL COMMENT '关注时间',
  `un_follow_time` date DEFAULT NULL COMMENT '取消关注时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_u_open_id` (`open_id`),
  KEY `id` (`id`),
  KEY `pk_user_id` (`user`),
  CONSTRAINT `pk_user_id` FOREIGN KEY (`user`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=943406 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `amend_reason`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `amend_reason` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(2000) DEFAULT NULL,
  `reason` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `api_partner`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `api_partner` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `code` varchar(1024) DEFAULT NULL,
  `app_id` varchar(100) DEFAULT NULL,
  `app_secret` varchar(2048) DEFAULT NULL,
  `single_company` smallint(1) DEFAULT NULL,
  `is_sync` tinyint(1) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `appid_mapping`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appid_mapping` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `appid` varchar(1024) DEFAULT NULL COMMENT 'appid',
  `mchid` varchar(1024) DEFAULT NULL COMMENT '合作伙伴id',
  `ios_cer_file` varchar(1024) DEFAULT NULL COMMENT 'ios 证书路径',
  `ios_cer_pwd` varchar(1024) DEFAULT NULL COMMENT 'ios 证书密码',
  `user_appid` varchar(512) DEFAULT NULL COMMENT 'userappid',
  `dev_ios_cer_file` varchar(512) DEFAULT NULL COMMENT ' dev ios cer file ',
  `dev_ios_cer_pwd` varchar(512) DEFAULT NULL COMMENT ' dev ios cer file pwd ',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `application_log`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `application_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_time` datetime DEFAULT NULL,
  `instance_no` varchar(45) DEFAULT NULL,
  `log_id` varchar(45) DEFAULT NULL,
  `log_level` tinyint(1) DEFAULT NULL,
  `log_message` text,
  `log_type` bigint(20) DEFAULT NULL,
  `obj_id` varchar(45) DEFAULT NULL,
  `obj_table` varchar(45) DEFAULT NULL,
  `operator` bigint(20) DEFAULT NULL,
  `user` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_APPLICATION_LOG_REF_INTERNAL_USER` (`operator`),
  KEY `FK_APPLICATION_LOG_REF_USER` (`user`),
  KEY `idx_application_log_user` (`user`),
  KEY `idx_application_log_objid` (`obj_id`),
  KEY `FK_APPLICATION_LOG_REF_LOG_TYPE` (`log_type`),
  CONSTRAINT `FK_APPLICATION_LOG_REF_INTERNAL_USER` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_APPLICATION_LOG_REF_LOG_TYPE` FOREIGN KEY (`log_type`) REFERENCES `log_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_APPLICATION_LOG_REF_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=1086737 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `appointment_insurance`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appointment_insurance` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user` bigint(20) NOT NULL,
  `license_plate_no` varchar(45) NOT NULL,
  `expire_before` datetime NOT NULL,
  `contact` varchar(45) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `status` tinyint(1) DEFAULT '1',
  `comment` varchar(2000) DEFAULT NULL,
  `source_channel` bigint(20) DEFAULT NULL,
  `source` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK_APPOINTMENT_INSURANCE_REF_USER` (`user`),
  KEY `FK_APPOINTMENT_INSURANCE_REF_CHANNEL_IDX` (`source_channel`),
  KEY `idx_appointment_insurance_create_time` (`create_time`),
  CONSTRAINT `FK_APPOINTMENT_INSURANCE_REF_CHANNEL_IDX` FOREIGN KEY (`source_channel`) REFERENCES `channel` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_APPOINTMENT_INSURANCE_REF_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=45473 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `area`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `area` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `type` bigint(20) DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL,
  `short_code` varchar(100) DEFAULT '',
  `city_code` int(11) DEFAULT NULL COMMENT '对应百度ip地址库里面的城市编码字段',
  `postal_code` varchar(10) DEFAULT NULL,
  `reform` tinyint(1) DEFAULT '0' COMMENT '是否费改',
  PRIMARY KEY (`id`),
  KEY `FK_AREA_REF_AREA_TYPE` (`type`),
  KEY `idx_active` (`active`),
  CONSTRAINT `FK_AREA_REF_AREA_TYPE` FOREIGN KEY (`type`) REFERENCES `area_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=820001 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `area_contact_info`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `area_contact_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `area` bigint(20) DEFAULT NULL COMMENT '城市',
  `name` varchar(20) DEFAULT NULL COMMENT '负责人姓名',
  `mobile` varchar(20) DEFAULT NULL COMMENT '负责人手机号',
  `email` varchar(45) DEFAULT NULL COMMENT '负责人邮箱',
  `qq` varchar(20) DEFAULT NULL COMMENT '负责人QQ',
  `province` bigint(20) DEFAULT NULL COMMENT '省份',
  `city` bigint(20) DEFAULT NULL COMMENT '城市',
  `district` bigint(20) DEFAULT NULL COMMENT '区县',
  `street` varchar(100) DEFAULT NULL COMMENT '街道',
  `comment` varchar(200) DEFAULT NULL COMMENT '备注',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  `operator` bigint(20) DEFAULT NULL COMMENT '操作人',
  PRIMARY KEY (`id`),
  KEY `FK_AREA_CONTACT_INFO_REF_AREA` (`area`),
  KEY `FK_AREA_CONTACT_INFO_REF_PROVINCE` (`province`),
  KEY `FK_AREA_CONTACT_INFO_REF_CITY` (`city`),
  KEY `FK_AREA_CONTACT_INFO_REF_DISTRICT` (`district`),
  KEY `FK_AREA_CONTACT_INFO_REF_OPERATOR` (`operator`),
  CONSTRAINT `FK_AREA_CONTACT_INFO_REF_AREA` FOREIGN KEY (`area`) REFERENCES `area` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_AREA_CONTACT_INFO_REF_CITY` FOREIGN KEY (`city`) REFERENCES `area` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_AREA_CONTACT_INFO_REF_DISTRICT` FOREIGN KEY (`district`) REFERENCES `area` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_AREA_CONTACT_INFO_REF_OPERATOR` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_AREA_CONTACT_INFO_REF_PROVINCE` FOREIGN KEY (`province`) REFERENCES `area` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `area_insurance_time_limit`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `area_insurance_time_limit` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `area` bigint(20) NOT NULL,
  `days` int(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_AREA_INSURANCE_TIME_LIMIT_REF_AREA` (`area`) USING BTREE,
  CONSTRAINT `area_insurance_time_limit_ibfk_1` FOREIGN KEY (`area`) REFERENCES `area` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `area_type`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `area_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(2000) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `arithmetic_operator`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `arithmetic_operator` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL COMMENT '运算符名称',
  `description` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `article`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `article` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(400) DEFAULT NULL,
  `content` varchar(4000) DEFAULT NULL,
  `url` varchar(200) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `weight` int(11) DEFAULT '1',
  `enable` tinyint(1) DEFAULT '1',
  `article_type` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `auto`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auto` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `engine_no` varchar(45) DEFAULT NULL,
  `enroll_date` date DEFAULT NULL,
  `kilometer_per_year` bigint(20) DEFAULT NULL,
  `license_color_code` varchar(10) DEFAULT NULL,
  `license_plate_no` varchar(45) DEFAULT NULL,
  `license_type` varchar(10) DEFAULT NULL,
  `owner` varchar(45) DEFAULT NULL,
  `vin_no` varchar(45) DEFAULT NULL,
  `area` bigint(20) DEFAULT NULL,
  `auto_type` bigint(20) DEFAULT NULL,
  `identity` varchar(45) DEFAULT NULL,
  `identity_type` bigint(20) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `disable` tinyint(1) DEFAULT '0',
  `bill_related` tinyint(1) DEFAULT '0',
  `insured_id_no` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_AUTO_REF_AREA` (`area`),
  KEY `FK_AUTO_REF_AUTO_TYPE` (`auto_type`),
  KEY `FK_AUTO_REF_IDENTITY` (`identity`),
  KEY `FK_AUTO_REF_IDENTITY_TYPE` (`identity_type`),
  KEY `idx_u_auto_licenseno` (`license_plate_no`),
  CONSTRAINT `FK_AUTO_REF_AREA` FOREIGN KEY (`area`) REFERENCES `area` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_AUTO_REF_AUTO_TYPE` FOREIGN KEY (`auto_type`) REFERENCES `auto_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_AUTO_REF_IDENTITY_TYPE` FOREIGN KEY (`identity_type`) REFERENCES `identity_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=604738 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `auto_service_type`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auto_service_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `auto_shop`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auto_shop` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `address` bigint(20) NOT NULL,
  `description` varchar(2000) DEFAULT NULL,
  `longitude` decimal(18,10) DEFAULT NULL,
  `latitude` decimal(18,10) DEFAULT NULL,
  `altitude` decimal(18,10) DEFAULT NULL,
  `contact_person_mobile` varchar(45) DEFAULT NULL,
  `contact_person` varchar(45) DEFAULT NULL,
  `contact_person_phone` varchar(45) DEFAULT NULL,
  `logo` varchar(300) DEFAULT NULL,
  `star` decimal(18,6) DEFAULT NULL,
  `brands` varchar(300) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `disabled` tinyint(1) DEFAULT '0',
  `comments` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_AUTO_SHOP_REF_ADDRESS` (`address`),
  KEY `idx_auto_shop_brands` (`brands`(255)),
  CONSTRAINT `FK_AUTO_SHOP_REF_ADDRESS` FOREIGN KEY (`address`) REFERENCES `auto_shop_address` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `auto_shop_address`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auto_shop_address` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `city` varchar(45) DEFAULT NULL,
  `district` varchar(45) DEFAULT NULL,
  `mobile` varchar(45) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  `postalcode` varchar(6) DEFAULT NULL,
  `province` varchar(45) DEFAULT NULL,
  `street` varchar(400) DEFAULT NULL,
  `telephone` varchar(45) DEFAULT NULL,
  `area` bigint(20) DEFAULT NULL,
  `disable` tinyint(1) DEFAULT '0',
  `address_detail` varchar(400) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_AUTO_SHOP_ADDRESS_REF_AREA` (`area`),
  CONSTRAINT `FK_AUTO_SHOP_ADDRESS_REF_AREA` FOREIGN KEY (`area`) REFERENCES `area` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `auto_shop_brand`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auto_shop_brand` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `auto_shop` bigint(20) NOT NULL,
  `name` varchar(100) COLLATE utf8_bin NOT NULL,
  `img_url` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_AUTO_SHOP_BRAND_REF_AUTO_SHOP` (`auto_shop`),
  CONSTRAINT `FK_AUTO_SHOP_BRAND_REF_AUTO_SHOP` FOREIGN KEY (`auto_shop`) REFERENCES `auto_shop` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `auto_shop_insurance_company`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auto_shop_insurance_company` (
  `auto_shop` bigint(20) NOT NULL,
  `insurance_company` bigint(20) NOT NULL,
  PRIMARY KEY (`auto_shop`,`insurance_company`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `auto_shop_picture`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auto_shop_picture` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `auto_shop` bigint(20) DEFAULT NULL,
  `url` varchar(300) DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  `original_name` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_AUTO_SHOP_PICTURE_REF_AUTO_SHOP` (`auto_shop`),
  CONSTRAINT `FK_AUTO_SHOP_PICTURE_REF_AUTO_SHOP` FOREIGN KEY (`auto_shop`) REFERENCES `auto_shop` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `auto_shop_service_item`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auto_shop_service_item` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `auto_shop` bigint(20) NOT NULL,
  `name` varchar(100) COLLATE utf8_bin NOT NULL,
  `img_url` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `disable` tinyint(1) DEFAULT '0',
  `service_kind` tinyint(1) DEFAULT '1' COMMENT '1:基本服务.2:特色服务',
  PRIMARY KEY (`id`),
  KEY `FK_AUTO_SHOP_SERVICE_ITEM_REF_AUTO_SHOP` (`auto_shop`),
  CONSTRAINT `FK_AUTO_SHOP_SERVICE_ITEM_REF_AUTO_SHOP` FOREIGN KEY (`auto_shop`) REFERENCES `auto_shop` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `auto_type`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auto_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `brand` varchar(45) DEFAULT NULL,
  `code` varchar(45) DEFAULT NULL,
  `current_price` decimal(18,2) DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  `exhaust_scale` varchar(10) DEFAULT NULL,
  `family` varchar(60) DEFAULT NULL,
  `auto_group` varchar(120) DEFAULT NULL,
  `manufacturer` varchar(45) DEFAULT NULL,
  `model` varchar(120) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  `new_price` decimal(18,2) DEFAULT NULL,
  `seats` tinyint(3) DEFAULT NULL,
  `logo` varchar(200) DEFAULT NULL,
  `brand_logo` varchar(45) DEFAULT NULL COMMENT '品牌logo文件名',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=129918 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `auto_vehicle_license_service_item`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auto_vehicle_license_service_item` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `service_name` varchar(50) NOT NULL,
  `priority` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `auto_vehicle_license_service_item_channel`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auto_vehicle_license_service_item_channel` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `channel` bigint(20) NOT NULL,
  `auto_service_type` bigint(20) NOT NULL,
  `auto_vehicle_license_service_item` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `auto_vehicle_license_service_channel_ibfk_1` (`channel`),
  KEY `auto_vehicle_license_service_channel_ibfk_2` (`auto_vehicle_license_service_item`),
  KEY `auto_vehicle_license_service_channel_ibfk_3` (`auto_service_type`),
  CONSTRAINT `auto_vehicle_license_service_channel_ibfk_1` FOREIGN KEY (`channel`) REFERENCES `channel` (`id`),
  CONSTRAINT `auto_vehicle_license_service_channel_ibfk_2` FOREIGN KEY (`auto_vehicle_license_service_item`) REFERENCES `auto_vehicle_license_service_item` (`id`),
  CONSTRAINT `auto_vehicle_license_service_channel_ibfk_3` FOREIGN KEY (`auto_service_type`) REFERENCES `auto_service_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `autohome_auto_type`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `autohome_auto_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `brand` bigint(20) NOT NULL,
  `family` bigint(20) NOT NULL,
  `code` varchar(45) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  `current_price` decimal(18,2) DEFAULT NULL,
  `new_price` decimal(18,2) DEFAULT NULL,
  `exhaust_scale` varchar(10) DEFAULT NULL,
  `manufacturer` varchar(45) DEFAULT NULL,
  `model` varchar(120) DEFAULT NULL,
  `seats` tinyint(3) DEFAULT NULL,
  `engine` varchar(45) DEFAULT NULL,
  `year` varchar(10) DEFAULT NULL,
  `status` char(1) DEFAULT NULL,
  `logo` varchar(100) DEFAULT NULL,
  `logo_hash` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_AH_AUTO_TYPE_REF_AH_BRAND` (`brand`),
  KEY `FK_AH_AUTO_TYPE_REF_AH_FAMILY` (`family`),
  KEY `idx_autohome_auto_type_name` (`name`),
  CONSTRAINT `FK_AH_AUTO_TYPE_REF_AH_BRAND` FOREIGN KEY (`brand`) REFERENCES `autohome_brand` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_AH_AUTO_TYPE_REF_AH_FAMILY` FOREIGN KEY (`family`) REFERENCES `autohome_family` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=18385 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `autohome_brand`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `autohome_brand` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `logo` varchar(100) DEFAULT NULL,
  `logo_hash` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_autohome_brand_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=153 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `autohome_family`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `autohome_family` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `brand` bigint(20) NOT NULL,
  `manufacturer` varchar(45) DEFAULT NULL,
  `logo` varchar(100) DEFAULT NULL,
  `logo_hash` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_AH_FAMILY_REF_AH_BRAND` (`brand`),
  KEY `idx_autohome_family_name` (`name`),
  CONSTRAINT `FK_AH_FAMILY_REF_AH_BRAND` FOREIGN KEY (`brand`) REFERENCES `autohome_brand` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=1289 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `baidu_syn_user_auto`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `baidu_syn_user_auto` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user` bigint(20) DEFAULT NULL,
  `auto` bigint(20) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `syn` int(11) DEFAULT NULL,
  `company` bigint(20) DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_USER_AUTO_REF_USER_BAIDU_SYN` (`user`),
  KEY `FK_USER_AUTO_REF_AUTO_BAIDU_SYN` (`auto`),
  KEY `idx_on_syn` (`syn`),
  KEY `FK_BAIDU_USERAUTO_REF_INSURANCE_COMPANY` (`company`),
  CONSTRAINT `FK_BAIDU_USERAUTO_REF_INSURANCE_COMPANY` FOREIGN KEY (`company`) REFERENCES `insurance_company` (`id`),
  CONSTRAINT `FK_USER_AUTO_REF_AUTO_BAIDU_SYN` FOREIGN KEY (`auto`) REFERENCES `auto` (`id`),
  CONSTRAINT `FK_USER_AUTO_REF_USER_BAIDU_SYN` FOREIGN KEY (`user`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13524 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `base_banner_resource`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `base_banner_resource` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `marketing_id` bigint(20) DEFAULT NULL,
  `insurance_company_id` bigint(20) DEFAULT NULL,
  `channel_id` bigint(20) DEFAULT NULL,
  `area_id` bigint(20) DEFAULT NULL,
  `company_logo` varchar(200) DEFAULT NULL,
  `figure` varchar(200) DEFAULT NULL,
  `banner` varchar(200) DEFAULT NULL,
  `title` varchar(200) DEFAULT NULL,
  `sub_title` varchar(200) DEFAULT NULL,
  `action` varchar(200) DEFAULT NULL,
  `pop_img` varchar(200) DEFAULT NULL,
  `link_url` varchar(200) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `resource_url` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_BASE_BANNER_RESOURCE_REF_MARKETING` (`marketing_id`),
  KEY `FK_BASE_BANNER_RESOURCE_REF_INSURANCE_COMPANY` (`insurance_company_id`),
  KEY `FK_BASE_BANNER_RESOURCE_REF_CHANNEL` (`channel_id`),
  KEY `FK_BASE_BANNER_RESOURCE_REF_AREA` (`area_id`),
  CONSTRAINT `FK_BASE_BANNER_RESOURCE_REF_AREA` FOREIGN KEY (`area_id`) REFERENCES `area` (`id`),
  CONSTRAINT `FK_BASE_BANNER_RESOURCE_REF_CHANNEL` FOREIGN KEY (`channel_id`) REFERENCES `channel` (`id`),
  CONSTRAINT `FK_BASE_BANNER_RESOURCE_REF_INSURANCE_COMPOANY` FOREIGN KEY (`insurance_company_id`) REFERENCES `insurance_company` (`id`),
  CONSTRAINT `FK_BASE_BANNER_RESOURCE_REF_MARKETING` FOREIGN KEY (`marketing_id`) REFERENCES `marketing` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=120 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bespeak_quote`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bespeak_quote` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `license_plate_no` varchar(45) DEFAULT NULL,
  `expire_date` date DEFAULT NULL,
  `user_true_name` varchar(45) DEFAULT NULL,
  `user_mobile` varchar(45) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `business_activity`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `business_activity` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL COMMENT '商务活动名称',
  `code` varchar(45) DEFAULT NULL COMMENT '商务活动编号',
  `partner` bigint(20) DEFAULT NULL COMMENT '合作商',
  `cooperation_mode` bigint(20) DEFAULT NULL COMMENT '合作方式',
  `rebate` decimal(18,2) DEFAULT NULL COMMENT '佣金',
  `budget` decimal(18,2) DEFAULT NULL COMMENT '预算',
  `start_time` datetime DEFAULT NULL COMMENT '活动开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '活动结束时间',
  `landing_page` varchar(100) DEFAULT NULL COMMENT '落地页',
  `comment` varchar(2000) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `operator` bigint(20) DEFAULT NULL COMMENT '操作人',
  `refresh_time` datetime DEFAULT NULL,
  `refresh_flag` tinyint(1) DEFAULT '1' COMMENT '数据更新标记',
  `link_man` varchar(45) DEFAULT NULL COMMENT '联系人',
  `mobile` varchar(45) DEFAULT NULL COMMENT '联系人手机号',
  `email` varchar(200) DEFAULT NULL,
  `frequency` tinyint(1) DEFAULT '1' COMMENT '发送频率',
  `enable` tinyint(1) DEFAULT '0' COMMENT '是否使用优惠券',
  `display` tinyint(1) DEFAULT '0' COMMENT '是否显示回到首页、我的等按钮',
  `home` tinyint(1) DEFAULT '1' COMMENT '是否可以回到首页',
  `footer` tinyint(1) DEFAULT '0' COMMENT '是否显示底部公司标识',
  `mine` tinyint(1) DEFAULT '1' COMMENT '是否可以显示我的',
  `btn` tinyint(1) DEFAULT '1' COMMENT '成功提交订单后是否显示按钮',
  `app` tinyint(1) DEFAULT '0' COMMENT '成功提交订单后是否显示公司微信二维码',
  `obj_table` varchar(45) DEFAULT NULL COMMENT '对象表名',
  `obj_id` varchar(45) DEFAULT NULL COMMENT '对象id',
  `landing_page_type` tinyint(1) DEFAULT NULL COMMENT '落地页类型，1-M站首页；2-M站购买页；3-M端活动页；4-PC端活动页',
  `top_brand` tinyint(1) DEFAULT '1' COMMENT '车车顶部品牌（涉及品牌）',
  `my_center` tinyint(1) DEFAULT '1' COMMENT '我的中心',
  `top_carousel` tinyint(1) DEFAULT '1' COMMENT '顶部轮播图（涉及品牌）',
  `activity_entry` tinyint(1) DEFAULT '1' COMMENT '活动入口',
  `our_customer` tinyint(1) DEFAULT '1' COMMENT '我们的客户',
  `bottom_carousel` tinyint(1) DEFAULT '1' COMMENT '底部轮播图（涉及品牌）',
  `bottom_info` tinyint(1) DEFAULT '1' COMMENT '底部信息（涉及品牌）',
  `bottom_download` tinyint(1) DEFAULT '1' COMMENT '底部下载（涉及品牌）',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_business_activity_code` (`code`),
  KEY `FK_BUSINESS_ACTIVITY_REF_PARTNER` (`partner`),
  KEY `FK_BUSINESS_ACTIVITY_REF_COOPERATION_MODE` (`cooperation_mode`),
  KEY `FK_BUSINESS_ACTIVITY_REF_INTERNAL_USER` (`operator`),
  KEY `idx_business_activity_name` (`name`),
  CONSTRAINT `FK_BUSINESS_ACTIVITY_REF_COOPERATION_MODE` FOREIGN KEY (`cooperation_mode`) REFERENCES `cooperation_mode` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_BUSINESS_ACTIVITY_REF_INTERNAL_USER` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_BUSINESS_ACTIVITY_REF_PARTNER` FOREIGN KEY (`partner`) REFERENCES `partner` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=424 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `channel`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `channel` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `parent` bigint(20) DEFAULT NULL,
  `api_partner` bigint(20) DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  `icon` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_CHANNEL_REF_SELF_idx` (`parent`),
  KEY `FK_CHANNEL_REF_API_PARTNER_idx` (`api_partner`),
  CONSTRAINT `FK_CHANNEL_REF_API_PARTNER` FOREIGN KEY (`api_partner`) REFERENCES `api_partner` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_CHANNEL_REF_SELF` FOREIGN KEY (`parent`) REFERENCES `channel` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=204 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `claim`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `claim` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `accident_date` date DEFAULT NULL,
  `accident_location` varchar(400) DEFAULT NULL,
  `amount` decimal(18,2) DEFAULT NULL,
  `claim_date` date DEFAULT NULL,
  `close_date` date DEFAULT NULL,
  `contact_phone` varchar(45) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `identity` varchar(45) DEFAULT NULL,
  `injured_person` tinyint(1) DEFAULT NULL,
  `license_plate_no` varchar(45) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  `policy_no` varchar(45) DEFAULT NULL,
  `record_date` date DEFAULT NULL,
  `accident_type` bigint(20) DEFAULT NULL,
  `auto` bigint(20) DEFAULT NULL,
  `identity_type` bigint(20) DEFAULT NULL,
  `insurance_company` bigint(20) DEFAULT NULL,
  `operator` bigint(20) DEFAULT NULL,
  `status` bigint(20) DEFAULT NULL,
  `type` bigint(20) DEFAULT NULL,
  `user` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_CLAIM_REF_ACCIDENT_TYPE` (`accident_type`),
  KEY `FK_CLAIM_REF_AUTO` (`auto`),
  KEY `FK_CLAIM_REF_IDENTITY_TYPE` (`identity_type`),
  KEY `FK_CLAIM_REF_INSURANCE_COMPANY` (`insurance_company`),
  KEY `FK_CLAIM_REF_INTERNAL_USER` (`operator`),
  KEY `FK_CLAIM_REF_CLAIM_STATUS` (`status`),
  KEY `FK_CLAIM_REF_INSURANCE_TYPE` (`type`),
  KEY `FK_CLAIM_REF_USER` (`user`),
  KEY `idx_claim` (`user`,`auto`),
  CONSTRAINT `FK_CLAIM_REF_ACCIDENT_TYPE` FOREIGN KEY (`accident_type`) REFERENCES `accident_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_CLAIM_REF_AUTO` FOREIGN KEY (`auto`) REFERENCES `auto` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_CLAIM_REF_CLAIM_STATUS` FOREIGN KEY (`status`) REFERENCES `claim_status` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_CLAIM_REF_IDENTITY_TYPE` FOREIGN KEY (`identity_type`) REFERENCES `identity_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_CLAIM_REF_INSURANCE_COMPANY` FOREIGN KEY (`insurance_company`) REFERENCES `insurance_company` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_CLAIM_REF_INSURANCE_TYPE` FOREIGN KEY (`type`) REFERENCES `insurance_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_CLAIM_REF_INTERNAL_USER` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_CLAIM_REF_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `claim_processing_result`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `claim_processing_result` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `result` tinyint(3) DEFAULT NULL,
  `applicant` bigint(20) DEFAULT NULL,
  `auto` bigint(20) DEFAULT NULL,
  `compulsory_insurance` bigint(20) DEFAULT NULL,
  `insurance` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_CLAIM_PROCESSING_RESULT_REF_USER` (`applicant`),
  KEY `FK_CLAIM_PROCESSING_RESULT_REF_AUTO` (`auto`),
  KEY `FK_CLAIM_PROCESSING_RESULT_REF_COMPULSORY_INSURANCE` (`compulsory_insurance`),
  KEY `FK_CLAIM_PROCESSING_RESULT_REF_INSURANCE` (`insurance`),
  CONSTRAINT `FK_CLAIM_PROCESSING_RESULT_REF_AUTO` FOREIGN KEY (`auto`) REFERENCES `auto` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_CLAIM_PROCESSING_RESULT_REF_COMPULSORY_INSURANCE` FOREIGN KEY (`compulsory_insurance`) REFERENCES `compulsory_insurance` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_CLAIM_PROCESSING_RESULT_REF_INSURANCE` FOREIGN KEY (`insurance`) REFERENCES `insurance` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_CLAIM_PROCESSING_RESULT_REF_USER` FOREIGN KEY (`applicant`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `claim_status`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `claim_status` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(2000) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `compulsory_insurance`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `compulsory_insurance` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `auto_tax` decimal(18,2) DEFAULT NULL,
  `compulsory_premium` decimal(18,2) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `discount` decimal(18,6) DEFAULT NULL,
  `effective_date` date DEFAULT NULL,
  `effective_hour` int(11) DEFAULT NULL,
  `expire_date` date DEFAULT NULL,
  `expire_hour` int(11) DEFAULT NULL,
  `insurance_image` varchar(200) DEFAULT NULL,
  `insured_name` varchar(45) DEFAULT NULL,
  `original_policy_no` varchar(45) DEFAULT NULL,
  `policy_no` varchar(45) DEFAULT NULL,
  `proposal_no` varchar(45) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `applicant` bigint(20) DEFAULT NULL,
  `auto` bigint(20) DEFAULT NULL,
  `insurance_agent` bigint(20) DEFAULT NULL,
  `insurance_company` bigint(20) DEFAULT NULL,
  `insurance_package` bigint(20) DEFAULT NULL,
  `operator` bigint(20) DEFAULT NULL,
  `quote_record` bigint(20) DEFAULT NULL,
  `applicant_name` varchar(45) DEFAULT NULL,
  `applicant_id_no` varchar(45) DEFAULT NULL,
  `applicant_mobile` varchar(45) DEFAULT NULL,
  `applicant_email` varchar(45) DEFAULT NULL,
  `insured_id_no` varchar(45) DEFAULT NULL,
  `insured_mobile` varchar(45) DEFAULT NULL,
  `insured_email` varchar(45) DEFAULT NULL,
  `institution` bigint(20) DEFAULT NULL COMMENT '出单机构',
  PRIMARY KEY (`id`),
  KEY `FK_COMPULSORY_INSURANCE_REF_USER` (`applicant`),
  KEY `FK_COMPULSORY_INSURANCE_REF_AUTO` (`auto`),
  KEY `FK_COMPULSORY_INSURANCE_REF_INSURANCE_AGENT` (`insurance_agent`),
  KEY `FK_COMPULSORY_INSURANCE_REF_INSURANCE_COMPANY` (`insurance_company`),
  KEY `FK_COMPULSORY_INSURANCE_REF_INSURANCE_PACKAGE` (`insurance_package`),
  KEY `FK_COMPULSORY_INSURANCE_REF_INTERNAL_USER` (`operator`),
  KEY `FK_COMPULSORY_INSURANCE_REF_QUOTE_RECORD` (`quote_record`),
  KEY `idx_compulsory_insurance_policy_no` (`policy_no`),
  KEY `idx_compulsory_insurance_proposal_no` (`proposal_no`),
  KEY `idx_compulsory_insurance` (`applicant`,`auto`),
  KEY `FK_COMPULSORY_INSURANCE_REF_INSTITUTION` (`institution`),
  CONSTRAINT `FK_COMPULSORY_INSURANCE_REF_AUTO` FOREIGN KEY (`auto`) REFERENCES `auto` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_COMPULSORY_INSURANCE_REF_INSTITUTION` FOREIGN KEY (`institution`) REFERENCES `institution` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_COMPULSORY_INSURANCE_REF_INSURANCE_AGENT` FOREIGN KEY (`insurance_agent`) REFERENCES `insurance_agent` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_COMPULSORY_INSURANCE_REF_INSURANCE_COMPANY` FOREIGN KEY (`insurance_company`) REFERENCES `insurance_company` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_COMPULSORY_INSURANCE_REF_INSURANCE_PACKAGE` FOREIGN KEY (`insurance_package`) REFERENCES `insurance_package` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_COMPULSORY_INSURANCE_REF_INTERNAL_USER` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_COMPULSORY_INSURANCE_REF_QUOTE_RECORD` FOREIGN KEY (`quote_record`) REFERENCES `quote_record` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_COMPULSORY_INSURANCE_REF_USER` FOREIGN KEY (`applicant`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=40048 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cooperation_mode`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cooperation_mode` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL COMMENT '合作方式名称',
  `description` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cps_channel`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cps_channel` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `channel_no` varchar(45) DEFAULT NULL,
  `rebate` decimal(18,2) DEFAULT NULL,
  `wap_url` varchar(45) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `link_man` varchar(45) DEFAULT NULL,
  `mobile` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `frequency` tinyint(1) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `operator` bigint(20) DEFAULT NULL,
  `enable` tinyint(1) DEFAULT '0',
  `display` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK_CPS_CHANNEL_REF_INTERNAL_USER` (`operator`),
  CONSTRAINT `FK_CPS_CHANNEL_REF_INTERNAL_USER` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `customer_field`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_field` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL COMMENT '自定义字段名称',
  `business_activity` bigint(20) DEFAULT NULL COMMENT '商务活动',
  `first_field` bigint(20) DEFAULT NULL COMMENT '基础字段A',
  `second_field` bigint(20) DEFAULT NULL COMMENT '基础字段B',
  `operator` bigint(20) DEFAULT NULL COMMENT '运算符',
  PRIMARY KEY (`id`),
  KEY `FK_CUSTOMER_FIELD_REF_BUSINESS_ACTIVITY` (`business_activity`),
  KEY `FK_CUSTOMER_FIELD_REF_FIRST_MONITOR_DATA_TYPE` (`first_field`),
  KEY `FK_CUSTOMER_FIELD_REF_SECOND_MONITOR_DATA_TYPE` (`second_field`),
  KEY `FK_CUSTOMER_FIELD_REF_ARITHMETIC_OPERATOR` (`operator`),
  CONSTRAINT `FK_CUSTOMER_FIELD_REF_ARITHMETIC_OPERATOR` FOREIGN KEY (`operator`) REFERENCES `arithmetic_operator` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_CUSTOMER_FIELD_REF_BUSINESS_ACTIVITY` FOREIGN KEY (`business_activity`) REFERENCES `business_activity` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_CUSTOMER_FIELD_REF_FIRST_MONITOR_DATA_TYPE` FOREIGN KEY (`first_field`) REFERENCES `monitor_data_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_CUSTOMER_FIELD_REF_SECOND_MONITOR_DATA_TYPE` FOREIGN KEY (`second_field`) REFERENCES `monitor_data_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `daily_insurance`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `daily_insurance` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `purchase_order` bigint(20) NOT NULL COMMENT '订单id',
  `policy_no` varchar(45) NOT NULL COMMENT '保单号',
  `insurance_package` bigint(20) NOT NULL COMMENT '停驶险种套餐',
  `create_time` datetime NOT NULL COMMENT '试算创建时间',
  `stop_apply_time` datetime DEFAULT NULL COMMENT '申请停驶时间',
  `stop_date` date NOT NULL COMMENT '保单停驶日期',
  `expect_restart_date` date NOT NULL COMMENT '保单复驶日期',
  `total_refund_amount` decimal(18,2) NOT NULL COMMENT '应退保费总额',
  `bank_no` varchar(100) DEFAULT NULL COMMENT '银行卡号',
  `bank_code` varchar(100) DEFAULT NULL COMMENT '银行代码',
  `restart_apply_time` datetime DEFAULT NULL COMMENT '复驶申请时间',
  `restart_date` date DEFAULT NULL COMMENT '保单实际复驶日期',
  `restart_apply_id` varchar(100) DEFAULT NULL COMMENT '复驶试算申请id，复驶申请后回填',
  `restart_apply_no` varchar(100) DEFAULT NULL COMMENT '复驶商业险申请单号，复驶申请后回填',
  `effective_date` date DEFAULT NULL COMMENT '商业险生效日期',
  `expire_date` date DEFAULT NULL COMMENT '商业险截止日期',
  `payable_amount` decimal(18,2) DEFAULT NULL COMMENT '市场价',
  `discount_amount` decimal(18,2) DEFAULT NULL COMMENT '折扣价',
  `paid_amount` decimal(18,2) DEFAULT NULL COMMENT '实际应付价格',
  `premium` decimal(18,2) DEFAULT NULL COMMENT '商业险保费',
  `restart_order_no` varchar(100) DEFAULT NULL COMMENT '复驶成功新订单号，复驶确认后回填',
  `restart_policy_no` varchar(100) DEFAULT NULL COMMENT '复驶成功新保单号，复驶支付回调成功后回填',
  `payment` bigint(20) DEFAULT NULL COMMENT '支付表id',
  `status` bigint(20) DEFAULT NULL COMMENT '状态',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `description` varchar(2000) DEFAULT NULL COMMENT '其他描述',
  PRIMARY KEY (`id`),
  KEY `FK_DAILY_INSURANCE_REF_ORDER` (`purchase_order`),
  KEY `FK_DAILY_INSURANCE_REF_PKG` (`insurance_package`),
  KEY `FK_DAILY_INSURANCE_REF_PAYMENT` (`payment`),
  KEY `FK_DAILY_INSURANCE_REF_STATUS` (`status`),
  CONSTRAINT `FK_DAILY_INSURANCE_REF_ORDER` FOREIGN KEY (`purchase_order`) REFERENCES `purchase_order` (`id`),
  CONSTRAINT `FK_DAILY_INSURANCE_REF_PAYMENT` FOREIGN KEY (`payment`) REFERENCES `payment` (`id`),
  CONSTRAINT `FK_DAILY_INSURANCE_REF_PKG` FOREIGN KEY (`insurance_package`) REFERENCES `insurance_package` (`id`),
  CONSTRAINT `FK_DAILY_INSURANCE_REF_STATUS` FOREIGN KEY (`status`) REFERENCES `daily_insurance_status` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `daily_insurance_detail`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `daily_insurance_detail` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `daily_insurance` bigint(20) NOT NULL COMMENT '按天买车险停复驶id',
  `code` varchar(50) NOT NULL COMMENT '险别代码',
  `name` varchar(50) NOT NULL COMMENT '险别名称',
  `refund_premium` decimal(18,2) NOT NULL COMMENT '应退保费',
  `amount` decimal(18,2) DEFAULT NULL COMMENT '保额',
  `premium` decimal(18,2) DEFAULT NULL COMMENT '保费',
  `iop` tinyint(1) DEFAULT NULL COMMENT '免赔标志',
  `iop_premium` decimal(18,2) DEFAULT NULL COMMENT '免赔保费',
  PRIMARY KEY (`id`),
  KEY `FK_INSURANCE_DETAIL_REF_DAILY_INSURANCE` (`daily_insurance`),
  CONSTRAINT `FK_INSURANCE_DETAIL_REF_DAILY_INSURANCE` FOREIGN KEY (`daily_insurance`) REFERENCES `daily_insurance` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `daily_insurance_status`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `daily_insurance_status` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `status` varchar(45) DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `delivery_info`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `delivery_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `express_company` varchar(45) DEFAULT NULL COMMENT '快递公司',
  `tracking_no` varchar(50) DEFAULT NULL COMMENT '快递单号',
  `delivery_man` varchar(20) DEFAULT NULL COMMENT '送货员',
  `mobile` varchar(20) DEFAULT NULL COMMENT '送货员手机号',
  `delivery_time` datetime DEFAULT NULL COMMENT '送货时间',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  `operator` bigint(20) DEFAULT NULL COMMENT '操作人',
  PRIMARY KEY (`id`),
  KEY `FK_DELIVERY_INFO_REF_OPERATOR` (`operator`),
  CONSTRAINT `FK_DELIVERY_INFO_REF_OPERATOR` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=16862 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `device`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `device` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `device_info` varchar(100) DEFAULT NULL,
  `device_type` bigint(20) DEFAULT NULL,
  `device_unique_id` varchar(100) NOT NULL,
  `user` bigint(20) DEFAULT NULL,
  `os_info` varchar(100) DEFAULT NULL,
  `os_version` varchar(100) DEFAULT NULL,
  `app_info` varchar(100) DEFAULT NULL,
  `app_version` varchar(100) DEFAULT NULL,
  `uuid` varchar(45) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `disable` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_u_device` (`device_unique_id`),
  KEY `FK_DEVICE_REF_USER` (`user`),
  CONSTRAINT `FK_DEVICE_REF_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=29575 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `didi_supplement_insurance`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `didi_supplement_insurance` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user` bigint(20) DEFAULT NULL,
  `auto` bigint(20) DEFAULT NULL,
  `last_commercial_policy_no` varchar(45) DEFAULT NULL COMMENT '上份商业险保单号',
  `last_compulsory_policy_no` varchar(45) DEFAULT NULL COMMENT '上份交强险保单号',
  `insured_name` varchar(45) DEFAULT NULL,
  `insured_identity` varchar(45) DEFAULT NULL,
  `insured_identity_type` bigint(20) DEFAULT NULL,
  `third_party_amount` decimal(18,2) DEFAULT NULL,
  `driver_amount` decimal(18,2) DEFAULT NULL,
  `passenger_amount` decimal(18,2) DEFAULT NULL,
  `insurance_company` bigint(20) DEFAULT NULL,
  `last_commercial_insurance_path` varchar(100) DEFAULT NULL COMMENT '上年商业险保单图片URL',
  `last_compulsory_insurance_path` varchar(100) DEFAULT NULL COMMENT '上面交强险保单图片URL',
  `driving_license_path` varchar(100) DEFAULT NULL COMMENT '行驶证图片URL',
  `owner_identity_path` varchar(100) DEFAULT NULL COMMENT '车主身份证图片URL',
  `insured_identity_path` varchar(100) DEFAULT NULL COMMENT '被保险人身份证图片URL',
  `status` bigint(20) DEFAULT NULL,
  `operator` bigint(20) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `comment` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_DIDI_SUPPLEMENT_INSURANCE_REF_USER` (`user`),
  KEY `FK_DIDI_SUPPLEMENT_INSURANCE_REF_AUTO` (`auto`),
  KEY `FK_DIDI_SUPPLEMENT_INSURANCE_REF_IDENTITY_TYPE` (`insured_identity_type`),
  KEY `FK_DIDI_SUPPLEMENT_INSURANCE_REF_INSURANCE_COMPANY` (`insurance_company`),
  KEY `FK_DIDI_SUPPLEMENT_INSURANCE_REF_DIDI_STATUS` (`status`),
  KEY `FK_DIDI_INSURANCE_REF_INTERNAL_USER` (`operator`),
  CONSTRAINT `FK_DIDI_INSURANCE_REF_INTERNAL_USER` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_DIDI_SUPPLEMENT_INSURANCE_REF_AUTO` FOREIGN KEY (`auto`) REFERENCES `auto` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_DIDI_SUPPLEMENT_INSURANCE_REF_DIDI_STATUS` FOREIGN KEY (`status`) REFERENCES `didi_supplement_status` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_DIDI_SUPPLEMENT_INSURANCE_REF_IDENTITY_TYPE` FOREIGN KEY (`insured_identity_type`) REFERENCES `identity_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_DIDI_SUPPLEMENT_INSURANCE_REF_INSURANCE_COMPANY` FOREIGN KEY (`insurance_company`) REFERENCES `insurance_company` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_DIDI_SUPPLEMENT_INSURANCE_REF_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `didi_supplement_record`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `didi_supplement_record` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `didi_supplement_insurance` bigint(20) DEFAULT NULL,
  `quote_record` bigint(20) DEFAULT NULL,
  `purchase_order` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_DIDI_SUPPLEMENT_RECORD_REF_DIDI_INSURANCE` (`didi_supplement_insurance`),
  KEY `FK_DIDI_SUPPLEMENT_RECORD_REF_QUOTE_RECORD` (`quote_record`),
  KEY `FK_DIDI_SUPPLEMENT_RECORD_REF_PURCHASE_ORDER` (`purchase_order`),
  CONSTRAINT `FK_DIDI_SUPPLEMENT_RECORD_REF_DIDI_INSURANCE` FOREIGN KEY (`didi_supplement_insurance`) REFERENCES `didi_supplement_insurance` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_DIDI_SUPPLEMENT_RECORD_REF_PURCHASE_ORDER` FOREIGN KEY (`purchase_order`) REFERENCES `purchase_order` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_DIDI_SUPPLEMENT_RECORD_REF_QUOTE_RECORD` FOREIGN KEY (`quote_record`) REFERENCES `quote_record` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `didi_supplement_status`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `didi_supplement_status` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `status` varchar(45) DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `driver_image`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `driver_image` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `obj_id` bigint(20) NOT NULL COMMENT '对象id',
  `obj_table` varchar(45) NOT NULL COMMENT '对象表名',
  `path` varchar(100) NOT NULL COMMENT '照片文件路径',
  `type` bigint(20) NOT NULL COMMENT '照片类型',
  `status` tinyint(1) DEFAULT '0' COMMENT '照片审核状态',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  `operator` bigint(20) DEFAULT NULL COMMENT '操作人',
  PRIMARY KEY (`id`),
  KEY `FK_DRIVER_IMAGE_REF_TYPE` (`type`),
  KEY `FK_DRIVER_IMAGE_REF_OPERATOR` (`operator`),
  CONSTRAINT `FK_DRIVER_IMAGE_REF_OPERATOR` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`),
  CONSTRAINT `FK_DRIVER_IMAGE_REF_TYPE` FOREIGN KEY (`type`) REFERENCES `image_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=175 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `feedback`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feedback` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `content` varchar(500) DEFAULT '',
  `user_id` bigint(20) DEFAULT '0',
  `create_time` datetime DEFAULT NULL,
  `status` bigint(20) DEFAULT '1',
  `mobile` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=599 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `filter_user`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `filter_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(20) NOT NULL COMMENT '名称',
  `sql_template` bigint(20) DEFAULT NULL COMMENT 'sql模板，关联sql_template表',
  `parameter` varchar(1000) DEFAULT NULL,
  `disable` tinyint(1) DEFAULT '1' COMMENT '是否启用，默认为禁用，0-启用，1-禁用',
  `comment` varchar(200) DEFAULT NULL COMMENT '备注',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  `operator` bigint(20) DEFAULT NULL COMMENT '操作人，关联internal_user表',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_filter_user_name` (`name`),
  KEY `FK_FILTER_USER_REF_SQL_TEMPLATE` (`sql_template`),
  KEY `FK_FILTER_USER_REF_OPERATOR` (`operator`),
  CONSTRAINT `FK_FILTER_USER_REF_OPERATOR` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_FILTER_USER_REF_SQL_TEMPLATE` FOREIGN KEY (`sql_template`) REFERENCES `sql_template` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `function`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `function` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(45) DEFAULT NULL,
  `function_no` varchar(10) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  `url` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gender`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gender` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(2000) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gift`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gift` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `effective_date` date DEFAULT NULL,
  `expire_date` date DEFAULT NULL,
  `gift_amount` decimal(18,2) DEFAULT NULL,
  `gift_type` bigint(20) DEFAULT NULL,
  `reason` varchar(2000) DEFAULT NULL,
  `source` bigint(20) DEFAULT NULL,
  `source_type` bigint(20) DEFAULT NULL,
  `applicant` bigint(20) DEFAULT NULL,
  `status` bigint(20) DEFAULT NULL,
  `quantity` tinyint(3) DEFAULT '1',
  `unit` varchar(10) DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  `gift_content` varchar(200) DEFAULT NULL,
  `full_limit_amount` decimal(18,2) DEFAULT NULL,
  `usage_rule_description` varchar(500) DEFAULT NULL,
  `gift_display` varchar(50) DEFAULT NULL,
  `usage_rule_class` varchar(150) DEFAULT NULL,
  `usage_rule_param` varchar(500) DEFAULT NULL,
  `alipass_serial_number` varchar(200) DEFAULT NULL,
  `alipass_status` varchar(20) DEFAULT NULL,
  `alipass_pass_id` varchar(100) DEFAULT NULL,
  `alipay_support` tinyint(1) DEFAULT '0' COMMENT '是否是支付宝可使用的红包',
  `gift_detail_link` varchar(200) DEFAULT NULL,
  `sync_channels` varchar(20) DEFAULT NULL COMMENT '优惠券需要同步的第三方渠道',
  PRIMARY KEY (`id`),
  KEY `FK_GIFT_REF_USER` (`applicant`),
  KEY `FK_GIFT_REF_GIFT_STATUS` (`status`),
  KEY `FK_GIFT_REF_GIFT_TYPE` (`gift_type`),
  CONSTRAINT `FK_GIFT_REF_GIFT_STATUS` FOREIGN KEY (`status`) REFERENCES `gift_status` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_GIFT_REF_GIFT_TYPE` FOREIGN KEY (`gift_type`) REFERENCES `gift_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_GIFT_REF_USER` FOREIGN KEY (`applicant`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=189628 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gift_area`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gift_area` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `area` bigint(20) NOT NULL,
  `source_type` bigint(20) NOT NULL,
  `source` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_GIFT_AREA_REF_AREA` (`area`),
  KEY `JK_GIFT_AREA_ST_S` (`source_type`,`source`),
  CONSTRAINT `FK_GIFT_AREA_REF_AREA` FOREIGN KEY (`area`) REFERENCES `area` (`id`),
  CONSTRAINT `FK_GIFT_AREA_REF_SOURCE_TYPE` FOREIGN KEY (`source_type`) REFERENCES `source_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=544 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gift_channel`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gift_channel` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `channel` bigint(20) NOT NULL,
  `source_type` bigint(20) NOT NULL,
  `source` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_GIFT_CHANNEL_REF_CHANNEL` (`channel`),
  KEY `FK_GIFT_CHANNEL_REF_SOURCE_TYPE` (`source_type`),
  CONSTRAINT `FK_GIFT_CHANNEL_REF_CHANNEL` FOREIGN KEY (`channel`) REFERENCES `channel` (`id`),
  CONSTRAINT `FK_GIFT_CHANNEL_REF_SOURCE_TYPE` FOREIGN KEY (`source_type`) REFERENCES `source_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=454 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gift_code`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gift_code` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `effective_date` date DEFAULT NULL,
  `expire_date` date DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `exchange_way` bigint(20) NOT NULL,
  `exchanged` tinyint(1) DEFAULT NULL,
  `applicant` bigint(20) DEFAULT NULL,
  `exchange_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `applicant` (`applicant`),
  KEY `FK_GIFT_CODE_REF_EXCHANGE_WAY` (`exchange_way`),
  CONSTRAINT `gift_code_ibfk_1` FOREIGN KEY (`exchange_way`) REFERENCES `gift_code_exchange_way` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `gift_code_ibfk_2` FOREIGN KEY (`applicant`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=147509 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gift_code_exchange_way`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gift_code_exchange_way` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `exchange_class` varchar(100) NOT NULL,
  `common_exchange` tinyint(1) DEFAULT NULL,
  `amount` decimal(18,2) DEFAULT NULL,
  `operator` bigint(20) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `effective_date` date DEFAULT NULL,
  `expire_date` date DEFAULT NULL,
  `amount_param` varchar(500) DEFAULT NULL,
  `full_limit_param` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `operator` (`operator`),
  CONSTRAINT `gift_code_exchange_way_ibfk_1` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gift_insurance_company`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gift_insurance_company` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `insurance_company` bigint(20) NOT NULL,
  `source_type` bigint(20) NOT NULL,
  `source` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_GIFT_INSURANCE_COMPANY_REF_INSURANCE_COMPANY` (`insurance_company`),
  KEY `JK_GIFT_INSURANCE_COMPANY_ST_S` (`source_type`,`source`),
  CONSTRAINT `FK_GIFT_INSURANCE_COMPANY_REF_INSURANCE_COMPANY` FOREIGN KEY (`insurance_company`) REFERENCES `insurance_company` (`id`),
  CONSTRAINT `FK_GIFT_INSURANCE_COMPANY_REF_SOURCE_TYPE` FOREIGN KEY (`source_type`) REFERENCES `source_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=348 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gift_status`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gift_status` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `status` varchar(45) DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  `rank` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gift_type`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gift_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  `use_type` bigint(20) DEFAULT NULL,
  `category` tinyint(3) DEFAULT NULL,
  `category_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `use_type` (`use_type`),
  CONSTRAINT `gift_type_ibfk_1` FOREIGN KEY (`use_type`) REFERENCES `gift_type_use_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gift_type_use_type`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gift_type_use_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `glass_type`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `glass_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(2000) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `identity_type`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `identity_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(2000) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `image_type`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `image_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(45) DEFAULT NULL COMMENT '类型名称',
  `description` varchar(200) DEFAULT NULL COMMENT '描述',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `institution`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `institution` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(20) DEFAULT NULL COMMENT '出单机构名称',
  `comment` varchar(200) DEFAULT NULL COMMENT '备注',
  `contact_name` varchar(20) DEFAULT NULL COMMENT '机构联系人姓名',
  `contact_mobile` varchar(20) DEFAULT NULL COMMENT '机构联系人手机号',
  `contact_email` varchar(45) DEFAULT NULL COMMENT '机构联系人邮箱',
  `contact_qq` varchar(20) DEFAULT NULL COMMENT '机构联系人QQ',
  `cheche_name` varchar(20) DEFAULT NULL COMMENT '车车责任人姓名',
  `cheche_mobile` varchar(20) DEFAULT NULL COMMENT '车车责任人手机号',
  `cheche_email` varchar(45) DEFAULT NULL COMMENT '车车责任人邮箱',
  `cheche_qq` varchar(20) DEFAULT NULL COMMENT '车车责任人QQ',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  `operator` bigint(20) DEFAULT NULL COMMENT '操作人',
  `enable` tinyint(1) DEFAULT NULL COMMENT '启用禁用标记',
  PRIMARY KEY (`id`),
  KEY `FK_INSTITUTION_REF_OPERATOR` (`operator`),
  CONSTRAINT `FK_INSTITUTION_REF_OPERATOR` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `institution_bank_account`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `institution_bank_account` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `institution` bigint(20) DEFAULT NULL COMMENT '出单机构',
  `bank` varchar(45) DEFAULT NULL COMMENT '开户行',
  `account_name` varchar(45) DEFAULT NULL COMMENT '开户名',
  `account_no` varchar(45) DEFAULT NULL COMMENT '帐号',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  `operator` bigint(20) DEFAULT NULL COMMENT '操作人',
  PRIMARY KEY (`id`),
  KEY `FK_INSTITUTION_BANK_ACCOUNT_REF_INSTITUTION` (`institution`),
  KEY `FK_INSTITUTION_BANK_ACCOUNT_REF_OPERATOR` (`operator`),
  CONSTRAINT `FK_INSTITUTION_BANK_ACCOUNT_REF_INSTITUTION` FOREIGN KEY (`institution`) REFERENCES `institution` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_INSTITUTION_BANK_ACCOUNT_REF_OPERATOR` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `institution_quote_record`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `institution_quote_record` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `purchase_order` bigint(20) DEFAULT NULL COMMENT '订单',
  `insurance_package` bigint(20) DEFAULT NULL COMMENT '报价套餐',
  `institution` bigint(20) DEFAULT NULL COMMENT '出单机构',
  `commercial_rebate` decimal(18,2) DEFAULT NULL COMMENT '商业险佣金',
  `compulsory_rebate` decimal(18,2) DEFAULT NULL COMMENT '交强险佣金',
  `commercial_policy_no` varchar(45) DEFAULT NULL COMMENT '商业险保单号',
  `compulsory_policy_no` varchar(45) DEFAULT NULL COMMENT '交强险保单号',
  `commercial_premium` decimal(18,2) DEFAULT NULL COMMENT '商业险保费',
  `compulsory_premium` decimal(18,2) DEFAULT NULL COMMENT '交强险保费',
  `auto_tax` decimal(18,2) DEFAULT NULL COMMENT '车船税',
  `third_party_amount` decimal(18,2) DEFAULT NULL COMMENT '三者险保额',
  `third_party_premium` decimal(18,2) DEFAULT NULL COMMENT '三者险保费',
  `theft_amount` decimal(18,2) DEFAULT NULL COMMENT '盗抢险保额',
  `theft_premium` decimal(18,2) DEFAULT NULL COMMENT '盗抢险保费',
  `damage_amount` decimal(18,2) DEFAULT NULL COMMENT '车损险保额',
  `damage_premium` decimal(18,2) DEFAULT NULL COMMENT '车损险保费',
  `driver_amount` decimal(18,2) DEFAULT NULL COMMENT '司机险保额',
  `driver_premium` decimal(18,2) DEFAULT NULL COMMENT '司机险保费',
  `passenger_amount` decimal(18,2) DEFAULT NULL COMMENT '乘客险保额',
  `passenger_premium` decimal(18,2) DEFAULT NULL COMMENT '乘客险保费',
  `passenger_count` tinyint(3) DEFAULT NULL COMMENT '乘客数量',
  `engine_premium` decimal(18,2) DEFAULT NULL COMMENT '发动机险保费',
  `glass_premium` decimal(18,2) DEFAULT NULL COMMENT '玻璃险保费',
  `scratch_amount` decimal(18,2) DEFAULT NULL COMMENT '划痕险保额',
  `scratch_premium` decimal(18,2) DEFAULT NULL COMMENT '划痕险保费',
  `spontaneous_loss_amount` decimal(18,2) DEFAULT NULL COMMENT '自燃险保额',
  `spontaneous_loss_premium` decimal(18,2) DEFAULT NULL COMMENT '自燃险保费',
  `third_party_iop` decimal(18,2) DEFAULT NULL COMMENT '三者险不计免赔',
  `theft_iop` decimal(18,2) DEFAULT NULL COMMENT '盗抢险不计免赔',
  `damage_iop` decimal(18,2) DEFAULT NULL COMMENT '车损险不计免赔',
  `driver_iop` decimal(18,2) DEFAULT NULL COMMENT '司机险不计免赔',
  `passenger_iop` decimal(18,2) DEFAULT NULL COMMENT '乘客险不计免赔',
  `engine_iop` decimal(18,2) DEFAULT NULL COMMENT '发动机险不计免赔',
  `scratch_iop` decimal(18,2) DEFAULT NULL COMMENT '划痕险不计免赔',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  `operator` bigint(20) DEFAULT NULL COMMENT '操作人',
  PRIMARY KEY (`id`),
  KEY `FK_INSTITUTION_QUOTE_RECORD_REF_PURCHASE_ORDER` (`purchase_order`),
  KEY `FK_INSTITUTION_QUOTE_RECORD_REF_INSURANCE_PACKAGE` (`insurance_package`),
  KEY `FK_INSTITUTION_QUOTE_RECORD_REF_OPERATOR` (`operator`),
  KEY `FK_INSTITUTION_QUOTE_RECORD_REF_INSTITUTION` (`institution`),
  CONSTRAINT `FK_INSTITUTION_QUOTE_RECORD_REF_INSTITUTION` FOREIGN KEY (`institution`) REFERENCES `institution` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_INSTITUTION_QUOTE_RECORD_REF_INSURANCE_PACKAGE` FOREIGN KEY (`insurance_package`) REFERENCES `insurance_package` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_INSTITUTION_QUOTE_RECORD_REF_OPERATOR` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_INSTITUTION_QUOTE_RECORD_REF_PURCHASE_ORDER` FOREIGN KEY (`purchase_order`) REFERENCES `purchase_order` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `institution_rebate`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `institution_rebate` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `institution` bigint(20) DEFAULT NULL COMMENT '出单机构',
  `area` bigint(20) DEFAULT NULL COMMENT '城市',
  `insurance_company` bigint(20) DEFAULT NULL COMMENT '保险公司',
  `commercial_rebate` decimal(18,2) DEFAULT NULL COMMENT '商业险佣金',
  `compulsory_rebate` decimal(18,2) DEFAULT NULL COMMENT '交强险佣金',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  `operator` bigint(20) DEFAULT NULL COMMENT '操作人',
  PRIMARY KEY (`id`),
  KEY `FK_INSTITUTION_REBATE_REF_INSTITUTION` (`institution`),
  KEY `FK_INSTITUTION_REBATE_REF_AREA` (`area`),
  KEY `FK_INSTITUTION_REBATE_REF_INSURANCE_COMPANY` (`insurance_company`),
  KEY `FK_INSTITUTION_REBATE_REF_OPERATOR` (`operator`),
  CONSTRAINT `FK_INSTITUTION_REBATE_REF_AREA` FOREIGN KEY (`area`) REFERENCES `area` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_INSTITUTION_REBATE_REF_INSTITUTION` FOREIGN KEY (`institution`) REFERENCES `institution` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_INSTITUTION_REBATE_REF_INSURANCE_COMPANY` FOREIGN KEY (`insurance_company`) REFERENCES `insurance_company` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_INSTITUTION_REBATE_REF_OPERATOR` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=567 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `institution_rebate_history`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `institution_rebate_history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `institution` bigint(20) NOT NULL,
  `area` bigint(20) NOT NULL,
  `insurance_company` bigint(20) NOT NULL,
  `commercial_rebate` decimal(18,2) NOT NULL,
  `compulsory_rebate` decimal(18,2) NOT NULL,
  `operation` tinyint(1) NOT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime DEFAULT NULL,
  `operator` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_INSTITUTION_REBATE_HISTORY_REF_INSTITUTION` (`institution`),
  KEY `FK_INSTITUTION_REBATE_HISTORY_REF_AREA` (`area`),
  KEY `FK_INSTITUTION_REBATE_HISTORY_REF_INSURANCE_COMPANY` (`insurance_company`),
  KEY `FK_INSTITUTION_REBATE_HISTORY_REF_INTERNAL_USER` (`operator`),
  CONSTRAINT `FK_INSTITUTION_REBATE_HISTORY_REF_AREA` FOREIGN KEY (`area`) REFERENCES `area` (`id`),
  CONSTRAINT `FK_INSTITUTION_REBATE_HISTORY_REF_INSTITUTION` FOREIGN KEY (`institution`) REFERENCES `institution` (`id`),
  CONSTRAINT `FK_INSTITUTION_REBATE_HISTORY_REF_INSURANCE_COMPANY` FOREIGN KEY (`insurance_company`) REFERENCES `insurance_company` (`id`),
  CONSTRAINT `FK_INSTITUTION_REBATE_HISTORY_REF_INTERNAL_USER` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1088 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `insurance`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `insurance` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_time` datetime DEFAULT NULL,
  `damage_amount` decimal(18,2) DEFAULT NULL,
  `damage_iop` decimal(18,2) DEFAULT NULL,
  `damage_premium` decimal(18,2) DEFAULT NULL,
  `discount` decimal(18,6) DEFAULT NULL,
  `driver_amount` decimal(18,2) DEFAULT NULL,
  `driver_iop` decimal(18,2) DEFAULT NULL,
  `driver_premium` decimal(18,2) DEFAULT NULL,
  `effective_date` date DEFAULT NULL,
  `effective_hour` tinyint(3) DEFAULT NULL,
  `engine_amount` decimal(18,2) DEFAULT NULL,
  `engine_iop` decimal(18,2) DEFAULT NULL,
  `engine_premium` decimal(18,2) DEFAULT NULL,
  `expire_date` date DEFAULT NULL,
  `expire_hour` tinyint(3) DEFAULT NULL,
  `glass_amount` decimal(18,2) DEFAULT NULL,
  `glass_premium` decimal(18,2) DEFAULT NULL,
  `insurance_image` varchar(200) DEFAULT NULL,
  `insured_name` varchar(45) DEFAULT NULL,
  `original_policy_no` varchar(45) DEFAULT NULL,
  `passenger_amount` decimal(18,2) DEFAULT NULL,
  `passenger_count` decimal(18,2) DEFAULT NULL,
  `passenger_iop` decimal(18,2) DEFAULT NULL,
  `passenger_premium` decimal(18,2) DEFAULT NULL,
  `policy_no` varchar(45) DEFAULT NULL,
  `premium` decimal(18,2) DEFAULT NULL,
  `proposal_no` varchar(45) DEFAULT NULL,
  `scratch_amount` decimal(18,2) DEFAULT NULL,
  `scratch_iop` decimal(18,2) DEFAULT NULL,
  `scratch_premium` decimal(18,2) DEFAULT NULL,
  `spontaneous_loss_amount` decimal(18,2) DEFAULT NULL,
  `spontaneous_loss_premium` decimal(18,2) DEFAULT NULL,
  `theft_amount` decimal(18,2) DEFAULT NULL,
  `theft_iop` decimal(18,2) DEFAULT NULL,
  `theft_premium` decimal(18,2) DEFAULT NULL,
  `third_party_amount` decimal(18,2) DEFAULT NULL,
  `third_party_iop` decimal(18,2) DEFAULT NULL,
  `third_party_premium` decimal(18,2) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `applicant` bigint(20) DEFAULT NULL,
  `auto` bigint(20) DEFAULT NULL,
  `insurance_agent` bigint(20) DEFAULT NULL,
  `insurance_company` bigint(20) DEFAULT NULL,
  `insurance_package` bigint(20) DEFAULT NULL,
  `operator` bigint(20) DEFAULT NULL,
  `quote_record` bigint(20) DEFAULT NULL,
  `applicant_name` varchar(45) DEFAULT NULL,
  `applicant_id_no` varchar(45) DEFAULT NULL,
  `applicant_mobile` varchar(45) DEFAULT NULL,
  `applicant_email` varchar(45) DEFAULT NULL,
  `insured_id_no` varchar(45) DEFAULT NULL,
  `insured_mobile` varchar(45) DEFAULT NULL,
  `insured_email` varchar(45) DEFAULT NULL,
  `institution` bigint(20) DEFAULT NULL COMMENT '出单机构',
  `iop_total` decimal(18,2) DEFAULT '0.00' COMMENT '不计免赔总额',
  `spontaneous_loss_iop` decimal(18,2) DEFAULT NULL,
  `unable_find_third_party_premium` decimal(18,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_INSURANCE_REF_USER` (`applicant`),
  KEY `FK_INSURANCE_REF_AUTO` (`auto`),
  KEY `FK_INSURANCE_REF_INSURANCE_AGENT` (`insurance_agent`),
  KEY `FK_INSURANCE_REF_INSURANCE_COMPANY` (`insurance_company`),
  KEY `FK_INSURANCE_REF_INSURANCE_PACKAGE` (`insurance_package`),
  KEY `FK_INSURANCE_REF_INTERNAL_USER` (`operator`),
  KEY `FK_INSURANCE_REF_QUOTE_RECORD` (`quote_record`),
  KEY `idx_compulsory_insurance_effective_date` (`effective_date`),
  KEY `idx_compulsory_insurance_expire_date` (`expire_date`),
  KEY `idx_insurance_policy_no` (`policy_no`),
  KEY `idx_insurance_proposal_no` (`proposal_no`),
  KEY `idx_insurance` (`applicant`,`auto`),
  KEY `idx_insurance_effective_date` (`effective_date`),
  KEY `idx_insurance_expire_date` (`expire_date`),
  KEY `FK_INSURANCE_REF_INSTITUTION` (`institution`),
  CONSTRAINT `FK_INSURANCE_REF_AUTO` FOREIGN KEY (`auto`) REFERENCES `auto` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_INSURANCE_REF_INSTITUTION` FOREIGN KEY (`institution`) REFERENCES `institution` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_INSURANCE_REF_INSURANCE_AGENT` FOREIGN KEY (`insurance_agent`) REFERENCES `insurance_agent` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_INSURANCE_REF_INSURANCE_COMPANY` FOREIGN KEY (`insurance_company`) REFERENCES `insurance_company` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_INSURANCE_REF_INSURANCE_PACKAGE` FOREIGN KEY (`insurance_package`) REFERENCES `insurance_package` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_INSURANCE_REF_INTERNAL_USER` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_INSURANCE_REF_QUOTE_RECORD` FOREIGN KEY (`quote_record`) REFERENCES `quote_record` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_INSURANCE_REF_USER` FOREIGN KEY (`applicant`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=46791 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `insurance_agent`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `insurance_agent` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_insurance_agent_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `insurance_company`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `insurance_company` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `code` varchar(10) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  `logo` varchar(50) DEFAULT NULL,
  `disable` tinyint(1) DEFAULT '0',
  `slogan` varchar(100) DEFAULT NULL,
  `type` tinyint(3) DEFAULT '1',
  `rank` tinyint(1) DEFAULT NULL,
  `description` varchar(4500) DEFAULT NULL,
  `renew_support` tinyint(1) DEFAULT NULL,
  `alipay_support` tinyint(1) DEFAULT '0' COMMENT '添加是否支持支付宝',
  `website_url` varchar(100) DEFAULT '',
  `promote` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_u_insurance_company_name` (`name`),
  UNIQUE KEY `idx_u_insurance_company_code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=100000000 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `insurance_company_area`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `insurance_company_area` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `insurance_company_id` bigint(20) NOT NULL,
  `area_id` bigint(20) NOT NULL,
  `quote_source_id` bigint(20) DEFAULT NULL,
  `inner_pay` tinyint(4) DEFAULT '1' COMMENT '是否使用保险公司的支付',
  `weight` int(10) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_company_area` (`insurance_company_id`,`area_id`),
  KEY `fk_insurance_company_id` (`insurance_company_id`),
  KEY `fk_area_id` (`area_id`),
  CONSTRAINT `fk_area_id` FOREIGN KEY (`area_id`) REFERENCES `area` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_insurance_company_id` FOREIGN KEY (`insurance_company_id`) REFERENCES `insurance_company` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=379 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `insurance_company_channel`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `insurance_company_channel` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `insurance_company_id` bigint(20) NOT NULL,
  `channel_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_icc_insurance_company_id` (`insurance_company_id`),
  KEY `fk_icc_channel_id` (`channel_id`),
  CONSTRAINT `fk_icc_channel_id` FOREIGN KEY (`channel_id`) REFERENCES `channel` (`id`),
  CONSTRAINT `fk_icc_insurance_company_id` FOREIGN KEY (`insurance_company_id`) REFERENCES `insurance_company` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=236 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `insurance_manager_service`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `insurance_manager_service` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `description` varchar(2000) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_third_party_code_group_code` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `insurance_manager_service_record`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `insurance_manager_service_record` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `insurance_manager_service` bigint(20) DEFAULT NULL COMMENT '车车管家服务',
  `source_id` bigint(20) DEFAULT NULL COMMENT '用户',
  `source_type` bigint(20) DEFAULT NULL,
  `user` bigint(20) DEFAULT NULL COMMENT '用户',
  `auto` bigint(20) DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `description` varchar(2000) NOT NULL,
  `status` tinyint(1) DEFAULT '1' COMMENT '服务记录状态',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_INSURANCE_MANAGER_SERVICE_RECORD_REF_SERVICE_idx` (`insurance_manager_service`),
  KEY `FK_INSURANCE_MANAGER_SERVICE_RECORD_REF_USER_idx` (`user`),
  KEY `FK_INSURANCE_MANAGER_SERVICE_RECORD_REF_AUTO_idx` (`auto`),
  KEY `FK_INSURANCE_MANAGER_SERVICE_RECORD_REF_SOURCE_TYPE_idx` (`source_type`),
  CONSTRAINT `FK_INSURANCE_MANAGER_SERVICE_RECORD_REF_AUTO` FOREIGN KEY (`auto`) REFERENCES `auto` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_INSURANCE_MANAGER_SERVICE_RECORD_REF_SERVICE` FOREIGN KEY (`insurance_manager_service`) REFERENCES `insurance_manager_service` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_INSURANCE_MANAGER_SERVICE_RECORD_REF_SOURCE_TYPE` FOREIGN KEY (`source_type`) REFERENCES `source_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_INSURANCE_MANAGER_SERVICE_RECORD_REF_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `insurance_package`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `insurance_package` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `auto_tax` tinyint(1) DEFAULT NULL,
  `compulsory` tinyint(1) DEFAULT NULL,
  `damage` tinyint(1) DEFAULT NULL,
  `damage_iop` tinyint(1) DEFAULT NULL,
  `driver_amount` decimal(18,2) DEFAULT NULL,
  `driver_iop` tinyint(1) DEFAULT NULL,
  `engine` tinyint(1) DEFAULT NULL,
  `engine_iop` tinyint(1) DEFAULT NULL,
  `glass` tinyint(1) DEFAULT NULL,
  `passenger_amount` decimal(18,2) DEFAULT NULL,
  `passenger_iop` tinyint(1) DEFAULT NULL,
  `scratch_amount` decimal(18,2) DEFAULT NULL,
  `scratch_iop` tinyint(1) DEFAULT NULL,
  `spontaneous_loss` tinyint(1) DEFAULT NULL,
  `theft` tinyint(1) DEFAULT NULL,
  `theft_iop` tinyint(1) DEFAULT NULL,
  `third_party_amount` decimal(18,2) DEFAULT NULL,
  `third_party_iop` tinyint(1) DEFAULT NULL,
  `unique_string` varchar(26) DEFAULT NULL,
  `glass_type` bigint(20) DEFAULT NULL,
  `type` bigint(20) DEFAULT NULL,
  `spontaneous_loss_iop` tinyint(1) DEFAULT NULL,
  `unable_find_third_party` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_u_insurance_package` (`unique_string`),
  KEY `FK_INSURANCE_PACKAGE_REF_GLASS_TYPE` (`glass_type`),
  KEY `FK_INSURANCE_PACKAGE_REF_INSURANCE_PACKAGE_TYPE` (`type`),
  CONSTRAINT `FK_INSURANCE_PACKAGE_REF_GLASS_TYPE` FOREIGN KEY (`glass_type`) REFERENCES `glass_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_INSURANCE_PACKAGE_REF_INSURANCE_PACKAGE_TYPE` FOREIGN KEY (`type`) REFERENCES `insurance_package_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=20411 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `insurance_package_type`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `insurance_package_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(2000) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `insurance_product`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `insurance_product` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `product_type` bigint(20) DEFAULT NULL,
  `web_url` varchar(500) DEFAULT NULL,
  `wap_url` varchar(500) DEFAULT NULL,
  `premium` varchar(100) DEFAULT NULL,
  `status` bigint(20) DEFAULT NULL,
  `hot_sale` tinyint(4) DEFAULT NULL,
  `insurance_product_company` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_INSURANCE_PRODUCT_REF_PRODUCT_TYPE` (`product_type`),
  KEY `FK_INSURANCE_PRODUCT_REF_STATUS` (`status`),
  KEY `FK_INSURANCE_PRODUCT_REF_INSURANCE_PRODUCT_COMPANY` (`insurance_product_company`),
  CONSTRAINT `FK_INSURANCE_PRODUCT_REF_INSURANCE_PRODUCT_COMPANY` FOREIGN KEY (`insurance_product_company`) REFERENCES `insurance_product_company` (`id`),
  CONSTRAINT `FK_INSURANCE_PRODUCT_REF_PRODUCT_TYPE` FOREIGN KEY (`product_type`) REFERENCES `insurance_product_type` (`id`),
  CONSTRAINT `FK_INSURANCE_PRODUCT_REF_STATUS` FOREIGN KEY (`status`) REFERENCES `insurance_product_status` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `insurance_product_company`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `insurance_product_company` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `code` varchar(10) DEFAULT NULL,
  `logo` varchar(50) DEFAULT NULL,
  `website_url` varchar(100) DEFAULT NULL,
  `description` varchar(4500) DEFAULT NULL,
  `mobile` varchar(45) DEFAULT NULL,
  `insurance_detail_url` varchar(100) DEFAULT NULL,
  `disable` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `insurance_product_detail`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `insurance_product_detail` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `insurance_product` bigint(20) DEFAULT NULL,
  `detail_name` bigint(20) DEFAULT NULL,
  `value` varchar(500) DEFAULT NULL,
  `display` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_PRODUCT_DETAIL_REF_INSURANCE_PRODUCT` (`insurance_product`),
  KEY `FK_PRODUCT_DETAIL_REF_DETAIL_KEY` (`detail_name`),
  CONSTRAINT `FK_PRODUCT_DETAIL_REF_DETAIL_KEY` FOREIGN KEY (`detail_name`) REFERENCES `insurance_product_detail_name` (`id`),
  CONSTRAINT `FK_PRODUCT_DETAIL_REF_INSURANCE_PRODUCT` FOREIGN KEY (`insurance_product`) REFERENCES `insurance_product` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=424 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `insurance_product_detail_name`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `insurance_product_detail_name` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `detail_name` varchar(100) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `insurance_product_status`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `insurance_product_status` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `status` varchar(50) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `insurance_product_tag`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `insurance_product_tag` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `insurance_product` bigint(20) DEFAULT NULL,
  `tag_type` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_PRODUCT_TAG_REF_INSURANCE_PRODUCT` (`insurance_product`),
  KEY `FK_PRODUCT_TAG_REF_TAG_TYPE` (`tag_type`),
  CONSTRAINT `FK_PRODUCT_TAG_REF_INSURANCE_PRODUCT` FOREIGN KEY (`insurance_product`) REFERENCES `insurance_product` (`id`),
  CONSTRAINT `FK_PRODUCT_TAG_REF_TAG_TYPE` FOREIGN KEY (`tag_type`) REFERENCES `tag_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=293 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `insurance_product_type`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `insurance_product_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `insurance_purchase_order_rebate`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `insurance_purchase_order_rebate` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `purchase_order` bigint(20) DEFAULT NULL COMMENT '订单',
  `up_rebate_channel` bigint(20) DEFAULT NULL COMMENT '上游佣金渠道',
  `up_channel_id` bigint(20) DEFAULT NULL COMMENT '上游佣金渠道id',
  `up_commercial_amount` decimal(18,2) DEFAULT '0.00' COMMENT '上游商业险佣金',
  `up_compulsory_amount` decimal(18,2) DEFAULT '0.00' COMMENT '上游交强险佣金',
  `up_commercial_rebate` decimal(18,2) DEFAULT '0.00' COMMENT '上游商业险费率',
  `up_compulsory_rebate` decimal(18,2) DEFAULT '0.00' COMMENT '上游交强险费率',
  `down_rebate_channel` bigint(20) DEFAULT NULL COMMENT '下游佣金渠道',
  `down_channel_id` bigint(20) DEFAULT NULL COMMENT '下游佣金渠道id',
  `down_commercial_amount` decimal(18,2) DEFAULT '0.00' COMMENT '下游商业险佣金',
  `down_compulsory_amount` decimal(18,2) DEFAULT '0.00' COMMENT '下游交强险佣金',
  `down_commercial_rebate` decimal(18,2) DEFAULT '0.00' COMMENT '下游商业险费率',
  `down_compulsory_rebate` decimal(18,2) DEFAULT '0.00' COMMENT '下游交强险费率',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_INSURANCE_PURCHASE_ORDER_REBATE_REF_PURCHASE_ORDER` (`purchase_order`),
  KEY `FK_INSURANCE_PURCHASE_ORDER_REBATE_REF_UP_REBATE_CHANNEL` (`up_rebate_channel`),
  KEY `FK_INSURANCE_PURCHASE_ORDER_REBATE_REF_DOWN_REBATE_CHANNEL` (`down_rebate_channel`),
  CONSTRAINT `FK_INSURANCE_PURCHASE_ORDER_REBATE_REF_DOWN_REBATE_CHANNEL` FOREIGN KEY (`down_rebate_channel`) REFERENCES `rebate_channel` (`id`),
  CONSTRAINT `FK_INSURANCE_PURCHASE_ORDER_REBATE_REF_PURCHASE_ORDER` FOREIGN KEY (`purchase_order`) REFERENCES `purchase_order` (`id`),
  CONSTRAINT `FK_INSURANCE_PURCHASE_ORDER_REBATE_REF_UP_REBATE_CHANNEL` FOREIGN KEY (`up_rebate_channel`) REFERENCES `rebate_channel` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7825 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `insurance_type`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `insurance_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(2000) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `internal_user`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `internal_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) DEFAULT NULL,
  `mobile` varchar(45) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  `user_id` varchar(100) DEFAULT NULL,
  `gender` bigint(20) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `disable` tinyint(1) DEFAULT '0',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `internal_user_type` tinyint(1) DEFAULT NULL COMMENT '系统用户类型',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_internal_user_id` (`user_id`),
  KEY `FK_INTERNAL_USER_REF_GENDER` (`gender`),
  CONSTRAINT `FK_INTERNAL_USER_REF_GENDER` FOREIGN KEY (`gender`) REFERENCES `gender` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=155 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `internal_user_login_log`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `internal_user_login_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `internal_user` bigint(20) NOT NULL,
  `ip` varchar(20) NOT NULL,
  `login_time` datetime NOT NULL,
  `platform` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_INTERNAL_USER_LOGIN_LOG_REF_INTERNAL_USER` (`internal_user`) USING BTREE,
  CONSTRAINT `FK_INTERNAL_USER_LOGIN_LOG_REF_INTERNAL_USER` FOREIGN KEY (`internal_user`) REFERENCES `internal_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19281 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `internal_user_relation`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `internal_user_relation` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `customer_user` bigint(20) DEFAULT NULL,
  `internal_user` bigint(20) DEFAULT NULL,
  `external_user` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_RELATION_CUSTOMER_REF_INTERNAL_USER` (`customer_user`),
  KEY `FK_RELATION_INTERNAL_REF_INTERNAL_USER` (`internal_user`),
  KEY `FK_RELATION_EXTERNAL_REF_INTERNAL_USER` (`external_user`),
  CONSTRAINT `FK_RELATION_CUSTOMER_REF_INTERNAL_USER` FOREIGN KEY (`customer_user`) REFERENCES `internal_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_RELATION_EXTERNAL_REF_INTERNAL_USER` FOREIGN KEY (`external_user`) REFERENCES `internal_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_RELATION_INTERNAL_REF_INTERNAL_USER` FOREIGN KEY (`internal_user`) REFERENCES `internal_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `internal_user_role`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `internal_user_role` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `internal_user` bigint(20) DEFAULT NULL,
  `role` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_INTERNAL_USER_ROLE_REF_INTERNAL_USER` (`internal_user`),
  KEY `FK_INSURANCE_USER_ROLE_REF_ROLE` (`role`),
  CONSTRAINT `FK_INSURANCE_USER_ROLE_REF_ROLE` FOREIGN KEY (`role`) REFERENCES `role` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_INTERNAL_USER_ROLE_REF_INTERNAL_USER` FOREIGN KEY (`internal_user`) REFERENCES `internal_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2657 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ios_display_message`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ios_display_message` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(400) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `icon_url` varchar(400) DEFAULT NULL,
  `description` varchar(400) DEFAULT NULL,
  `message_type` bigint(20) NOT NULL,
  `weight` int(10) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `channels` varchar(100) DEFAULT NULL,
  `enable` tinyint(4) DEFAULT '1' COMMENT '是否启用',
  `tag` varchar(200) DEFAULT '' COMMENT '标记字段',
  `version` varchar(10) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `fk_message_type` (`message_type`),
  CONSTRAINT `fk_message_type` FOREIGN KEY (`message_type`) REFERENCES `message_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=116 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_type`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `description` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `manual_quote_log`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `manual_quote_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `purchase_order` bigint(20) DEFAULT NULL,
  `error_code` varchar(200) DEFAULT NULL,
  `operator` bigint(20) DEFAULT NULL,
  `operate_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `manual_quote_log_ibfk_1` (`purchase_order`),
  KEY `manual_quote_log_ibfk_2` (`operator`),
  CONSTRAINT `manual_quote_log_ibfk_1` FOREIGN KEY (`purchase_order`) REFERENCES `purchase_order` (`id`),
  CONSTRAINT `manual_quote_log_ibfk_2` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=306 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `marketing`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `marketing` (
  `id` bigint(20) NOT NULL COMMENT '营销活动主表',
  `name` varchar(100) NOT NULL,
  `code` varchar(9) NOT NULL,
  `begin_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `gift_expire_date` varchar(100) DEFAULT NULL COMMENT '优惠券过期日期',
  `channel` varchar(100) DEFAULT NULL,
  `amount` varchar(100) DEFAULT NULL COMMENT '营销活动赠送代金券金额，可包含多个，用分号分割',
  `full_limit` varchar(500) DEFAULT NULL COMMENT '优惠券使用的满减条件，如订单满1000才能使用',
  `gift_class` varchar(100) DEFAULT NULL,
  `marketing_type` varchar(10) DEFAULT NULL COMMENT '活动类型',
  `quote_support` tinyint(1) DEFAULT '1' COMMENT '是否支持报价时领取优惠券 1 支持 0 不支持',
  `short_name` varchar(100) DEFAULT NULL COMMENT '优惠活动简称',
  `marketing_service` varchar(200) DEFAULT NULL COMMENT 'serviceBeanID',
  `description` varchar(2000) DEFAULT NULL,
  `activity_type` bigint(20) DEFAULT '1' COMMENT '活动类型',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_MARKETING_REF_ACTIVITY_TYPE` (`activity_type`),
  CONSTRAINT `FK_MARKETING_REF_ACTIVITY_TYPE` FOREIGN KEY (`activity_type`) REFERENCES `activity_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `marketing_img`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `marketing_img` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL COMMENT '图片名称',
  `description` varchar(500) DEFAULT NULL COMMENT '图片描述',
  `icon_url` varchar(500) DEFAULT NULL COMMENT '图片本身的url',
  `url` varchar(500) DEFAULT NULL COMMENT '图片link的url',
  `use_type` varchar(45) DEFAULT NULL COMMENT '图片关联的类型',
  `use_code` varchar(45) DEFAULT NULL COMMENT '图片关联的对象值',
  `rank` bigint(10) DEFAULT NULL COMMENT '排列顺序,默认为降序',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `marketing_insurance_type`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `marketing_insurance_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(2000) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `marketing_lottery`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `marketing_lottery` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `marketing_id` bigint(20) NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `mobile` varchar(11) DEFAULT NULL,
  `resource_table_name` varchar(100) NOT NULL,
  `resource_id` bigint(20) NOT NULL,
  `create_time` datetime NOT NULL,
  `used` tinyint(1) DEFAULT '0',
  `lottery_time` datetime DEFAULT NULL,
  `gift_name` varchar(100) DEFAULT NULL,
  `gift_quantity` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=197 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `marketing_relation`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `marketing_relation` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `master_table_name` varchar(100) NOT NULL,
  `master_id` bigint(20) NOT NULL,
  `slave_table_name` varchar(100) NOT NULL,
  `slave_id` bigint(20) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2189 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `marketing_res`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `marketing_res` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `marketing_id` bigint(20) DEFAULT NULL,
  `res_package_id` bigint(20) DEFAULT NULL,
  `res_package_name` varchar(45) DEFAULT NULL,
  `res_name` varchar(45) DEFAULT NULL,
  `amount` decimal(18,2) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `marketing_res_package`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `marketing_res_package` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `marketing_id` bigint(20) DEFAULT NULL,
  `amount` decimal(18,2) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `resMemoInfo` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `marketing_rule`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `marketing_rule` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `marketing` bigint(20) DEFAULT NULL,
  `title` varchar(45) DEFAULT NULL,
  `sub_title` varchar(45) DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  `area` bigint(20) DEFAULT NULL,
  `channel` bigint(20) DEFAULT NULL,
  `insurance_company` bigint(20) DEFAULT NULL,
  `activity_type` bigint(20) DEFAULT NULL,
  `status` bigint(20) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `effective_date` date DEFAULT NULL,
  `expire_date` date DEFAULT NULL,
  `top_image` varchar(200) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `operator` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `area_idx` (`area`),
  KEY `marketing_disconut_activity_type` (`activity_type`),
  KEY `marketing_disconut_channel` (`channel`),
  KEY `marketing_disconut_insurance_company` (`insurance_company`),
  KEY `marketing_disconut_marketing_idx` (`marketing`),
  KEY `FK_MARKETING_RULE_REF_STATUS_idx` (`status`),
  KEY `rule_area_channel_company` (`area`,`channel`,`insurance_company`),
  KEY `marketing_rule_ibfk_7` (`operator`),
  CONSTRAINT `FK_MARKETING_RULE_REF_ACTIVITY_TYPE` FOREIGN KEY (`activity_type`) REFERENCES `activity_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_MARKETING_RULE_REF_AREA` FOREIGN KEY (`area`) REFERENCES `area` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_MARKETING_RULE_REF_CHANNEL` FOREIGN KEY (`channel`) REFERENCES `channel` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_MARKETING_RULE_REF_COMPANY` FOREIGN KEY (`insurance_company`) REFERENCES `insurance_company` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_MARKETING_RULE_REF_MARKETING` FOREIGN KEY (`marketing`) REFERENCES `marketing` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_MARKETING_RULE_REF_STATUS` FOREIGN KEY (`status`) REFERENCES `marketing_rule_status` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `marketing_rule_ibfk_7` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5210 DEFAULT CHARSET=utf8 COMMENT='活动优惠规则对照表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `marketing_rule_status`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `marketing_rule_status` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(2000) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `marketing_schedule_condition`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `marketing_schedule_condition` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `schedule_condition` bigint(20) DEFAULT NULL,
  `marketing` bigint(20) DEFAULT NULL,
  `channel` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_MSC_REF_SCHEDULE_CONDITION` (`schedule_condition`),
  KEY `FK_MSC_REF_MARKETING` (`marketing`),
  KEY `FK_MSC_REF_CHANNEL` (`channel`),
  CONSTRAINT `FK_MSC_REF_MARKETING` FOREIGN KEY (`marketing`) REFERENCES `marketing` (`id`),
  CONSTRAINT `FK_MSC_REF_SCHEDULE_CONDITION` FOREIGN KEY (`schedule_condition`) REFERENCES `schedule_condition` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `marketing_shared`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `marketing_shared` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `marketing_rule` bigint(20) NOT NULL,
  `wechat_shared` tinyint(1) NOT NULL,
  `wechat_main_title` varchar(100) DEFAULT NULL,
  `wechat_sub_title` varchar(100) DEFAULT NULL,
  `alipay_shared` tinyint(1) NOT NULL,
  `alipay_main_title` varchar(100) DEFAULT NULL,
  `alipay_sub_title` varchar(100) DEFAULT NULL,
  `shared_icon` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_MARKETING_SHARED_REF_MARKETING_RULE` (`marketing_rule`),
  CONSTRAINT `FK_MARKETING_SHARED_REF_MARKETING_RULE` FOREIGN KEY (`marketing_rule`) REFERENCES `marketing_rule` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5210 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `marketing_success`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `marketing_success` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `marketing_id` bigint(20) NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `mobile` varchar(11) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `effect_date` datetime NOT NULL,
  `failure_date` datetime NOT NULL,
  `amount` decimal(18,2) DEFAULT NULL,
  `user_code` varchar(100) DEFAULT NULL,
  `user_type` varchar(100) DEFAULT NULL,
  `source_channel` varchar(45) DEFAULT NULL,
  `license_plate_no` varchar(45) DEFAULT NULL COMMENT '车牌号',
  `area` bigint(10) DEFAULT NULL COMMENT '所属地区',
  `synced` tinyint(1) DEFAULT '0' COMMENT '记录是否已同步到gift表',
  `description` varchar(2000) DEFAULT NULL,
  `channel` bigint(20) DEFAULT NULL,
  `detail_table_name` varchar(100) DEFAULT NULL,
  `detail` bigint(20) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `marketing_id` (`marketing_id`),
  KEY `mobile_synced` (`synced`,`mobile`),
  KEY `FK_MARKETING_SUCCESS_REF_CHANNEL` (`channel`),
  KEY `index_detail` (`detail`),
  KEY `IDX_MARKETING_SUCCESS_MOBILE` (`mobile`),
  CONSTRAINT `FK_MARKETING_SUCCESS_REF_CHANNEL` FOREIGN KEY (`channel`) REFERENCES `channel` (`id`),
  CONSTRAINT `marketing_success_ibfk_1` FOREIGN KEY (`marketing_id`) REFERENCES `marketing` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=552706 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `marketing_user_operation`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `marketing_user_operation` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `marketing_id` bigint(20) NOT NULL,
  `mobile` varchar(11) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `user_code` varchar(100) DEFAULT NULL,
  `user_type` varchar(100) DEFAULT NULL,
  `operate_date` datetime NOT NULL,
  `operate_type` varchar(100) DEFAULT NULL,
  `operate_channel` varchar(100) DEFAULT NULL,
  `target_channel` varchar(100) DEFAULT NULL,
  `remarks` varchar(500) DEFAULT NULL,
  `source_channel` varchar(45) DEFAULT NULL,
  `user` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_MMO` (`marketing_id`,`mobile`,`operate_type`),
  KEY `index_MO` (`marketing_id`,`operate_date`)
) ENGINE=InnoDB AUTO_INCREMENT=2933 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `member_points`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_points` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `comments` varchar(2000) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `effective_date` datetime DEFAULT NULL,
  `expire_date` datetime DEFAULT NULL,
  `points` decimal(18,0) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `operator` bigint(20) DEFAULT NULL,
  `source` bigint(20) DEFAULT NULL,
  `user` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_MEMBER_POINTS_REF_INTERNAL_USER` (`operator`),
  KEY `FK_MEMBER_POINTS_REF_MEMBER_POINTS_REASON` (`source`),
  KEY `FK_MEMBER_POINTS_REF_USER` (`user`),
  CONSTRAINT `FK_MEMBER_POINTS_REF_INTERNAL_USER` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_MEMBER_POINTS_REF_MEMBER_POINTS_REASON` FOREIGN KEY (`source`) REFERENCES `member_points_reason` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_MEMBER_POINTS_REF_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `member_points_reason`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_points_reason` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(2000) DEFAULT NULL,
  `source` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `message_status`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `message_status` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `status` varchar(45) DEFAULT NULL COMMENT '状态',
  `description` varchar(200) DEFAULT NULL COMMENT '描述',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `message_template`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `message_template` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `message_conveter` varchar(120) DEFAULT NULL,
  `message_template` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `message_type`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `message_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `type` varchar(100) DEFAULT NULL,
  `description` varchar(400) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `message_variable`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `message_variable` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `code` varchar(45) DEFAULT NULL COMMENT '变量编号',
  `name` varchar(45) DEFAULT NULL COMMENT '变量名称',
  `type` varchar(45) DEFAULT NULL COMMENT '变量类型',
  `placeholder` varchar(45) DEFAULT NULL COMMENT '变量解释',
  `length` smallint(4) DEFAULT NULL COMMENT '变量长度',
  `parameter` varchar(45) DEFAULT NULL COMMENT '使用到的参数',
  `model_class` varchar(100) DEFAULT NULL COMMENT '获取值关联的Model类',
  `model_method` varchar(100) DEFAULT NULL COMMENT '获取值关联的Model类方法',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_message_variable_code` (`code`),
  UNIQUE KEY `idx_message_variable_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mobile_area`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mobile_area` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `mobile` varchar(50) DEFAULT NULL,
  `area` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_MOBILE_AREA_REF_AREA` (`area`),
  KEY `MOBILE` (`mobile`),
  CONSTRAINT `FK_MOBILE_AREA_REF_AREA` FOREIGN KEY (`area`) REFERENCES `area` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=694965 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mobile_device_pic_rule`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mobile_device_pic_rule` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `message_type` varchar(200) NOT NULL COMMENT '图片显示类别',
  `client` varchar(200) NOT NULL COMMENT '客户端类型',
  `version` varchar(200) NOT NULL COMMENT '是否默认（每个类别应该有一个默认）',
  `screen_size` varchar(500) NOT NULL COMMENT '屏幕尺寸',
  `image_suffix` varchar(200) NOT NULL COMMENT '对应图片名字后缀',
  `description` varchar(400) DEFAULT NULL,
  `order` int(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1002 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `monitor_data_type`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `monitor_data_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL COMMENT '监控数据类型名称',
  `description` varchar(2000) DEFAULT NULL,
  `show_flag` tinyint(1) DEFAULT '1' COMMENT '是否显示',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `oc_quote_source`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oc_quote_source` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `operation_type`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `operation_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `description` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `order_agent`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_agent` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `purchase_order` bigint(20) DEFAULT NULL,
  `agent` bigint(20) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `FK_ORDER_AGENT_REF_PURCHASE_ORDER` (`purchase_order`) USING BTREE,
  KEY `FK_ORDER_AGENT_REF_AGENT` (`agent`),
  CONSTRAINT `FK_ORDER_AGENT_REF_AGENT` FOREIGN KEY (`agent`) REFERENCES `agent` (`id`),
  CONSTRAINT `FK_ORDER_AGENT_REF_PURCHASE_ORDER` FOREIGN KEY (`purchase_order`) REFERENCES `purchase_order` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10978 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `order_cancel_reason`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_cancel_reason` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `cancel_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `description` varchar(400) DEFAULT NULL,
  `order_id` bigint(20) DEFAULT NULL,
  `order_cancel_reason_type_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pk_order_id` (`order_id`),
  KEY `pk_order_cancle_type_id` (`order_cancel_reason_type_id`),
  CONSTRAINT `pk_order_cancle_type_id` FOREIGN KEY (`order_cancel_reason_type_id`) REFERENCES `order_cancel_reason_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `pk_order_id` FOREIGN KEY (`order_id`) REFERENCES `purchase_order` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=315 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `order_cancel_reason_type`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_cancel_reason_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `reason` varchar(200) NOT NULL,
  `description` varchar(400) DEFAULT NULL,
  `order` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `order_cooperation_info`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_cooperation_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `purchase_order` bigint(20) DEFAULT NULL COMMENT '订单',
  `area` bigint(20) DEFAULT NULL COMMENT '城市',
  `insurance_company` bigint(20) DEFAULT NULL COMMENT '保险公司',
  `area_contact_info` bigint(20) DEFAULT NULL COMMENT '车车分站',
  `institution` bigint(20) DEFAULT NULL COMMENT '出单机构',
  `appoint_time` datetime DEFAULT NULL COMMENT '指定出单机构时间',
  `status` bigint(20) DEFAULT NULL COMMENT '合作出单状态',
  `reason` varchar(45) DEFAULT NULL COMMENT '订单异常原因',
  `rebate_status` tinyint(1) DEFAULT NULL COMMENT '确认佣金到账状态',
  `audit_status` tinyint(1) DEFAULT NULL COMMENT '审核状态',
  `income_status` tinyint(1) DEFAULT NULL COMMENT '收益状态',
  `match_status` tinyint(1) DEFAULT NULL COMMENT '险种保额匹配状态',
  `quote_status` tinyint(1) DEFAULT NULL COMMENT '报价状态',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  `operator` bigint(20) DEFAULT NULL COMMENT '最后操作人',
  `assigner` bigint(20) DEFAULT NULL COMMENT '指定操作人',
  PRIMARY KEY (`id`),
  KEY `FK_ORDER_COOPERATION_INFO_REF_PURCHASE_ORDER` (`purchase_order`),
  KEY `FK_ORDER_COOPERATION_INFO_REF_AREA` (`area`),
  KEY `FK_ORDER_COOPERATION_INFO_REF_INSURANCE_COMPANY` (`insurance_company`),
  KEY `FK_ORDER_COOPERATION_INFO_REF_AREA_CONTACT_INFO` (`area_contact_info`),
  KEY `FK_ORDER_COOPERATION_INFO_REF_INSTITUTION` (`institution`),
  KEY `FK_ORDER_COOPERATION_INFO_REF_STATUS` (`status`),
  KEY `FK_ORDER_COOPERATION_INFO_REF_OPERATOR` (`operator`),
  KEY `FK_ORDER_COOPERATION_INFO_REF_ASSIGNER` (`assigner`),
  CONSTRAINT `FK_ORDER_COOPERATION_INFO_REF_AREA` FOREIGN KEY (`area`) REFERENCES `area` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_ORDER_COOPERATION_INFO_REF_AREA_CONTACT_INFO` FOREIGN KEY (`area_contact_info`) REFERENCES `area_contact_info` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_ORDER_COOPERATION_INFO_REF_ASSIGNER` FOREIGN KEY (`assigner`) REFERENCES `internal_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_ORDER_COOPERATION_INFO_REF_INSTITUTION` FOREIGN KEY (`institution`) REFERENCES `institution` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_ORDER_COOPERATION_INFO_REF_INSURANCE_COMPANY` FOREIGN KEY (`insurance_company`) REFERENCES `insurance_company` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_ORDER_COOPERATION_INFO_REF_OPERATOR` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_ORDER_COOPERATION_INFO_REF_PURCHASE_ORDER` FOREIGN KEY (`purchase_order`) REFERENCES `purchase_order` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_ORDER_COOPERATION_INFO_REF_STATUS` FOREIGN KEY (`status`) REFERENCES `order_cooperation_status` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `order_cooperation_status`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_cooperation_status` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `status` varchar(45) DEFAULT NULL COMMENT '状态',
  `description` varchar(200) DEFAULT NULL COMMENT '描述',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `order_operation_info`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_operation_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `purchase_order` bigint(20) DEFAULT NULL,
  `original_status` bigint(20) DEFAULT NULL,
  `current_status` bigint(20) DEFAULT NULL,
  `assigner` bigint(20) DEFAULT NULL,
  `operator` bigint(20) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `re_confirm_date` date DEFAULT NULL,
  `pay_time` date DEFAULT NULL,
  `send_time` date DEFAULT NULL,
  `pay_period` varchar(20) DEFAULT NULL,
  `send_period` varchar(20) DEFAULT NULL,
  `confirm_no` varchar(100) DEFAULT NULL,
  `insurance_inputter` bigint(20) DEFAULT NULL,
  `comment` varchar(2000) DEFAULT NULL,
  `owner` bigint(20) DEFAULT NULL COMMENT '订单当前所有者',
  `confirm_order_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_ORDER_OPERATION_INFO_REF_ORDER` (`purchase_order`),
  KEY `FK_ORDER_OPERATION_INFO_ORIGINAL_REF_INSURE_STATUS` (`original_status`),
  KEY `FK_ORDER_OPERATION_INFO_CURRENT_REF_INSURE_STATUS` (`current_status`),
  KEY `FK_ORDER_OPERATION_INFO_ASSIGNER_REF_INTERNAL_USER` (`assigner`),
  KEY `FK_ORDER_OPERATION_INFO_OPERATOR_REF_INTERNAL_USER` (`operator`),
  KEY `FK_ORDER_OPERATION_INFO_REF_INTERNAL_USER_INSURANCE_INPUTTER` (`insurance_inputter`),
  KEY `FK_ORDER_OPERATION_INFO_REF_INTERNAL_USER_OWNER` (`owner`),
  KEY `FK_ORDER_OPERATION_INFO_CREATE_TIME` (`create_time`),
  KEY `FK_ORDER_OPERATION_INFO_UPDATE_TIME` (`update_time`),
  CONSTRAINT `FK_ORDER_OPERATION_INFO_ASSIGNER_REF_INTERNAL_USER` FOREIGN KEY (`assigner`) REFERENCES `internal_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_ORDER_OPERATION_INFO_CURRENT_REF_INSURE_STATUS` FOREIGN KEY (`current_status`) REFERENCES `order_transmission_status` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_ORDER_OPERATION_INFO_OPERATOR_REF_INTERNAL_USER` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_ORDER_OPERATION_INFO_ORIGINAL_REF_INSURE_STATUS` FOREIGN KEY (`original_status`) REFERENCES `order_transmission_status` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_ORDER_OPERATION_INFO_REF_INTERNAL_USER_INSURANCE_INPUTTER` FOREIGN KEY (`insurance_inputter`) REFERENCES `internal_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_ORDER_OPERATION_INFO_REF_INTERNAL_USER_OWNER` FOREIGN KEY (`owner`) REFERENCES `internal_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_ORDER_OPERATION_INFO_REF_ORDER` FOREIGN KEY (`purchase_order`) REFERENCES `purchase_order` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=84702 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `order_process_history`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_process_history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `purchase_order` bigint(20) DEFAULT NULL COMMENT '订单',
  `original_status` bigint(20) DEFAULT NULL COMMENT '原出单状态，关联合作出单状态表或独立出单状态表',
  `current_status` bigint(20) DEFAULT NULL COMMENT '新出单状态，关联合作出单状态表或独立出单状态表',
  `order_process_type` bigint(20) DEFAULT NULL COMMENT '订单处理类型',
  `comment` varchar(2000) DEFAULT NULL COMMENT '备注',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `operator` bigint(20) DEFAULT NULL COMMENT '操作人',
  PRIMARY KEY (`id`),
  KEY `FK_ORDER_PROCESS_HISTORY_REF_PURCHASE_ORDER` (`purchase_order`),
  KEY `FK_ORDER_PROCESS_HISTORY_REF_TYPE` (`order_process_type`),
  KEY `FK_ORDER_PROCESS_HISTORY_REF_OPERATOR` (`operator`),
  CONSTRAINT `FK_ORDER_PROCESS_HISTORY_REF_OPERATOR` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_ORDER_PROCESS_HISTORY_REF_PURCHASE_ORDER` FOREIGN KEY (`purchase_order`) REFERENCES `purchase_order` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_ORDER_PROCESS_HISTORY_REF_TYPE` FOREIGN KEY (`order_process_type`) REFERENCES `order_process_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=102821 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `order_process_type`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_process_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(45) DEFAULT NULL COMMENT '类型名称',
  `description` varchar(200) DEFAULT NULL COMMENT '描述',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `order_source_type`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_source_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `order_status`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_status` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(2000) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `order_transmission_status`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_transmission_status` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `status` varchar(45) DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  `reference` bigint(20) DEFAULT NULL COMMENT '新订单状态',
  PRIMARY KEY (`id`),
  KEY `FK_ORDER_TRANSMISSION_STATUS_REF_ORDER_TRANSMISSION_STATUS` (`reference`),
  CONSTRAINT `FK_ORDER_TRANSMISSION_STATUS_REF_ORDER_TRANSMISSION_STATUS` FOREIGN KEY (`reference`) REFERENCES `order_transmission_status` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `order_type`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(2000) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `parameter`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `parameter` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `param_name` varchar(45) DEFAULT NULL,
  `param_value` text,
  `access_log` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_PARAMETER_REF_ACCESS_LOG` (`access_log`),
  CONSTRAINT `FK_PARAMETER_REF_ACCESS_LOG` FOREIGN KEY (`access_log`) REFERENCES `access_log` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2181218 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `parser_mutual_message`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `parser_mutual_message` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_time` datetime DEFAULT NULL,
  `content` text,
  `step_note` varchar(100) DEFAULT NULL,
  `message_type` smallint(6) DEFAULT NULL,
  `license_plate_no` varchar(45) DEFAULT NULL,
  `insurance_company` bigint(20) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_PARSER_MUTUAL_MESSAGE_REF_INSURANCE_COMPANY` (`insurance_company`),
  CONSTRAINT `FK_PARSER_MUTUAL_MESSAGE_REF_INSURANCE_COMPANY` FOREIGN KEY (`insurance_company`) REFERENCES `insurance_company` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31543 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `partner`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `partner` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL COMMENT '合作商名称',
  `cooperation_time` date DEFAULT NULL COMMENT '预计首次合作时间',
  `partner_type` bigint(20) DEFAULT NULL COMMENT '合作商类型',
  `enable` tinyint(1) DEFAULT '0' COMMENT '是否启用',
  `comment` varchar(2000) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `operator` bigint(20) DEFAULT NULL COMMENT '操作人',
  PRIMARY KEY (`id`),
  KEY `FK_PARTNER_REF_PARTNER_TYPE` (`partner_type`),
  KEY `FK_PARTNER_REF_INTERNAL_USER` (`operator`),
  KEY `idx_partner_name` (`name`),
  CONSTRAINT `FK_PARTNER_REF_INTERNAL_USER` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_PARTNER_REF_PARNTER_TYPE` FOREIGN KEY (`partner_type`) REFERENCES `partner_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `partner_attachment`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `partner_attachment` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `partner` bigint(20) DEFAULT NULL COMMENT '合作商',
  `contract_url` varchar(300) DEFAULT NULL COMMENT '合同文件URL',
  `contract_name` varchar(300) DEFAULT NULL COMMENT '合同原始文件名称',
  `technical_document_url` varchar(300) DEFAULT NULL COMMENT '技术文档文件URL',
  `technical_document_name` varchar(300) DEFAULT NULL COMMENT '技术文档原始文件名称',
  PRIMARY KEY (`id`),
  KEY `FK_PPARTNER_ATTACHMENT_REF_PARTNER` (`partner`),
  CONSTRAINT `FK_PPARTNER_ATTACHMENT_REF_PARTNER` FOREIGN KEY (`partner`) REFERENCES `partner` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `partner_cooperation_mode`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `partner_cooperation_mode` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `partner` bigint(20) DEFAULT NULL COMMENT '合作商',
  `cooperation_mode` bigint(20) DEFAULT NULL COMMENT '合作方式',
  PRIMARY KEY (`id`),
  KEY `FK_PARTNER_COOPERATION_MODE_REF_PARTNER` (`partner`),
  KEY `FK_PARTNER_COOPERATION_MODE_REF_COOPERATION_MODE` (`cooperation_mode`),
  CONSTRAINT `FK_PARTNER_COOPERATION_MODE_REF_COOPERATION_MODE` FOREIGN KEY (`cooperation_mode`) REFERENCES `cooperation_mode` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_PARTNER_COOPERATION_MODE_REF_PARTNER` FOREIGN KEY (`partner`) REFERENCES `partner` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=134 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `partner_gift_status`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `partner_gift_status` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `partner_gift_sync`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `partner_gift_sync` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `gift` bigint(20) NOT NULL,
  `channel` bigint(20) NOT NULL,
  `serial_number` varchar(32) DEFAULT NULL,
  `partner_gift_status` bigint(20) DEFAULT NULL,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `error_msg` varchar(2000) DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_gift_id` (`gift`),
  KEY `fk_channel_id` (`channel`),
  KEY `fk_coupon_status_id` (`partner_gift_status`),
  CONSTRAINT `fk_channel_id` FOREIGN KEY (`channel`) REFERENCES `channel` (`id`),
  CONSTRAINT `fk_gift_id` FOREIGN KEY (`gift`) REFERENCES `gift` (`id`),
  CONSTRAINT `fk_partner_gift_status` FOREIGN KEY (`partner_gift_status`) REFERENCES `partner_gift_status` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15598 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `partner_order`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `partner_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `partner_third` bigint(20) NOT NULL,
  `partner_order_no` varchar(200) DEFAULT NULL,
  `partner_user_id` bigint(20) DEFAULT NULL,
  `purchase_order_id` bigint(20) NOT NULL,
  `channel` varchar(20) DEFAULT NULL COMMENT '汽车之家有两种app，主app和查违章都下单，此字段记录订单来源于哪个app',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `update_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `notify_info` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_partner_third` (`partner_third`),
  KEY `fk_partner_user_id` (`partner_user_id`),
  KEY `fk_purchase_order_id` (`purchase_order_id`),
  CONSTRAINT `fk_partner_third` FOREIGN KEY (`partner_third`) REFERENCES `api_partner` (`id`),
  CONSTRAINT `fk_partner_user_id` FOREIGN KEY (`partner_user_id`) REFERENCES `partner_user` (`id`),
  CONSTRAINT `fk_purchase_order_id` FOREIGN KEY (`purchase_order_id`) REFERENCES `purchase_order` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12854 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `partner_order_sync`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `partner_order_sync` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `partner_order` bigint(20) DEFAULT NULL,
  `status` int(2) DEFAULT '0',
  `description` varchar(2000) DEFAULT NULL,
  `sync_body` text,
  `send_sync_message` text,
  `receive_sync_message` text,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `purchase_order_status` bigint(20) DEFAULT NULL,
  `partner_order_sync_request_parent` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_PARTNER_ORDER_SYNC_REF_PARTNER_ORDER` (`partner_order`),
  KEY `partner_order_sync_ibfk_2` (`purchase_order_status`),
  KEY `partner_order_sync_ibfk_3` (`partner_order_sync_request_parent`),
  CONSTRAINT `FK_PARTNER_ORDER_SYNC_REF_PARTNER_ORDER` FOREIGN KEY (`partner_order`) REFERENCES `partner_order` (`id`),
  CONSTRAINT `partner_order_sync_ibfk_2` FOREIGN KEY (`purchase_order_status`) REFERENCES `order_status` (`id`),
  CONSTRAINT `partner_order_sync_ibfk_3` FOREIGN KEY (`partner_order_sync_request_parent`) REFERENCES `partner_order_sync` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13607 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `partner_type`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `partner_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL COMMENT '合作商类型名称',
  `description` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `partner_user`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `partner_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `partner` bigint(20) NOT NULL,
  `user` bigint(20) NOT NULL,
  `partner_id` varchar(1024) DEFAULT NULL,
  `partner_mobile` varchar(45) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `description` text COMMENT 'partner修改描述',
  PRIMARY KEY (`id`),
  UNIQUE KEY `un_uid` (`partner`,`user`),
  KEY `fk_user` (`user`),
  KEY `fk_partner` (`partner`),
  CONSTRAINT `fk_partner` FOREIGN KEY (`partner`) REFERENCES `api_partner` (`id`),
  CONSTRAINT `fk_user` FOREIGN KEY (`user`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=569602 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payment`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `amount` decimal(18,2) DEFAULT NULL,
  `comments` varchar(2000) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `thirdparty_payment_no` varchar(100) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `channel` bigint(20) DEFAULT NULL,
  `operator` bigint(20) DEFAULT NULL,
  `purchase_order` bigint(20) DEFAULT NULL,
  `status` bigint(20) DEFAULT NULL,
  `user` bigint(20) DEFAULT NULL,
  `client_type` bigint(20) DEFAULT NULL,
  `out_trade_no` varchar(30) DEFAULT NULL,
  `upstream_id` bigint(20) DEFAULT NULL,
  `payment_type` bigint(20) DEFAULT NULL,
  `purchase_order_amend` bigint(20) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `purchase_order_history` bigint(20) DEFAULT NULL,
  `mch_id` varchar(20) DEFAULT NULL,
  `app_id` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_payment_channel_payment_no` (`channel`,`thirdparty_payment_no`),
  KEY `FK_PAYMENT_REF_PAYMENT_CHANNEL` (`channel`),
  KEY `FK_PAYMENT_REF_INTERNAL_USER` (`operator`),
  KEY `FK_PAYMENT_REF_PURCHASE_ORDER` (`purchase_order`),
  KEY `FK_PAYMENT_REF_PAYMENT_STATUS` (`status`),
  KEY `FK_PAYMENT_REF_USER` (`user`),
  KEY `FK_PAYMENT_REF_CHANNEL` (`client_type`),
  KEY `payment_ibfk_7` (`upstream_id`),
  KEY `payment_ibfk_9` (`purchase_order_amend`),
  KEY `payment_ibfk_8` (`payment_type`),
  KEY `payment_ref_order_history` (`purchase_order_history`),
  CONSTRAINT `FK_PAYMENT_REF_CHANNEL` FOREIGN KEY (`client_type`) REFERENCES `channel` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_PAYMENT_REF_INTERNAL_USER` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_PAYMENT_REF_PAYMENT_CHANNEL` FOREIGN KEY (`channel`) REFERENCES `payment_channel` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_PAYMENT_REF_PAYMENT_STATUS` FOREIGN KEY (`status`) REFERENCES `payment_status` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_PAYMENT_REF_PURCHASE_ORDER` FOREIGN KEY (`purchase_order`) REFERENCES `purchase_order` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_PAYMENT_REF_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `payment_ibfk_7` FOREIGN KEY (`upstream_id`) REFERENCES `payment` (`id`),
  CONSTRAINT `payment_ibfk_8` FOREIGN KEY (`payment_type`) REFERENCES `payment_type` (`id`),
  CONSTRAINT `payment_ibfk_9` FOREIGN KEY (`purchase_order_amend`) REFERENCES `purchase_order_amend` (`id`),
  CONSTRAINT `payment_ref_order_history` FOREIGN KEY (`purchase_order_history`) REFERENCES `purchase_order_history` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=102300 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payment_channel`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_channel` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `channel` varchar(45) DEFAULT NULL,
  `customer_pay` smallint(1) DEFAULT NULL COMMENT '区分支付渠道是用户支付，还是车车支付（代金券，代理人减免等）',
  `description` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payment_status`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_status` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(2000) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payment_type`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_type` (
  `id` bigint(20) NOT NULL,
  `name` varchar(50) NOT NULL DEFAULT '',
  `description` varchar(2000) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `perfect_driver`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `perfect_driver` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `user` bigint(20) DEFAULT NULL COMMENT '用户',
  `auto` bigint(20) DEFAULT NULL COMMENT '车辆',
  `channel` bigint(20) NOT NULL COMMENT '渠道',
  `purchase_order` bigint(20) DEFAULT NULL COMMENT '订单',
  `renew_purchase_order` bigint(20) DEFAULT NULL COMMENT '续保订单',
  `insured_name` varchar(45) DEFAULT NULL COMMENT '被保险人姓名',
  `insured_id_no` varchar(45) DEFAULT NULL COMMENT '被保险人身份证号',
  `expire_date` datetime DEFAULT NULL COMMENT '保险到期日',
  `category` varchar(10) DEFAULT NULL COMMENT '车辆种类',
  `insurance_company_ids` varchar(45) DEFAULT NULL COMMENT '用户预选保险公司id',
  `insurance_package` bigint(20) DEFAULT NULL COMMENT '用户预选保险套餐',
  `audit_status` tinyint(1) DEFAULT '0' COMMENT '审核状态',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  `transfer_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_PERFECT_DRIVER_REF_USER` (`user`),
  KEY `FK_PERFECT_DRIVER_REF_AUTO` (`auto`),
  KEY `FK_PERFECT_DRIVER_REF_CHANNEL` (`channel`),
  KEY `FK_PERFECT_DRIVER_REF_PURCHASE_ORDER` (`purchase_order`),
  KEY `FK_PERFECT_DRIVER_REF_RENEW_PURCHASE_ORDER` (`renew_purchase_order`),
  KEY `FK_PERFECT_DRIVER_REF_INSURANCE_PACKAGE` (`insurance_package`),
  CONSTRAINT `FK_PERFECT_DRIVER_REF_AUTO` FOREIGN KEY (`auto`) REFERENCES `auto` (`id`),
  CONSTRAINT `FK_PERFECT_DRIVER_REF_CHANNEL` FOREIGN KEY (`channel`) REFERENCES `channel` (`id`),
  CONSTRAINT `FK_PERFECT_DRIVER_REF_INSURANCE_PACKAGE` FOREIGN KEY (`insurance_package`) REFERENCES `insurance_package` (`id`),
  CONSTRAINT `FK_PERFECT_DRIVER_REF_PURCHASE_ORDER` FOREIGN KEY (`purchase_order`) REFERENCES `purchase_order` (`id`),
  CONSTRAINT `FK_PERFECT_DRIVER_REF_RENEW_PURCHASE_ORDER` FOREIGN KEY (`renew_purchase_order`) REFERENCES `purchase_order` (`id`),
  CONSTRAINT `FK_PERFECT_DRIVER_REF_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1016 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `perfect_driver_process`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `perfect_driver_process` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `perfect_driver` bigint(20) DEFAULT NULL COMMENT '好车主',
  `status` bigint(20) DEFAULT NULL COMMENT '跟进人操作状态',
  `order_center_operator` bigint(20) DEFAULT NULL COMMENT 'C端操作人',
  `call_center_operator` bigint(20) DEFAULT NULL COMMENT '电销操作人',
  `oc_operation_time` datetime DEFAULT NULL COMMENT 'C端操作人操作时间',
  `cc_operation_time` datetime DEFAULT NULL COMMENT '电销操作人操作时间',
  PRIMARY KEY (`id`),
  KEY `FK_PERFECT_DRIVER_PROCESS_REF_PERFECT_DRIVER` (`perfect_driver`),
  KEY `FK_PERFECT_DRIVER_PROCESS_REF_STATUS` (`status`),
  KEY `FK_PERFECT_DRIVER_REF_QUOTE_OPERATOR` (`order_center_operator`),
  KEY `FK_PERFECT_DRIVER_REF_CONTACT_OPERATOR` (`call_center_operator`),
  CONSTRAINT `FK_PERFECT_DRIVER_PROCESS_REF_CC_OPERATOR` FOREIGN KEY (`call_center_operator`) REFERENCES `internal_user` (`id`),
  CONSTRAINT `FK_PERFECT_DRIVER_PROCESS_REF_OC_OPERATOR` FOREIGN KEY (`order_center_operator`) REFERENCES `internal_user` (`id`),
  CONSTRAINT `FK_PERFECT_DRIVER_PROCESS_REF_PERFECT_DRIVER` FOREIGN KEY (`perfect_driver`) REFERENCES `perfect_driver` (`id`),
  CONSTRAINT `FK_PERFECT_DRIVER_PROCESS_REF_STATUS` FOREIGN KEY (`status`) REFERENCES `perfect_driver_process_status` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1016 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `perfect_driver_process_history`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `perfect_driver_process_history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `perfect_driver` bigint(20) DEFAULT NULL COMMENT '好车主',
  `comment` varchar(100) DEFAULT NULL COMMENT '备注',
  `operator` bigint(20) DEFAULT NULL COMMENT '操作人',
  `operate_type` tinyint(1) DEFAULT '0' COMMENT '操作类型',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `FK_PERFECT_DRIVER_HISTORY_REF_PERFECT_DRIVER` (`perfect_driver`),
  KEY `FK_PERFECT_DRIVER_HISTORY_REF_OPERATOR` (`operator`),
  CONSTRAINT `FK_PERFECT_DRIVER_HISTORY_REF_OPERATOR` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`),
  CONSTRAINT `FK_PERFECT_DRIVER_HISTORY_REF_PERFECT_DRIVER` FOREIGN KEY (`perfect_driver`) REFERENCES `perfect_driver` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2321 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `perfect_driver_process_status`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `perfect_driver_process_status` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `status` varchar(45) DEFAULT NULL COMMENT '状态',
  `description` varchar(200) DEFAULT NULL COMMENT '描述',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `perfect_driver_rebate`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `perfect_driver_rebate` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `perfect_driver` bigint(20) DEFAULT NULL COMMENT '好车主',
  `rebate` decimal(18,2) DEFAULT NULL COMMENT '返现金额',
  `type` tinyint(3) DEFAULT '0' COMMENT '返现类型',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  KEY `FK_PERFECT_DRIVER_REBATE_REF_PERFECT_DRIVER` (`perfect_driver`),
  CONSTRAINT `FK_PERFECT_DRIVER_REBATE_REF_PERFECT_DRIVER` FOREIGN KEY (`perfect_driver`) REFERENCES `perfect_driver` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `permission`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permission` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(2000) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  `type` bigint(20) DEFAULT NULL,
  `permission_type` bigint(20) DEFAULT NULL COMMENT '权限类型',
  `code` varchar(20) DEFAULT NULL COMMENT '权限值',
  `level` int(1) DEFAULT '0' COMMENT '权限类型 0-普通权限 1-特殊权限',
  PRIMARY KEY (`id`),
  KEY `FK_PERMISSION_REF_ROLE_TYPE` (`type`),
  KEY `FK_PERMISSION_REF_PERMISSION_TYPE` (`permission_type`),
  KEY `idx_permission_level` (`level`),
  CONSTRAINT `FK_PERMISSION_REF_PERMISSION_TYPE` FOREIGN KEY (`permission_type`) REFERENCES `permission_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_PERMISSION_REF_ROLE_TYPE` FOREIGN KEY (`type`) REFERENCES `role_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=162 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `permission_resource`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permission_resource` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `permission` bigint(20) DEFAULT NULL,
  `resource` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_PERMISSION_RESOURCE_REF_PERMISSION` (`permission`),
  KEY `FK_PERMISSION_RESOURCE_REF_RESOURCE` (`resource`),
  CONSTRAINT `FK_PERMISSION_RESOURCE_REF_PERMISSION` FOREIGN KEY (`permission`) REFERENCES `permission` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_PERMISSION_RESOURCE_REF_RESOURCE` FOREIGN KEY (`resource`) REFERENCES `resource` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=152 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `permission_type`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permission_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `platform_access_log`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `platform_access_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ip` varchar(20) DEFAULT NULL,
  `url` varchar(200) DEFAULT NULL,
  `param` varchar(2000) DEFAULT NULL,
  `request_type` varchar(10) DEFAULT NULL,
  `request_time` datetime DEFAULT NULL,
  `platform` varchar(20) DEFAULT NULL,
  `internal_user` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_PLATFORM_ACCESS_LOG_REF_INTERNAL_USER` (`internal_user`) USING BTREE,
  KEY `platform` (`platform`),
  KEY `request_time` (`request_time`),
  CONSTRAINT `FK_PLATFORM_ACCESS_LOG_REF_INTERNAL_USER` FOREIGN KEY (`internal_user`) REFERENCES `internal_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6835936 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `potential_user`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `potential_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `license_no` varchar(45) DEFAULT NULL,
  `mobile` varchar(45) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  `status` bigint(20) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `update_time` datetime NOT NULL,
  `user` varchar(100) NOT NULL,
  `comment` varchar(200) DEFAULT NULL,
  `operator` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_POTENTIAL_USER_REF_POTENTIAL_USER_STATUS` (`status`),
  CONSTRAINT `FK_POTENTIAL_USER_REF_POTENTIAL_USER_STATUS` FOREIGN KEY (`status`) REFERENCES `potential_user_status` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `potential_user_status`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `potential_user_status` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(2000) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `purchase_order`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `payable_amount` decimal(18,2) DEFAULT NULL COMMENT '应付金额',
  `paid_amount` decimal(18,2) DEFAULT NULL COMMENT '实付金额',
  `create_time` datetime DEFAULT NULL,
  `invoice_header` varchar(300) DEFAULT NULL,
  `obj_id` bigint(20) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `applicant` bigint(20) DEFAULT NULL,
  `channel` bigint(20) DEFAULT NULL,
  `source_channel` bigint(20) DEFAULT NULL,
  `delivery_address` bigint(20) DEFAULT NULL,
  `operator` bigint(20) DEFAULT NULL,
  `status` bigint(20) DEFAULT NULL,
  `type` bigint(20) DEFAULT NULL,
  `auto` bigint(20) DEFAULT NULL,
  `send_date` date DEFAULT NULL,
  `time_period` varchar(20) DEFAULT NULL,
  `order_no` varchar(50) DEFAULT NULL,
  `wechat_payment_called_times` int(11) DEFAULT '0' COMMENT '记录微信支付调用次数，处理重复单据号问题。',
  `wechat_payment_success_order_no` char(27) DEFAULT NULL,
  `version` bigint(20) DEFAULT NULL,
  `company_activity` bigint(20) DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  `area` bigint(20) DEFAULT NULL,
  `order_source_type` bigint(20) DEFAULT NULL COMMENT '订单来源类型',
  `order_source_id` varchar(45) DEFAULT NULL COMMENT '订单来源id',
  `tracking_no` varchar(50) DEFAULT NULL,
  `delivery_info` bigint(20) DEFAULT NULL COMMENT '快递信息',
  `comment` varchar(1000) DEFAULT NULL COMMENT '备注信息',
  `audit` int(11) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_purchase_order_no` (`order_no`),
  KEY `FK_PURCHASE_ORDER_REF_USER` (`applicant`),
  KEY `FK_PURCHASE_ORDER_REF_PAYMENT_CHANNEL` (`channel`),
  KEY `FK_PURCHASE_ORDER_REF_ADDRESS` (`delivery_address`),
  KEY `FK_PURCHASE_ORDER_REF_INTERNAL_USER` (`operator`),
  KEY `FK_PURCHASE_ORDER_REF_ORDER_STATUS` (`status`),
  KEY `FK_PURCHASE_ORDER_REF_ORDER_TYPE` (`type`),
  KEY `FK_PURCHASE_ORDER_REF_AUTO` (`auto`),
  KEY `idx_purchase_order` (`type`,`obj_id`),
  KEY `idx_purchase_order_user_auto` (`applicant`,`auto`),
  KEY `FK_PURCHASE_ORDER_REF_CHANNEL_idx` (`source_channel`),
  KEY `FK_PURCHASE_ORDER_REF_AREA` (`area`),
  KEY `FK_PURCHASE_ORDER_REF_ORDER_SOURCE_TYPE` (`order_source_type`),
  KEY `FK_PURCHASE_ORDER_REF_DELIVERY_INFO` (`delivery_info`),
  CONSTRAINT `FK_PURCHASE_ORDER_REF_ADDRESS` FOREIGN KEY (`delivery_address`) REFERENCES `address` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_PURCHASE_ORDER_REF_AREA` FOREIGN KEY (`area`) REFERENCES `area` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_PURCHASE_ORDER_REF_AUTO` FOREIGN KEY (`auto`) REFERENCES `auto` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_PURCHASE_ORDER_REF_CHANNEL` FOREIGN KEY (`source_channel`) REFERENCES `channel` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_PURCHASE_ORDER_REF_DELIVERY_INFO` FOREIGN KEY (`delivery_info`) REFERENCES `delivery_info` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_PURCHASE_ORDER_REF_INTERNAL_USER` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_PURCHASE_ORDER_REF_ORDER_SOURCE_TYPE` FOREIGN KEY (`order_source_type`) REFERENCES `order_source_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_PURCHASE_ORDER_REF_ORDER_STATUS` FOREIGN KEY (`status`) REFERENCES `order_status` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_PURCHASE_ORDER_REF_ORDER_TYPE` FOREIGN KEY (`type`) REFERENCES `order_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_PURCHASE_ORDER_REF_PAYMENT_CHANNEL` FOREIGN KEY (`channel`) REFERENCES `payment_channel` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_PURCHASE_ORDER_REF_USER` FOREIGN KEY (`applicant`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=86385 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `purchase_order_amend`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_order_amend` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `order_operation_info` bigint(20) DEFAULT NULL,
  `purchase_order` bigint(20) DEFAULT NULL,
  `original_quote_record` bigint(20) DEFAULT NULL,
  `new_quote_record` bigint(20) DEFAULT NULL,
  `payment_type` bigint(20) DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  `purchase_order_amend_status` bigint(20) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `purchase_order_history` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `purchase_order_amend_ibk1` (`payment_type`),
  KEY `purchase_order_amend_ibk2` (`purchase_order`),
  KEY `purchase_order_amend_ibk4` (`order_operation_info`),
  KEY `purchase_order_amend_ibk5` (`original_quote_record`),
  KEY `purchase_order_amend_ibk6` (`new_quote_record`),
  KEY `purchase_order_amend_ibk7` (`purchase_order_amend_status`),
  KEY `purchase_order_amend_ibk8` (`purchase_order_history`),
  CONSTRAINT `purchase_order_amend_ibk1` FOREIGN KEY (`payment_type`) REFERENCES `payment_type` (`id`),
  CONSTRAINT `purchase_order_amend_ibk2` FOREIGN KEY (`purchase_order`) REFERENCES `purchase_order` (`id`),
  CONSTRAINT `purchase_order_amend_ibk4` FOREIGN KEY (`order_operation_info`) REFERENCES `order_operation_info` (`id`),
  CONSTRAINT `purchase_order_amend_ibk5` FOREIGN KEY (`original_quote_record`) REFERENCES `quote_record` (`id`),
  CONSTRAINT `purchase_order_amend_ibk6` FOREIGN KEY (`new_quote_record`) REFERENCES `quote_record` (`id`),
  CONSTRAINT `purchase_order_amend_ibk7` FOREIGN KEY (`purchase_order_amend_status`) REFERENCES `purchase_order_amend_status` (`id`),
  CONSTRAINT `purchase_order_amend_ibk8` FOREIGN KEY (`purchase_order_history`) REFERENCES `purchase_order_history` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=577 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `purchase_order_amend_status`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_order_amend_status` (
  `id` bigint(20) NOT NULL,
  `name` varchar(50) NOT NULL DEFAULT '',
  `description` varchar(2000) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `purchase_order_brief`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_order_brief` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `license_plate_no` varchar(45) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `institution` varchar(100) DEFAULT NULL,
  `insurance_company` varchar(100) DEFAULT NULL,
  `source_channel` varchar(100) DEFAULT NULL,
  `order_date` date DEFAULT NULL,
  `business_premium` decimal(18,2) DEFAULT NULL,
  `compulsory_premium` decimal(18,2) DEFAULT NULL,
  `auto_tax` decimal(18,2) DEFAULT NULL,
  `business_discount` decimal(18,2) DEFAULT NULL,
  `compulsory_discount` decimal(18,2) DEFAULT NULL,
  `paid_amount` decimal(18,2) DEFAULT NULL,
  `payment_channel` varchar(45) DEFAULT NULL,
  `account` varchar(45) DEFAULT '车车',
  `area` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50935 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `purchase_order_gift`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_order_gift` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `purchase_order` bigint(20) DEFAULT NULL,
  `gift` bigint(20) DEFAULT NULL,
  `given_after_order` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_PURCHASE_ORDER_GIFT_REF_PURCHASE_ORDER` (`purchase_order`),
  KEY `FK_PURCHASE_ORDER_GIFT_REF_GIFT` (`gift`),
  CONSTRAINT `purchase_order_gift_ibfk_1` FOREIGN KEY (`purchase_order`) REFERENCES `purchase_order` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `purchase_order_gift_ibfk_2` FOREIGN KEY (`gift`) REFERENCES `gift` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=17669 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `purchase_order_gift_history`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_order_gift_history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `purchase_order_history` bigint(20) DEFAULT NULL,
  `gift` bigint(20) DEFAULT NULL,
  `given_after_order` tinyint(1) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_ORDER_AMEND_GIFT_REF_GIFT` (`gift`),
  KEY `FK_ORDER_AMEND_GIFT_REF_ORDER_HIS` (`purchase_order_history`),
  CONSTRAINT `FK_ORDER_GIFT_HIS_REF_GIFT` FOREIGN KEY (`gift`) REFERENCES `gift` (`id`),
  CONSTRAINT `FK_ORDER_GIFT_HIS_REF_ORDER_HIS` FOREIGN KEY (`purchase_order_history`) REFERENCES `purchase_order_history` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4432 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `purchase_order_history`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_order_history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `purchase_order` bigint(20) DEFAULT NULL,
  `history_create_time` datetime DEFAULT NULL,
  `payable_amount` decimal(18,2) DEFAULT NULL COMMENT '应付金额',
  `paid_amount` decimal(18,2) DEFAULT NULL COMMENT '实付金额',
  `create_time` datetime DEFAULT NULL,
  `invoice_header` varchar(300) DEFAULT NULL,
  `obj_id` bigint(20) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `applicant` bigint(20) DEFAULT NULL,
  `channel` bigint(20) DEFAULT NULL,
  `source_channel` bigint(20) DEFAULT NULL,
  `delivery_address` bigint(20) DEFAULT NULL,
  `operator` bigint(20) DEFAULT NULL,
  `status` bigint(20) DEFAULT NULL,
  `type` bigint(20) DEFAULT NULL,
  `auto` bigint(20) DEFAULT NULL,
  `send_date` date DEFAULT NULL,
  `time_period` varchar(20) DEFAULT NULL,
  `order_no` varchar(50) DEFAULT NULL,
  `wechat_payment_called_times` int(11) DEFAULT '0' COMMENT '记录微信支付调用次数，处理重复单据号问题。',
  `wechat_payment_success_order_no` varchar(27) DEFAULT NULL,
  `version` bigint(20) DEFAULT NULL,
  `company_activity` bigint(20) DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  `area` bigint(20) DEFAULT NULL,
  `order_source_type` bigint(20) DEFAULT NULL COMMENT '订单来源类型',
  `order_source_id` varchar(45) DEFAULT NULL COMMENT '订单来源id',
  `tracking_no` varchar(50) DEFAULT NULL,
  `delivery_info` bigint(20) DEFAULT NULL COMMENT '快递信息',
  `comment` varchar(1000) DEFAULT NULL COMMENT '备注信息',
  `audit` int(11) DEFAULT '1',
  `operation_type` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_PURCHASE_ORDER_HIS_REF_USER` (`applicant`),
  KEY `FK_PURCHASE_ORDER_HIS_REF_PAYMENT_CHANNEL` (`channel`),
  KEY `FK_PURCHASE_ORDER_HIS_REF_ADDRESS` (`delivery_address`),
  KEY `FK_PURCHASE_ORDER_HIS_REF_INTERNAL_USER` (`operator`),
  KEY `FK_PURCHASE_ORDER_HIS_REF_ORDER_STATUS` (`status`),
  KEY `FK_PURCHASE_ORDER_HIS_REF_ORDER_TYPE` (`type`),
  KEY `FK_PURCHASE_ORDER_HIS_REF_AUTO` (`auto`),
  KEY `idx_purchase_order_his` (`type`,`obj_id`),
  KEY `idx_purchase_order_his_user_auto` (`applicant`,`auto`),
  KEY `FK_PURCHASE_ORDER_HIS_REF_CHANNEL_idx` (`source_channel`),
  KEY `FK_PURCHASE_ORDER_HIS_REF_AREA` (`area`),
  KEY `FK_PURCHASE_ORDER_HIS_REF_ORDER_SOURCE_TYPE` (`order_source_type`),
  KEY `FK_PURCHASE_ORDER_HIS_REF_DELIVERY_INFO` (`delivery_info`),
  KEY `FK_PURCHASE_ORDER_HIS_REF_OPERATION_TYPE` (`operation_type`),
  CONSTRAINT `FK_PURCHASE_ORDER_HIS_REF_ADDRESS` FOREIGN KEY (`delivery_address`) REFERENCES `address` (`id`),
  CONSTRAINT `FK_PURCHASE_ORDER_HIS_REF_AREA` FOREIGN KEY (`area`) REFERENCES `area` (`id`),
  CONSTRAINT `FK_PURCHASE_ORDER_HIS_REF_AUTO` FOREIGN KEY (`auto`) REFERENCES `auto` (`id`),
  CONSTRAINT `FK_PURCHASE_ORDER_HIS_REF_CHANNEL` FOREIGN KEY (`source_channel`) REFERENCES `channel` (`id`),
  CONSTRAINT `FK_PURCHASE_ORDER_HIS_REF_DELIVERY_INFO` FOREIGN KEY (`delivery_info`) REFERENCES `delivery_info` (`id`),
  CONSTRAINT `FK_PURCHASE_ORDER_HIS_REF_INTERNAL_USER` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`),
  CONSTRAINT `FK_PURCHASE_ORDER_HIS_REF_OPERATION_TYPE` FOREIGN KEY (`operation_type`) REFERENCES `operation_type` (`id`),
  CONSTRAINT `FK_PURCHASE_ORDER_HIS_REF_ORDER_SOURCE_TYPE` FOREIGN KEY (`order_source_type`) REFERENCES `order_source_type` (`id`),
  CONSTRAINT `FK_PURCHASE_ORDER_HIS_REF_ORDER_STATUS` FOREIGN KEY (`status`) REFERENCES `order_status` (`id`),
  CONSTRAINT `FK_PURCHASE_ORDER_HIS_REF_ORDER_TYPE` FOREIGN KEY (`type`) REFERENCES `order_type` (`id`),
  CONSTRAINT `FK_PURCHASE_ORDER_HIS_REF_PAYMENT_CHANNEL` FOREIGN KEY (`channel`) REFERENCES `payment_channel` (`id`),
  CONSTRAINT `FK_PURCHASE_ORDER_HIS_REF_USER` FOREIGN KEY (`applicant`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5651 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `purchase_order_image`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_order_image` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `purchase_order` bigint(20) NOT NULL,
  `url` varchar(200) NOT NULL,
  `image_type` bigint(20) NOT NULL,
  `status` smallint(2) DEFAULT '0',
  `operator` bigint(20) DEFAULT NULL,
  `source` smallint(2) DEFAULT NULL,
  `upload_time` datetime DEFAULT NULL,
  `audit_time` datetime DEFAULT NULL,
  `channel` bigint(20) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `expire_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_PURCHASE_ORDER_IMAGE_REF_PURCHASE_ORDER` (`purchase_order`),
  KEY `FK_PURCHASE_ORDER_IMAGE_REF_INTERNAL_USER` (`operator`),
  KEY `FK_PURCHASE_ORDER_IMAGE_REF_PURCHASE_ORDER_IMAGE_TYPE` (`image_type`),
  KEY `FK_PURCHASE_ORDER_IMAGE_REF_CHANNEL` (`channel`),
  CONSTRAINT `FK_PURCHASE_ORDER_IMAGE_REF_CHANNEL` FOREIGN KEY (`channel`) REFERENCES `channel` (`id`),
  CONSTRAINT `FK_PURCHASE_ORDER_IMAGE_REF_INTERNAL_USER` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`),
  CONSTRAINT `FK_PURCHASE_ORDER_IMAGE_REF_PURCHASE_ORDER` FOREIGN KEY (`purchase_order`) REFERENCES `purchase_order` (`id`),
  CONSTRAINT `FK_PURCHASE_ORDER_IMAGE_REF_PURCHASE_ORDER_IMAGE_TYPE` FOREIGN KEY (`image_type`) REFERENCES `purchase_order_image_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15203 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `purchase_order_image_scene`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_order_image_scene` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `purchase_order_image_scene_type`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_order_image_scene_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `image_scene` bigint(20) NOT NULL,
  `image_type` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_IMAGE_SCENE_TYPE_REF_PURCHASE_ORDER_IMAGE_SCENE` (`image_scene`),
  KEY `FK_IMAGE_SCENE_TYPE_REF_PURCHASE_ORDER_IMAGE_TYPE` (`image_type`),
  CONSTRAINT `FK_IMAGE_SCENE_TYPE_REF_PURCHASE_ORDER_IMAGE_SCENE` FOREIGN KEY (`image_scene`) REFERENCES `purchase_order_image_scene` (`id`),
  CONSTRAINT `FK_IMAGE_SCENE_TYPE_REF_PURCHASE_ORDER_IMAGE_TYPE` FOREIGN KEY (`image_type`) REFERENCES `purchase_order_image_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `purchase_order_image_status`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_order_image_status` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `purchase_order` bigint(20) NOT NULL,
  `status` smallint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK_IMAGE_STATUS_REF_PURCHASE_ORDER` (`purchase_order`),
  CONSTRAINT `FK_IMAGE_STATUS_REF_PURCHASE_ORDER` FOREIGN KEY (`purchase_order`) REFERENCES `purchase_order` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13181 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `purchase_order_image_type`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_order_image_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `parent_id` bigint(20) NOT NULL,
  `operator` bigint(20) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `sample_url` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_PURCHASE_ORDER_IMAGE_TYPE_REF_INTERNAL_USER` (`operator`),
  CONSTRAINT `FK_IMAGE_TYPE_REF_INTERNAL_USER` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=141 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `purchase_order_refund`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_order_refund` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `purchase_order` bigint(20) DEFAULT NULL COMMENT '订单',
  `user_check` tinyint(1) DEFAULT '1' COMMENT '是否车车退款给用户',
  `cheche_check` tinyint(1) DEFAULT NULL COMMENT '是否出单机构退款给车车',
  `rebate_check` tinyint(1) DEFAULT NULL COMMENT '是否退佣金给出单机构',
  `user_status` tinyint(1) DEFAULT NULL COMMENT '退款给用户状态，0-未退款，1-已退款',
  `cheche_status` tinyint(1) DEFAULT NULL COMMENT '退款给车车状态，0-未退款，1-已退款',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  `operator` bigint(20) DEFAULT NULL COMMENT '操作人',
  PRIMARY KEY (`id`),
  KEY `FK_PURCHASE_ORDER_REFUND_REF_PURCHASE_ORDER` (`purchase_order`),
  KEY `FK_PURCHASE_ORDER_REFUND_REF_OPERATOR` (`operator`),
  CONSTRAINT `FK_PURCHASE_ORDER_REFUND_REF_OPERATOR` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_PURCHASE_ORDER_REFUND_REF_PURCHASE_ORDER` FOREIGN KEY (`purchase_order`) REFERENCES `purchase_order` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `push_message`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `push_message` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `message_no` varchar(10) NOT NULL,
  `title` varchar(45) DEFAULT NULL,
  `body` varchar(200) DEFAULT NULL,
  `data` varchar(200) DEFAULT NULL,
  `sound` varchar(45) DEFAULT NULL,
  `operation` varchar(45) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `type` int(11) DEFAULT '0',
  `disable` tinyint(1) DEFAULT '0',
  `auto_increment_badge` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_u_push_message_message_no` (`message_no`),
  KEY `idx_push_message_type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `qrcode_channel`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qrcode_channel` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `code` varchar(10) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `expire_time` datetime DEFAULT NULL,
  `rebate` decimal(18,2) DEFAULT NULL,
  `department` varchar(20) DEFAULT NULL COMMENT '所属部门',
  `comment` varchar(2000) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `operator` bigint(20) DEFAULT NULL,
  `wechat_qrcode` bigint(20) DEFAULT NULL,
  `disable` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK_QRCODE_CHANNEL_REF_INTERNAL_USER` (`operator`),
  CONSTRAINT `FK_QRCODE_CHANNEL_REF_INTERNAL_USER` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2407 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `qrcode_statistics`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qrcode_statistics` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `qrcode_channel` bigint(20) NOT NULL,
  `statistics_time` datetime DEFAULT NULL,
  `scan_count` int(8) NOT NULL,
  `subscribe_count` int(8) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_QRCODE_STATISTICS_REF_QRCODE_CHANNEL` (`qrcode_channel`),
  CONSTRAINT `FK_QRCODE_STATISTICS_REF_QRCODE_CHANNEL` FOREIGN KEY (`qrcode_channel`) REFERENCES `qrcode_channel` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=332506 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `quote`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quote` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `quote_time` datetime DEFAULT NULL,
  `applicant` bigint(20) DEFAULT NULL,
  `auto` bigint(20) DEFAULT NULL,
  `status` bigint(20) DEFAULT NULL,
  `source_channel` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_PURCHASE_ORDER_REF_USER` (`applicant`),
  KEY `FK_PURCHASE_ORDER_REF_AUTO` (`auto`),
  KEY `FK_PURCHASE_ORDER_REF_QUOTE_STATUS` (`status`),
  KEY `idx_quote` (`applicant`,`auto`),
  KEY `FK_QUOTE_REF_CHANNEL_idx` (`source_channel`),
  CONSTRAINT `FK_QUOTE_REF_AUTO` FOREIGN KEY (`auto`) REFERENCES `auto` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_QUOTE_REF_CHANNEL` FOREIGN KEY (`source_channel`) REFERENCES `channel` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_QUOTE_REF_QUOTE_STATUS` FOREIGN KEY (`status`) REFERENCES `quote_status` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_QUOTE_REF_USER` FOREIGN KEY (`applicant`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=114027 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `quote_amend`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quote_amend` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `amend_amount` decimal(18,2) DEFAULT NULL,
  `comment` varchar(2000) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `amend_payment` bigint(20) DEFAULT NULL,
  `insurance` bigint(20) DEFAULT NULL,
  `operator` bigint(20) DEFAULT NULL,
  `original_payment` bigint(20) DEFAULT NULL,
  `quote_record` bigint(20) DEFAULT NULL,
  `reason` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_AMEND_QUOTE_AMEND_REF_PAYMENT` (`amend_payment`),
  KEY `FK_QUOTE_AMEND_REF_INSURANCE` (`insurance`),
  KEY `FK_QUOTE_AMEND_REF_INTERNAL_USER` (`operator`),
  KEY `FK_ORIGINAL_QUOTE_AMEND_REF_PAYMENT` (`original_payment`),
  KEY `FK_QUOTE_AMEND_REF_QUOTE_RECORD` (`quote_record`),
  KEY `FK_QUOTE_AMEND_REF_AMEND_REASON` (`reason`),
  CONSTRAINT `FK_AMEND_QUOTE_AMEND_REF_PAYMENT` FOREIGN KEY (`amend_payment`) REFERENCES `payment` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_ORIGINAL_QUOTE_AMEND_REF_PAYMENT` FOREIGN KEY (`original_payment`) REFERENCES `payment` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_QUOTE_AMEND_REF_AMEND_REASON` FOREIGN KEY (`reason`) REFERENCES `amend_reason` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_QUOTE_AMEND_REF_INSURANCE` FOREIGN KEY (`insurance`) REFERENCES `insurance` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_QUOTE_AMEND_REF_INTERNAL_USER` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_QUOTE_AMEND_REF_QUOTE_RECORD` FOREIGN KEY (`quote_record`) REFERENCES `quote_record` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `quote_entrance`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quote_entrance` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `entrance` varchar(100) DEFAULT NULL COMMENT '拍照报价入口',
  `description` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_U_QUOTE_ENTRANCE_RF_ENTRANCE` (`entrance`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `quote_flow_type`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quote_flow_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(2000) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `quote_modification`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quote_modification` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `quote_source` bigint(20) NOT NULL,
  `quote_source_id` bigint(20) NOT NULL,
  `insurance_company_ids` varchar(45) DEFAULT NULL,
  `insurance_package` bigint(20) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_QUOTE_SOURCE_REF_OC_QUOTE_SOURCE` (`quote_source`),
  KEY `INDEX_QUOTE_MODIFICATION_QUOTE_SOURCE_ID` (`quote_source_id`),
  KEY `FK_INSURANCE_PACKAGE_REF_INSURANCE_PACKAGE` (`insurance_package`),
  CONSTRAINT `FK_INSURANCE_PACKAGE_REF_INSURANCE_PACKAGE` FOREIGN KEY (`insurance_package`) REFERENCES `insurance_package` (`id`),
  CONSTRAINT `FK_QUOTE_SOURCE_REF_OC_QUOTE_SOURCE` FOREIGN KEY (`quote_source`) REFERENCES `oc_quote_source` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3728 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `quote_phone`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quote_phone` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `license_plate_no` varchar(45) DEFAULT NULL COMMENT '车牌号',
  `owner` varchar(45) DEFAULT NULL COMMENT '车主',
  `identity` varchar(45) DEFAULT NULL COMMENT '车主身份证号',
  `insured_name` varchar(45) DEFAULT NULL COMMENT '被保险人姓名',
  `insured_id_no` varchar(45) DEFAULT NULL COMMENT '被保险人身份证号',
  `vin_no` varchar(45) DEFAULT NULL COMMENT 'VIN码',
  `engine_no` varchar(45) DEFAULT NULL COMMENT '发动机号',
  `enroll_date` date DEFAULT NULL COMMENT '初登日期',
  `model` varchar(120) DEFAULT NULL COMMENT '车型',
  `code` varchar(45) DEFAULT NULL COMMENT '品牌型号',
  `expire_date` date DEFAULT NULL COMMENT '保险到期日',
  `visited` tinyint(1) DEFAULT NULL COMMENT '是否需回访 1已回访 0需回访',
  `comment` varchar(200) DEFAULT NULL COMMENT '备注',
  `user` bigint(20) DEFAULT NULL COMMENT '用户',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `operator` bigint(20) DEFAULT NULL COMMENT '当前操作人',
  `responsible` bigint(20) DEFAULT NULL COMMENT '责任人',
  `source_channel` bigint(20) DEFAULT NULL,
  `transfer_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_QUOTE_PHONE_REF_USER` (`user`),
  KEY `idx_quote_phone_license_plate_no` (`license_plate_no`),
  KEY `FK_QUOTE_PHONE_OPERATOR_REF_INTERNAL_USER` (`operator`),
  KEY `FK_QUOTE_PHONE_RESPONSIBLE_REF_INTERNAL_USER` (`responsible`),
  KEY `FK_QUOTE_PHONE_REF_CHANNEL_IDX` (`source_channel`),
  CONSTRAINT `FK_QUOTE_PHONE_OPERATOR_REF_INTERNAL_USER` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_QUOTE_PHONE_REF_CHANNEL_IDX` FOREIGN KEY (`source_channel`) REFERENCES `channel` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_QUOTE_PHONE_REF_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_QUOTE_PHONE_RESPONSIBLE_REF_INTERNAL_USER` FOREIGN KEY (`responsible`) REFERENCES `internal_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=33973 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `quote_photo`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quote_photo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `license_plate_no` varchar(45) DEFAULT NULL COMMENT '车牌号',
  `owner` varchar(45) DEFAULT NULL COMMENT '车主',
  `identity` varchar(45) DEFAULT NULL COMMENT '车主身份证号',
  `insured_name` varchar(45) DEFAULT NULL COMMENT '被保险人姓名',
  `insured_id_no` varchar(45) DEFAULT NULL COMMENT '被保险人身份证号',
  `vin_no` varchar(45) DEFAULT NULL COMMENT 'VIN码',
  `engine_no` varchar(45) DEFAULT NULL COMMENT '发动机号',
  `enroll_date` date DEFAULT NULL COMMENT '初登日期',
  `model` varchar(120) DEFAULT NULL COMMENT '车型',
  `code` varchar(45) DEFAULT NULL COMMENT '品牌型号',
  `expire_date` date DEFAULT NULL COMMENT '保险到期日',
  `disable` tinyint(1) DEFAULT NULL COMMENT '是否有效 1无效 0有效',
  `visited` tinyint(1) DEFAULT NULL COMMENT '是否需回访 1已回访 0需回访',
  `comment` varchar(200) DEFAULT NULL COMMENT '备注',
  `user` bigint(20) DEFAULT NULL COMMENT '用户',
  `user_img` bigint(20) DEFAULT NULL COMMENT '用户上传图片',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `activity` bigint(20) DEFAULT NULL,
  `operator` bigint(20) DEFAULT NULL COMMENT '当前操作人',
  `responsible` bigint(20) DEFAULT NULL COMMENT '责任人',
  `transfer_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_QUOTE_PHOTO_USER_REF_USER` (`user`),
  KEY `FK_QUOTE_PHOTO_USER_IMG_REF_USER_IMG` (`user_img`),
  KEY `idx_quote_photo_license_plate_no` (`license_plate_no`),
  KEY `idx_quote_photo_activity` (`activity`),
  KEY `FK_QUOTE_PHOTO_OPERATOR_REF_INTERNAL_USER` (`operator`),
  KEY `FK_QUOTE_PHOTO_RESPONSIBLE_REF_INTERNAL_USER` (`responsible`),
  KEY `IDX_QUOTE_PHOTO_CREATE_TIME` (`create_time`),
  CONSTRAINT `FK_QUOTE_PHOTO_MARKING_REF_MARKING` FOREIGN KEY (`activity`) REFERENCES `marketing` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_QUOTE_PHOTO_OPERATOR_REF_INTERNAL_USER` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_QUOTE_PHOTO_RESPONSIBLE_REF_INTERNAL_USER` FOREIGN KEY (`responsible`) REFERENCES `internal_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_QUOTE_PHOTO_USER_IMG_REF_USER_IMG` FOREIGN KEY (`user_img`) REFERENCES `user_img` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_QUOTE_PHOTO_USER_REF_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=12993 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `quote_record`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quote_record` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `discount` decimal(18,6) DEFAULT NULL,
  `auto_tax` decimal(18,2) DEFAULT NULL,
  `compulsory_effective_date` date DEFAULT NULL,
  `compulsory_expire_date` date DEFAULT NULL,
  `compulsory_original_policy_no` varchar(45) DEFAULT NULL,
  `compulsory_premium` decimal(18,2) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `damage_amount` decimal(18,2) DEFAULT NULL,
  `damage_iop` decimal(18,2) DEFAULT NULL,
  `damage_premium` decimal(18,2) DEFAULT NULL,
  `driver_amount` decimal(18,2) DEFAULT NULL,
  `driver_iop` decimal(18,2) DEFAULT NULL,
  `driver_premium` decimal(18,2) DEFAULT NULL,
  `effective_date` date DEFAULT NULL,
  `engine_amount` decimal(18,2) DEFAULT NULL,
  `engine_iop` decimal(18,2) DEFAULT NULL,
  `engine_premium` decimal(18,2) DEFAULT NULL,
  `expire_date` date DEFAULT NULL,
  `glass_amount` decimal(18,2) DEFAULT NULL,
  `glass_premium` decimal(18,2) DEFAULT NULL,
  `original_policy_no` varchar(45) DEFAULT NULL,
  `passenger_amount` decimal(18,2) DEFAULT NULL,
  `passenger_count` tinyint(3) DEFAULT NULL,
  `passenger_iop` decimal(18,2) DEFAULT NULL,
  `passenger_premium` decimal(18,2) DEFAULT NULL,
  `premium` decimal(18,2) DEFAULT NULL,
  `scratch_amount` decimal(18,2) DEFAULT NULL,
  `scratch_iop` decimal(18,2) DEFAULT NULL,
  `scratch_premium` decimal(18,2) DEFAULT NULL,
  `spontaneous_loss_amount` decimal(18,2) DEFAULT NULL,
  `spontaneous_loss_premium` decimal(18,2) DEFAULT NULL,
  `theft_amount` decimal(18,2) DEFAULT NULL,
  `theft_iop` decimal(18,2) DEFAULT NULL,
  `theft_premium` decimal(18,2) DEFAULT NULL,
  `third_party_amount` decimal(18,2) DEFAULT NULL,
  `third_party_iop` decimal(18,2) DEFAULT NULL,
  `third_party_premium` decimal(18,2) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `applicant` bigint(20) DEFAULT NULL,
  `auto` bigint(20) DEFAULT NULL,
  `insurance_company` bigint(20) DEFAULT NULL,
  `area` bigint(20) DEFAULT NULL,
  `insurance_package` bigint(20) DEFAULT NULL,
  `quote` bigint(20) DEFAULT NULL,
  `type` bigint(20) DEFAULT NULL,
  `quote_flow_type` bigint(20) DEFAULT '1' COMMENT '报价通道类型',
  `changed_car` tinyint(1) DEFAULT '0' COMMENT '是否留牌换车',
  `iop_total` decimal(18,2) DEFAULT '0.00',
  `channel` bigint(20) DEFAULT NULL,
  `owner_mobile` varchar(45) DEFAULT NULL,
  `spontaneous_loss_iop` decimal(18,2) DEFAULT NULL,
  `unable_find_third_party_premium` decimal(18,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_QUOTE_RECORD_REF_USER` (`applicant`),
  KEY `FK_QUOTE_RECORD_REF_AUTO` (`auto`),
  KEY `FK_QUOTE_RECORD_REF_INSURANCE_COMPANY` (`insurance_company`),
  KEY `FK_QUOTE_RECORD_REF_AREA` (`area`),
  KEY `FK_QUOTE_RECORD_REF_INSURANCE_PACKAGE` (`insurance_package`),
  KEY `FK_QUOTE_RECORD_REF_QUOTE` (`quote`),
  KEY `FK_QUOTE_RECORD_REF_QUOTE_SOURCE` (`type`),
  KEY `idx_quote_record` (`applicant`,`auto`),
  KEY `quote_flow_type` (`quote_flow_type`),
  KEY `FK_QUOTE_RECORD_REF_CHANNEL` (`channel`),
  CONSTRAINT `FK_QUOTE_RECORD_REF_AREA` FOREIGN KEY (`area`) REFERENCES `area` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_QUOTE_RECORD_REF_AUTO` FOREIGN KEY (`auto`) REFERENCES `auto` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_QUOTE_RECORD_REF_CHANNEL` FOREIGN KEY (`channel`) REFERENCES `channel` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_QUOTE_RECORD_REF_INSURANCE_COMPANY` FOREIGN KEY (`insurance_company`) REFERENCES `insurance_company` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_QUOTE_RECORD_REF_INSURANCE_PACKAGE` FOREIGN KEY (`insurance_package`) REFERENCES `insurance_package` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_QUOTE_RECORD_REF_QUOTE` FOREIGN KEY (`quote`) REFERENCES `quote` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_QUOTE_RECORD_REF_QUOTE_SOURCE` FOREIGN KEY (`type`) REFERENCES `quote_source` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_QUOTE_RECORD_REF_USER` FOREIGN KEY (`applicant`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `quote_record_ibfk_1` FOREIGN KEY (`quote_flow_type`) REFERENCES `quote_flow_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=171697 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `quote_record_cache`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quote_record_cache` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `perfect_driver` bigint(20) DEFAULT NULL,
  `type` tinyint(1) DEFAULT '1' COMMENT '报价类型，1-电销报价，2-传统报价',
  `quote_record` bigint(20) DEFAULT NULL COMMENT '报价记录',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  `operator` bigint(20) DEFAULT NULL COMMENT '操作人',
  `insurance_company` bigint(20) DEFAULT NULL,
  `policy_description` varchar(1000) DEFAULT '',
  `quote_modification` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_QUOTE_RECORD_CACHE_REF_PERFECT_DRIVER` (`perfect_driver`),
  KEY `FK_QUOTE_RECORD_CACHE_REF_QUOTE_RECORD` (`quote_record`),
  KEY `FK_QUOTE_RECORD_CACHE_REF_OPERATOR` (`operator`),
  KEY `FK_QUOTE_RECORD_CACHE_REF_INSURANCE_COMPANY` (`insurance_company`),
  KEY `FK_QUOTE_RECORD_CACHE_REF_QUOTE_MODIFICATION` (`quote_modification`),
  CONSTRAINT `FK_QUOTE_RECORD_CACHE_REF_INSURANCE_COMPANY` FOREIGN KEY (`insurance_company`) REFERENCES `insurance_company` (`id`),
  CONSTRAINT `FK_QUOTE_RECORD_CACHE_REF_OPERATOR` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`),
  CONSTRAINT `FK_QUOTE_RECORD_CACHE_REF_PERFECT_DRIVER` FOREIGN KEY (`perfect_driver`) REFERENCES `perfect_driver` (`id`),
  CONSTRAINT `FK_QUOTE_RECORD_CACHE_REF_QUOTE_MODIFICATION` FOREIGN KEY (`quote_modification`) REFERENCES `quote_modification` (`id`),
  CONSTRAINT `FK_QUOTE_RECORD_CACHE_REF_QUOTE_RECORD` FOREIGN KEY (`quote_record`) REFERENCES `quote_record` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8151 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `quote_source`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quote_source` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(2000) DEFAULT NULL,
  `source` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `quote_status`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quote_status` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(2000) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `quote_supplement_info`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quote_supplement_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `auto` bigint(20) NOT NULL,
  `quote_record` bigint(20) NOT NULL,
  `supplement_info_type` bigint(20) NOT NULL,
  `field_path` varchar(200) DEFAULT NULL,
  `field_type` varchar(50) DEFAULT NULL,
  `field_label` varchar(200) DEFAULT NULL,
  `validation_type` varchar(200) DEFAULT NULL,
  `value` varchar(200) DEFAULT NULL,
  `value_name` varchar(200) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_SUPPLEMENT_INFO_REF_AUTO` (`auto`),
  KEY `FK_SUPPLEMENT_INFO_REF_QUOTE_RECORD` (`quote_record`),
  KEY `FK_SUPPLEMENT_INFO_REF_SUPPLEMENT_INFO_TYPE` (`supplement_info_type`),
  CONSTRAINT `FK_SUPPLEMENT_INFO_REF_AUTO` FOREIGN KEY (`auto`) REFERENCES `auto` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_SUPPLEMENT_INFO_REF_QUOTE_RECORD` FOREIGN KEY (`quote_record`) REFERENCES `quote_record` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_SUPPLEMENT_INFO_REF_SUPPLEMENT_INFO_TYPE` FOREIGN KEY (`supplement_info_type`) REFERENCES `supplement_info_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=29891 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `re_send_message`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `re_send_message` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `send_type` varchar(10) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  `tos` varchar(100) DEFAULT NULL,
  `send_date` date DEFAULT NULL,
  `unique_string` varchar(45) DEFAULT NULL,
  `count` tinyint(2) DEFAULT '0',
  `param` mediumtext,
  `message_no` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=603 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `rebate_channel`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rebate_channel` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL COMMENT '佣金渠道名称',
  `type` tinyint(1) DEFAULT '0' COMMENT '类型，0-上游，1-下游，默认值为0',
  `description` varchar(45) DEFAULT NULL COMMENT '描述',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `resource`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resource` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL COMMENT '资源名称',
  `parent` bigint(20) DEFAULT NULL COMMENT '上级资源',
  `resource_type` bigint(20) DEFAULT NULL COMMENT '资源类型',
  `level` tinyint(1) DEFAULT NULL COMMENT '资源等级',
  PRIMARY KEY (`id`),
  KEY `FK_RESOURCE_REF_PARENT_RESOURCE` (`parent`),
  KEY `FK_RESOURCE_REF_RESOURCE_TYPE` (`resource_type`),
  CONSTRAINT `FK_RESOURCE_REF_PARENT_RESOURCE` FOREIGN KEY (`parent`) REFERENCES `resource` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_RESOURCE_REF_RESOURCE_TYPE` FOREIGN KEY (`resource_type`) REFERENCES `resource_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `resource_type`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resource_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `role`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(2000) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  `type` bigint(20) DEFAULT NULL,
  `disable` tinyint(1) DEFAULT '1' COMMENT '角色禁用标记',
  `level` int(1) DEFAULT '0' COMMENT '角色类型 0-普通角色 1-特殊角色',
  PRIMARY KEY (`id`),
  KEY `FK_ROLE_REF_ROLE_TYPE` (`type`),
  KEY `idx_role_name` (`name`),
  KEY `idx_role_level` (`level`),
  CONSTRAINT `FK_ROLE_REF_ROLE_TYPE` FOREIGN KEY (`type`) REFERENCES `role_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `role_permission`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_permission` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `permission` bigint(20) DEFAULT NULL,
  `role` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_ROLE_PERMISSION_REF_PERMISSION` (`permission`),
  KEY `FK_ROLE_PERMISSION_REF_ROLE` (`role`),
  CONSTRAINT `FK_ROLE_PERMISSION_REF_PERMISSION` FOREIGN KEY (`permission`) REFERENCES `permission` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_ROLE_PERMISSION_REF_ROLE` FOREIGN KEY (`role`) REFERENCES `role` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2780 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `role_type`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(2000) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `rule_config`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rule_config` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `marketing_rule` bigint(20) DEFAULT NULL,
  `rule_param` bigint(20) DEFAULT NULL,
  `rule_value` varchar(2000) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rule_config_marketing_rule` (`marketing_rule`),
  KEY `rule_config_rule_param` (`rule_param`),
  CONSTRAINT `FK_RULE_CONFIG_REF_MARKETING_RULE` FOREIGN KEY (`marketing_rule`) REFERENCES `marketing_rule` (`id`),
  CONSTRAINT `FK_RULE_CONFIG_REF_RULE_PARAM` FOREIGN KEY (`rule_param`) REFERENCES `rule_param` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33982 DEFAULT CHARSET=utf8 COMMENT='活动优惠规则配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `rule_param`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rule_param` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `param_name` varchar(45) DEFAULT NULL,
  `param_type` bigint(20) DEFAULT NULL,
  `activity_type` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `activity_type_idx` (`activity_type`),
  KEY `param_type_idx` (`param_type`),
  CONSTRAINT `FK_RULE_PARAM_REF_ACTIVITY_TYPE` FOREIGN KEY (`activity_type`) REFERENCES `activity_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_RULE_PARAM_REF_PARAM_TYPE` FOREIGN KEY (`param_type`) REFERENCES `rule_param_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COMMENT='优惠参数配置枚举表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `rule_param_type`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rule_param_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `type` varchar(45) DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='优惠参数类型 (1:int;2:boolean;3:long...)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `schedule_condition`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedule_condition` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(45) NOT NULL COMMENT '条件名称',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `schedule_message`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedule_message` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `sms_template` bigint(20) NOT NULL COMMENT '短信模板',
  `schedule_condition` bigint(20) DEFAULT NULL COMMENT '条件',
  `disable` tinyint(1) DEFAULT '1' COMMENT '是否启用，默认为禁用，0-启用，1-禁用',
  `comment` varchar(200) DEFAULT NULL COMMENT '备注',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  `operator` bigint(20) DEFAULT NULL COMMENT '操作人，关联internal_user表',
  PRIMARY KEY (`id`),
  KEY `FK_SCHEDULE_MESSAGE_REF_SMS_TEMPLATE` (`sms_template`),
  KEY `FK_SCHEDULE_MESSAGE_REF_SCHEDULE_CONDITION` (`schedule_condition`),
  KEY `FK_SCHEDULE_MESSAGE_REF_OPERATOR` (`operator`),
  CONSTRAINT `FK_SCHEDULE_MESSAGE_REF_CONDITION` FOREIGN KEY (`schedule_condition`) REFERENCES `schedule_condition` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_SCHEDULE_MESSAGE_REF_OPERATOR` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_SCHEDULE_MESSAGE_REF_SMS_TEMPLATE` FOREIGN KEY (`sms_template`) REFERENCES `sms_template` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=132 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `schedule_message_log`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedule_message_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `schedule_message` bigint(20) NOT NULL COMMENT '条件触发短信',
  `mobile` varchar(11) DEFAULT NULL COMMENT '手机号',
  `send_time` datetime DEFAULT NULL COMMENT '发送时间',
  `status` tinyint(1) DEFAULT NULL COMMENT '状态1-成功，2-失败',
  `parameter` varchar(1000) DEFAULT NULL COMMENT '发送给用户的短信参数',
  PRIMARY KEY (`id`),
  KEY `FK_SCHEDULE_MESSAGE_LOG_REF_SCHEDULE_MESSAGE` (`schedule_message`),
  CONSTRAINT `FK_SCHEDULE_MESSAGE_LOG_REF_SCHEDULE_MESSAGE` FOREIGN KEY (`schedule_message`) REFERENCES `schedule_message` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=273126 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `script_history`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `script_history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `version` varchar(10) NOT NULL,
  `script` varchar(200) NOT NULL,
  `create_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1229 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sinosig_city_code`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sinosig_city_code` (
  `id` varchar(255) NOT NULL,
  `city_plate` varchar(10) DEFAULT NULL,
  `cont_name` varchar(45) DEFAULT NULL,
  `pro_plate` varchar(10) DEFAULT NULL,
  `rank` tinyint(1) DEFAULT NULL,
  `spelling` varchar(45) DEFAULT NULL,
  `spelling_acronym` varchar(10) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `province` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_CITY_REF_CITY_CODE` (`city`),
  KEY `FK_PROVINCE_REF_CITY_CODE` (`province`),
  CONSTRAINT `FK_CITY_REF_CITY_CODE` FOREIGN KEY (`city`) REFERENCES `sinosig_city_code` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_PROVINCE_REF_CITY_CODE` FOREIGN KEY (`province`) REFERENCES `sinosig_city_code` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sinosig_message`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sinosig_message` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `content` text,
  `create_time` datetime DEFAULT NULL,
  `engine_no` varchar(45) DEFAULT NULL,
  `identity` varchar(45) DEFAULT NULL,
  `license_no` varchar(45) DEFAULT NULL,
  `message_type` varchar(10) DEFAULT NULL,
  `mobile` varchar(45) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  `request_type` varchar(10) DEFAULT NULL,
  `session_id` varchar(50) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  `vin_no` varchar(45) DEFAULT NULL,
  `user_id` varchar(45) DEFAULT NULL,
  `user_token` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38037 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sms_template`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sms_template` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(30) DEFAULT NULL,
  `zucp_code` varchar(30) DEFAULT NULL COMMENT '漫道模板编号',
  `yxt_code` varchar(30) DEFAULT NULL COMMENT '盈信通模板编号',
  `disable` tinyint(1) DEFAULT '1' COMMENT '是否启用，默认为禁用，0-启用，1-禁用',
  `content` varchar(1000) NOT NULL COMMENT '短信模板内容，涉及到变量',
  `comment` varchar(200) DEFAULT NULL COMMENT '备注',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  `operator` bigint(20) DEFAULT NULL COMMENT '操作人，关联internal_user表',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_sms_template_name` (`name`),
  KEY `FK_SMS_TEMPLATE_REF_OPERATOR` (`operator`),
  CONSTRAINT `FK_SMS_TEMPLATE_REF_OPERATOR` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=205 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `source_type`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `source_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sql_parameter`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sql_parameter` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `code` varchar(20) NOT NULL COMMENT '编号,例如：${?1}',
  `name` varchar(45) DEFAULT NULL COMMENT '名称，例如：手机号',
  `type` varchar(20) DEFAULT NULL COMMENT '类型，例如varchar,date,time,number',
  `placeholder` varchar(45) DEFAULT NULL COMMENT '参数描述',
  `length` smallint(4) DEFAULT NULL COMMENT '参数值长度',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_sql_parameter_code` (`code`),
  UNIQUE KEY `idx_sql_parameter_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sql_template`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sql_template` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(45) DEFAULT NULL COMMENT '名称',
  `content` varchar(1000) DEFAULT NULL COMMENT 'SQL语句，可以包含参数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `supplement_info_type`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `supplement_info_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(2000) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_exception`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_exception` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(45) DEFAULT NULL,
  `instance_no` varchar(45) DEFAULT NULL,
  `ip_value` varchar(45) NOT NULL,
  `port_value` varchar(45) NOT NULL,
  `exception_type` varchar(150) DEFAULT NULL,
  `exception_content` varchar(20000) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=66686 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_instance`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_instance` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `instance_group` varchar(45) NOT NULL,
  `instance_no` varchar(45) NOT NULL,
  `ip_value` varchar(45) NOT NULL,
  `port_value` varchar(45) NOT NULL,
  `create_time` datetime NOT NULL,
  `update_time` datetime NOT NULL,
  `disable` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sys_version`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_version` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `channel` bigint(20) NOT NULL,
  `version` varchar(20) DEFAULT NULL,
  `update_advice` varchar(20) NOT NULL,
  `reason` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `channel` (`channel`),
  CONSTRAINT `sys_version_ibfk_1` FOREIGN KEY (`channel`) REFERENCES `channel` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tag_type`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tag_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `task_import_marketing_success_data`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `task_import_marketing_success_data` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `cache_key` varchar(100) NOT NULL,
  `marketing` bigint(20) NOT NULL,
  `enable` tinyint(2) NOT NULL,
  `priority` tinyint(2) NOT NULL,
  `source` bigint(20) DEFAULT NULL,
  `channel` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cache_key` (`cache_key`),
  KEY `FK_TASK_TEL_MARKETING_CENTER_REF_MARKETING` (`marketing`),
  KEY `FK_TASK_TEL_MARKETING_CENTER_REF_TEL_MARKETING_CENTER_SOURCE` (`source`),
  KEY `task_import_marketing_success_data_ibfk_3` (`channel`),
  CONSTRAINT `FK_TASK_TEL_MARKETING_CENTER_REF_MARKETING` FOREIGN KEY (`marketing`) REFERENCES `marketing` (`id`),
  CONSTRAINT `FK_TASK_TEL_MARKETING_CENTER_REF_TEL_MARKETING_CENTER_SOURCE` FOREIGN KEY (`source`) REFERENCES `tel_marketing_center_source` (`id`),
  CONSTRAINT `task_import_marketing_success_data_ibfk_3` FOREIGN KEY (`channel`) REFERENCES `channel` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `task_job`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `task_job` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `job_class` varchar(100) NOT NULL,
  `job_name` varchar(50) NOT NULL,
  `job_cron_expression` varchar(50) NOT NULL,
  `param_key1` varchar(50) DEFAULT NULL,
  `param_value1` varchar(100) DEFAULT NULL,
  `param_key2` varchar(50) DEFAULT NULL,
  `param_value2` varchar(100) DEFAULT NULL,
  `param_key3` varchar(50) DEFAULT NULL,
  `param_value3` varchar(100) DEFAULT NULL,
  `comment` varchar(500) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `update_time` datetime NOT NULL,
  `operator` bigint(20) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_TASK_JOB_OPERATOR_REF_INTERNAL_USER` (`operator`),
  CONSTRAINT `FK_TASK_JOB_OPERATOR_REF_INTERNAL_USER` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tel_marketing_center`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tel_marketing_center` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `user` bigint(20) DEFAULT NULL COMMENT '用户ID',
  `mobile` varchar(50) NOT NULL COMMENT '用户电话',
  `user_name` varchar(45) DEFAULT NULL COMMENT '用户名',
  `processed_number` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '处理次数',
  `status` bigint(20) DEFAULT NULL COMMENT '状态|标记',
  `priority` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '优先级',
  `operator` bigint(20) DEFAULT NULL COMMENT '操作人|指派人',
  `expire_time` datetime DEFAULT NULL COMMENT '到期时间',
  `trigger_time` datetime DEFAULT NULL COMMENT '触发时间',
  `source` bigint(20) DEFAULT NULL COMMENT '来源',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `display` tinyint(1) DEFAULT NULL COMMENT '是否显示 1显示 0不显示',
  `source_create_time` datetime DEFAULT NULL COMMENT '来源的创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `FK_TEL_MARKETING_CENTER_REF_USER` (`user`),
  KEY `FK_TEL_MARKETING_CENTER_REF_SOURCE` (`source`),
  KEY `FK_TEL_MARKETING_CENTER_REF_STATUS` (`status`),
  KEY `FK_TEL_MARKETING_CENTER_REF_OPERATOR` (`operator`),
  KEY `INDEX_TEL_MARKETING_CENTER_REF_MOBILE` (`mobile`),
  KEY `idx_tel_marketing_center_mobile` (`mobile`),
  CONSTRAINT `FK_TEL_MARKETING_CENTER_REF_OPERATOR` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_TEL_MARKETING_CENTER_REF_SOURCE` FOREIGN KEY (`source`) REFERENCES `tel_marketing_center_source` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_TEL_MARKETING_CENTER_REF_STATUS` FOREIGN KEY (`status`) REFERENCES `tel_marketing_center_status` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_TEL_MARKETING_CENTER_REF_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=806452 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tel_marketing_center_channel_filter`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tel_marketing_center_channel_filter` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `exclude_channels` varchar(255) DEFAULT NULL,
  `task_type` int(20) NOT NULL,
  `create_time` datetime NOT NULL,
  `update_time` datetime NOT NULL,
  `operator` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_TASK_EXCULDE_CHANNEL_SETTING_OPERATOR_REF_INTERNAL_USER` (`operator`) USING BTREE,
  CONSTRAINT `FK_TASK_EXCULDE_CHANNEL_SETTING_OPERATOR_REF_INTERNAL_USER` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tel_marketing_center_history`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tel_marketing_center_history` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `tel_marketing_center` bigint(20) DEFAULT NULL COMMENT '电话营销中心数据',
  `operator` bigint(20) DEFAULT NULL COMMENT '操作人',
  `comment` varchar(200) DEFAULT NULL COMMENT '备注',
  `deal_result` varchar(45) DEFAULT NULL COMMENT '处理结果',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `type` tinyint(1) DEFAULT NULL,
  `result_detail` varchar(50) DEFAULT NULL,
  `status` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_TEL_MARKETING_CENTER_HISTORY_REF_TEL_MARKETING_CENTER` (`tel_marketing_center`),
  KEY `FK_TEL_MARKETING_CENTER_HISTORY_REF_OPERATOR` (`operator`),
  KEY `tel_marketing_center_history_ibfk_3` (`status`),
  CONSTRAINT `tel_marketing_center_history_ibfk_1` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `tel_marketing_center_history_ibfk_2` FOREIGN KEY (`tel_marketing_center`) REFERENCES `tel_marketing_center` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `tel_marketing_center_history_ibfk_3` FOREIGN KEY (`status`) REFERENCES `tel_marketing_center_status` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=343288 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tel_marketing_center_order`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tel_marketing_center_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tel_marketing_center_history` bigint(20) unsigned DEFAULT NULL,
  `purchase_order` bigint(20) DEFAULT NULL,
  `create_time` datetime NOT NULL,
  `update_time` datetime NOT NULL,
  `operator` bigint(2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_TEL_MARKETING_CENTER_ORDER_REF_INTERNAL_USER` (`operator`),
  KEY `FK_TEL_MARKETING_CENTER_ORDER_REF_PURCHASE_ORDER` (`tel_marketing_center_history`),
  KEY `FK_TEL_MARKETING_CENTER_ORDER_REF_TEL_MARKETING_CENTER_HISTORY` (`purchase_order`),
  CONSTRAINT `FK_TEL_MARKETING_CENTER_ORDER_REF_INTERNAL_USER` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_TEL_MARKETING_CENTER_ORDER_REF_PURCHASE_ORDER` FOREIGN KEY (`purchase_order`) REFERENCES `purchase_order` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_TEL_MARKETING_CENTER_ORDER_REF_TEL_MARKETING_CENTER_HISTORY` FOREIGN KEY (`tel_marketing_center_history`) REFERENCES `tel_marketing_center_history` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=630 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tel_marketing_center_repeat`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tel_marketing_center_repeat` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `user` bigint(20) DEFAULT NULL COMMENT '用户ID',
  `mobile` varchar(50) NOT NULL COMMENT '用户电话',
  `user_name` varchar(45) DEFAULT NULL COMMENT '用户名',
  `source` bigint(20) DEFAULT NULL COMMENT '来源',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `source_create_time` datetime DEFAULT NULL COMMENT '来源的创建时间',
  `source_id` bigint(20) DEFAULT NULL COMMENT '来源id',
  `source_table` varchar(45) DEFAULT NULL COMMENT '来源表名',
  `channel` bigint(20) DEFAULT NULL COMMENT '渠道',
  PRIMARY KEY (`id`),
  KEY `FK_TEL_MARKETING_CENTER_REPEAT_REF_USER` (`user`),
  KEY `FK_TEL_MARKETING_CENTER_REPEAT_REF_SOURCE` (`source`),
  KEY `FK_TEL_MARKETING_CENTER_REPEAT_REF_CHANNEL` (`channel`),
  KEY `idx_tel_marketing_center_repeat_mobile` (`mobile`),
  CONSTRAINT `FK_TEL_MARKETING_CENTER_REPEAT_REF_CHANNEL` FOREIGN KEY (`channel`) REFERENCES `channel` (`id`),
  CONSTRAINT `FK_TEL_MARKETING_CENTER_REPEAT_REF_SOURCE` FOREIGN KEY (`source`) REFERENCES `tel_marketing_center_source` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_TEL_MARKETING_CENTER_REPEAT_REF_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=903006 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tel_marketing_center_repeat_info`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tel_marketing_center_repeat_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `repeat_id` bigint(20) DEFAULT NULL,
  `source_table` varchar(45) DEFAULT NULL COMMENT '来源表名',
  `source_id` bigint(20) DEFAULT NULL COMMENT '来源id',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `FK_TEL_MARKETING_CENTER_REPEAT_INFO_SOURCE_TABLE_ID` (`source_table`,`source_id`),
  KEY `FK_TEL_MARKETING_CENTER_REPEAT_INFO_REF_TEL_REPEAT` (`repeat_id`),
  CONSTRAINT `tel_marketing_center_repeat_info_ibfk_1` FOREIGN KEY (`repeat_id`) REFERENCES `tel_marketing_center_repeat` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23828 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tel_marketing_center_source`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tel_marketing_center_source` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(2000) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  `enable` tinyint(1) DEFAULT '1' COMMENT '可用标记',
  `type` tinyint(1) DEFAULT '0' COMMENT '类型',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=150 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tel_marketing_center_status`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tel_marketing_center_status` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(2000) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=95 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `temp_mobile`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `temp_mobile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mobile` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mobile_UNIQUE` (`mobile`)
) ENGINE=InnoDB AUTO_INCREMENT=6422 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `third_party_code`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `third_party_code` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `user` bigint(20) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `occupied` tinyint(1) DEFAULT '0' COMMENT '是否已领用',
  `code_group` bigint(20) DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  `code_type` bigint(20) DEFAULT NULL COMMENT '优惠码的类别',
  `effective_date` date DEFAULT NULL,
  `expire_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `FK_THIRD_PARTY_CODE_REF_USER_idx` (`user`),
  KEY `FK_THIRD_PARTY_CODE_REF_GROUP_idx` (`code_group`),
  KEY `FK_THIRD_PARTY_CODE_REF_CODE_TYPE` (`code_type`),
  CONSTRAINT `FK_THIRD_PARTY_CODE_REF_CODE_TYPE` FOREIGN KEY (`code_type`) REFERENCES `third_party_code_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_THIRD_PARTY_CODE_REF_GROUP` FOREIGN KEY (`code_group`) REFERENCES `third_party_code_group` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_THIRD_PARTY_CODE_REF_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3787 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `third_party_code_group`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `third_party_code_group` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `name` varchar(45) NOT NULL,
  `description` varchar(2000) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_third_party_code_group_code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `third_party_code_type`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `third_party_code_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `amount` decimal(18,2) DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_third_party_code_group_code` (`amount`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `third_party_identity`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `third_party_identity` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `third_party` tinyint(2) DEFAULT NULL,
  `thirdparty_user_id` varchar(100) DEFAULT NULL,
  `user` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_THIRD_PARTY_IDENTITY_REF_USER` (`user`),
  CONSTRAINT `FK_THIRD_PARTY_IDENTITY_REF_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `third_service_fail`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `third_service_fail` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) NOT NULL,
  `company_id` bigint(20) NOT NULL,
  `message` text,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `device_uniqueid` varchar(255) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `identity` varchar(45) DEFAULT NULL,
  `identity_type` bigint(20) DEFAULT NULL,
  `is_member` tinyint(1) DEFAULT NULL,
  `member_points` decimal(18,0) DEFAULT NULL,
  `mobile` varchar(45) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `user_id` varchar(45) DEFAULT NULL,
  `year_of_birth` int(10) DEFAULT NULL,
  `gender` bigint(20) DEFAULT NULL,
  `user_type` bigint(20) DEFAULT '1',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `bound` tinyint(1) DEFAULT NULL,
  `head_img_url` varchar(200) DEFAULT NULL,
  `nick_name` varchar(200) DEFAULT NULL,
  `sex` tinyint(1) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `company` bigint(20) DEFAULT NULL,
  `register_ip` varchar(45) DEFAULT NULL COMMENT '注册IP',
  `register_channel` bigint(20) DEFAULT NULL COMMENT '注册渠道',
  `user_source` bigint(20) DEFAULT NULL COMMENT '用户来源',
  `audit` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_user_id` (`user_id`),
  KEY `FK_USER_REF_GENDER` (`gender`),
  KEY `FK_USER_REF_IDENTITY` (`identity`),
  KEY `FK_USER_REF_USER_TYPE` (`user_type`),
  KEY `FK_USER_REF_IDENTITY_TYPE` (`identity_type`),
  KEY `idx_user_name` (`name`),
  KEY `idx_user_identity` (`identity`,`identity_type`),
  KEY `FK_USER_REF_CHANNEL` (`register_channel`),
  KEY `idx_user_mobile` (`mobile`),
  KEY `FK_USER_REF_USER_SOURCE` (`user_source`),
  KEY `INDEX_USER_REF_MOBILE` (`mobile`),
  KEY `INDEX_USER_REF_CREATE_TIME` (`create_time`),
  CONSTRAINT `FK_USER_REF_CHANNEL` FOREIGN KEY (`register_channel`) REFERENCES `channel` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_USER_REF_GENDER` FOREIGN KEY (`gender`) REFERENCES `gender` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_USER_REF_IDENTITY_TYPE` FOREIGN KEY (`identity_type`) REFERENCES `identity_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_USER_REF_USER_SOURCE` FOREIGN KEY (`user_source`) REFERENCES `user_source` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_USER_REF_USER_TYPE` FOREIGN KEY (`user_type`) REFERENCES `user_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2191115 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_auto`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_auto` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user` bigint(20) DEFAULT NULL,
  `auto` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_USER_AUTO_REF_USER` (`user`),
  KEY `FK_USER_AUTO_REF_AUTO` (`auto`),
  CONSTRAINT `FK_USER_AUTO_REF_AUTO` FOREIGN KEY (`auto`) REFERENCES `auto` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_USER_AUTO_REF_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=258781 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_img`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_img` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user` bigint(20) DEFAULT NULL,
  `driving_license_path` varchar(1024) DEFAULT NULL COMMENT '行驶证图片URL',
  `owner_identity_path` varchar(1024) DEFAULT NULL COMMENT '驾驶身份证图片URL',
  `create_time` datetime DEFAULT NULL,
  `comment` varchar(2000) DEFAULT NULL,
  `active` tinyint(1) DEFAULT '1',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `source_channel` bigint(20) DEFAULT NULL,
  `quote_entrance` bigint(20) DEFAULT NULL COMMENT '拍照报价入口',
  PRIMARY KEY (`id`),
  KEY `FK_USER_IMG_REF_USER` (`user`),
  KEY `FK_USER_IMG_REF_CHANNEL_IDX` (`source_channel`),
  KEY `FK_USER_IMG_REF_QUOTE_ENTRANCE` (`quote_entrance`),
  CONSTRAINT `FK_USER_IMG_REF_CHANNEL_IDX` FOREIGN KEY (`source_channel`) REFERENCES `channel` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_USER_IMG_REF_QUOTE_ENTRANCE` FOREIGN KEY (`quote_entrance`) REFERENCES `quote_entrance` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_USER_IMG_REF_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=12993 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_invitation`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_invitation` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '记录用户的邀请关系',
  `user` bigint(20) DEFAULT NULL,
  `invited` bigint(200) DEFAULT NULL COMMENT '被邀请人',
  `create_time` datetime DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_invitation_create_time` (`create_time`),
  KEY `FK_USER_INVITATION_USER_REF_USER` (`user`),
  KEY `FK_USER_INVITATION_INVITED_REF_USER` (`invited`),
  CONSTRAINT `FK_USER_INVITATION_INVITED_REF_USER` FOREIGN KEY (`invited`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_USER_INVITATION_USER_REF_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=126 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_invitation_code`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_invitation_code` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '记录用户的邀请码',
  `user` bigint(20) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `code` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_u_user_invitation_code_code` (`code`),
  KEY `FK_USER_INVITATION_CODE_REF_USER` (`user`),
  CONSTRAINT `FK_USER_INVITATION_CODE_REF_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=1449 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_login_info`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_login_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user` bigint(20) DEFAULT NULL,
  `last_login_time` datetime DEFAULT NULL COMMENT '最后登录时间',
  `last_login_ip` varchar(45) DEFAULT NULL COMMENT '最后登录IP',
  `area` bigint(20) DEFAULT NULL,
  `channel` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_USER_LOGIN_INFO_REF_USER` (`user`),
  KEY `FK_USER_LOGIN_INFO_REF_AREA` (`area`),
  KEY `FK_USER_LOGIN_INFO_REF_CHANNEL` (`channel`),
  CONSTRAINT `FK_USER_LOGIN_INFO_REF_AREA` FOREIGN KEY (`area`) REFERENCES `area` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_USER_LOGIN_INFO_REF_CHANNEL` FOREIGN KEY (`channel`) REFERENCES `channel` (`id`),
  CONSTRAINT `FK_USER_LOGIN_INFO_REF_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=649849 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_message`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_message` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_time` datetime DEFAULT NULL,
  `has_push` tinyint(1) DEFAULT NULL,
  `has_read` tinyint(1) DEFAULT NULL,
  `message` bigint(20) DEFAULT NULL,
  `user` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_USER_MESSAGE_REF_MESSAGE_TEMPLATE` (`message`),
  KEY `FK_USER_MESSAGE_REF_USER` (`user`),
  CONSTRAINT `FK_USER_MESSAGE_REF_MESSAGE_TEMPLATE` FOREIGN KEY (`message`) REFERENCES `message_template` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_USER_MESSAGE_REF_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_red_packet`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_red_packet` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `license_plate_no` varchar(45) DEFAULT NULL COMMENT '车牌号',
  `mobile` varchar(45) DEFAULT NULL COMMENT '用户手机号码',
  `nick_name` varchar(200) DEFAULT NULL COMMENT '微信用户的别名',
  `open_id` varchar(100) DEFAULT NULL COMMENT '微信的open_id',
  `operate_date` date DEFAULT NULL COMMENT '用户预约成功的日期',
  `user` bigint(20) DEFAULT NULL COMMENT '用户',
  `quote_photo` bigint(20) NOT NULL COMMENT 'quote_photo表 的主键',
  `status` smallint(1) NOT NULL DEFAULT '1' COMMENT '审核状态',
  `sms_flag` tinyint(1) DEFAULT NULL COMMENT '短信发送状态',
  `sms_result` varchar(45) DEFAULT NULL COMMENT '短信发送结果',
  `red_flag` tinyint(1) DEFAULT NULL COMMENT '微信红包发放状态',
  `red_result` varchar(45) DEFAULT NULL COMMENT '红包发放结果',
  `is_satisfied` smallint(1) DEFAULT '1' COMMENT '是否满足发红包的三个条件',
  `description` varchar(2000) DEFAULT NULL COMMENT '不能发送红包的原因',
  PRIMARY KEY (`id`),
  KEY `FK_USER_RED_PACKET_USER_REF_USER` (`user`),
  KEY `FK_USER_RED_PACKET_QUOTE_PHOTO_REF_QUOTE_PHOTO` (`quote_photo`),
  CONSTRAINT `FK_USER_RED_PACKET_QUOTE_PHOTO_REF_QUOTE_PHOTO` FOREIGN KEY (`quote_photo`) REFERENCES `quote_photo` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_USER_RED_PACKET_USER_REF_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=387 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_role`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_role` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `role` bigint(20) DEFAULT NULL,
  `user` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_USER_ROLE_REF_ROLE` (`role`),
  KEY `FK_USER_ROLE_REF_USER` (`user`),
  CONSTRAINT `FK_USER_ROLE_REF_ROLE` FOREIGN KEY (`role`) REFERENCES `role` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_USER_ROLE_REF_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_source`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_source` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_type`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(2000) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `uuidmapping`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uuidmapping` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(45) COLLATE utf8_bin NOT NULL,
  `session_id` varchar(45) COLLATE utf8_bin NOT NULL,
  `user` bigint(20) DEFAULT NULL,
  `logged` tinyint(1) NOT NULL,
  `update_date` datetime NOT NULL,
  `login_date` datetime DEFAULT NULL,
  `logout_date` datetime DEFAULT NULL,
  `client_type` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `version` varchar(512) COLLATE utf8_bin DEFAULT NULL COMMENT '版本信息',
  `appid` varchar(512) COLLATE utf8_bin DEFAULT NULL COMMENT 'appid',
  PRIMARY KEY (`id`),
  KEY `FK_UUID_MAPPING_REF_USER_idx` (`user`),
  KEY `idx_uuid_clienttype` (`uuid`,`client_type`),
  CONSTRAINT `FK_UUID_MAPPING_REF_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=47180 DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='维护app的uuid和系统session mapping，保证app session不过期';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vehicle_contact`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vehicle_contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mobile` varchar(50) DEFAULT NULL,
  `vehicle_license` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_VEHICLE_CONTACT_REF_VEHICLE_LICENSE` (`vehicle_license`),
  KEY `IDX_VEHICLE_CONTACT_MOBILE` (`mobile`),
  KEY `IDX_VEHICLE_CONTACT_CREATE_TIME` (`create_time`)
) ENGINE=InnoDB AUTO_INCREMENT=492758 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vehicle_license`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vehicle_license` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `license_plate_no` varchar(45) DEFAULT NULL,
  `engine_no` varchar(45) DEFAULT NULL,
  `owner` varchar(45) DEFAULT NULL,
  `vin_no` varchar(45) DEFAULT NULL,
  `enroll_date` date DEFAULT NULL,
  `identity` varchar(45) DEFAULT NULL,
  `brand_code` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_vehicle_license_licenseno` (`license_plate_no`)
) ENGINE=InnoDB AUTO_INCREMENT=3610168 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vip_company`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vip_company` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `code` varchar(45) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  `comment` varchar(2000) DEFAULT NULL,
  `operator` bigint(20) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_VIP_COMPANY_REF_INTERNAL_USER` (`operator`),
  CONSTRAINT `FK_VIP_COMPANY_REF_INTERNAL_USER` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vip_company_activity`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vip_company_activity` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `company` bigint(20) NOT NULL,
  `insurance_url` varchar(100) NOT NULL,
  `error_url` varchar(100) DEFAULT NULL,
  `begin_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `discount` decimal(18,6) DEFAULT NULL,
  `rule_class` varchar(100) NOT NULL,
  `unsupport_company` varchar(45) DEFAULT NULL,
  `payment_channel_channel` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_VIP_COMPANY_ACTIVITY_REF_COMPANY` (`company`),
  CONSTRAINT `FK_VIP_COMPANY_ACTIVITY_REF_COMPANY` FOREIGN KEY (`company`) REFERENCES `vip_company` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wechat_activity`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wechat_activity` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `begin_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_u_activity_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wechat_qrcode`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wechat_qrcode` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `scene_id` bigint(20) DEFAULT NULL,
  `scene_str` varchar(10) DEFAULT NULL,
  `action_name` varchar(20) DEFAULT NULL,
  `ticket` varchar(100) DEFAULT NULL,
  `url` varchar(200) DEFAULT NULL,
  `image_url` varchar(200) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `expire_seconds` int(10) DEFAULT NULL,
  `target` varchar(20) DEFAULT NULL,
  `comments` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1327 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wechat_red_packet`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wechat_red_packet` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `open_id` varchar(100) NOT NULL,
  `mch_bill_no` varchar(100) NOT NULL,
  `min_amount` decimal(18,2) NOT NULL,
  `max_amount` decimal(18,2) NOT NULL,
  `total_amount` decimal(18,2) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `activity` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_WECHAT_RED_PACKET_REF_WECHAT_ACTIVITY` (`activity`),
  KEY `idx_open_id_activity` (`open_id`,`activity`),
  CONSTRAINT `FK_WECHAT_RED_PACKET_REF_WECHAT_ACTIVITY` FOREIGN KEY (`activity`) REFERENCES `webchat_activity` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=333 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wechat_user_channel`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wechat_user_channel` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `open_id` varchar(100) DEFAULT NULL,
  `channel` bigint(20) DEFAULT NULL,
  `wechat_user_info` bigint(20) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `description` varchar(1000) DEFAULT NULL,
  `subscribe` bigint(20) DEFAULT NULL,
  `qrcode` bigint(20) DEFAULT NULL,
  `qrcode_channel` bigint(20) DEFAULT NULL,
  `subscribe_time` bigint(20) DEFAULT NULL,
  `unsubscribed` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `open_id_UNIQUE` (`open_id`),
  KEY `FK_WECHAT_OPEN_ID_REF_WECHAT_USER_INFO_idx_idx` (`wechat_user_info`),
  KEY `FK_WECHAT_USER_CHANNEL_REF_CHANNEL_idx` (`channel`),
  KEY `INDEX_OPENID_CHANNEL` (`open_id`,`channel`),
  KEY `INDEX_WECHAT_USER_CHANNEL_OPENID` (`open_id`),
  KEY `INDEX_WECHAT_USER_CHANNEL_QRCODE` (`qrcode`),
  KEY `INDEX_WECHAT_USER_CHANNEL_QRCODE_CHANNEL` (`qrcode_channel`),
  CONSTRAINT `FK_WECHAT_OPEN_ID_REF_WECHAT_USER_INFO_idx` FOREIGN KEY (`wechat_user_info`) REFERENCES `wechat_user_info` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_WECHAT_USER_CHANNEL_REF_CHANNEL` FOREIGN KEY (`channel`) REFERENCES `channel` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=262778 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `wechat_user_info`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wechat_user_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `subscribe` bigint(20) DEFAULT NULL,
  `nick_name` varchar(200) DEFAULT NULL,
  `sex` tinyint(1) DEFAULT NULL,
  `language` varchar(45) DEFAULT NULL,
  `city` varchar(45) DEFAULT NULL,
  `province` varchar(45) DEFAULT NULL,
  `country` varchar(45) DEFAULT NULL,
  `head_img_url` varchar(200) DEFAULT NULL,
  `subscribe_time` bigint(20) DEFAULT NULL,
  `unsubscribed` tinyint(1) DEFAULT NULL,
  `user` bigint(20) DEFAULT NULL,
  `qrcode` bigint(20) DEFAULT NULL,
  `qrcode_channel` bigint(20) DEFAULT NULL,
  `union_id` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_WECHAT_USER_INFO_REF_USER` (`user`),
  KEY `idx_w_user_qrcode` (`qrcode`),
  KEY `idx_w_user_qrcode_channel` (`qrcode_channel`),
  CONSTRAINT `FK_WECHAT_USER_INFO_REF_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=261028 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-12-26 17:51:45
