-- ����Ϊ�û��б�ʧ�ܵĶ�����Ϣ����
-- ���±�����
update compulsory_insurance set proposal_no = '00200005003000120170021657',policy_no = '10200005003000120170001750' where quote_record =  (select obj_id from purchase_order where order_no = 'I20170510001499');
update insurance set proposal_no = '00200005003301120170024228',policy_no = '10200005003301120170001272' where quote_record = (select obj_id from purchase_order where order_no = 'I20170510001499');

-- ���¶���״̬,֧��״̬
update purchase_order set status = 5 where order_no = 'I20170510001499';
update payment set status = 2,thirdparty_payment_no='2017051021001004220223657046' where purchase_order = (select id from purchase_order where order_no = 'I20170510001499');
-- ���³���״̬
update order_operation_info set original_status = current_status,current_status = 15,update_time = now(),confirm_order_date = now() where purchase_order = (select id from purchase_order where order_no = 'I20170510001499');