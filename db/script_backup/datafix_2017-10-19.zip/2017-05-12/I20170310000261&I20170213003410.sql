-- 京JR5665，I20170310000261，商业险保单号：10200000603301120170000167 原保单添加短期保单及各险种保费
-- 修改报价
UPDATE `quote_record` SET `compulsory_premium`='574.27', `damage_premium`='2612.95', `premium`='3945.70', `third_party_premium`='818.08', `iop_total`='514.67' WHERE id = (SELECT obj_id FROM purchase_order WHERE order_no = 'I20170310000261');
-- 修改订单
UPDATE `purchase_order` SET `payable_amount`='5269.97', `paid_amount`='5269.97' WHERE order_no = 'I20170310000261';
-- 修改商业保单
UPDATE `insurance` SET `damage_premium`='2612.95', `premium`='3945.70', `third_party_premium`='818.08', `iop_total`='514.67' WHERE quote_record = (SELECT obj_id FROM purchase_order WHERE order_no = 'I20170310000261');
-- 修改交强保单
UPDATE `compulsory_insurance` SET `compulsory_premium`='574.27' WHERE quote_record = (SELECT obj_id FROM purchase_order WHERE order_no = 'I20170310000261');
-- 修改支付记录
UPDATE `payment` SET `amount`='5269.97' WHERE purchase_order = (SELECT id FROM purchase_order WHERE order_no = 'I20170310000261');

-- 京Q6R0R9，I20170213003410，商业险保单号：10200000603301120170000167 增加了险种和保额（增加商业险三者的不计免赔）103.6
-- 修改报价
UPDATE `quote_record` SET `premium`='1006.76', `iop_total`='221.40' WHERE id = (SELECT obj_id FROM purchase_order WHERE order_no = 'I20170213003410');
-- 修改订单
UPDATE `purchase_order` SET `payable_amount`='1006.76', `paid_amount`='1006.76' WHERE order_no = 'I20170213003410';
-- 修改商业保单
UPDATE `insurance` SET `premium`='1006.76', `iop_total`='221.40' WHERE quote_record = (SELECT obj_id FROM purchase_order WHERE order_no = 'I20170213003410');
-- 修改支付记录
UPDATE `payment` SET `amount`='1006.76' WHERE purchase_order = (SELECT id FROM purchase_order WHERE order_no = 'I20170213003410');