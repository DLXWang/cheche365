-- 订单号：I20170425001846  车牌号：京N543Z7 这个客户要改被保险跟投保人
UPDATE insurance SET insured_name='刘文林', applicant_name='刘文林', applicant_id_no='330823198209151119', insured_id_no='330823198209151119' WHERE quote_record=(SELECT obj_id FROM purchase_order WHERE order_no = 'I20170425001846');
-- I20170503001800 修改投保人身份证
UPDATE insurance SET applicant_id_no='440881198511160058' WHERE quote_record=(SELECT obj_id FROM purchase_order WHERE order_no = 'I20170503001800');