-- 更新保单起保日期、保额、保费及保单号
UPDATE insurance SET damage_amount='345900.00', damage_premium='5172.33', effective_date='2017-05-11', expire_date='2018-05-12', policy_no='10200005003301120170001286', premium='7471.70', third_party_premium='1324.80', iop_total='974.57' WHERE quote_record = (SELECT obj_id FROM purchase_order WHERE order_no = 'I20170511002118');

-- 更新订单金额及状态
UPDATE purchase_order SET payable_amount='7471.70', paid_amount='7471.70', update_time=now(), status=5, description='2017-05-10 13:06:00 微信7471.70元' WHERE order_no = 'I20170511002118';

-- 更新报价金额
UPDATE quote_record SET compulsory_effective_date='2017-05-11', compulsory_expire_date='2018-05-12', damage_amount='345900.00', damage_premium='5172.33', effective_date='2017-05-11', expire_date='2018-05-12', premium='7471.70', third_party_premium='1324.80', iop_total='974.57' WHERE id = (SELECT obj_id FROM purchase_order WHERE order_no = 'I20170511002118');

-- 更新支付金额及状态
UPDATE payment SET amount='7471.70', update_time=now(), status=2 WHERE purchase_order = (SELECT id FROM purchase_order WHERE order_no = 'I20170511002118');

-- 更新车辆信息
UPDATE auto SET engine_no='7021430', license_plate_no='京WM2891', vin_no='LYVDE40A3HB151822', update_time=now() WHERE id = (SELECT auto FROM purchase_order WHERE order_no = 'I20170511002118');

-- 更新出单状态
update order_operation_info set original_status = current_status,current_status = 15,update_time = now(),confirm_order_date = now() where purchase_order = (select id from purchase_order where order_no = 'I20170511002118');

-- 添加日志数据
insert into `order_process_history` ( `purchase_order`, `original_status`, `current_status`, `order_process_type`, `comment`, `create_time`, `operator`) values ( (SELECT id FROM purchase_order WHERE order_no = 'I20170511002118'), '1', '15', '1', '京WM2891临时车牌手动录单', now(), '8');

-- 切换用户：京WM2891，把下单手机号17051002070 改成客户手机号18811431133
update user_auto set user = (select id from user where mobile = '18811431133' )  where auto  = (select po.auto from purchase_order po where po.order_no = 'I20170511002118' );
update address set applicant = (select id from user where mobile = '18811431133' )  where id = (select po.delivery_address from purchase_order po where po.order_no = 'I20170511002118' );
update quote_record set applicant = (select id from user where mobile = '18811431133' )  where id = (select po.obj_id from purchase_order po where po.order_no = 'I20170511002118' );
update payment set user = (select id from user where mobile = '18811431133' )  where purchase_order=(select po.id from purchase_order po where po.order_no = 'I20170511002118' );
update insurance set applicant=(select id from user where mobile = '18811431133' )  where quote_record=(select po.obj_id from purchase_order po where po.order_no = 'I20170511002118' );
update compulsory_insurance set applicant=(select id from user where mobile = '18811431133' )  where quote_record=(select po.obj_id from purchase_order po where po.order_no = 'I20170511002118' );
update marketing_success set user_id = (select id from user where mobile = '18811431133' ),mobile = '18811431133' where user_id = (select po.applicant from purchase_order po where po.order_no = 'I20170511002118' )  and marketing_id = 76;
update daily_insurance_offer set user = (select id from user where mobile = '18811431133' )   where purchase_order = (select po.id from purchase_order po where po.order_no = 'I20170511002118' );
update purchase_order set applicant = (select id from user where mobile = '18811431133' )  where order_no = 'I20170511002118';