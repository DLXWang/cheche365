-- I20170515000908	线下退款

-- 更新订单状态
update purchase_order set status = 6 where order_no = 'I20170515000908';
-- 添加退款记录
insert into `payment` (`amount`, `comments`, `create_time`, `update_time`, `channel`, `purchase_order`, `status`, `user`, `client_type`, `out_trade_no`, `upstream_id`, `payment_type`) values ('4093.31', '支付宝', now(), now(), '1', '320828', '2', '2667811', '11', 'I20170515000908', NULL, '4');
-- 更新出单状态
update order_operation_info set original_status = current_status,current_status = 17,update_time = now(),confirm_order_date = now() where purchase_order = (select id from purchase_order where order_no = 'I20170515000908');
-- 添加日志数据
insert into `order_process_history` ( `purchase_order`, `original_status`, `current_status`, `order_process_type`, `comment`, `create_time`, `operator`) values ( (SELECT id FROM purchase_order WHERE order_no = 'I20170515000908'), '1', '17', '1', '订单状态由[未确认]改变为[退款中]', now(), '8');