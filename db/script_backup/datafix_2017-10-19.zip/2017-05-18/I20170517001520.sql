-- 更新商业保单投保人被保人姓名、保单号
UPDATE insurance SET insured_name='江友', applicant_name='江友', policy_no='10200005003301120170001537', insurance_package='12667' WHERE quote_record = (SELECT obj_id FROM purchase_order WHERE order_no = 'I20170517001520');

-- 添加交强保单
INSERT INTO compulsory_insurance (`auto_tax`, `compulsory_premium`, `create_time`, `discount`, `effective_date`, `effective_hour`, `expire_date`, `expire_hour`, `insurance_image`, `insured_name`, `original_policy_no`, `policy_no`, `proposal_no`, `update_time`, `applicant`, `auto`, `insurance_agent`, `insurance_company`, `insurance_package`, `operator`, `quote_record`, `applicant_name`, `applicant_id_no`, `applicant_mobile`, `applicant_email`, `insured_id_no`, `insured_mobile`, `insured_email`, `institution`) VALUES ('750.00', '761.43', now(), '1.000000', '2017-05-21', '0', '2018-05-20', '24', NULL, '江友', NULL, '10200005003000120170002046', NULL, NULL, '1725085', '814525', NULL, '65000', '12667', NULL, '377033', '江友', '430281198604165312', NULL, NULL, '430281198604165312', NULL, NULL, NULL);

-- 更新订单金额及状态
UPDATE purchase_order SET payable_amount='2302.42', paid_amount='2302.42', update_time=now(), status=5, description='2017-05-17 13:06:00 微信2302.42元' WHERE order_no = 'I20170517001520';

-- 更新报价金额
UPDATE quote_record SET compulsory_premium='761.43', auto_tax='750.0', insurance_package='12667' WHERE id = (SELECT obj_id FROM purchase_order WHERE order_no = 'I20170517001520');

-- 更新支付金额及状态
UPDATE payment SET amount='2302.42', update_time=now(), status=2 WHERE purchase_order = (SELECT id FROM purchase_order WHERE order_no = 'I20170517001520');

-- 更新车辆信息
UPDATE auto SET owner='江子云', identity='430281195210125314', update_time=now() WHERE id = (SELECT auto FROM purchase_order WHERE order_no = 'I20170517001520');

-- 添加日志数据
insert into `order_process_history` ( `purchase_order`, `original_status`, `current_status`, `order_process_type`, `comment`, `create_time`, `operator`) values ( (SELECT id FROM purchase_order WHERE order_no = 'I20170517001520'), '1', '15', '1', '京QH86A7手动录单', now(), '8');

-- 切换用户：京QH86A7，把下单手机号17051002070 改成客户手机号13552310573
update user_auto set user = (select id from user where mobile = '13552310573' )  where auto  = (select po.auto from purchase_order po where po.order_no = 'I20170517001520' );
update address set applicant = (select id from user where mobile = '13552310573' )  where id = (select po.delivery_address from purchase_order po where po.order_no = 'I20170517001520' );
update quote_record set applicant = (select id from user where mobile = '13552310573' )  where id = (select po.obj_id from purchase_order po where po.order_no = 'I20170517001520' );
update payment set user = (select id from user where mobile = '13552310573' )  where purchase_order=(select po.id from purchase_order po where po.order_no = 'I20170517001520' );
update insurance set applicant=(select id from user where mobile = '13552310573' )  where quote_record=(select po.obj_id from purchase_order po where po.order_no = 'I20170517001520' );
update compulsory_insurance set applicant=(select id from user where mobile = '13552310573' )  where quote_record=(select po.obj_id from purchase_order po where po.order_no = 'I20170517001520' );
update marketing_success set user_id = (select id from user where mobile = '13552310573' ),mobile = '13552310573' where user_id = (select po.applicant from purchase_order po where po.order_no = 'I20170517001520' )  and marketing_id = 76;
update daily_insurance_offer set user = (select id from user where mobile = '13552310573' )   where purchase_order = (select po.id from purchase_order po where po.order_no = 'I20170517001520' );
update purchase_order set applicant = (select id from user where mobile = '13552310573' )  where order_no = 'I20170517001520';