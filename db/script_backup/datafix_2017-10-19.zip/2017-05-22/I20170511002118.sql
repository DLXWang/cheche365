-- 之前B2B录单（I20170511002118）临时车牌“京WM2891”改为“京N23YZ9”
UPDATE auto SET license_plate_no='京N23YZ9' WHERE id = (SELECT auto FROM purchase_order WHERE order_no = 'I20170511002118');