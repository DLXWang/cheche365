UPDATE purchase_order SET status = 1 where id = 321100
