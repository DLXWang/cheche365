update insurance_person set identity =null where id in(7094,37455,37456,7245,7253,23706,23723,30170,30184,30354,9194,13110);
update insurance_person set name='长盛环保工程有限公司' where id=37455;
update insurance_person set name='亿森物流有限公司' where id=37456;