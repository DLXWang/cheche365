UPDATE `insurance` SET  `damage_amount`='40300.00', `damage_iop`='63.41', `damage_premium`='422.70', 
`discount`='1.000000', `driver_amount`='0.00', `driver_iop`='0.00', `driver_premium`='0.00',
 `engine_amount`='0.00', `engine_iop`='0.00', `engine_premium`='0.00', 
 `glass_amount`='0.00', `glass_premium`='0.00',  `passenger_amount`='0.00', 
`passenger_count`='0', `passenger_iop`='0.00', `passenger_premium`='0.00', 
`premium`='903.05',  `scratch_amount`='0.00', `scratch_iop`='0.00', `scratch_premium`='0.00', 
`spontaneous_loss_amount`='0.00', `spontaneous_loss_premium`='0.00', `theft_amount`='0.00', `theft_iop`='0.00',
 `theft_premium`='0.00', `third_party_amount`='100000.00', `third_party_iop`='54.38',
 `third_party_premium`='362.56', 
 `insurance_package`='11136',`iop_total`='117.79',
 `spontaneous_loss_iop`='0.00', `unable_find_third_party_premium`='0.00' WHERE (`id`='107230');



UPDATE `insurance` SET  `damage_amount`='433137.39', `damage_iop`='1171.16', `damage_premium`='6636.57', 
 `driver_amount`='200000.00', `driver_iop`='72.00', `driver_premium`='408.00', 
 `engine_iop`='0.00', `engine_premium`='0.00',  `glass_amount`='0.00',`glass_premium`='0.00',  `passenger_amount`='200000.00', 
`passenger_count`='0', `passenger_iop`='184.95', `passenger_premium`='1048.05', `premium`='15439.58',
`scratch_amount`='0.00', `scratch_iop`='0.00', `scratch_premium`='0.00', `spontaneous_loss_amount`='433137.39', 
`spontaneous_loss_premium`='1762.84', `theft_amount`='433137.39', `theft_iop`='347.69', `theft_premium`='1970.23', 
`third_party_amount`='1500000.00', `third_party_iop`='229.05', `third_party_premium`='1297.95',
  `insurance_package`='22592',
  `iop_total`='0.00', `spontaneous_loss_iop`='0.00', `unable_find_third_party_premium`='0.00' WHERE (`id`='108227');


UPDATE `insurance` SET  `damage_amount`='568224.46', `damage_iop`='1536.42', `damage_premium`='8706.39', 
`driver_amount`='200000.00', `driver_iop`='72.00', `driver_premium`='408.00', 
 `engine_amount`='0.00', `engine_iop`='0.00', `engine_premium`='0.00', 
`glass_amount`='0.00', `glass_premium`='0.00',  `passenger_amount`='200000.00', `passenger_count`='0.00', 
`passenger_iop`='184.95', `passenger_premium`='1048.05',  `premium`='19244.39', 
 `scratch_amount`='0.00', `scratch_iop`='0.00', `scratch_premium`='0.00', `spontaneous_loss_amount`='568224.46',
 `spontaneous_loss_premium`='2312.63', `theft_amount`='568224.46', `theft_iop`='456.13', `theft_premium`='2584.71', 
`third_party_amount`='1500000.00', `third_party_iop`='229.05', `third_party_premium`='1297.95', 
 `insurance_package`='22595',`iop_total`='0.00', `spontaneous_loss_iop`='0.00', `unable_find_third_party_premium`='0.00' WHERE (`id`='98267');