update insurance_person set identity =null where id in(26280,26276,37740,37744);
update insurance_person set name='上海正祥机械部件有限公司' where id=37740;
update insurance_person set name='鹰潭华运达物流有限公司' where id=37744;
update auto set identity= null,identity_type=10 where id=722135;
update insurance set applicant_id_no = null ,insured_id_no = null,insured_name='四川睿金五金公司嘉兴分公司' where id=123155;
update compulsory_insurance set applicant_id_no = null ,insured_id_no = null,insured_name='四川睿金五金公司嘉兴分公司' where id=115149;