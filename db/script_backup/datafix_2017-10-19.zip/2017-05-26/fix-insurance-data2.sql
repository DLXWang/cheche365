update auto set owner='四川睿金五金公司嘉兴分公司' where id=722135;
update insurance set applicant_name='四川睿金五金公司嘉兴分公司' where id=123155;