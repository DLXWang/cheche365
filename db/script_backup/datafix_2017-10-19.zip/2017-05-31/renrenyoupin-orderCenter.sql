﻿update order_operation_info set current_status ='1' where  purchase_order in (SELECT id FROM purchase_order WHERE order_no='I20170531001287');
