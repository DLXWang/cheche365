﻿update payment set status='2' where purchase_order in (select id from purchase_order where order_no='I20170531001287');
update purchase_order set status='3' where order_no ='I20170531001287';