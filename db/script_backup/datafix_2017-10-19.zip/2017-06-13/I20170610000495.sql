update purchase_order set status =2 where id=324578;
update payment set status =4 where status=1 and payment_type=2 and purchase_order=324578;
update purchase_order_amend set purchase_order_amend_status=2 where payment_type=2 and purchase_order_amend_status=1 and purchase_order=324578;
update order_operation_info set original_status=current_status,current_status=1 where purchase_order=324578;
insert into order_process_history ( purchase_order, original_status, current_status, order_process_type, comment, create_time, operator) values ( '324578', '22', '1', '1', '����״̬��[׷�Ӹ���]�ı�Ϊ[δȷ��]', now(), '8');
