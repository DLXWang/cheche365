-- 之前B2B录单（I20170306003632）临时车牌“京N813Y2”改为“京Q16GC7”
UPDATE auto SET license_plate_no='京Q16GC7' WHERE id = (SELECT auto FROM purchase_order WHERE order_no = 'I20170306003632');