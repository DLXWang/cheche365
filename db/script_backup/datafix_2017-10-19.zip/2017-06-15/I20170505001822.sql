UPDATE `daily_restart_insurance` SET `restart_policy_no`='10200005003301120170001143-2', `status`='5' WHERE `id`='14';
UPDATE `daily_insurance` SET `restart_date`='2017-06-15',`status`='7' WHERE `id`='2435';
