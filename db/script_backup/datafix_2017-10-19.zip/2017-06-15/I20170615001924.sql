﻿update purchase_order set status =2 where id=324938;
update purchase_order_amend set purchase_order_amend_status=3 where id=1481;
update order_operation_info set original_status=current_status,current_status=1 where purchase_order=324938;
insert into order_process_history ( purchase_order, original_status, current_status, order_process_type, comment, create_time, operator) values ( '324938', '16', '1', '1', '订单状态由[退款中]改变为[取消退款]', now(), '8');
 