INSERT into user (mobile, create_time, audit, bound, user_type) values ('15039382105', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('WB648010', '深圳市金荣达美科技有限公司', 'LFNA4HB58ETA04881', '粤BT9441', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15039382105'), (select max(id) from auto where license_plate_no = '粤BT9441'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15039382105'), p.auto = (select max(id) from auto where license_plate_no ='粤BT9441') where  p.id = 260065 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15039382105'), i.auto = (select max(id) from auto where license_plate_no ='粤BT9441')  where p.obj_id = i.quote_record and  p.id = 260065 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15039382105'), i.auto = (select max(id) from auto where license_plate_no ='粤BT9441')  where p.obj_id = i.quote_record and p.id =  260065 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15039382105'), qr.auto = (select max(id) from auto where license_plate_no = '粤BT9441') where p.obj_id = qr.id and p.id = 260065 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15039382105') where pay.purchase_order = p.id and p.id = 260065 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15568075224', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('344170', '深圳市宝安区新华书店', 'LSYGN4AFX4K005775', '粤BBA840', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15568075224'), (select max(id) from auto where license_plate_no = '粤BBA840'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15568075224'), p.auto = (select max(id) from auto where license_plate_no ='粤BBA840') where  p.id = 260239 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15568075224'), i.auto = (select max(id) from auto where license_plate_no ='粤BBA840')  where p.obj_id = i.quote_record and  p.id = 260239 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15568075224'), i.auto = (select max(id) from auto where license_plate_no ='粤BBA840')  where p.obj_id = i.quote_record and p.id =  260239 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15568075224'), qr.auto = (select max(id) from auto where license_plate_no = '粤BBA840') where p.obj_id = qr.id and p.id = 260239 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15568075224') where pay.purchase_order = p.id and p.id = 260239 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13080128588', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('4008087', '邦州科技（苏州）有限公司', 'LVHRR7836D5008108', '苏E9975F', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13080128588'), (select max(id) from auto where license_plate_no = '苏E9975F'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13080128588'), p.auto = (select max(id) from auto where license_plate_no ='苏E9975F') where  p.id = 260240 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13080128588'), i.auto = (select max(id) from auto where license_plate_no ='苏E9975F')  where p.obj_id = i.quote_record and  p.id = 260240 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13080128588'), i.auto = (select max(id) from auto where license_plate_no ='苏E9975F')  where p.obj_id = i.quote_record and p.id =  260240 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13080128588'), qr.auto = (select max(id) from auto where license_plate_no = '苏E9975F') where p.obj_id = qr.id and p.id = 260240 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13080128588') where pay.purchase_order = p.id and p.id = 260240 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18011363470', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('UA90821066', '曹军', 'LZWACAGA7A7169857', '沪A596T5', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18011363470'), (select max(id) from auto where license_plate_no = '沪A596T5'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18011363470'), p.auto = (select max(id) from auto where license_plate_no ='沪A596T5') where  p.id = 260261 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18011363470'), i.auto = (select max(id) from auto where license_plate_no ='沪A596T5')  where p.obj_id = i.quote_record and  p.id = 260261 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18011363470'), i.auto = (select max(id) from auto where license_plate_no ='沪A596T5')  where p.obj_id = i.quote_record and p.id =  260261 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18011363470'), qr.auto = (select max(id) from auto where license_plate_no = '沪A596T5') where p.obj_id = qr.id and p.id = 260261 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18011363470') where pay.purchase_order = p.id and p.id = 260261 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15186481382', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('G181373', '深圳市赢时通汽车服务有限公司', 'LFMAP22C3D0491024', '粤B1NB58', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15186481382'), (select max(id) from auto where license_plate_no = '粤B1NB58'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15186481382'), p.auto = (select max(id) from auto where license_plate_no ='粤B1NB58') where  p.id = 260262 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15186481382'), i.auto = (select max(id) from auto where license_plate_no ='粤B1NB58')  where p.obj_id = i.quote_record and  p.id = 260262 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15186481382'), i.auto = (select max(id) from auto where license_plate_no ='粤B1NB58')  where p.obj_id = i.quote_record and p.id =  260262 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15186481382'), qr.auto = (select max(id) from auto where license_plate_no = '粤B1NB58') where p.obj_id = qr.id and p.id = 260262 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15186481382') where pay.purchase_order = p.id and p.id = 260262 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18777907682', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('588686', '深圳市凤凰建设机械城有限公司', 'LSYHDAAA07K020784', '粤BXQ815', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18777907682'), (select max(id) from auto where license_plate_no = '粤BXQ815'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18777907682'), p.auto = (select max(id) from auto where license_plate_no ='粤BXQ815') where  p.id = 260283 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18777907682'), i.auto = (select max(id) from auto where license_plate_no ='粤BXQ815')  where p.obj_id = i.quote_record and  p.id = 260283 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18777907682'), i.auto = (select max(id) from auto where license_plate_no ='粤BXQ815')  where p.obj_id = i.quote_record and p.id =  260283 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18777907682'), qr.auto = (select max(id) from auto where license_plate_no = '粤BXQ815') where p.obj_id = qr.id and p.id = 260283 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18777907682') where pay.purchase_order = p.id and p.id = 260283 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15518299221', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('159300', '昆山建兴建设工程有限公司', 'LSVT91336BN068109', '苏E699MT', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15518299221'), (select max(id) from auto where license_plate_no = '苏E699MT'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15518299221'), p.auto = (select max(id) from auto where license_plate_no ='苏E699MT') where  p.id = 260284 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15518299221'), i.auto = (select max(id) from auto where license_plate_no ='苏E699MT')  where p.obj_id = i.quote_record and  p.id = 260284 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15518299221'), i.auto = (select max(id) from auto where license_plate_no ='苏E699MT')  where p.obj_id = i.quote_record and p.id =  260284 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15518299221'), qr.auto = (select max(id) from auto where license_plate_no = '苏E699MT') where p.obj_id = qr.id and p.id = 260284 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15518299221') where pay.purchase_order = p.id and p.id = 260284 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13347377551', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('SPA1039', '林小芳', 'LGB2AAA31EZ111110', '京AU6K89', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13347377551'), (select max(id) from auto where license_plate_no = '京AU6K89'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13347377551'), p.auto = (select max(id) from auto where license_plate_no ='京AU6K89') where  p.id = 260297 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13347377551'), i.auto = (select max(id) from auto where license_plate_no ='京AU6K89')  where p.obj_id = i.quote_record and  p.id = 260297 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13347377551'), i.auto = (select max(id) from auto where license_plate_no ='京AU6K89')  where p.obj_id = i.quote_record and p.id =  260297 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13347377551'), qr.auto = (select max(id) from auto where license_plate_no = '京AU6K89') where p.obj_id = qr.id and p.id = 260297 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13347377551') where pay.purchase_order = p.id and p.id = 260297 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13818936286', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('917843', '常熟市启源针纺织品有限公司', 'LSVCD2A47CN069397', '苏EB36S2', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13818936286'), (select max(id) from auto where license_plate_no = '苏EB36S2'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13818936286'), p.auto = (select max(id) from auto where license_plate_no ='苏EB36S2') where  p.id = 277928 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13818936286'), i.auto = (select max(id) from auto where license_plate_no ='苏EB36S2')  where p.obj_id = i.quote_record and  p.id = 277928 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13818936286'), i.auto = (select max(id) from auto where license_plate_no ='苏EB36S2')  where p.obj_id = i.quote_record and p.id =  277928 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13818936286'), qr.auto = (select max(id) from auto where license_plate_no = '苏EB36S2') where p.obj_id = qr.id and p.id = 277928 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13818936286') where pay.purchase_order = p.id and p.id = 277928 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15880585344', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('2GRA573344', '张家港市合兴漆布厂', 'JTJBK11AX92414773', '苏EFU791', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15880585344'), (select max(id) from auto where license_plate_no = '苏EFU791'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15880585344'), p.auto = (select max(id) from auto where license_plate_no ='苏EFU791') where  p.id = 277929 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15880585344'), i.auto = (select max(id) from auto where license_plate_no ='苏EFU791')  where p.obj_id = i.quote_record and  p.id = 277929 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15880585344'), i.auto = (select max(id) from auto where license_plate_no ='苏EFU791')  where p.obj_id = i.quote_record and p.id =  277929 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15880585344'), qr.auto = (select max(id) from auto where license_plate_no = '苏EFU791') where p.obj_id = qr.id and p.id = 277929 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15880585344') where pay.purchase_order = p.id and p.id = 277929 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15016055238', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('56787A', '李留青', 'LSYEKS2M0CH101699', '京K5349H', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15016055238'), (select max(id) from auto where license_plate_no = '京K5349H'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15016055238'), p.auto = (select max(id) from auto where license_plate_no ='京K5349H') where  p.id = 281009 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15016055238'), i.auto = (select max(id) from auto where license_plate_no ='京K5349H')  where p.obj_id = i.quote_record and  p.id = 281009 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15016055238'), i.auto = (select max(id) from auto where license_plate_no ='京K5349H')  where p.obj_id = i.quote_record and p.id =  281009 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15016055238'), qr.auto = (select max(id) from auto where license_plate_no = '京K5349H') where p.obj_id = qr.id and p.id = 281009 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15016055238') where pay.purchase_order = p.id and p.id = 281009 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15512145664', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('G4EDC5009409', '深圳市迅达汽车运输有限公司', 'LJDDAA226C0491423', '粤BQ0F43', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15512145664'), (select max(id) from auto where license_plate_no = '粤BQ0F43'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15512145664'), p.auto = (select max(id) from auto where license_plate_no ='粤BQ0F43') where  p.id = 281011 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15512145664'), i.auto = (select max(id) from auto where license_plate_no ='粤BQ0F43')  where p.obj_id = i.quote_record and  p.id = 281011 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15512145664'), i.auto = (select max(id) from auto where license_plate_no ='粤BQ0F43')  where p.obj_id = i.quote_record and p.id =  281011 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15512145664'), qr.auto = (select max(id) from auto where license_plate_no = '粤BQ0F43') where p.obj_id = qr.id and p.id = 281011 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15512145664') where pay.purchase_order = p.id and p.id = 281011 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18698440070', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('1505509144', '李志红', 'LGWEE4A40FF104274', '京HCC083', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18698440070'), (select max(id) from auto where license_plate_no = '京HCC083'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18698440070'), p.auto = (select max(id) from auto where license_plate_no ='京HCC083') where  p.id = 281016 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18698440070'), i.auto = (select max(id) from auto where license_plate_no ='京HCC083')  where p.obj_id = i.quote_record and  p.id = 281016 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18698440070'), i.auto = (select max(id) from auto where license_plate_no ='京HCC083')  where p.obj_id = i.quote_record and p.id =  281016 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18698440070'), qr.auto = (select max(id) from auto where license_plate_no = '京HCC083') where p.obj_id = qr.id and p.id = 281016 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18698440070') where pay.purchase_order = p.id and p.id = 281016 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13066632298', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('8274554', '中国共产党深圳市纪律检查委员会', 'LFMES5811AS008556', '粤BH7133', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13066632298'), (select max(id) from auto where license_plate_no = '粤BH7133'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13066632298'), p.auto = (select max(id) from auto where license_plate_no ='粤BH7133') where  p.id = 281027 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13066632298'), i.auto = (select max(id) from auto where license_plate_no ='粤BH7133')  where p.obj_id = i.quote_record and  p.id = 281027 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13066632298'), i.auto = (select max(id) from auto where license_plate_no ='粤BH7133')  where p.obj_id = i.quote_record and p.id =  281027 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13066632298'), qr.auto = (select max(id) from auto where license_plate_no = '粤BH7133') where p.obj_id = qr.id and p.id = 281027 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13066632298') where pay.purchase_order = p.id and p.id = 281027 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18724427174', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('313054', '深圳市华裕特特殊钢有限公司', 'LFV2A11G3A3505501', '粤B147L6', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18724427174'), (select max(id) from auto where license_plate_no = '粤B147L6'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18724427174'), p.auto = (select max(id) from auto where license_plate_no ='粤B147L6') where  p.id = 281028 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18724427174'), i.auto = (select max(id) from auto where license_plate_no ='粤B147L6')  where p.obj_id = i.quote_record and  p.id = 281028 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18724427174'), i.auto = (select max(id) from auto where license_plate_no ='粤B147L6')  where p.obj_id = i.quote_record and p.id =  281028 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18724427174'), qr.auto = (select max(id) from auto where license_plate_no = '粤B147L6') where p.obj_id = qr.id and p.id = 281028 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18724427174') where pay.purchase_order = p.id and p.id = 281028 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13122272176', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('064648', '徐华伟', 'LSVGL49J982067363', '沪CQ6731', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13122272176'), (select max(id) from auto where license_plate_no = '沪CQ6731'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13122272176'), p.auto = (select max(id) from auto where license_plate_no ='沪CQ6731') where  p.id = 281034 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13122272176'), i.auto = (select max(id) from auto where license_plate_no ='沪CQ6731')  where p.obj_id = i.quote_record and  p.id = 281034 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13122272176'), i.auto = (select max(id) from auto where license_plate_no ='沪CQ6731')  where p.obj_id = i.quote_record and p.id =  281034 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13122272176'), qr.auto = (select max(id) from auto where license_plate_no = '沪CQ6731') where p.obj_id = qr.id and p.id = 281034 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13122272176') where pay.purchase_order = p.id and p.id = 281034 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15744688196', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('41124330', '苏州吉裕顺建筑装饰工程有限公司', 'LSGDC82C65E006611', '苏EP59Q8', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15744688196'), (select max(id) from auto where license_plate_no = '苏EP59Q8'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15744688196'), p.auto = (select max(id) from auto where license_plate_no ='苏EP59Q8') where  p.id = 281043 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15744688196'), i.auto = (select max(id) from auto where license_plate_no ='苏EP59Q8')  where p.obj_id = i.quote_record and  p.id = 281043 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15744688196'), i.auto = (select max(id) from auto where license_plate_no ='苏EP59Q8')  where p.obj_id = i.quote_record and p.id =  281043 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15744688196'), qr.auto = (select max(id) from auto where license_plate_no = '苏EP59Q8') where p.obj_id = qr.id and p.id = 281043 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15744688196') where pay.purchase_order = p.id and p.id = 281043 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18025847314', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('A08582', '王存文', 'LTA1222B9D2014760', '京J33252', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18025847314'), (select max(id) from auto where license_plate_no = '京J33252'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18025847314'), p.auto = (select max(id) from auto where license_plate_no ='京J33252') where  p.id = 281046 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18025847314'), i.auto = (select max(id) from auto where license_plate_no ='京J33252')  where p.obj_id = i.quote_record and  p.id = 281046 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18025847314'), i.auto = (select max(id) from auto where license_plate_no ='京J33252')  where p.obj_id = i.quote_record and p.id =  281046 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18025847314'), qr.auto = (select max(id) from auto where license_plate_no = '京J33252') where p.obj_id = qr.id and p.id = 281046 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18025847314') where pay.purchase_order = p.id and p.id = 281046 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13070676370', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('U90171929A', '城固县大桥农资有限责任公司', 'LVBV4PBB99E443395', '京F16061', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13070676370'), (select max(id) from auto where license_plate_no = '京F16061'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13070676370'), p.auto = (select max(id) from auto where license_plate_no ='京F16061') where  p.id = 281049 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13070676370'), i.auto = (select max(id) from auto where license_plate_no ='京F16061')  where p.obj_id = i.quote_record and  p.id = 281049 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13070676370'), i.auto = (select max(id) from auto where license_plate_no ='京F16061')  where p.obj_id = i.quote_record and p.id =  281049 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13070676370'), qr.auto = (select max(id) from auto where license_plate_no = '京F16061') where p.obj_id = qr.id and p.id = 281049 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13070676370') where pay.purchase_order = p.id and p.id = 281049 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13411636209', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('A14000', '上海泰斗商务咨询有限公司', 'LFV3A23CXD3085518', '沪A0V267', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13411636209'), (select max(id) from auto where license_plate_no = '沪A0V267'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13411636209'), p.auto = (select max(id) from auto where license_plate_no ='沪A0V267') where  p.id = 281050 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13411636209'), i.auto = (select max(id) from auto where license_plate_no ='沪A0V267')  where p.obj_id = i.quote_record and  p.id = 281050 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13411636209'), i.auto = (select max(id) from auto where license_plate_no ='沪A0V267')  where p.obj_id = i.quote_record and p.id =  281050 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13411636209'), qr.auto = (select max(id) from auto where license_plate_no = '沪A0V267') where p.obj_id = qr.id and p.id = 281050 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13411636209') where pay.purchase_order = p.id and p.id = 281050 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18843319881', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('SMN7136', '宜川县人民医院', 'LJXBHFHC5DT055827', '京JN6995', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18843319881'), (select max(id) from auto where license_plate_no = '京JN6995'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18843319881'), p.auto = (select max(id) from auto where license_plate_no ='京JN6995') where  p.id = 281051 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18843319881'), i.auto = (select max(id) from auto where license_plate_no ='京JN6995')  where p.obj_id = i.quote_record and  p.id = 281051 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18843319881'), i.auto = (select max(id) from auto where license_plate_no ='京JN6995')  where p.obj_id = i.quote_record and p.id =  281051 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18843319881'), qr.auto = (select max(id) from auto where license_plate_no = '京JN6995') where p.obj_id = qr.id and p.id = 281051 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18843319881') where pay.purchase_order = p.id and p.id = 281051 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15911321544', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('AWL002189', '唐鸿华', 'LFVBA14B7Y3011491', '沪A33D36', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15911321544'), (select max(id) from auto where license_plate_no = '沪A33D36'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15911321544'), p.auto = (select max(id) from auto where license_plate_no ='沪A33D36') where  p.id = 281054 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15911321544'), i.auto = (select max(id) from auto where license_plate_no ='沪A33D36')  where p.obj_id = i.quote_record and  p.id = 281054 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15911321544'), i.auto = (select max(id) from auto where license_plate_no ='沪A33D36')  where p.obj_id = i.quote_record and p.id =  281054 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15911321544'), qr.auto = (select max(id) from auto where license_plate_no = '沪A33D36') where p.obj_id = qr.id and p.id = 281054 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15911321544') where pay.purchase_order = p.id and p.id = 281054 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15043060791', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('003564', '深圳市倍纳实电子有限公司', 'LFV2C12KX53004236', '粤BVT790', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15043060791'), (select max(id) from auto where license_plate_no = '粤BVT790'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15043060791'), p.auto = (select max(id) from auto where license_plate_no ='粤BVT790') where  p.id = 281055 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15043060791'), i.auto = (select max(id) from auto where license_plate_no ='粤BVT790')  where p.obj_id = i.quote_record and  p.id = 281055 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15043060791'), i.auto = (select max(id) from auto where license_plate_no ='粤BVT790')  where p.obj_id = i.quote_record and p.id =  281055 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15043060791'), qr.auto = (select max(id) from auto where license_plate_no = '粤BVT790') where p.obj_id = qr.id and p.id = 281055 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15043060791') where pay.purchase_order = p.id and p.id = 281055 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18779398205', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('LJ465Q-1AE6509116591', '胡春雷', 'LZWABCJ1652088651', '沪CPD119', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18779398205'), (select max(id) from auto where license_plate_no = '沪CPD119'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18779398205'), p.auto = (select max(id) from auto where license_plate_no ='沪CPD119') where  p.id = 281056 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18779398205'), i.auto = (select max(id) from auto where license_plate_no ='沪CPD119')  where p.obj_id = i.quote_record and  p.id = 281056 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18779398205'), i.auto = (select max(id) from auto where license_plate_no ='沪CPD119')  where p.obj_id = i.quote_record and p.id =  281056 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18779398205'), qr.auto = (select max(id) from auto where license_plate_no = '沪CPD119') where p.obj_id = qr.id and p.id = 281056 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18779398205') where pay.purchase_order = p.id and p.id = 281056 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13181315434', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('8CC1321002', '李敏杰', 'LZWACAGA7C6082193', '京AZ270Y', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13181315434'), (select max(id) from auto where license_plate_no = '京AZ270Y'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13181315434'), p.auto = (select max(id) from auto where license_plate_no ='京AZ270Y') where  p.id = 281059 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13181315434'), i.auto = (select max(id) from auto where license_plate_no ='京AZ270Y')  where p.obj_id = i.quote_record and  p.id = 281059 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13181315434'), i.auto = (select max(id) from auto where license_plate_no ='京AZ270Y')  where p.obj_id = i.quote_record and p.id =  281059 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13181315434'), qr.auto = (select max(id) from auto where license_plate_no = '京AZ270Y') where p.obj_id = qr.id and p.id = 281059 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13181315434') where pay.purchase_order = p.id and p.id = 281059 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13287139143', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('60302911', '王昌锋', 'LFNAFUKM5F1E05960', '京AQ3895', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13287139143'), (select max(id) from auto where license_plate_no = '京AQ3895'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13287139143'), p.auto = (select max(id) from auto where license_plate_no ='京AQ3895') where  p.id = 281061 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13287139143'), i.auto = (select max(id) from auto where license_plate_no ='京AQ3895')  where p.obj_id = i.quote_record and  p.id = 281061 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13287139143'), i.auto = (select max(id) from auto where license_plate_no ='京AQ3895')  where p.obj_id = i.quote_record and p.id =  281061 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13287139143'), qr.auto = (select max(id) from auto where license_plate_no = '京AQ3895') where p.obj_id = qr.id and p.id = 281061 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13287139143') where pay.purchase_order = p.id and p.id = 281061 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18672514823', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('8C52110649', '吴兴芹', 'LZWACAGA6C4206725', '京DH2833', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18672514823'), (select max(id) from auto where license_plate_no = '京DH2833'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18672514823'), p.auto = (select max(id) from auto where license_plate_no ='京DH2833') where  p.id = 281063 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18672514823'), i.auto = (select max(id) from auto where license_plate_no ='京DH2833')  where p.obj_id = i.quote_record and  p.id = 281063 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18672514823'), i.auto = (select max(id) from auto where license_plate_no ='京DH2833')  where p.obj_id = i.quote_record and p.id =  281063 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18672514823'), qr.auto = (select max(id) from auto where license_plate_no = '京DH2833') where p.obj_id = qr.id and p.id = 281063 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18672514823') where pay.purchase_order = p.id and p.id = 281063 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18902108663', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('11158180', '张强', 'LGKG42G99B9K01759', '京AJ723X', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18902108663'), (select max(id) from auto where license_plate_no = '京AJ723X'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18902108663'), p.auto = (select max(id) from auto where license_plate_no ='京AJ723X') where  p.id = 281066 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18902108663'), i.auto = (select max(id) from auto where license_plate_no ='京AJ723X')  where p.obj_id = i.quote_record and  p.id = 281066 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18902108663'), i.auto = (select max(id) from auto where license_plate_no ='京AJ723X')  where p.obj_id = i.quote_record and p.id =  281066 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18902108663'), qr.auto = (select max(id) from auto where license_plate_no = '京AJ723X') where p.obj_id = qr.id and p.id = 281066 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18902108663') where pay.purchase_order = p.id and p.id = 281066 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13360479630', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('D5HE030155', '茹玉伟', 'LS4BDB3D7DF068808', '京A1D927', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13360479630'), (select max(id) from auto where license_plate_no = '京A1D927'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13360479630'), p.auto = (select max(id) from auto where license_plate_no ='京A1D927') where  p.id = 281073 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13360479630'), i.auto = (select max(id) from auto where license_plate_no ='京A1D927')  where p.obj_id = i.quote_record and  p.id = 281073 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13360479630'), i.auto = (select max(id) from auto where license_plate_no ='京A1D927')  where p.obj_id = i.quote_record and p.id =  281073 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13360479630'), qr.auto = (select max(id) from auto where license_plate_no = '京A1D927') where p.obj_id = qr.id and p.id = 281073 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13360479630') where pay.purchase_order = p.id and p.id = 281073 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18922478948', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('1610B044126', '张双录', 'LZGCL2M46AG002074', '京AF6331', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18922478948'), (select max(id) from auto where license_plate_no = '京AF6331'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18922478948'), p.auto = (select max(id) from auto where license_plate_no ='京AF6331') where  p.id = 281086 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18922478948'), i.auto = (select max(id) from auto where license_plate_no ='京AF6331')  where p.obj_id = i.quote_record and  p.id = 281086 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18922478948'), i.auto = (select max(id) from auto where license_plate_no ='京AF6331')  where p.obj_id = i.quote_record and p.id =  281086 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18922478948'), qr.auto = (select max(id) from auto where license_plate_no = '京AF6331') where p.obj_id = qr.id and p.id = 281086 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18922478948') where pay.purchase_order = p.id and p.id = 281086 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18045943541', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('F1001600', '深圳市安达运输有限公司', 'LJDDAA222F0652399', '粤B0U6G7', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18045943541'), (select max(id) from auto where license_plate_no = '粤B0U6G7'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18045943541'), p.auto = (select max(id) from auto where license_plate_no ='粤B0U6G7') where  p.id = 281088 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18045943541'), i.auto = (select max(id) from auto where license_plate_no ='粤B0U6G7')  where p.obj_id = i.quote_record and  p.id = 281088 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18045943541'), i.auto = (select max(id) from auto where license_plate_no ='粤B0U6G7')  where p.obj_id = i.quote_record and p.id =  281088 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18045943541'), qr.auto = (select max(id) from auto where license_plate_no = '粤B0U6G7') where p.obj_id = qr.id and p.id = 281088 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18045943541') where pay.purchase_order = p.id and p.id = 281088 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18027573456', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('910945Y', '常熟市虞山镇人民政府', 'LJNTGU2G18N014315', '苏EWN380', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18027573456'), (select max(id) from auto where license_plate_no = '苏EWN380'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18027573456'), p.auto = (select max(id) from auto where license_plate_no ='苏EWN380') where  p.id = 281089 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18027573456'), i.auto = (select max(id) from auto where license_plate_no ='苏EWN380')  where p.obj_id = i.quote_record and  p.id = 281089 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18027573456'), i.auto = (select max(id) from auto where license_plate_no ='苏EWN380')  where p.obj_id = i.quote_record and p.id =  281089 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18027573456'), qr.auto = (select max(id) from auto where license_plate_no = '苏EWN380') where p.obj_id = qr.id and p.id = 281089 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18027573456') where pay.purchase_order = p.id and p.id = 281089 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13341218821', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('E797248', '聂兴红', 'LFMAPE2C3B0277312', '京ASH969', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13341218821'), (select max(id) from auto where license_plate_no = '京ASH969'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13341218821'), p.auto = (select max(id) from auto where license_plate_no ='京ASH969') where  p.id = 281091 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13341218821'), i.auto = (select max(id) from auto where license_plate_no ='京ASH969')  where p.obj_id = i.quote_record and  p.id = 281091 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13341218821'), i.auto = (select max(id) from auto where license_plate_no ='京ASH969')  where p.obj_id = i.quote_record and p.id =  281091 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13341218821'), qr.auto = (select max(id) from auto where license_plate_no = '京ASH969') where p.obj_id = qr.id and p.id = 281091 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13341218821') where pay.purchase_order = p.id and p.id = 281091 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13943691600', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('CJB001113', '德宝仓储发展（深圳）有限公司', 'WAUKH54E99N012987', '粤B5029T', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13943691600'), (select max(id) from auto where license_plate_no = '粤B5029T'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13943691600'), p.auto = (select max(id) from auto where license_plate_no ='粤B5029T') where  p.id = 281093 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13943691600'), i.auto = (select max(id) from auto where license_plate_no ='粤B5029T')  where p.obj_id = i.quote_record and  p.id = 281093 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13943691600'), i.auto = (select max(id) from auto where license_plate_no ='粤B5029T')  where p.obj_id = i.quote_record and p.id =  281093 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13943691600'), qr.auto = (select max(id) from auto where license_plate_no = '粤B5029T') where p.obj_id = qr.id and p.id = 281093 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13943691600') where pay.purchase_order = p.id and p.id = 281093 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13465280482', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('79040634', '何永娥', 'LSGJR62U87S107233', '沪CG0986', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13465280482'), (select max(id) from auto where license_plate_no = '沪CG0986'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13465280482'), p.auto = (select max(id) from auto where license_plate_no ='沪CG0986') where  p.id = 281094 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13465280482'), i.auto = (select max(id) from auto where license_plate_no ='沪CG0986')  where p.obj_id = i.quote_record and  p.id = 281094 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13465280482'), i.auto = (select max(id) from auto where license_plate_no ='沪CG0986')  where p.obj_id = i.quote_record and p.id =  281094 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13465280482'), qr.auto = (select max(id) from auto where license_plate_no = '沪CG0986') where p.obj_id = qr.id and p.id = 281094 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13465280482') where pay.purchase_order = p.id and p.id = 281094 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15555888899', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('212366814', '王保记', 'LGXC16DF9C0110385', '京HC8968', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15555888899'), (select max(id) from auto where license_plate_no = '京HC8968'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15555888899'), p.auto = (select max(id) from auto where license_plate_no ='京HC8968') where  p.id = 281095 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15555888899'), i.auto = (select max(id) from auto where license_plate_no ='京HC8968')  where p.obj_id = i.quote_record and  p.id = 281095 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15555888899'), i.auto = (select max(id) from auto where license_plate_no ='京HC8968')  where p.obj_id = i.quote_record and p.id =  281095 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15555888899'), qr.auto = (select max(id) from auto where license_plate_no = '京HC8968') where p.obj_id = qr.id and p.id = 281095 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15555888899') where pay.purchase_order = p.id and p.id = 281095 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13514935804', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('4502295', '深圳市汇业达通讯技术有限公司', 'LHGGE6739C2002296', '粤B543SZ', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13514935804'), (select max(id) from auto where license_plate_no = '粤B543SZ'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13514935804'), p.auto = (select max(id) from auto where license_plate_no ='粤B543SZ') where  p.id = 281096 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13514935804'), i.auto = (select max(id) from auto where license_plate_no ='粤B543SZ')  where p.obj_id = i.quote_record and  p.id = 281096 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13514935804'), i.auto = (select max(id) from auto where license_plate_no ='粤B543SZ')  where p.obj_id = i.quote_record and p.id =  281096 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13514935804'), qr.auto = (select max(id) from auto where license_plate_no = '粤B543SZ') where p.obj_id = qr.id and p.id = 281096 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13514935804') where pay.purchase_order = p.id and p.id = 281096 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18025943553', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('006756', '张淑萍', 'LSVEU49F092343057', '京AQL365', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18025943553'), (select max(id) from auto where license_plate_no = '京AQL365'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18025943553'), p.auto = (select max(id) from auto where license_plate_no ='京AQL365') where  p.id = 281099 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18025943553'), i.auto = (select max(id) from auto where license_plate_no ='京AQL365')  where p.obj_id = i.quote_record and  p.id = 281099 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18025943553'), i.auto = (select max(id) from auto where license_plate_no ='京AQL365')  where p.obj_id = i.quote_record and p.id =  281099 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18025943553'), qr.auto = (select max(id) from auto where license_plate_no = '京AQL365') where p.obj_id = qr.id and p.id = 281099 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18025943553') where pay.purchase_order = p.id and p.id = 281099 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13164580827', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('C4ZW039667', '尹建飞', 'LS5A3ABR1CA536447', '京VFF990', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13164580827'), (select max(id) from auto where license_plate_no = '京VFF990'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13164580827'), p.auto = (select max(id) from auto where license_plate_no ='京VFF990') where  p.id = 281102 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13164580827'), i.auto = (select max(id) from auto where license_plate_no ='京VFF990')  where p.obj_id = i.quote_record and  p.id = 281102 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13164580827'), i.auto = (select max(id) from auto where license_plate_no ='京VFF990')  where p.obj_id = i.quote_record and p.id =  281102 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13164580827'), qr.auto = (select max(id) from auto where license_plate_no = '京VFF990') where p.obj_id = qr.id and p.id = 281102 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13164580827') where pay.purchase_order = p.id and p.id = 281102 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18731511803', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('F1001616', '深圳市安达运输有限公司', 'LJDDAA224F0652386', '粤B1U6G2', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18731511803'), (select max(id) from auto where license_plate_no = '粤B1U6G2'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18731511803'), p.auto = (select max(id) from auto where license_plate_no ='粤B1U6G2') where  p.id = 281103 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18731511803'), i.auto = (select max(id) from auto where license_plate_no ='粤B1U6G2')  where p.obj_id = i.quote_record and  p.id = 281103 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18731511803'), i.auto = (select max(id) from auto where license_plate_no ='粤B1U6G2')  where p.obj_id = i.quote_record and p.id =  281103 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18731511803'), qr.auto = (select max(id) from auto where license_plate_no = '粤B1U6G2') where p.obj_id = qr.id and p.id = 281103 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18731511803') where pay.purchase_order = p.id and p.id = 281103 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13180702215', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('A8190530', '贺伟', 'LSGJA52U4AH269737', '京A668E4', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13180702215'), (select max(id) from auto where license_plate_no = '京A668E4'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13180702215'), p.auto = (select max(id) from auto where license_plate_no ='京A668E4') where  p.id = 281104 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13180702215'), i.auto = (select max(id) from auto where license_plate_no ='京A668E4')  where p.obj_id = i.quote_record and  p.id = 281104 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13180702215'), i.auto = (select max(id) from auto where license_plate_no ='京A668E4')  where p.obj_id = i.quote_record and p.id =  281104 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13180702215'), qr.auto = (select max(id) from auto where license_plate_no = '京A668E4') where p.obj_id = qr.id and p.id = 281104 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13180702215') where pay.purchase_order = p.id and p.id = 281104 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18744917312', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('27295231416130', '深圳市安盛华钟表有限公司', 'WDDHF5EB2AA141534', '粤B0HT79', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18744917312'), (select max(id) from auto where license_plate_no = '粤B0HT79'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18744917312'), p.auto = (select max(id) from auto where license_plate_no ='粤B0HT79') where  p.id = 281105 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18744917312'), i.auto = (select max(id) from auto where license_plate_no ='粤B0HT79')  where p.obj_id = i.quote_record and  p.id = 281105 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18744917312'), i.auto = (select max(id) from auto where license_plate_no ='粤B0HT79')  where p.obj_id = i.quote_record and p.id =  281105 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18744917312'), qr.auto = (select max(id) from auto where license_plate_no = '粤B0HT79') where p.obj_id = qr.id and p.id = 281105 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18744917312') where pay.purchase_order = p.id and p.id = 281105 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15372923077', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('27294631265731', '深圳市海川广告有限公司', 'WDDNG5EB3AA291281', '粤BQ89D2', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15372923077'), (select max(id) from auto where license_plate_no = '粤BQ89D2'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15372923077'), p.auto = (select max(id) from auto where license_plate_no ='粤BQ89D2') where  p.id = 281107 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15372923077'), i.auto = (select max(id) from auto where license_plate_no ='粤BQ89D2')  where p.obj_id = i.quote_record and  p.id = 281107 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15372923077'), i.auto = (select max(id) from auto where license_plate_no ='粤BQ89D2')  where p.obj_id = i.quote_record and p.id =  281107 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15372923077'), qr.auto = (select max(id) from auto where license_plate_no = '粤BQ89D2') where p.obj_id = qr.id and p.id = 281107 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15372923077') where pay.purchase_order = p.id and p.id = 281107 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13965729799', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('50440947', '深圳市宝新科五金制品有限公司', 'LFN189AG03CA06408', '粤B52197', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13965729799'), (select max(id) from auto where license_plate_no = '粤B52197'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13965729799'), p.auto = (select max(id) from auto where license_plate_no ='粤B52197') where  p.id = 281109 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13965729799'), i.auto = (select max(id) from auto where license_plate_no ='粤B52197')  where p.obj_id = i.quote_record and  p.id = 281109 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13965729799'), i.auto = (select max(id) from auto where license_plate_no ='粤B52197')  where p.obj_id = i.quote_record and p.id =  281109 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13965729799'), qr.auto = (select max(id) from auto where license_plate_no = '粤B52197') where p.obj_id = qr.id and p.id = 281109 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13965729799') where pay.purchase_order = p.id and p.id = 281109 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13697274533', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('A0142655', '深圳市星河泉新材料有限公司五金配件分厂', 'LVFAB2ADXAG019600', '粤B345KQ', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13697274533'), (select max(id) from auto where license_plate_no = '粤B345KQ'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13697274533'), p.auto = (select max(id) from auto where license_plate_no ='粤B345KQ') where  p.id = 281110 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13697274533'), i.auto = (select max(id) from auto where license_plate_no ='粤B345KQ')  where p.obj_id = i.quote_record and  p.id = 281110 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13697274533'), i.auto = (select max(id) from auto where license_plate_no ='粤B345KQ')  where p.obj_id = i.quote_record and p.id =  281110 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13697274533'), qr.auto = (select max(id) from auto where license_plate_no = '粤B345KQ') where p.obj_id = qr.id and p.id = 281110 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13697274533') where pay.purchase_order = p.id and p.id = 281110 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18931413530', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('564691', '宋峰', 'LSVCB23T8C2024397', '沪CCA535', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18931413530'), (select max(id) from auto where license_plate_no = '沪CCA535'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18931413530'), p.auto = (select max(id) from auto where license_plate_no ='沪CCA535') where  p.id = 281112 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18931413530'), i.auto = (select max(id) from auto where license_plate_no ='沪CCA535')  where p.obj_id = i.quote_record and  p.id = 281112 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18931413530'), i.auto = (select max(id) from auto where license_plate_no ='沪CCA535')  where p.obj_id = i.quote_record and p.id =  281112 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18931413530'), qr.auto = (select max(id) from auto where license_plate_no = '沪CCA535') where p.obj_id = qr.id and p.id = 281112 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18931413530') where pay.purchase_order = p.id and p.id = 281112 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18861431206', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('D0809AA0484', '长武县晓海农机部', 'LJVA04D6XAW006777', '京DF0729', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18861431206'), (select max(id) from auto where license_plate_no = '京DF0729'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18861431206'), p.auto = (select max(id) from auto where license_plate_no ='京DF0729') where  p.id = 281114 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18861431206'), i.auto = (select max(id) from auto where license_plate_no ='京DF0729')  where p.obj_id = i.quote_record and  p.id = 281114 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18861431206'), i.auto = (select max(id) from auto where license_plate_no ='京DF0729')  where p.obj_id = i.quote_record and p.id =  281114 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18861431206'), qr.auto = (select max(id) from auto where license_plate_no = '京DF0729') where p.obj_id = qr.id and p.id = 281114 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18861431206') where pay.purchase_order = p.id and p.id = 281114 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15546326897', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('87239192', '昆山华顺运输有限公司', 'LGAX2B137B2019100', '苏EP9787', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15546326897'), (select max(id) from auto where license_plate_no = '苏EP9787'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15546326897'), p.auto = (select max(id) from auto where license_plate_no ='苏EP9787') where  p.id = 281115 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15546326897'), i.auto = (select max(id) from auto where license_plate_no ='苏EP9787')  where p.obj_id = i.quote_record and  p.id = 281115 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15546326897'), i.auto = (select max(id) from auto where license_plate_no ='苏EP9787')  where p.obj_id = i.quote_record and p.id =  281115 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15546326897'), qr.auto = (select max(id) from auto where license_plate_no = '苏EP9787') where p.obj_id = qr.id and p.id = 281115 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15546326897') where pay.purchase_order = p.id and p.id = 281115 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15286981188', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('SJP1459', '李小军', 'LRH12A2B5B0000991', '京JQ0169', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15286981188'), (select max(id) from auto where license_plate_no = '京JQ0169'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15286981188'), p.auto = (select max(id) from auto where license_plate_no ='京JQ0169') where  p.id = 281116 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15286981188'), i.auto = (select max(id) from auto where license_plate_no ='京JQ0169')  where p.obj_id = i.quote_record and  p.id = 281116 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15286981188'), i.auto = (select max(id) from auto where license_plate_no ='京JQ0169')  where p.obj_id = i.quote_record and p.id =  281116 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15286981188'), qr.auto = (select max(id) from auto where license_plate_no = '京JQ0169') where p.obj_id = qr.id and p.id = 281116 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15286981188') where pay.purchase_order = p.id and p.id = 281116 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15791329658', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('185729', '陆菊华', 'LFV3B28R3C3075616', '沪MR1597', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15791329658'), (select max(id) from auto where license_plate_no = '沪MR1597'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15791329658'), p.auto = (select max(id) from auto where license_plate_no ='沪MR1597') where  p.id = 281117 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15791329658'), i.auto = (select max(id) from auto where license_plate_no ='沪MR1597')  where p.obj_id = i.quote_record and  p.id = 281117 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15791329658'), i.auto = (select max(id) from auto where license_plate_no ='沪MR1597')  where p.obj_id = i.quote_record and p.id =  281117 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15791329658'), qr.auto = (select max(id) from auto where license_plate_no = '沪MR1597') where p.obj_id = qr.id and p.id = 281117 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15791329658') where pay.purchase_order = p.id and p.id = 281117 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15547930710', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('JAABA0187', '罗蜀秦', 'LZ0CC5X26B2001581', '京JC6391', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15547930710'), (select max(id) from auto where license_plate_no = '京JC6391'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15547930710'), p.auto = (select max(id) from auto where license_plate_no ='京JC6391') where  p.id = 281121 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15547930710'), i.auto = (select max(id) from auto where license_plate_no ='京JC6391')  where p.obj_id = i.quote_record and  p.id = 281121 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15547930710'), i.auto = (select max(id) from auto where license_plate_no ='京JC6391')  where p.obj_id = i.quote_record and p.id =  281121 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15547930710'), qr.auto = (select max(id) from auto where license_plate_no = '京JC6391') where p.obj_id = qr.id and p.id = 281121 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15547930710') where pay.purchase_order = p.id and p.id = 281121 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18156897079', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('Q101234197H', '深圳市金源源运输有限公司', 'LVBV3JBB3AE058239', '粤BE51X1', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18156897079'), (select max(id) from auto where license_plate_no = '粤BE51X1'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18156897079'), p.auto = (select max(id) from auto where license_plate_no ='粤BE51X1') where  p.id = 281123 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18156897079'), i.auto = (select max(id) from auto where license_plate_no ='粤BE51X1')  where p.obj_id = i.quote_record and  p.id = 281123 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18156897079'), i.auto = (select max(id) from auto where license_plate_no ='粤BE51X1')  where p.obj_id = i.quote_record and p.id =  281123 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18156897079'), qr.auto = (select max(id) from auto where license_plate_no = '粤BE51X1') where p.obj_id = qr.id and p.id = 281123 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18156897079') where pay.purchase_order = p.id and p.id = 281123 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13377451950', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('B02066246', '苏州工业园区中科洲翔机械加工有限公司', 'LSYAFAAN1BG030203', '苏E9TD76', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13377451950'), (select max(id) from auto where license_plate_no = '苏E9TD76'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13377451950'), p.auto = (select max(id) from auto where license_plate_no ='苏E9TD76') where  p.id = 281124 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13377451950'), i.auto = (select max(id) from auto where license_plate_no ='苏E9TD76')  where p.obj_id = i.quote_record and  p.id = 281124 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13377451950'), i.auto = (select max(id) from auto where license_plate_no ='苏E9TD76')  where p.obj_id = i.quote_record and p.id =  281124 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13377451950'), qr.auto = (select max(id) from auto where license_plate_no = '苏E9TD76') where p.obj_id = qr.id and p.id = 281124 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13377451950') where pay.purchase_order = p.id and p.id = 281124 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18531189355', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('C03071557', '王小伍', 'LZWACAGAICI059599', '京CL7645', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18531189355'), (select max(id) from auto where license_plate_no = '京CL7645'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18531189355'), p.auto = (select max(id) from auto where license_plate_no ='京CL7645') where  p.id = 281127 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18531189355'), i.auto = (select max(id) from auto where license_plate_no ='京CL7645')  where p.obj_id = i.quote_record and  p.id = 281127 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18531189355'), i.auto = (select max(id) from auto where license_plate_no ='京CL7645')  where p.obj_id = i.quote_record and p.id =  281127 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18531189355'), qr.auto = (select max(id) from auto where license_plate_no = '京CL7645') where p.obj_id = qr.id and p.id = 281127 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18531189355') where pay.purchase_order = p.id and p.id = 281127 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13232872628', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('FD7E02175', '王佩芳', 'LVVDC12A27D140712', '沪C622X8', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13232872628'), (select max(id) from auto where license_plate_no = '沪C622X8'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13232872628'), p.auto = (select max(id) from auto where license_plate_no ='沪C622X8') where  p.id = 281128 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13232872628'), i.auto = (select max(id) from auto where license_plate_no ='沪C622X8')  where p.obj_id = i.quote_record and  p.id = 281128 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13232872628'), i.auto = (select max(id) from auto where license_plate_no ='沪C622X8')  where p.obj_id = i.quote_record and p.id =  281128 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13232872628'), qr.auto = (select max(id) from auto where license_plate_no = '沪C622X8') where p.obj_id = qr.id and p.id = 281128 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13232872628') where pay.purchase_order = p.id and p.id = 281128 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13247578956', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('B61E000025', '赵艳娣', 'LSCBB23D6BG141961', '京ES7945', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13247578956'), (select max(id) from auto where license_plate_no = '京ES7945'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13247578956'), p.auto = (select max(id) from auto where license_plate_no ='京ES7945') where  p.id = 281134 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13247578956'), i.auto = (select max(id) from auto where license_plate_no ='京ES7945')  where p.obj_id = i.quote_record and  p.id = 281134 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13247578956'), i.auto = (select max(id) from auto where license_plate_no ='京ES7945')  where p.obj_id = i.quote_record and p.id =  281134 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13247578956'), qr.auto = (select max(id) from auto where license_plate_no = '京ES7945') where p.obj_id = qr.id and p.id = 281134 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13247578956') where pay.purchase_order = p.id and p.id = 281134 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15167866926', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('DJ9022', '冯军', 'LSYYDADB4CC100744', '京A8N082', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15167866926'), (select max(id) from auto where license_plate_no = '京A8N082'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15167866926'), p.auto = (select max(id) from auto where license_plate_no ='京A8N082') where  p.id = 281137 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15167866926'), i.auto = (select max(id) from auto where license_plate_no ='京A8N082')  where p.obj_id = i.quote_record and  p.id = 281137 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15167866926'), i.auto = (select max(id) from auto where license_plate_no ='京A8N082')  where p.obj_id = i.quote_record and p.id =  281137 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15167866926'), qr.auto = (select max(id) from auto where license_plate_no = '京A8N082') where p.obj_id = qr.id and p.id = 281137 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15167866926') where pay.purchase_order = p.id and p.id = 281137 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18864160384', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('ED757208', '张家港保税区兆丰贸易有限公司', '1C4NJCCA3ED757208', '苏EY256Q', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18864160384'), (select max(id) from auto where license_plate_no = '苏EY256Q'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18864160384'), p.auto = (select max(id) from auto where license_plate_no ='苏EY256Q') where  p.id = 281138 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18864160384'), i.auto = (select max(id) from auto where license_plate_no ='苏EY256Q')  where p.obj_id = i.quote_record and  p.id = 281138 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18864160384'), i.auto = (select max(id) from auto where license_plate_no ='苏EY256Q')  where p.obj_id = i.quote_record and p.id =  281138 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18864160384'), qr.auto = (select max(id) from auto where license_plate_no = '苏EY256Q') where p.obj_id = qr.id and p.id = 281138 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18864160384') where pay.purchase_order = p.id and p.id = 281138 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13804303623', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('C02697', '张妮', 'LSVGJ4555D2011834', '京E54001', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13804303623'), (select max(id) from auto where license_plate_no = '京E54001'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13804303623'), p.auto = (select max(id) from auto where license_plate_no ='京E54001') where  p.id = 281140 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13804303623'), i.auto = (select max(id) from auto where license_plate_no ='京E54001')  where p.obj_id = i.quote_record and  p.id = 281140 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13804303623'), i.auto = (select max(id) from auto where license_plate_no ='京E54001')  where p.obj_id = i.quote_record and p.id =  281140 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13804303623'), qr.auto = (select max(id) from auto where license_plate_no = '京E54001') where p.obj_id = qr.id and p.id = 281140 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13804303623') where pay.purchase_order = p.id and p.id = 281140 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13076266395', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('DW062257', '李欢欢', 'LBEYFAKD3DY190680', '京A171BB', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13076266395'), (select max(id) from auto where license_plate_no = '京A171BB'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13076266395'), p.auto = (select max(id) from auto where license_plate_no ='京A171BB') where  p.id = 281146 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13076266395'), i.auto = (select max(id) from auto where license_plate_no ='京A171BB')  where p.obj_id = i.quote_record and  p.id = 281146 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13076266395'), i.auto = (select max(id) from auto where license_plate_no ='京A171BB')  where p.obj_id = i.quote_record and p.id =  281146 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13076266395'), qr.auto = (select max(id) from auto where license_plate_no = '京A171BB') where p.obj_id = qr.id and p.id = 281146 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13076266395') where pay.purchase_order = p.id and p.id = 281146 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13242381278', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('EQ486314130', '上海运良锻压机床有限公司', 'LGBC1AE053R000691', '沪CTN777', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13242381278'), (select max(id) from auto where license_plate_no = '沪CTN777'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13242381278'), p.auto = (select max(id) from auto where license_plate_no ='沪CTN777') where  p.id = 281154 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13242381278'), i.auto = (select max(id) from auto where license_plate_no ='沪CTN777')  where p.obj_id = i.quote_record and  p.id = 281154 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13242381278'), i.auto = (select max(id) from auto where license_plate_no ='沪CTN777')  where p.obj_id = i.quote_record and p.id =  281154 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13242381278'), qr.auto = (select max(id) from auto where license_plate_no = '沪CTN777') where p.obj_id = qr.id and p.id = 281154 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13242381278') where pay.purchase_order = p.id and p.id = 281154 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13161257955', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('AFE0579715', '张红科', 'LSVAF033142334585', '沪C41T15', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13161257955'), (select max(id) from auto where license_plate_no = '沪C41T15'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13161257955'), p.auto = (select max(id) from auto where license_plate_no ='沪C41T15') where  p.id = 281156 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13161257955'), i.auto = (select max(id) from auto where license_plate_no ='沪C41T15')  where p.obj_id = i.quote_record and  p.id = 281156 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13161257955'), i.auto = (select max(id) from auto where license_plate_no ='沪C41T15')  where p.obj_id = i.quote_record and p.id =  281156 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13161257955'), qr.auto = (select max(id) from auto where license_plate_no = '沪C41T15') where p.obj_id = qr.id and p.id = 281156 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13161257955') where pay.purchase_order = p.id and p.id = 281156 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13892756348', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('F1001661', '深圳市安达运输有限公司', 'LJDDAA222F0652385', '粤B7V4P1', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13892756348'), (select max(id) from auto where license_plate_no = '粤B7V4P1'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13892756348'), p.auto = (select max(id) from auto where license_plate_no ='粤B7V4P1') where  p.id = 281157 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13892756348'), i.auto = (select max(id) from auto where license_plate_no ='粤B7V4P1')  where p.obj_id = i.quote_record and  p.id = 281157 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13892756348'), i.auto = (select max(id) from auto where license_plate_no ='粤B7V4P1')  where p.obj_id = i.quote_record and p.id =  281157 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13892756348'), qr.auto = (select max(id) from auto where license_plate_no = '粤B7V4P1') where p.obj_id = qr.id and p.id = 281157 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13892756348') where pay.purchase_order = p.id and p.id = 281157 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13294391268', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('036581E', '张强', 'LB37824S99X041932', '京ELQ805', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13294391268'), (select max(id) from auto where license_plate_no = '京ELQ805'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13294391268'), p.auto = (select max(id) from auto where license_plate_no ='京ELQ805') where  p.id = 281158 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13294391268'), i.auto = (select max(id) from auto where license_plate_no ='京ELQ805')  where p.obj_id = i.quote_record and  p.id = 281158 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13294391268'), i.auto = (select max(id) from auto where license_plate_no ='京ELQ805')  where p.obj_id = i.quote_record and p.id =  281158 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13294391268'), qr.auto = (select max(id) from auto where license_plate_no = '京ELQ805') where p.obj_id = qr.id and p.id = 281158 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13294391268') where pay.purchase_order = p.id and p.id = 281158 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15018089130', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('F270542', '深圳市大烨中贸易有限公司', 'LFMAPE2C0D0480015', '粤BX3A88', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15018089130'), (select max(id) from auto where license_plate_no = '粤BX3A88'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15018089130'), p.auto = (select max(id) from auto where license_plate_no ='粤BX3A88') where  p.id = 281159 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15018089130'), i.auto = (select max(id) from auto where license_plate_no ='粤BX3A88')  where p.obj_id = i.quote_record and  p.id = 281159 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15018089130'), i.auto = (select max(id) from auto where license_plate_no ='粤BX3A88')  where p.obj_id = i.quote_record and p.id =  281159 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15018089130'), qr.auto = (select max(id) from auto where license_plate_no = '粤BX3A88') where p.obj_id = qr.id and p.id = 281159 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15018089130') where pay.purchase_order = p.id and p.id = 281159 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15640236738', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('D3431723', '深圳市泰克曼电子有限公司', 'LJ12GKS25D4409314', '粤B8MG85', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15640236738'), (select max(id) from auto where license_plate_no = '粤B8MG85'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15640236738'), p.auto = (select max(id) from auto where license_plate_no ='粤B8MG85') where  p.id = 281162 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15640236738'), i.auto = (select max(id) from auto where license_plate_no ='粤B8MG85')  where p.obj_id = i.quote_record and  p.id = 281162 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15640236738'), i.auto = (select max(id) from auto where license_plate_no ='粤B8MG85')  where p.obj_id = i.quote_record and p.id =  281162 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15640236738'), qr.auto = (select max(id) from auto where license_plate_no = '粤B8MG85') where p.obj_id = qr.id and p.id = 281162 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15640236738') where pay.purchase_order = p.id and p.id = 281162 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18891461374', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('103754', '梁志龙', 'LSVT91332AN120530', '沪KA9233', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18891461374'), (select max(id) from auto where license_plate_no = '沪KA9233'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18891461374'), p.auto = (select max(id) from auto where license_plate_no ='沪KA9233') where  p.id = 281163 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18891461374'), i.auto = (select max(id) from auto where license_plate_no ='沪KA9233')  where p.obj_id = i.quote_record and  p.id = 281163 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18891461374'), i.auto = (select max(id) from auto where license_plate_no ='沪KA9233')  where p.obj_id = i.quote_record and p.id =  281163 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18891461374'), qr.auto = (select max(id) from auto where license_plate_no = '沪KA9233') where p.obj_id = qr.id and p.id = 281163 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18891461374') where pay.purchase_order = p.id and p.id = 281163 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13920978169', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('BJH051384', '深圳前景建筑工程有限公司', 'LFV2A21J663026322', '粤BP8E41', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13920978169'), (select max(id) from auto where license_plate_no = '粤BP8E41'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13920978169'), p.auto = (select max(id) from auto where license_plate_no ='粤BP8E41') where  p.id = 281164 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13920978169'), i.auto = (select max(id) from auto where license_plate_no ='粤BP8E41')  where p.obj_id = i.quote_record and  p.id = 281164 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13920978169'), i.auto = (select max(id) from auto where license_plate_no ='粤BP8E41')  where p.obj_id = i.quote_record and p.id =  281164 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13920978169'), qr.auto = (select max(id) from auto where license_plate_no = '粤BP8E41') where p.obj_id = qr.id and p.id = 281164 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13920978169') where pay.purchase_order = p.id and p.id = 281164 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18186163323', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('684840', '张之春', 'LSVXN65N4D2127882', '沪C72H55', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18186163323'), (select max(id) from auto where license_plate_no = '沪C72H55'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18186163323'), p.auto = (select max(id) from auto where license_plate_no ='沪C72H55') where  p.id = 281165 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18186163323'), i.auto = (select max(id) from auto where license_plate_no ='沪C72H55')  where p.obj_id = i.quote_record and  p.id = 281165 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18186163323'), i.auto = (select max(id) from auto where license_plate_no ='沪C72H55')  where p.obj_id = i.quote_record and p.id =  281165 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18186163323'), qr.auto = (select max(id) from auto where license_plate_no = '沪C72H55') where p.obj_id = qr.id and p.id = 281165 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18186163323') where pay.purchase_order = p.id and p.id = 281165 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18911851979', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('F16D3 62230221', '赵建杰', 'LSGJT62U36S122383', '沪C79A18', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18911851979'), (select max(id) from auto where license_plate_no = '沪C79A18'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18911851979'), p.auto = (select max(id) from auto where license_plate_no ='沪C79A18') where  p.id = 281166 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18911851979'), i.auto = (select max(id) from auto where license_plate_no ='沪C79A18')  where p.obj_id = i.quote_record and  p.id = 281166 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18911851979'), i.auto = (select max(id) from auto where license_plate_no ='沪C79A18')  where p.obj_id = i.quote_record and p.id =  281166 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18911851979'), qr.auto = (select max(id) from auto where license_plate_no = '沪C79A18') where p.obj_id = qr.id and p.id = 281166 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18911851979') where pay.purchase_order = p.id and p.id = 281166 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13685329426', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('8DA2210711', '清涧县公安局', 'LZWADAGA2D4202721', '京K2342警', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13685329426'), (select max(id) from auto where license_plate_no = '京K2342警'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13685329426'), p.auto = (select max(id) from auto where license_plate_no ='京K2342警') where  p.id = 281167 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13685329426'), i.auto = (select max(id) from auto where license_plate_no ='京K2342警')  where p.obj_id = i.quote_record and  p.id = 281167 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13685329426'), i.auto = (select max(id) from auto where license_plate_no ='京K2342警')  where p.obj_id = i.quote_record and p.id =  281167 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13685329426'), qr.auto = (select max(id) from auto where license_plate_no = '京K2342警') where p.obj_id = qr.id and p.id = 281167 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13685329426') where pay.purchase_order = p.id and p.id = 281167 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13339133295', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('9C290031', '深圳市迈迪加科技发展有限公司', 'LSGUD82C8AE006617', '粤B9S5J0', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13339133295'), (select max(id) from auto where license_plate_no = '粤B9S5J0'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13339133295'), p.auto = (select max(id) from auto where license_plate_no ='粤B9S5J0') where  p.id = 281171 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13339133295'), i.auto = (select max(id) from auto where license_plate_no ='粤B9S5J0')  where p.obj_id = i.quote_record and  p.id = 281171 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13339133295'), i.auto = (select max(id) from auto where license_plate_no ='粤B9S5J0')  where p.obj_id = i.quote_record and p.id =  281171 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13339133295'), qr.auto = (select max(id) from auto where license_plate_no = '粤B9S5J0') where p.obj_id = qr.id and p.id = 281171 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13339133295') where pay.purchase_order = p.id and p.id = 281171 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18826152045', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('BGC005139', '张伟', 'LSVCM49F942323082', '沪C58059', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18826152045'), (select max(id) from auto where license_plate_no = '沪C58059'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18826152045'), p.auto = (select max(id) from auto where license_plate_no ='沪C58059') where  p.id = 281172 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18826152045'), i.auto = (select max(id) from auto where license_plate_no ='沪C58059')  where p.obj_id = i.quote_record and  p.id = 281172 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18826152045'), i.auto = (select max(id) from auto where license_plate_no ='沪C58059')  where p.obj_id = i.quote_record and p.id =  281172 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18826152045'), qr.auto = (select max(id) from auto where license_plate_no = '沪C58059') where p.obj_id = qr.id and p.id = 281172 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18826152045') where pay.purchase_order = p.id and p.id = 281172 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15271168096', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('719761', '深圳市龙城物业管理有限公司', 'LSYGJ3AF03K075161', '粤BBK121', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15271168096'), (select max(id) from auto where license_plate_no = '粤BBK121'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15271168096'), p.auto = (select max(id) from auto where license_plate_no ='粤BBK121') where  p.id = 281175 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15271168096'), i.auto = (select max(id) from auto where license_plate_no ='粤BBK121')  where p.obj_id = i.quote_record and  p.id = 281175 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15271168096'), i.auto = (select max(id) from auto where license_plate_no ='粤BBK121')  where p.obj_id = i.quote_record and p.id =  281175 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15271168096'), qr.auto = (select max(id) from auto where license_plate_no = '粤BBK121') where p.obj_id = qr.id and p.id = 281175 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15271168096') where pay.purchase_order = p.id and p.id = 281175 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18912380281', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('Q110205535B', '上海春明玻璃制品有限公司', 'LJ11KBACXB6009254', '沪KF9128', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18912380281'), (select max(id) from auto where license_plate_no = '沪KF9128'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18912380281'), p.auto = (select max(id) from auto where license_plate_no ='沪KF9128') where  p.id = 281181 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18912380281'), i.auto = (select max(id) from auto where license_plate_no ='沪KF9128')  where p.obj_id = i.quote_record and  p.id = 281181 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18912380281'), i.auto = (select max(id) from auto where license_plate_no ='沪KF9128')  where p.obj_id = i.quote_record and p.id =  281181 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18912380281'), qr.auto = (select max(id) from auto where license_plate_no = '沪KF9128') where p.obj_id = qr.id and p.id = 281181 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18912380281') where pay.purchase_order = p.id and p.id = 281181 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13094222416', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('7C130005', '南郑县梁山镇人民政府', 'LSGVU54ZX8Y016157', '京F69321', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13094222416'), (select max(id) from auto where license_plate_no = '京F69321'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13094222416'), p.auto = (select max(id) from auto where license_plate_no ='京F69321') where  p.id = 281183 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13094222416'), i.auto = (select max(id) from auto where license_plate_no ='京F69321')  where p.obj_id = i.quote_record and  p.id = 281183 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13094222416'), i.auto = (select max(id) from auto where license_plate_no ='京F69321')  where p.obj_id = i.quote_record and p.id =  281183 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13094222416'), qr.auto = (select max(id) from auto where license_plate_no = '京F69321') where p.obj_id = qr.id and p.id = 281183 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13094222416') where pay.purchase_order = p.id and p.id = 281183 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18957625135', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('111230001', '倪顺林', 'LSGGF59B5BH236411', '沪AHE186', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18957625135'), (select max(id) from auto where license_plate_no = '沪AHE186'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18957625135'), p.auto = (select max(id) from auto where license_plate_no ='沪AHE186') where  p.id = 281184 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18957625135'), i.auto = (select max(id) from auto where license_plate_no ='沪AHE186')  where p.obj_id = i.quote_record and  p.id = 281184 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18957625135'), i.auto = (select max(id) from auto where license_plate_no ='沪AHE186')  where p.obj_id = i.quote_record and p.id =  281184 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18957625135'), qr.auto = (select max(id) from auto where license_plate_no = '沪AHE186') where p.obj_id = qr.id and p.id = 281184 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18957625135') where pay.purchase_order = p.id and p.id = 281184 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15769982091', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('C042116', '金栋', 'LSYYBACA9DC114557', '京E6469B', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15769982091'), (select max(id) from auto where license_plate_no = '京E6469B'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15769982091'), p.auto = (select max(id) from auto where license_plate_no ='京E6469B') where  p.id = 281185 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15769982091'), i.auto = (select max(id) from auto where license_plate_no ='京E6469B')  where p.obj_id = i.quote_record and  p.id = 281185 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15769982091'), i.auto = (select max(id) from auto where license_plate_no ='京E6469B')  where p.obj_id = i.quote_record and p.id =  281185 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15769982091'), qr.auto = (select max(id) from auto where license_plate_no = '京E6469B') where p.obj_id = qr.id and p.id = 281185 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15769982091') where pay.purchase_order = p.id and p.id = 281185 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18785897134', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('263677', '刘志虎', 'LFV2A21G883644876', '京AE076T', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18785897134'), (select max(id) from auto where license_plate_no = '京AE076T'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18785897134'), p.auto = (select max(id) from auto where license_plate_no ='京AE076T') where  p.id = 281188 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18785897134'), i.auto = (select max(id) from auto where license_plate_no ='京AE076T')  where p.obj_id = i.quote_record and  p.id = 281188 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18785897134'), i.auto = (select max(id) from auto where license_plate_no ='京AE076T')  where p.obj_id = i.quote_record and p.id =  281188 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18785897134'), qr.auto = (select max(id) from auto where license_plate_no = '京AE076T') where p.obj_id = qr.id and p.id = 281188 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18785897134') where pay.purchase_order = p.id and p.id = 281188 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13384498299', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('244661', '苏州市城区地方海事处', 'LSVTN133682216717', '苏E0B852', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13384498299'), (select max(id) from auto where license_plate_no = '苏E0B852'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13384498299'), p.auto = (select max(id) from auto where license_plate_no ='苏E0B852') where  p.id = 281189 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13384498299'), i.auto = (select max(id) from auto where license_plate_no ='苏E0B852')  where p.obj_id = i.quote_record and  p.id = 281189 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13384498299'), i.auto = (select max(id) from auto where license_plate_no ='苏E0B852')  where p.obj_id = i.quote_record and p.id =  281189 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13384498299'), qr.auto = (select max(id) from auto where license_plate_no = '苏E0B852') where p.obj_id = qr.id and p.id = 281189 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13384498299') where pay.purchase_order = p.id and p.id = 281189 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15321343937', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('F195342', '深圳市南山区永贵源商行', 'LFMARE2CXD3506483', '粤B5J7K5', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15321343937'), (select max(id) from auto where license_plate_no = '粤B5J7K5'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15321343937'), p.auto = (select max(id) from auto where license_plate_no ='粤B5J7K5') where  p.id = 281190 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15321343937'), i.auto = (select max(id) from auto where license_plate_no ='粤B5J7K5')  where p.obj_id = i.quote_record and  p.id = 281190 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15321343937'), i.auto = (select max(id) from auto where license_plate_no ='粤B5J7K5')  where p.obj_id = i.quote_record and p.id =  281190 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15321343937'), qr.auto = (select max(id) from auto where license_plate_no = '粤B5J7K5') where p.obj_id = qr.id and p.id = 281190 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15321343937') where pay.purchase_order = p.id and p.id = 281190 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18620413035', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('020718', '苏州环秀园林营造有限公司', 'LSYBCAAB88K035245', '苏E9HQ13', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18620413035'), (select max(id) from auto where license_plate_no = '苏E9HQ13'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18620413035'), p.auto = (select max(id) from auto where license_plate_no ='苏E9HQ13') where  p.id = 281191 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18620413035'), i.auto = (select max(id) from auto where license_plate_no ='苏E9HQ13')  where p.obj_id = i.quote_record and  p.id = 281191 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18620413035'), i.auto = (select max(id) from auto where license_plate_no ='苏E9HQ13')  where p.obj_id = i.quote_record and p.id =  281191 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18620413035'), qr.auto = (select max(id) from auto where license_plate_no = '苏E9HQ13') where p.obj_id = qr.id and p.id = 281191 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18620413035') where pay.purchase_order = p.id and p.id = 281191 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13765974231', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('1318148', '苏州龙辉运输有限公司', 'LGDCH81G1CB501357', '苏E0U9E1', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13765974231'), (select max(id) from auto where license_plate_no = '苏E0U9E1'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13765974231'), p.auto = (select max(id) from auto where license_plate_no ='苏E0U9E1') where  p.id = 281193 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13765974231'), i.auto = (select max(id) from auto where license_plate_no ='苏E0U9E1')  where p.obj_id = i.quote_record and  p.id = 281193 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13765974231'), i.auto = (select max(id) from auto where license_plate_no ='苏E0U9E1')  where p.obj_id = i.quote_record and p.id =  281193 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13765974231'), qr.auto = (select max(id) from auto where license_plate_no = '苏E0U9E1') where p.obj_id = qr.id and p.id = 281193 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13765974231') where pay.purchase_order = p.id and p.id = 281193 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15074165504', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('A68SAB00180', '苏州市尚驰汽车服务有限公司', 'LKLR1FSD4BB560107', '苏E2D917', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15074165504'), (select max(id) from auto where license_plate_no = '苏E2D917'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15074165504'), p.auto = (select max(id) from auto where license_plate_no ='苏E2D917') where  p.id = 281195 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15074165504'), i.auto = (select max(id) from auto where license_plate_no ='苏E2D917')  where p.obj_id = i.quote_record and  p.id = 281195 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15074165504'), i.auto = (select max(id) from auto where license_plate_no ='苏E2D917')  where p.obj_id = i.quote_record and p.id =  281195 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15074165504'), qr.auto = (select max(id) from auto where license_plate_no = '苏E2D917') where p.obj_id = qr.id and p.id = 281195 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15074165504') where pay.purchase_order = p.id and p.id = 281195 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15951142213', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('87334349', '深圳市万安物流有限公司', 'LGAX2BG49C1018845', '粤BY1365', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15951142213'), (select max(id) from auto where license_plate_no = '粤BY1365'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15951142213'), p.auto = (select max(id) from auto where license_plate_no ='粤BY1365') where  p.id = 281196 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15951142213'), i.auto = (select max(id) from auto where license_plate_no ='粤BY1365')  where p.obj_id = i.quote_record and  p.id = 281196 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15951142213'), i.auto = (select max(id) from auto where license_plate_no ='粤BY1365')  where p.obj_id = i.quote_record and p.id =  281196 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15951142213'), qr.auto = (select max(id) from auto where license_plate_no = '粤BY1365') where p.obj_id = qr.id and p.id = 281196 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15951142213') where pay.purchase_order = p.id and p.id = 281196 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15180002150', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('B407011232', '上海新军物流有限公司', 'LSH5LAD457A000287', '沪B24737', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15180002150'), (select max(id) from auto where license_plate_no = '沪B24737'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15180002150'), p.auto = (select max(id) from auto where license_plate_no ='沪B24737') where  p.id = 281198 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15180002150'), i.auto = (select max(id) from auto where license_plate_no ='沪B24737')  where p.obj_id = i.quote_record and  p.id = 281198 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15180002150'), i.auto = (select max(id) from auto where license_plate_no ='沪B24737')  where p.obj_id = i.quote_record and p.id =  281198 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15180002150'), qr.auto = (select max(id) from auto where license_plate_no = '沪B24737') where p.obj_id = qr.id and p.id = 281198 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15180002150') where pay.purchase_order = p.id and p.id = 281198 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15359901726', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('0472022', '中国共产党山阳县王庄乡委员会', 'LSVA10333A2234286', '京H33636', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15359901726'), (select max(id) from auto where license_plate_no = '京H33636'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15359901726'), p.auto = (select max(id) from auto where license_plate_no ='京H33636') where  p.id = 281202 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15359901726'), i.auto = (select max(id) from auto where license_plate_no ='京H33636')  where p.obj_id = i.quote_record and  p.id = 281202 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15359901726'), i.auto = (select max(id) from auto where license_plate_no ='京H33636')  where p.obj_id = i.quote_record and p.id =  281202 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15359901726'), qr.auto = (select max(id) from auto where license_plate_no = '京H33636') where p.obj_id = qr.id and p.id = 281202 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15359901726') where pay.purchase_order = p.id and p.id = 281202 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13331054641', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('448871', '黄光新', 'LGWCAC1659A000041', '京KHD123', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13331054641'), (select max(id) from auto where license_plate_no = '京KHD123'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13331054641'), p.auto = (select max(id) from auto where license_plate_no ='京KHD123') where  p.id = 281203 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13331054641'), i.auto = (select max(id) from auto where license_plate_no ='京KHD123')  where p.obj_id = i.quote_record and  p.id = 281203 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13331054641'), i.auto = (select max(id) from auto where license_plate_no ='京KHD123')  where p.obj_id = i.quote_record and p.id =  281203 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13331054641'), qr.auto = (select max(id) from auto where license_plate_no = '京KHD123') where p.obj_id = qr.id and p.id = 281203 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13331054641') where pay.purchase_order = p.id and p.id = 281203 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13750372626', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('3548428', '苏州旺得福建材有限公司', 'LHGGD384072048422', '苏E7ZB88', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13750372626'), (select max(id) from auto where license_plate_no = '苏E7ZB88'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13750372626'), p.auto = (select max(id) from auto where license_plate_no ='苏E7ZB88') where  p.id = 281208 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13750372626'), i.auto = (select max(id) from auto where license_plate_no ='苏E7ZB88')  where p.obj_id = i.quote_record and  p.id = 281208 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13750372626'), i.auto = (select max(id) from auto where license_plate_no ='苏E7ZB88')  where p.obj_id = i.quote_record and p.id =  281208 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13750372626'), qr.auto = (select max(id) from auto where license_plate_no = '苏E7ZB88') where p.obj_id = qr.id and p.id = 281208 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13750372626') where pay.purchase_order = p.id and p.id = 281208 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13832375581', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('7A170189', '姬广宾', 'LSGUD82C87E038749', '沪C52W72', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13832375581'), (select max(id) from auto where license_plate_no = '沪C52W72'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13832375581'), p.auto = (select max(id) from auto where license_plate_no ='沪C52W72') where  p.id = 281210 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13832375581'), i.auto = (select max(id) from auto where license_plate_no ='沪C52W72')  where p.obj_id = i.quote_record and  p.id = 281210 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13832375581'), i.auto = (select max(id) from auto where license_plate_no ='沪C52W72')  where p.obj_id = i.quote_record and p.id =  281210 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13832375581'), qr.auto = (select max(id) from auto where license_plate_no = '沪C52W72') where p.obj_id = qr.id and p.id = 281210 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13832375581') where pay.purchase_order = p.id and p.id = 281210 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13960260422', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('G6CU53001224', '美亚远大（深圳）科技有限公司', 'LJDBAA25950005093', '粤B5LM56', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13960260422'), (select max(id) from auto where license_plate_no = '粤B5LM56'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13960260422'), p.auto = (select max(id) from auto where license_plate_no ='粤B5LM56') where  p.id = 281214 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13960260422'), i.auto = (select max(id) from auto where license_plate_no ='粤B5LM56')  where p.obj_id = i.quote_record and  p.id = 281214 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13960260422'), i.auto = (select max(id) from auto where license_plate_no ='粤B5LM56')  where p.obj_id = i.quote_record and p.id =  281214 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13960260422'), qr.auto = (select max(id) from auto where license_plate_no = '粤B5LM56') where p.obj_id = qr.id and p.id = 281214 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13960260422') where pay.purchase_order = p.id and p.id = 281214 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13238958527', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('2201183', '朱雪雷', 'LHGGM3635B2001180', '沪CTP198', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13238958527'), (select max(id) from auto where license_plate_no = '沪CTP198'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13238958527'), p.auto = (select max(id) from auto where license_plate_no ='沪CTP198') where  p.id = 281219 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13238958527'), i.auto = (select max(id) from auto where license_plate_no ='沪CTP198')  where p.obj_id = i.quote_record and  p.id = 281219 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13238958527'), i.auto = (select max(id) from auto where license_plate_no ='沪CTP198')  where p.obj_id = i.quote_record and p.id =  281219 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13238958527'), qr.auto = (select max(id) from auto where license_plate_no = '沪CTP198') where p.obj_id = qr.id and p.id = 281219 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13238958527') where pay.purchase_order = p.id and p.id = 281219 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15195032866', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('587529C', '方晓', 'LGBH12E249Y020779', '沪CCZ931', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15195032866'), (select max(id) from auto where license_plate_no = '沪CCZ931'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15195032866'), p.auto = (select max(id) from auto where license_plate_no ='沪CCZ931') where  p.id = 281221 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15195032866'), i.auto = (select max(id) from auto where license_plate_no ='沪CCZ931')  where p.obj_id = i.quote_record and  p.id = 281221 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15195032866'), i.auto = (select max(id) from auto where license_plate_no ='沪CCZ931')  where p.obj_id = i.quote_record and p.id =  281221 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15195032866'), qr.auto = (select max(id) from auto where license_plate_no = '沪CCZ931') where p.obj_id = qr.id and p.id = 281221 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15195032866') where pay.purchase_order = p.id and p.id = 281221 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15670436062', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('AB527400', '晏阿强', 'LBEHDAEB9AY379782', '京A8C203', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15670436062'), (select max(id) from auto where license_plate_no = '京A8C203'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15670436062'), p.auto = (select max(id) from auto where license_plate_no ='京A8C203') where  p.id = 281226 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15670436062'), i.auto = (select max(id) from auto where license_plate_no ='京A8C203')  where p.obj_id = i.quote_record and  p.id = 281226 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15670436062'), i.auto = (select max(id) from auto where license_plate_no ='京A8C203')  where p.obj_id = i.quote_record and p.id =  281226 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15670436062'), qr.auto = (select max(id) from auto where license_plate_no = '京A8C203') where p.obj_id = qr.id and p.id = 281226 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15670436062') where pay.purchase_order = p.id and p.id = 281226 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13391442217', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('J02L1E30042', '深圳市光明新区公明琼铄金属五金边角料加工厂', 'LGGR4C356EL907381', '粤BY1505', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13391442217'), (select max(id) from auto where license_plate_no = '粤BY1505'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13391442217'), p.auto = (select max(id) from auto where license_plate_no ='粤BY1505') where  p.id = 281227 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13391442217'), i.auto = (select max(id) from auto where license_plate_no ='粤BY1505')  where p.obj_id = i.quote_record and  p.id = 281227 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13391442217'), i.auto = (select max(id) from auto where license_plate_no ='粤BY1505')  where p.obj_id = i.quote_record and p.id =  281227 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13391442217'), qr.auto = (select max(id) from auto where license_plate_no = '粤BY1505') where p.obj_id = qr.id and p.id = 281227 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13391442217') where pay.purchase_order = p.id and p.id = 281227 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13003872019', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('60649001', '张家港市合兴漆布厂', 'LJXCMCCB96T011491', '苏EGQ449', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13003872019'), (select max(id) from auto where license_plate_no = '苏EGQ449'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13003872019'), p.auto = (select max(id) from auto where license_plate_no ='苏EGQ449') where  p.id = 281228 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13003872019'), i.auto = (select max(id) from auto where license_plate_no ='苏EGQ449')  where p.obj_id = i.quote_record and  p.id = 281228 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13003872019'), i.auto = (select max(id) from auto where license_plate_no ='苏EGQ449')  where p.obj_id = i.quote_record and p.id =  281228 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13003872019'), qr.auto = (select max(id) from auto where license_plate_no = '苏EGQ449') where p.obj_id = qr.id and p.id = 281228 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13003872019') where pay.purchase_order = p.id and p.id = 281228 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13108279532', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('07047525', '苏州荔凯货物运输有限公司', 'LGDTM9GP67A121242', '苏ER1879', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13108279532'), (select max(id) from auto where license_plate_no = '苏ER1879'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13108279532'), p.auto = (select max(id) from auto where license_plate_no ='苏ER1879') where  p.id = 281230 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13108279532'), i.auto = (select max(id) from auto where license_plate_no ='苏ER1879')  where p.obj_id = i.quote_record and  p.id = 281230 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13108279532'), i.auto = (select max(id) from auto where license_plate_no ='苏ER1879')  where p.obj_id = i.quote_record and p.id =  281230 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13108279532'), qr.auto = (select max(id) from auto where license_plate_no = '苏ER1879') where p.obj_id = qr.id and p.id = 281230 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13108279532') where pay.purchase_order = p.id and p.id = 281230 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13116728415', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('0007753', '王世斌', 'L6T7844S57N062566', '京JGF699', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13116728415'), (select max(id) from auto where license_plate_no = '京JGF699'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13116728415'), p.auto = (select max(id) from auto where license_plate_no ='京JGF699') where  p.id = 281233 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13116728415'), i.auto = (select max(id) from auto where license_plate_no ='京JGF699')  where p.obj_id = i.quote_record and  p.id = 281233 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13116728415'), i.auto = (select max(id) from auto where license_plate_no ='京JGF699')  where p.obj_id = i.quote_record and p.id =  281233 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13116728415'), qr.auto = (select max(id) from auto where license_plate_no = '京JGF699') where p.obj_id = qr.id and p.id = 281233 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13116728415') where pay.purchase_order = p.id and p.id = 281233 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15549138373', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('B5074329', '吴江市松陵江南水乡大酒店', 'LJXCMCCB1BT053423', '苏EU0G23', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15549138373'), (select max(id) from auto where license_plate_no = '苏EU0G23'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15549138373'), p.auto = (select max(id) from auto where license_plate_no ='苏EU0G23') where  p.id = 281234 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15549138373'), i.auto = (select max(id) from auto where license_plate_no ='苏EU0G23')  where p.obj_id = i.quote_record and  p.id = 281234 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15549138373'), i.auto = (select max(id) from auto where license_plate_no ='苏EU0G23')  where p.obj_id = i.quote_record and p.id =  281234 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15549138373'), qr.auto = (select max(id) from auto where license_plate_no = '苏EU0G23') where p.obj_id = qr.id and p.id = 281234 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15549138373') where pay.purchase_order = p.id and p.id = 281234 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18576820687', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('A1GD3010509', '薛念军', 'LSJA16E34DG030654', '京HA2186', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18576820687'), (select max(id) from auto where license_plate_no = '京HA2186'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18576820687'), p.auto = (select max(id) from auto where license_plate_no ='京HA2186') where  p.id = 281235 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18576820687'), i.auto = (select max(id) from auto where license_plate_no ='京HA2186')  where p.obj_id = i.quote_record and  p.id = 281235 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18576820687'), i.auto = (select max(id) from auto where license_plate_no ='京HA2186')  where p.obj_id = i.quote_record and p.id =  281235 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18576820687'), qr.auto = (select max(id) from auto where license_plate_no = '京HA2186') where p.obj_id = qr.id and p.id = 281235 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18576820687') where pay.purchase_order = p.id and p.id = 281235 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13184767451', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('111671185', '苏州市中诚丝绸有限公司', 'LSGPB64U2BS207347', '苏E31J12', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13184767451'), (select max(id) from auto where license_plate_no = '苏E31J12'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13184767451'), p.auto = (select max(id) from auto where license_plate_no ='苏E31J12') where  p.id = 281236 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13184767451'), i.auto = (select max(id) from auto where license_plate_no ='苏E31J12')  where p.obj_id = i.quote_record and  p.id = 281236 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13184767451'), i.auto = (select max(id) from auto where license_plate_no ='苏E31J12')  where p.obj_id = i.quote_record and p.id =  281236 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13184767451'), qr.auto = (select max(id) from auto where license_plate_no = '苏E31J12') where p.obj_id = qr.id and p.id = 281236 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13184767451') where pay.purchase_order = p.id and p.id = 281236 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18969869182', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('1UR0260049', '深圳市万年青投资发展有限公司', 'JTJJM7FX6C5047043', '粤BY460K', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18969869182'), (select max(id) from auto where license_plate_no = '粤BY460K'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18969869182'), p.auto = (select max(id) from auto where license_plate_no ='粤BY460K') where  p.id = 281238 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18969869182'), i.auto = (select max(id) from auto where license_plate_no ='粤BY460K')  where p.obj_id = i.quote_record and  p.id = 281238 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18969869182'), i.auto = (select max(id) from auto where license_plate_no ='粤BY460K')  where p.obj_id = i.quote_record and p.id =  281238 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18969869182'), qr.auto = (select max(id) from auto where license_plate_no = '粤BY460K') where p.obj_id = qr.id and p.id = 281238 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18969869182') where pay.purchase_order = p.id and p.id = 281238 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13491943832', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('F453920', '渭南讯通通信有限责任公司', 'LFMKV30F2A0041017', '京EQE016', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13491943832'), (select max(id) from auto where license_plate_no = '京EQE016'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13491943832'), p.auto = (select max(id) from auto where license_plate_no ='京EQE016') where  p.id = 281242 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13491943832'), i.auto = (select max(id) from auto where license_plate_no ='京EQE016')  where p.obj_id = i.quote_record and  p.id = 281242 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13491943832'), i.auto = (select max(id) from auto where license_plate_no ='京EQE016')  where p.obj_id = i.quote_record and p.id =  281242 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13491943832'), qr.auto = (select max(id) from auto where license_plate_no = '京EQE016') where p.obj_id = qr.id and p.id = 281242 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13491943832') where pay.purchase_order = p.id and p.id = 281242 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13928389992', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('51950521', '杨莉红', 'LFNJJ5LN6BLA07229', '京E91018', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13928389992'), (select max(id) from auto where license_plate_no = '京E91018'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13928389992'), p.auto = (select max(id) from auto where license_plate_no ='京E91018') where  p.id = 281247 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13928389992'), i.auto = (select max(id) from auto where license_plate_no ='京E91018')  where p.obj_id = i.quote_record and  p.id = 281247 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13928389992'), i.auto = (select max(id) from auto where license_plate_no ='京E91018')  where p.obj_id = i.quote_record and p.id =  281247 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13928389992'), qr.auto = (select max(id) from auto where license_plate_no = '京E91018') where p.obj_id = qr.id and p.id = 281247 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13928389992') where pay.purchase_order = p.id and p.id = 281247 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13594212784', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('30013366', '深圳金光华实业集团有限公司', 'LWLNKRHFX7L018383', '粤BYF485', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13594212784'), (select max(id) from auto where license_plate_no = '粤BYF485'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13594212784'), p.auto = (select max(id) from auto where license_plate_no ='粤BYF485') where  p.id = 281251 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13594212784'), i.auto = (select max(id) from auto where license_plate_no ='粤BYF485')  where p.obj_id = i.quote_record and  p.id = 281251 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13594212784'), i.auto = (select max(id) from auto where license_plate_no ='粤BYF485')  where p.obj_id = i.quote_record and p.id =  281251 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13594212784'), qr.auto = (select max(id) from auto where license_plate_no = '粤BYF485') where p.obj_id = qr.id and p.id = 281251 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13594212784') where pay.purchase_order = p.id and p.id = 281251 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15222951569', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('51575777', '上海锐波实业有限公司', 'LFNAFUCL3ACA00392', '沪BD7005', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15222951569'), (select max(id) from auto where license_plate_no = '沪BD7005'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15222951569'), p.auto = (select max(id) from auto where license_plate_no ='沪BD7005') where  p.id = 281253 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15222951569'), i.auto = (select max(id) from auto where license_plate_no ='沪BD7005')  where p.obj_id = i.quote_record and  p.id = 281253 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15222951569'), i.auto = (select max(id) from auto where license_plate_no ='沪BD7005')  where p.obj_id = i.quote_record and p.id =  281253 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15222951569'), qr.auto = (select max(id) from auto where license_plate_no = '沪BD7005') where p.obj_id = qr.id and p.id = 281253 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15222951569') where pay.purchase_order = p.id and p.id = 281253 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18972908544', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('72008265', '梁伯龙', 'LGAR8HGN271016587', '京AB9843', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18972908544'), (select max(id) from auto where license_plate_no = '京AB9843'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18972908544'), p.auto = (select max(id) from auto where license_plate_no ='京AB9843') where  p.id = 281254 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18972908544'), i.auto = (select max(id) from auto where license_plate_no ='京AB9843')  where p.obj_id = i.quote_record and  p.id = 281254 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18972908544'), i.auto = (select max(id) from auto where license_plate_no ='京AB9843')  where p.obj_id = i.quote_record and p.id =  281254 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18972908544'), qr.auto = (select max(id) from auto where license_plate_no = '京AB9843') where p.obj_id = qr.id and p.id = 281254 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18972908544') where pay.purchase_order = p.id and p.id = 281254 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18990233303', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('00808224', '苏州市乐业机械厂', 'LBVFP1907CSF69919', '苏EQ256B', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18990233303'), (select max(id) from auto where license_plate_no = '苏EQ256B'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18990233303'), p.auto = (select max(id) from auto where license_plate_no ='苏EQ256B') where  p.id = 281255 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18990233303'), i.auto = (select max(id) from auto where license_plate_no ='苏EQ256B')  where p.obj_id = i.quote_record and  p.id = 281255 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18990233303'), i.auto = (select max(id) from auto where license_plate_no ='苏EQ256B')  where p.obj_id = i.quote_record and p.id =  281255 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18990233303'), qr.auto = (select max(id) from auto where license_plate_no = '苏EQ256B') where p.obj_id = qr.id and p.id = 281255 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18990233303') where pay.purchase_order = p.id and p.id = 281255 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13419679965', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('12051810562508PN', '苏州市科恩纺织品有限公司', 'SALMN1D44CA388881', '苏EQF858', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13419679965'), (select max(id) from auto where license_plate_no = '苏EQF858'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13419679965'), p.auto = (select max(id) from auto where license_plate_no ='苏EQF858') where  p.id = 281257 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13419679965'), i.auto = (select max(id) from auto where license_plate_no ='苏EQF858')  where p.obj_id = i.quote_record and  p.id = 281257 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13419679965'), i.auto = (select max(id) from auto where license_plate_no ='苏EQF858')  where p.obj_id = i.quote_record and p.id =  281257 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13419679965'), qr.auto = (select max(id) from auto where license_plate_no = '苏EQF858') where p.obj_id = qr.id and p.id = 281257 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13419679965') where pay.purchase_order = p.id and p.id = 281257 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13049862180', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('11559036', '白建儒', 'LGHU12192B9J43875', '京DE7825', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13049862180'), (select max(id) from auto where license_plate_no = '京DE7825'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13049862180'), p.auto = (select max(id) from auto where license_plate_no ='京DE7825') where  p.id = 281261 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13049862180'), i.auto = (select max(id) from auto where license_plate_no ='京DE7825')  where p.obj_id = i.quote_record and  p.id = 281261 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13049862180'), i.auto = (select max(id) from auto where license_plate_no ='京DE7825')  where p.obj_id = i.quote_record and p.id =  281261 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13049862180'), qr.auto = (select max(id) from auto where license_plate_no = '京DE7825') where p.obj_id = qr.id and p.id = 281261 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13049862180') where pay.purchase_order = p.id and p.id = 281261 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15101161134', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('960342', '何林安', 'LFV2A11G0C4024733', '京VKN688', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15101161134'), (select max(id) from auto where license_plate_no = '京VKN688'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15101161134'), p.auto = (select max(id) from auto where license_plate_no ='京VKN688') where  p.id = 281266 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15101161134'), i.auto = (select max(id) from auto where license_plate_no ='京VKN688')  where p.obj_id = i.quote_record and  p.id = 281266 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15101161134'), i.auto = (select max(id) from auto where license_plate_no ='京VKN688')  where p.obj_id = i.quote_record and p.id =  281266 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15101161134'), qr.auto = (select max(id) from auto where license_plate_no = '京VKN688') where p.obj_id = qr.id and p.id = 281266 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15101161134') where pay.purchase_order = p.id and p.id = 281266 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13280892851', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('C7NG02246', '武明', 'L6T7824S2CN137366', '京DWW082', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13280892851'), (select max(id) from auto where license_plate_no = '京DWW082'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13280892851'), p.auto = (select max(id) from auto where license_plate_no ='京DWW082') where  p.id = 281272 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13280892851'), i.auto = (select max(id) from auto where license_plate_no ='京DWW082')  where p.obj_id = i.quote_record and  p.id = 281272 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13280892851'), i.auto = (select max(id) from auto where license_plate_no ='京DWW082')  where p.obj_id = i.quote_record and p.id =  281272 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13280892851'), qr.auto = (select max(id) from auto where license_plate_no = '京DWW082') where p.obj_id = qr.id and p.id = 281272 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13280892851') where pay.purchase_order = p.id and p.id = 281272 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18640704036', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('323356', '刘文娟', 'LFV3A23C8D3066076', '京A611GK', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18640704036'), (select max(id) from auto where license_plate_no = '京A611GK'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18640704036'), p.auto = (select max(id) from auto where license_plate_no ='京A611GK') where  p.id = 281279 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18640704036'), i.auto = (select max(id) from auto where license_plate_no ='京A611GK')  where p.obj_id = i.quote_record and  p.id = 281279 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18640704036'), i.auto = (select max(id) from auto where license_plate_no ='京A611GK')  where p.obj_id = i.quote_record and p.id =  281279 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18640704036'), qr.auto = (select max(id) from auto where license_plate_no = '京A611GK') where p.obj_id = qr.id and p.id = 281279 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18640704036') where pay.purchase_order = p.id and p.id = 281279 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18187190532', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('4009872', '苏州久华电子有限公司', 'LVHRE1831A5005170', '苏E5YC81', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18187190532'), (select max(id) from auto where license_plate_no = '苏E5YC81'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18187190532'), p.auto = (select max(id) from auto where license_plate_no ='苏E5YC81') where  p.id = 281280 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18187190532'), i.auto = (select max(id) from auto where license_plate_no ='苏E5YC81')  where p.obj_id = i.quote_record and  p.id = 281280 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18187190532'), i.auto = (select max(id) from auto where license_plate_no ='苏E5YC81')  where p.obj_id = i.quote_record and p.id =  281280 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18187190532'), qr.auto = (select max(id) from auto where license_plate_no = '苏E5YC81') where p.obj_id = qr.id and p.id = 281280 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18187190532') where pay.purchase_order = p.id and p.id = 281280 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13123269851', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('133484008', '李张全', 'LSGJA52H7EH059237', '京JQ9089', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13123269851'), (select max(id) from auto where license_plate_no = '京JQ9089'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13123269851'), p.auto = (select max(id) from auto where license_plate_no ='京JQ9089') where  p.id = 281281 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13123269851'), i.auto = (select max(id) from auto where license_plate_no ='京JQ9089')  where p.obj_id = i.quote_record and  p.id = 281281 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13123269851'), i.auto = (select max(id) from auto where license_plate_no ='京JQ9089')  where p.obj_id = i.quote_record and p.id =  281281 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13123269851'), qr.auto = (select max(id) from auto where license_plate_no = '京JQ9089') where p.obj_id = qr.id and p.id = 281281 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13123269851') where pay.purchase_order = p.id and p.id = 281281 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15793259452', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('E1NF02873', '刘佰海', 'L6T7824S7EN017565', '京A7NM97', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15793259452'), (select max(id) from auto where license_plate_no = '京A7NM97'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15793259452'), p.auto = (select max(id) from auto where license_plate_no ='京A7NM97') where  p.id = 281282 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15793259452'), i.auto = (select max(id) from auto where license_plate_no ='京A7NM97')  where p.obj_id = i.quote_record and  p.id = 281282 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15793259452'), i.auto = (select max(id) from auto where license_plate_no ='京A7NM97')  where p.obj_id = i.quote_record and p.id =  281282 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15793259452'), qr.auto = (select max(id) from auto where license_plate_no = '京A7NM97') where p.obj_id = qr.id and p.id = 281282 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15793259452') where pay.purchase_order = p.id and p.id = 281282 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15393827677', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('DA465Q-2-4501986-D1', '马光明', 'LKENC51A04B032861', '京AUX103', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15393827677'), (select max(id) from auto where license_plate_no = '京AUX103'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15393827677'), p.auto = (select max(id) from auto where license_plate_no ='京AUX103') where  p.id = 281283 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15393827677'), i.auto = (select max(id) from auto where license_plate_no ='京AUX103')  where p.obj_id = i.quote_record and  p.id = 281283 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15393827677'), i.auto = (select max(id) from auto where license_plate_no ='京AUX103')  where p.obj_id = i.quote_record and p.id =  281283 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15393827677'), qr.auto = (select max(id) from auto where license_plate_no = '京AUX103') where p.obj_id = qr.id and p.id = 281283 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15393827677') where pay.purchase_order = p.id and p.id = 281283 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15713548004', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('119355W', '刘少丽', 'LGBK22E78CY261167', '京A5U781', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15713548004'), (select max(id) from auto where license_plate_no = '京A5U781'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15713548004'), p.auto = (select max(id) from auto where license_plate_no ='京A5U781') where  p.id = 281284 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15713548004'), i.auto = (select max(id) from auto where license_plate_no ='京A5U781')  where p.obj_id = i.quote_record and  p.id = 281284 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15713548004'), i.auto = (select max(id) from auto where license_plate_no ='京A5U781')  where p.obj_id = i.quote_record and p.id =  281284 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15713548004'), qr.auto = (select max(id) from auto where license_plate_no = '京A5U781') where p.obj_id = qr.id and p.id = 281284 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15713548004') where pay.purchase_order = p.id and p.id = 281284 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13555149338', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('C648442', '不凡帝范梅勒糖果（深圳）有限公司', 'LVGBH42K59G312324', '粤BP239V', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13555149338'), (select max(id) from auto where license_plate_no = '粤BP239V'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13555149338'), p.auto = (select max(id) from auto where license_plate_no ='粤BP239V') where  p.id = 281285 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13555149338'), i.auto = (select max(id) from auto where license_plate_no ='粤BP239V')  where p.obj_id = i.quote_record and  p.id = 281285 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13555149338'), i.auto = (select max(id) from auto where license_plate_no ='粤BP239V')  where p.obj_id = i.quote_record and p.id =  281285 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13555149338'), qr.auto = (select max(id) from auto where license_plate_no = '粤BP239V') where p.obj_id = qr.id and p.id = 281285 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13555149338') where pay.purchase_order = p.id and p.id = 281285 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13724808201', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('CB153268', '金林其', 'LJXCMCCB2CT110780', '沪M35162', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13724808201'), (select max(id) from auto where license_plate_no = '沪M35162'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13724808201'), p.auto = (select max(id) from auto where license_plate_no ='沪M35162') where  p.id = 281289 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13724808201'), i.auto = (select max(id) from auto where license_plate_no ='沪M35162')  where p.obj_id = i.quote_record and  p.id = 281289 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13724808201'), i.auto = (select max(id) from auto where license_plate_no ='沪M35162')  where p.obj_id = i.quote_record and p.id =  281289 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13724808201'), qr.auto = (select max(id) from auto where license_plate_no = '沪M35162') where p.obj_id = qr.id and p.id = 281289 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13724808201') where pay.purchase_order = p.id and p.id = 281289 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13908156618', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('DC4J008071', '苏州品鉴元筑建筑装饰工程有限公司', 'LS5A2ABE0DA113957', '苏E0WJ36', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13908156618'), (select max(id) from auto where license_plate_no = '苏E0WJ36'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13908156618'), p.auto = (select max(id) from auto where license_plate_no ='苏E0WJ36') where  p.id = 281302 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13908156618'), i.auto = (select max(id) from auto where license_plate_no ='苏E0WJ36')  where p.obj_id = i.quote_record and  p.id = 281302 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13908156618'), i.auto = (select max(id) from auto where license_plate_no ='苏E0WJ36')  where p.obj_id = i.quote_record and p.id =  281302 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13908156618'), qr.auto = (select max(id) from auto where license_plate_no = '苏E0WJ36') where p.obj_id = qr.id and p.id = 281302 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13908156618') where pay.purchase_order = p.id and p.id = 281302 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18997816413', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('B01034756', '胡孝婷', 'LJPSCA215BB000578', '京DE6252', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18997816413'), (select max(id) from auto where license_plate_no = '京DE6252'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18997816413'), p.auto = (select max(id) from auto where license_plate_no ='京DE6252') where  p.id = 281304 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18997816413'), i.auto = (select max(id) from auto where license_plate_no ='京DE6252')  where p.obj_id = i.quote_record and  p.id = 281304 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18997816413'), i.auto = (select max(id) from auto where license_plate_no ='京DE6252')  where p.obj_id = i.quote_record and p.id =  281304 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18997816413'), qr.auto = (select max(id) from auto where license_plate_no = '京DE6252') where p.obj_id = qr.id and p.id = 281304 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18997816413') where pay.purchase_order = p.id and p.id = 281304 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15213598202', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('606120755S', '深圳市宝安区松岗大方纸品厂', 'LZWDBAGA962064158', '粤BQZ356', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15213598202'), (select max(id) from auto where license_plate_no = '粤BQZ356'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15213598202'), p.auto = (select max(id) from auto where license_plate_no ='粤BQZ356') where  p.id = 281318 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15213598202'), i.auto = (select max(id) from auto where license_plate_no ='粤BQZ356')  where p.obj_id = i.quote_record and  p.id = 281318 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15213598202'), i.auto = (select max(id) from auto where license_plate_no ='粤BQZ356')  where p.obj_id = i.quote_record and p.id =  281318 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15213598202'), qr.auto = (select max(id) from auto where license_plate_no = '粤BQZ356') where p.obj_id = qr.id and p.id = 281318 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15213598202') where pay.purchase_order = p.id and p.id = 281318 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13292160225', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('Q100409765D', '苏州市吴中区甪直景祥精密五金厂', 'LJ11KBAB7AC013981', '苏E87P81', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13292160225'), (select max(id) from auto where license_plate_no = '苏E87P81'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13292160225'), p.auto = (select max(id) from auto where license_plate_no ='苏E87P81') where  p.id = 281330 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13292160225'), i.auto = (select max(id) from auto where license_plate_no ='苏E87P81')  where p.obj_id = i.quote_record and  p.id = 281330 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13292160225'), i.auto = (select max(id) from auto where license_plate_no ='苏E87P81')  where p.obj_id = i.quote_record and p.id =  281330 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13292160225'), qr.auto = (select max(id) from auto where license_plate_no = '苏E87P81') where p.obj_id = qr.id and p.id = 281330 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13292160225') where pay.purchase_order = p.id and p.id = 281330 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18583015735', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('05032388', '苏州市吴中区甪直凌塘米厂', 'LGDGJ81G85B101059', '苏ER7053', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18583015735'), (select max(id) from auto where license_plate_no = '苏ER7053'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18583015735'), p.auto = (select max(id) from auto where license_plate_no ='苏ER7053') where  p.id = 281331 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18583015735'), i.auto = (select max(id) from auto where license_plate_no ='苏ER7053')  where p.obj_id = i.quote_record and  p.id = 281331 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18583015735'), i.auto = (select max(id) from auto where license_plate_no ='苏ER7053')  where p.obj_id = i.quote_record and p.id =  281331 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18583015735'), qr.auto = (select max(id) from auto where license_plate_no = '苏ER7053') where p.obj_id = qr.id and p.id = 281331 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18583015735') where pay.purchase_order = p.id and p.id = 281331 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15081432745', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('950885X', '昆山市交通局玉山交通管理中心所', 'LJNTGU2G56N009521', '苏ENR470', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15081432745'), (select max(id) from auto where license_plate_no = '苏ENR470'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15081432745'), p.auto = (select max(id) from auto where license_plate_no ='苏ENR470') where  p.id = 281332 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15081432745'), i.auto = (select max(id) from auto where license_plate_no ='苏ENR470')  where p.obj_id = i.quote_record and  p.id = 281332 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15081432745'), i.auto = (select max(id) from auto where license_plate_no ='苏ENR470')  where p.obj_id = i.quote_record and p.id =  281332 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15081432745'), qr.auto = (select max(id) from auto where license_plate_no = '苏ENR470') where p.obj_id = qr.id and p.id = 281332 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15081432745') where pay.purchase_order = p.id and p.id = 281332 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13286793542', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('BA984107', '钱和荣', 'LBELMBKC6BY160602', '沪CTU011', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13286793542'), (select max(id) from auto where license_plate_no = '沪CTU011'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13286793542'), p.auto = (select max(id) from auto where license_plate_no ='沪CTU011') where  p.id = 281334 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13286793542'), i.auto = (select max(id) from auto where license_plate_no ='沪CTU011')  where p.obj_id = i.quote_record and  p.id = 281334 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13286793542'), i.auto = (select max(id) from auto where license_plate_no ='沪CTU011')  where p.obj_id = i.quote_record and p.id =  281334 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13286793542'), qr.auto = (select max(id) from auto where license_plate_no = '沪CTU011') where p.obj_id = qr.id and p.id = 281334 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13286793542') where pay.purchase_order = p.id and p.id = 281334 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15503835597', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('AWB032749', '常伟', 'LFVBA11J133048850', '京A713GJ', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15503835597'), (select max(id) from auto where license_plate_no = '京A713GJ'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15503835597'), p.auto = (select max(id) from auto where license_plate_no ='京A713GJ') where  p.id = 281338 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15503835597'), i.auto = (select max(id) from auto where license_plate_no ='京A713GJ')  where p.obj_id = i.quote_record and  p.id = 281338 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15503835597'), i.auto = (select max(id) from auto where license_plate_no ='京A713GJ')  where p.obj_id = i.quote_record and p.id =  281338 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15503835597'), qr.auto = (select max(id) from auto where license_plate_no = '京A713GJ') where p.obj_id = qr.id and p.id = 281338 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15503835597') where pay.purchase_order = p.id and p.id = 281338 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15132491671', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('8038237', '潘利娜', 'LVFAB2A078G057568', '京A837UW', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15132491671'), (select max(id) from auto where license_plate_no = '京A837UW'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15132491671'), p.auto = (select max(id) from auto where license_plate_no ='京A837UW') where  p.id = 281357 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15132491671'), i.auto = (select max(id) from auto where license_plate_no ='京A837UW')  where p.obj_id = i.quote_record and  p.id = 281357 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15132491671'), i.auto = (select max(id) from auto where license_plate_no ='京A837UW')  where p.obj_id = i.quote_record and p.id =  281357 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15132491671'), qr.auto = (select max(id) from auto where license_plate_no = '京A837UW') where p.obj_id = qr.id and p.id = 281357 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15132491671') where pay.purchase_order = p.id and p.id = 281357 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15360337299', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('1413D016764', '苏州优扬货运有限公司', 'LZ5N2DE53DB006320', '苏E3A396', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15360337299'), (select max(id) from auto where license_plate_no = '苏E3A396'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15360337299'), p.auto = (select max(id) from auto where license_plate_no ='苏E3A396') where  p.id = 281381 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15360337299'), i.auto = (select max(id) from auto where license_plate_no ='苏E3A396')  where p.obj_id = i.quote_record and  p.id = 281381 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15360337299'), i.auto = (select max(id) from auto where license_plate_no ='苏E3A396')  where p.obj_id = i.quote_record and p.id =  281381 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15360337299'), qr.auto = (select max(id) from auto where license_plate_no = '苏E3A396') where p.obj_id = qr.id and p.id = 281381 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15360337299') where pay.purchase_order = p.id and p.id = 281381 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15702091063', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('0102732', '苏州俄邦工程塑胶有限公司', 'LSVAU033172205370', '苏E2L523', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15702091063'), (select max(id) from auto where license_plate_no = '苏E2L523'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15702091063'), p.auto = (select max(id) from auto where license_plate_no ='苏E2L523') where  p.id = 281382 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15702091063'), i.auto = (select max(id) from auto where license_plate_no ='苏E2L523')  where p.obj_id = i.quote_record and  p.id = 281382 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15702091063'), i.auto = (select max(id) from auto where license_plate_no ='苏E2L523')  where p.obj_id = i.quote_record and p.id =  281382 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15702091063'), qr.auto = (select max(id) from auto where license_plate_no = '苏E2L523') where p.obj_id = qr.id and p.id = 281382 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15702091063') where pay.purchase_order = p.id and p.id = 281382 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18759679898', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('LABJ05148', '陈磊', 'LVVDB21BXBD362541', '京K4985H', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18759679898'), (select max(id) from auto where license_plate_no = '京K4985H'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18759679898'), p.auto = (select max(id) from auto where license_plate_no ='京K4985H') where  p.id = 281385 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18759679898'), i.auto = (select max(id) from auto where license_plate_no ='京K4985H')  where p.obj_id = i.quote_record and  p.id = 281385 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18759679898'), i.auto = (select max(id) from auto where license_plate_no ='京K4985H')  where p.obj_id = i.quote_record and p.id =  281385 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18759679898'), qr.auto = (select max(id) from auto where license_plate_no = '京K4985H') where p.obj_id = qr.id and p.id = 281385 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18759679898') where pay.purchase_order = p.id and p.id = 281385 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15776270185', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('4005583', '深圳市鸿荣轩建设工程有限公司', 'LVHRE2854A5003050', '粤BF213N', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15776270185'), (select max(id) from auto where license_plate_no = '粤BF213N'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15776270185'), p.auto = (select max(id) from auto where license_plate_no ='粤BF213N') where  p.id = 281386 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15776270185'), i.auto = (select max(id) from auto where license_plate_no ='粤BF213N')  where p.obj_id = i.quote_record and  p.id = 281386 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15776270185'), i.auto = (select max(id) from auto where license_plate_no ='粤BF213N')  where p.obj_id = i.quote_record and p.id =  281386 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15776270185'), qr.auto = (select max(id) from auto where license_plate_no = '粤BF213N') where p.obj_id = qr.id and p.id = 281386 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15776270185') where pay.purchase_order = p.id and p.id = 281386 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18605800295', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('09D0742', '太仓市顺发装潢钣金加工厂', 'LNVA1CA3X9V400844', '苏EK7625', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18605800295'), (select max(id) from auto where license_plate_no = '苏EK7625'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18605800295'), p.auto = (select max(id) from auto where license_plate_no ='苏EK7625') where  p.id = 281388 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18605800295'), i.auto = (select max(id) from auto where license_plate_no ='苏EK7625')  where p.obj_id = i.quote_record and  p.id = 281388 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18605800295'), i.auto = (select max(id) from auto where license_plate_no ='苏EK7625')  where p.obj_id = i.quote_record and p.id =  281388 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18605800295'), qr.auto = (select max(id) from auto where license_plate_no = '苏EK7625') where p.obj_id = qr.id and p.id = 281388 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18605800295') where pay.purchase_order = p.id and p.id = 281388 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15120640225', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('262206', '常熟市磊磊奶制品销售有限公司', 'LSYGF1AE82K081415', '苏ED6645', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15120640225'), (select max(id) from auto where license_plate_no = '苏ED6645'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15120640225'), p.auto = (select max(id) from auto where license_plate_no ='苏ED6645') where  p.id = 281389 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15120640225'), i.auto = (select max(id) from auto where license_plate_no ='苏ED6645')  where p.obj_id = i.quote_record and  p.id = 281389 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15120640225'), i.auto = (select max(id) from auto where license_plate_no ='苏ED6645')  where p.obj_id = i.quote_record and p.id =  281389 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15120640225'), qr.auto = (select max(id) from auto where license_plate_no = '苏ED6645') where p.obj_id = qr.id and p.id = 281389 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15120640225') where pay.purchase_order = p.id and p.id = 281389 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13567519614', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('85036010', '昆山市花桥线带厂', 'LJXBLCCB58T051245', '苏EM3Y55', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13567519614'), (select max(id) from auto where license_plate_no = '苏EM3Y55'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13567519614'), p.auto = (select max(id) from auto where license_plate_no ='苏EM3Y55') where  p.id = 281390 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13567519614'), i.auto = (select max(id) from auto where license_plate_no ='苏EM3Y55')  where p.obj_id = i.quote_record and  p.id = 281390 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13567519614'), i.auto = (select max(id) from auto where license_plate_no ='苏EM3Y55')  where p.obj_id = i.quote_record and p.id =  281390 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13567519614'), qr.auto = (select max(id) from auto where license_plate_no = '苏EM3Y55') where p.obj_id = qr.id and p.id = 281390 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13567519614') where pay.purchase_order = p.id and p.id = 281390 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15365330653', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('911223751', '杨旭兵', 'LB37624S1AL004598', '京KS5982', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15365330653'), (select max(id) from auto where license_plate_no = '京KS5982'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15365330653'), p.auto = (select max(id) from auto where license_plate_no ='京KS5982') where  p.id = 281391 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15365330653'), i.auto = (select max(id) from auto where license_plate_no ='京KS5982')  where p.obj_id = i.quote_record and  p.id = 281391 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15365330653'), i.auto = (select max(id) from auto where license_plate_no ='京KS5982')  where p.obj_id = i.quote_record and p.id =  281391 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15365330653'), qr.auto = (select max(id) from auto where license_plate_no = '京KS5982') where p.obj_id = qr.id and p.id = 281391 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15365330653') where pay.purchase_order = p.id and p.id = 281391 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15210814011', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('007295', '段小明', 'LSYAFAAN7CG309429', '京CN8172', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15210814011'), (select max(id) from auto where license_plate_no = '京CN8172'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15210814011'), p.auto = (select max(id) from auto where license_plate_no ='京CN8172') where  p.id = 281392 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15210814011'), i.auto = (select max(id) from auto where license_plate_no ='京CN8172')  where p.obj_id = i.quote_record and  p.id = 281392 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15210814011'), i.auto = (select max(id) from auto where license_plate_no ='京CN8172')  where p.obj_id = i.quote_record and p.id =  281392 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15210814011'), qr.auto = (select max(id) from auto where license_plate_no = '京CN8172') where p.obj_id = qr.id and p.id = 281392 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15210814011') where pay.purchase_order = p.id and p.id = 281392 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13001039395', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('09200806', '上海至瑞物资经营部', 'LGDCH81G79A168841', '沪JQ5592', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13001039395'), (select max(id) from auto where license_plate_no = '沪JQ5592'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13001039395'), p.auto = (select max(id) from auto where license_plate_no ='沪JQ5592') where  p.id = 281400 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13001039395'), i.auto = (select max(id) from auto where license_plate_no ='沪JQ5592')  where p.obj_id = i.quote_record and  p.id = 281400 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13001039395'), i.auto = (select max(id) from auto where license_plate_no ='沪JQ5592')  where p.obj_id = i.quote_record and p.id =  281400 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13001039395'), qr.auto = (select max(id) from auto where license_plate_no = '沪JQ5592') where p.obj_id = qr.id and p.id = 281400 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13001039395') where pay.purchase_order = p.id and p.id = 281400 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15116399237', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('0100994-E', '任王斌', 'LVFAB2AB5AG009667', '京E7998L', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15116399237'), (select max(id) from auto where license_plate_no = '京E7998L'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15116399237'), p.auto = (select max(id) from auto where license_plate_no ='京E7998L') where  p.id = 281423 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15116399237'), i.auto = (select max(id) from auto where license_plate_no ='京E7998L')  where p.obj_id = i.quote_record and  p.id = 281423 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15116399237'), i.auto = (select max(id) from auto where license_plate_no ='京E7998L')  where p.obj_id = i.quote_record and p.id =  281423 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15116399237'), qr.auto = (select max(id) from auto where license_plate_no = '京E7998L') where p.obj_id = qr.id and p.id = 281423 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15116399237') where pay.purchase_order = p.id and p.id = 281423 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15714439388', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('3157801', '李汶龙', 'LVRHFAML1DN528056', '京CX2110', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15714439388'), (select max(id) from auto where license_plate_no = '京CX2110'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15714439388'), p.auto = (select max(id) from auto where license_plate_no ='京CX2110') where  p.id = 281425 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15714439388'), i.auto = (select max(id) from auto where license_plate_no ='京CX2110')  where p.obj_id = i.quote_record and  p.id = 281425 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15714439388'), i.auto = (select max(id) from auto where license_plate_no ='京CX2110')  where p.obj_id = i.quote_record and p.id =  281425 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15714439388'), qr.auto = (select max(id) from auto where license_plate_no = '京CX2110') where p.obj_id = qr.id and p.id = 281425 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15714439388') where pay.purchase_order = p.id and p.id = 281425 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15300247432', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('16197110028569E08.8', '上海诚壹塑胶制品有限公司', 'LSKF5BC148A001809', '沪B75996', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15300247432'), (select max(id) from auto where license_plate_no = '沪B75996'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15300247432'), p.auto = (select max(id) from auto where license_plate_no ='沪B75996') where  p.id = 281437 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15300247432'), i.auto = (select max(id) from auto where license_plate_no ='沪B75996')  where p.obj_id = i.quote_record and  p.id = 281437 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15300247432'), i.auto = (select max(id) from auto where license_plate_no ='沪B75996')  where p.obj_id = i.quote_record and p.id =  281437 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15300247432'), qr.auto = (select max(id) from auto where license_plate_no = '沪B75996') where p.obj_id = qr.id and p.id = 281437 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15300247432') where pay.purchase_order = p.id and p.id = 281437 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18183612854', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('84CF008302', '深圳市南兴运输有限公司', 'LSCAC63R98E014153', '粤B052G5', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18183612854'), (select max(id) from auto where license_plate_no = '粤B052G5'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18183612854'), p.auto = (select max(id) from auto where license_plate_no ='粤B052G5') where  p.id = 281438 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18183612854'), i.auto = (select max(id) from auto where license_plate_no ='粤B052G5')  where p.obj_id = i.quote_record and  p.id = 281438 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18183612854'), i.auto = (select max(id) from auto where license_plate_no ='粤B052G5')  where p.obj_id = i.quote_record and p.id =  281438 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18183612854'), qr.auto = (select max(id) from auto where license_plate_no = '粤B052G5') where p.obj_id = qr.id and p.id = 281438 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18183612854') where pay.purchase_order = p.id and p.id = 281438 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13126056373', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('101490146', '刘健', 'LSGPB64U1AS115029', '沪CJK070', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13126056373'), (select max(id) from auto where license_plate_no = '沪CJK070'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13126056373'), p.auto = (select max(id) from auto where license_plate_no ='沪CJK070') where  p.id = 281443 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13126056373'), i.auto = (select max(id) from auto where license_plate_no ='沪CJK070')  where p.obj_id = i.quote_record and  p.id = 281443 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13126056373'), i.auto = (select max(id) from auto where license_plate_no ='沪CJK070')  where p.obj_id = i.quote_record and p.id =  281443 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13126056373'), qr.auto = (select max(id) from auto where license_plate_no = '沪CJK070') where p.obj_id = qr.id and p.id = 281443 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13126056373') where pay.purchase_order = p.id and p.id = 281443 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18781232841', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('80402245', '王向忠', 'LFPM4ACC8B1E03080', '沪C685N9', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18781232841'), (select max(id) from auto where license_plate_no = '沪C685N9'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18781232841'), p.auto = (select max(id) from auto where license_plate_no ='沪C685N9') where  p.id = 281452 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18781232841'), i.auto = (select max(id) from auto where license_plate_no ='沪C685N9')  where p.obj_id = i.quote_record and  p.id = 281452 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18781232841'), i.auto = (select max(id) from auto where license_plate_no ='沪C685N9')  where p.obj_id = i.quote_record and p.id =  281452 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18781232841'), qr.auto = (select max(id) from auto where license_plate_no = '沪C685N9') where p.obj_id = qr.id and p.id = 281452 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18781232841') where pay.purchase_order = p.id and p.id = 281452 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15612071405', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('61N13B16A', '深圳市超帆达科技有限公司', 'WBA1A310XCJ165986', '粤BQ7X81', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15612071405'), (select max(id) from auto where license_plate_no = '粤BQ7X81'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15612071405'), p.auto = (select max(id) from auto where license_plate_no ='粤BQ7X81') where  p.id = 281461 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15612071405'), i.auto = (select max(id) from auto where license_plate_no ='粤BQ7X81')  where p.obj_id = i.quote_record and  p.id = 281461 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15612071405'), i.auto = (select max(id) from auto where license_plate_no ='粤BQ7X81')  where p.obj_id = i.quote_record and p.id =  281461 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15612071405'), qr.auto = (select max(id) from auto where license_plate_no = '粤BQ7X81') where p.obj_id = qr.id and p.id = 281461 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15612071405') where pay.purchase_order = p.id and p.id = 281461 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15238933311', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('A5057614', '魏小民', 'LJDFAA14XA0144539', '京AB656H', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15238933311'), (select max(id) from auto where license_plate_no = '京AB656H'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15238933311'), p.auto = (select max(id) from auto where license_plate_no ='京AB656H') where  p.id = 281464 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15238933311'), i.auto = (select max(id) from auto where license_plate_no ='京AB656H')  where p.obj_id = i.quote_record and  p.id = 281464 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15238933311'), i.auto = (select max(id) from auto where license_plate_no ='京AB656H')  where p.obj_id = i.quote_record and p.id =  281464 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15238933311'), qr.auto = (select max(id) from auto where license_plate_no = '京AB656H') where p.obj_id = qr.id and p.id = 281464 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15238933311') where pay.purchase_order = p.id and p.id = 281464 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13507359230', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('110480324', '苏州殿泰精密电子有限公司', 'LSGPC52U8AF197649', '苏ET85V6', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13507359230'), (select max(id) from auto where license_plate_no = '苏ET85V6'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13507359230'), p.auto = (select max(id) from auto where license_plate_no ='苏ET85V6') where  p.id = 281466 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13507359230'), i.auto = (select max(id) from auto where license_plate_no ='苏ET85V6')  where p.obj_id = i.quote_record and  p.id = 281466 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13507359230'), i.auto = (select max(id) from auto where license_plate_no ='苏ET85V6')  where p.obj_id = i.quote_record and p.id =  281466 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13507359230'), qr.auto = (select max(id) from auto where license_plate_no = '苏ET85V6') where p.obj_id = qr.id and p.id = 281466 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13507359230') where pay.purchase_order = p.id and p.id = 281466 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18635320375', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('2803180', '深圳美尔洁科技有限公司', 'LFBUD1369D6S08172', '粤B0RM65', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18635320375'), (select max(id) from auto where license_plate_no = '粤B0RM65'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18635320375'), p.auto = (select max(id) from auto where license_plate_no ='粤B0RM65') where  p.id = 281469 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18635320375'), i.auto = (select max(id) from auto where license_plate_no ='粤B0RM65')  where p.obj_id = i.quote_record and  p.id = 281469 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18635320375'), i.auto = (select max(id) from auto where license_plate_no ='粤B0RM65')  where p.obj_id = i.quote_record and p.id =  281469 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18635320375'), qr.auto = (select max(id) from auto where license_plate_no = '粤B0RM65') where p.obj_id = qr.id and p.id = 281469 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18635320375') where pay.purchase_order = p.id and p.id = 281469 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15331113581', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('J1DS2A02378', '屈光兵', 'LS1D363B8A0348153', '京G13308', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15331113581'), (select max(id) from auto where license_plate_no = '京G13308'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15331113581'), p.auto = (select max(id) from auto where license_plate_no ='京G13308') where  p.id = 281472 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15331113581'), i.auto = (select max(id) from auto where license_plate_no ='京G13308')  where p.obj_id = i.quote_record and  p.id = 281472 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15331113581'), i.auto = (select max(id) from auto where license_plate_no ='京G13308')  where p.obj_id = i.quote_record and p.id =  281472 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15331113581'), qr.auto = (select max(id) from auto where license_plate_no = '京G13308') where p.obj_id = qr.id and p.id = 281472 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15331113581') where pay.purchase_order = p.id and p.id = 281472 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18618702075', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('J45D2B60018', '余景东', 'L38PDHVCXBA001354', '京EH8866', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18618702075'), (select max(id) from auto where license_plate_no = '京EH8866'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18618702075'), p.auto = (select max(id) from auto where license_plate_no ='京EH8866') where  p.id = 281483 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18618702075'), i.auto = (select max(id) from auto where license_plate_no ='京EH8866')  where p.obj_id = i.quote_record and  p.id = 281483 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18618702075'), i.auto = (select max(id) from auto where license_plate_no ='京EH8866')  where p.obj_id = i.quote_record and p.id =  281483 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18618702075'), qr.auto = (select max(id) from auto where license_plate_no = '京EH8866') where p.obj_id = qr.id and p.id = 281483 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18618702075') where pay.purchase_order = p.id and p.id = 281483 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15227510741', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('E13N2C00022', '苏州市沧浪区南兴粮店', 'LNYAFFA45CK300125', '苏E2S552', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15227510741'), (select max(id) from auto where license_plate_no = '苏E2S552'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15227510741'), p.auto = (select max(id) from auto where license_plate_no ='苏E2S552') where  p.id = 281484 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15227510741'), i.auto = (select max(id) from auto where license_plate_no ='苏E2S552')  where p.obj_id = i.quote_record and  p.id = 281484 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15227510741'), i.auto = (select max(id) from auto where license_plate_no ='苏E2S552')  where p.obj_id = i.quote_record and p.id =  281484 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15227510741'), qr.auto = (select max(id) from auto where license_plate_no = '苏E2S552') where p.obj_id = qr.id and p.id = 281484 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15227510741') where pay.purchase_order = p.id and p.id = 281484 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13337829580', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('F894029', '深圳市海怡小汽车出租有限公司', 'LFMAP22C3A0173691', '粤B784Z9', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13337829580'), (select max(id) from auto where license_plate_no = '粤B784Z9'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13337829580'), p.auto = (select max(id) from auto where license_plate_no ='粤B784Z9') where  p.id = 281490 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13337829580'), i.auto = (select max(id) from auto where license_plate_no ='粤B784Z9')  where p.obj_id = i.quote_record and  p.id = 281490 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13337829580'), i.auto = (select max(id) from auto where license_plate_no ='粤B784Z9')  where p.obj_id = i.quote_record and p.id =  281490 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13337829580'), qr.auto = (select max(id) from auto where license_plate_no = '粤B784Z9') where p.obj_id = qr.id and p.id = 281490 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13337829580') where pay.purchase_order = p.id and p.id = 281490 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13568133231', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('AYJ0212758', '苏州市吴中区东山镇财政所', 'LSVHH133232170888', '苏ER2305', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13568133231'), (select max(id) from auto where license_plate_no = '苏ER2305'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13568133231'), p.auto = (select max(id) from auto where license_plate_no ='苏ER2305') where  p.id = 281493 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13568133231'), i.auto = (select max(id) from auto where license_plate_no ='苏ER2305')  where p.obj_id = i.quote_record and  p.id = 281493 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13568133231'), i.auto = (select max(id) from auto where license_plate_no ='苏ER2305')  where p.obj_id = i.quote_record and p.id =  281493 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13568133231'), qr.auto = (select max(id) from auto where license_plate_no = '苏ER2305') where p.obj_id = qr.id and p.id = 281493 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13568133231') where pay.purchase_order = p.id and p.id = 281493 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13549846452', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('EQ49112023121', '杨长成', 'LDNL38YP520039886', '沪CP8399', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13549846452'), (select max(id) from auto where license_plate_no = '沪CP8399'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13549846452'), p.auto = (select max(id) from auto where license_plate_no ='沪CP8399') where  p.id = 281495 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13549846452'), i.auto = (select max(id) from auto where license_plate_no ='沪CP8399')  where p.obj_id = i.quote_record and  p.id = 281495 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13549846452'), i.auto = (select max(id) from auto where license_plate_no ='沪CP8399')  where p.obj_id = i.quote_record and p.id =  281495 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13549846452'), qr.auto = (select max(id) from auto where license_plate_no = '沪CP8399') where p.obj_id = qr.id and p.id = 281495 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13549846452') where pay.purchase_order = p.id and p.id = 281495 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15899563064', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('1927898', '孟庆良', 'LHGCP168692027898', '沪CCG791', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15899563064'), (select max(id) from auto where license_plate_no = '沪CCG791'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15899563064'), p.auto = (select max(id) from auto where license_plate_no ='沪CCG791') where  p.id = 281502 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15899563064'), i.auto = (select max(id) from auto where license_plate_no ='沪CCG791')  where p.obj_id = i.quote_record and  p.id = 281502 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15899563064'), i.auto = (select max(id) from auto where license_plate_no ='沪CCG791')  where p.obj_id = i.quote_record and p.id =  281502 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15899563064'), qr.auto = (select max(id) from auto where license_plate_no = '沪CCG791') where p.obj_id = qr.id and p.id = 281502 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15899563064') where pay.purchase_order = p.id and p.id = 281502 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18515416119', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('244960', '深圳市佳景广告设计有限责任公司', 'LFV2A21G063074631', '粤BNP927', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18515416119'), (select max(id) from auto where license_plate_no = '粤BNP927'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18515416119'), p.auto = (select max(id) from auto where license_plate_no ='粤BNP927') where  p.id = 281503 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18515416119'), i.auto = (select max(id) from auto where license_plate_no ='粤BNP927')  where p.obj_id = i.quote_record and  p.id = 281503 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18515416119'), i.auto = (select max(id) from auto where license_plate_no ='粤BNP927')  where p.obj_id = i.quote_record and p.id =  281503 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18515416119'), qr.auto = (select max(id) from auto where license_plate_no = '粤BNP927') where p.obj_id = qr.id and p.id = 281503 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18515416119') where pay.purchase_order = p.id and p.id = 281503 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13830119338', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('JL474Q642Y20125', '韩红芳', 'LS5H2CBR16B051561', '京EE5438', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13830119338'), (select max(id) from auto where license_plate_no = '京EE5438'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13830119338'), p.auto = (select max(id) from auto where license_plate_no ='京EE5438') where  p.id = 281505 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13830119338'), i.auto = (select max(id) from auto where license_plate_no ='京EE5438')  where p.obj_id = i.quote_record and  p.id = 281505 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13830119338'), i.auto = (select max(id) from auto where license_plate_no ='京EE5438')  where p.obj_id = i.quote_record and p.id =  281505 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13830119338'), qr.auto = (select max(id) from auto where license_plate_no = '京EE5438') where p.obj_id = qr.id and p.id = 281505 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13830119338') where pay.purchase_order = p.id and p.id = 281505 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18713319293', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('D140124595', '王小平', 'LGWCA2196EB000557', '京JB6794', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18713319293'), (select max(id) from auto where license_plate_no = '京JB6794'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18713319293'), p.auto = (select max(id) from auto where license_plate_no ='京JB6794') where  p.id = 281509 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18713319293'), i.auto = (select max(id) from auto where license_plate_no ='京JB6794')  where p.obj_id = i.quote_record and  p.id = 281509 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18713319293'), i.auto = (select max(id) from auto where license_plate_no ='京JB6794')  where p.obj_id = i.quote_record and p.id =  281509 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18713319293'), qr.auto = (select max(id) from auto where license_plate_no = '京JB6794') where p.obj_id = qr.id and p.id = 281509 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18713319293') where pay.purchase_order = p.id and p.id = 281509 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15391499487', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('122830849', '宋晓晖', 'LSGPC54U7DF017482', '沪CER872', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15391499487'), (select max(id) from auto where license_plate_no = '沪CER872'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15391499487'), p.auto = (select max(id) from auto where license_plate_no ='沪CER872') where  p.id = 281513 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15391499487'), i.auto = (select max(id) from auto where license_plate_no ='沪CER872')  where p.obj_id = i.quote_record and  p.id = 281513 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15391499487'), i.auto = (select max(id) from auto where license_plate_no ='沪CER872')  where p.obj_id = i.quote_record and p.id =  281513 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15391499487'), qr.auto = (select max(id) from auto where license_plate_no = '沪CER872') where p.obj_id = qr.id and p.id = 281513 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15391499487') where pay.purchase_order = p.id and p.id = 281513 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13905242956', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('11010265', 'ADDONIZIO SCOTT JAMES', 'LNBRCFEC8BN805175', '粤BN702W', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13905242956'), (select max(id) from auto where license_plate_no = '粤BN702W'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13905242956'), p.auto = (select max(id) from auto where license_plate_no ='粤BN702W') where  p.id = 281514 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13905242956'), i.auto = (select max(id) from auto where license_plate_no ='粤BN702W')  where p.obj_id = i.quote_record and  p.id = 281514 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13905242956'), i.auto = (select max(id) from auto where license_plate_no ='粤BN702W')  where p.obj_id = i.quote_record and p.id =  281514 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13905242956'), qr.auto = (select max(id) from auto where license_plate_no = '粤BN702W') where p.obj_id = qr.id and p.id = 281514 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13905242956') where pay.purchase_order = p.id and p.id = 281514 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18906987786', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('8D31010020', '赵伟伟', 'LZWCBAGA2D7068645', '京JM7576', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18906987786'), (select max(id) from auto where license_plate_no = '京JM7576'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18906987786'), p.auto = (select max(id) from auto where license_plate_no ='京JM7576') where  p.id = 281515 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18906987786'), i.auto = (select max(id) from auto where license_plate_no ='京JM7576')  where p.obj_id = i.quote_record and  p.id = 281515 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18906987786'), i.auto = (select max(id) from auto where license_plate_no ='京JM7576')  where p.obj_id = i.quote_record and p.id =  281515 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18906987786'), qr.auto = (select max(id) from auto where license_plate_no = '京JM7576') where p.obj_id = qr.id and p.id = 281515 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18906987786') where pay.purchase_order = p.id and p.id = 281515 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15083095595', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('61007183', '谷林', 'LJ16AA33467009363', '京AD1334', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15083095595'), (select max(id) from auto where license_plate_no = '京AD1334'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15083095595'), p.auto = (select max(id) from auto where license_plate_no ='京AD1334') where  p.id = 281521 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15083095595'), i.auto = (select max(id) from auto where license_plate_no ='京AD1334')  where p.obj_id = i.quote_record and  p.id = 281521 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15083095595'), i.auto = (select max(id) from auto where license_plate_no ='京AD1334')  where p.obj_id = i.quote_record and p.id =  281521 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15083095595'), qr.auto = (select max(id) from auto where license_plate_no = '京AD1334') where p.obj_id = qr.id and p.id = 281521 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15083095595') where pay.purchase_order = p.id and p.id = 281521 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18652295001', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('0335042', '周阿团', 'LSVA1033092119916', '京A281DZ', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18652295001'), (select max(id) from auto where license_plate_no = '京A281DZ'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18652295001'), p.auto = (select max(id) from auto where license_plate_no ='京A281DZ') where  p.id = 281522 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18652295001'), i.auto = (select max(id) from auto where license_plate_no ='京A281DZ')  where p.obj_id = i.quote_record and  p.id = 281522 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18652295001'), i.auto = (select max(id) from auto where license_plate_no ='京A281DZ')  where p.obj_id = i.quote_record and p.id =  281522 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18652295001'), qr.auto = (select max(id) from auto where license_plate_no = '京A281DZ') where p.obj_id = qr.id and p.id = 281522 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18652295001') where pay.purchase_order = p.id and p.id = 281522 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18816329064', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('A5060706', '常熟市志达汽车租赁有限公司', 'LJXBMCHD3AT052715', '苏ES2253', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18816329064'), (select max(id) from auto where license_plate_no = '苏ES2253'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18816329064'), p.auto = (select max(id) from auto where license_plate_no ='苏ES2253') where  p.id = 281523 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18816329064'), i.auto = (select max(id) from auto where license_plate_no ='苏ES2253')  where p.obj_id = i.quote_record and  p.id = 281523 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18816329064'), i.auto = (select max(id) from auto where license_plate_no ='苏ES2253')  where p.obj_id = i.quote_record and p.id =  281523 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18816329064'), qr.auto = (select max(id) from auto where license_plate_no = '苏ES2253') where p.obj_id = qr.id and p.id = 281523 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18816329064') where pay.purchase_order = p.id and p.id = 281523 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13901708510', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('BDW048978', '王建荣', 'LFV4A24FX53012387', '沪D03925', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13901708510'), (select max(id) from auto where license_plate_no = '沪D03925'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13901708510'), p.auto = (select max(id) from auto where license_plate_no ='沪D03925') where  p.id = 281525 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13901708510'), i.auto = (select max(id) from auto where license_plate_no ='沪D03925')  where p.obj_id = i.quote_record and  p.id = 281525 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13901708510'), i.auto = (select max(id) from auto where license_plate_no ='沪D03925')  where p.obj_id = i.quote_record and p.id =  281525 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13901708510'), qr.auto = (select max(id) from auto where license_plate_no = '沪D03925') where p.obj_id = qr.id and p.id = 281525 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13901708510') where pay.purchase_order = p.id and p.id = 281525 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15696984402', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('F16D365240978', '马媛媛', 'LSGJT62U96S163472', '京K83300', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15696984402'), (select max(id) from auto where license_plate_no = '京K83300'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15696984402'), p.auto = (select max(id) from auto where license_plate_no ='京K83300') where  p.id = 281527 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15696984402'), i.auto = (select max(id) from auto where license_plate_no ='京K83300')  where p.obj_id = i.quote_record and  p.id = 281527 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15696984402'), i.auto = (select max(id) from auto where license_plate_no ='京K83300')  where p.obj_id = i.quote_record and p.id =  281527 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15696984402'), qr.auto = (select max(id) from auto where license_plate_no = '京K83300') where p.obj_id = qr.id and p.id = 281527 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15696984402') where pay.purchase_order = p.id and p.id = 281527 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15668174904', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('243399', '深圳圣之奥家具有限公司', 'LFV3A28K5C3054692', '粤BL627R', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15668174904'), (select max(id) from auto where license_plate_no = '粤BL627R'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15668174904'), p.auto = (select max(id) from auto where license_plate_no ='粤BL627R') where  p.id = 281528 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15668174904'), i.auto = (select max(id) from auto where license_plate_no ='粤BL627R')  where p.obj_id = i.quote_record and  p.id = 281528 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15668174904'), i.auto = (select max(id) from auto where license_plate_no ='粤BL627R')  where p.obj_id = i.quote_record and p.id =  281528 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15668174904'), qr.auto = (select max(id) from auto where license_plate_no = '粤BL627R') where p.obj_id = qr.id and p.id = 281528 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15668174904') where pay.purchase_order = p.id and p.id = 281528 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13598832891', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('U56258', '王金森', 'LSVCH6A46DN134995', '京GX6663', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13598832891'), (select max(id) from auto where license_plate_no = '京GX6663'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13598832891'), p.auto = (select max(id) from auto where license_plate_no ='京GX6663') where  p.id = 281529 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13598832891'), i.auto = (select max(id) from auto where license_plate_no ='京GX6663')  where p.obj_id = i.quote_record and  p.id = 281529 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13598832891'), i.auto = (select max(id) from auto where license_plate_no ='京GX6663')  where p.obj_id = i.quote_record and p.id =  281529 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13598832891'), qr.auto = (select max(id) from auto where license_plate_no = '京GX6663') where p.obj_id = qr.id and p.id = 281529 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13598832891') where pay.purchase_order = p.id and p.id = 281529 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15829864114', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('102620647', '吴鸣华', 'LSGGF53X6AH291971', '沪K69153', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15829864114'), (select max(id) from auto where license_plate_no = '沪K69153'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15829864114'), p.auto = (select max(id) from auto where license_plate_no ='沪K69153') where  p.id = 281530 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15829864114'), i.auto = (select max(id) from auto where license_plate_no ='沪K69153')  where p.obj_id = i.quote_record and  p.id = 281530 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15829864114'), i.auto = (select max(id) from auto where license_plate_no ='沪K69153')  where p.obj_id = i.quote_record and p.id =  281530 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15829864114'), qr.auto = (select max(id) from auto where license_plate_no = '沪K69153') where p.obj_id = qr.id and p.id = 281530 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15829864114') where pay.purchase_order = p.id and p.id = 281530 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18187175484', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('8DC1111235', '惠延龙', 'LZWADAGA1D4241509', '京JR1606', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18187175484'), (select max(id) from auto where license_plate_no = '京JR1606'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18187175484'), p.auto = (select max(id) from auto where license_plate_no ='京JR1606') where  p.id = 281531 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18187175484'), i.auto = (select max(id) from auto where license_plate_no ='京JR1606')  where p.obj_id = i.quote_record and  p.id = 281531 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18187175484'), i.auto = (select max(id) from auto where license_plate_no ='京JR1606')  where p.obj_id = i.quote_record and p.id =  281531 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18187175484'), qr.auto = (select max(id) from auto where license_plate_no = '京JR1606') where p.obj_id = qr.id and p.id = 281531 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18187175484') where pay.purchase_order = p.id and p.id = 281531 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13842015397', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('3336054', '张家港保税区长隆新材料有限公司', 'LVSHFAAL0CN214724', '苏E273GY', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13842015397'), (select max(id) from auto where license_plate_no = '苏E273GY'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13842015397'), p.auto = (select max(id) from auto where license_plate_no ='苏E273GY') where  p.id = 281532 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13842015397'), i.auto = (select max(id) from auto where license_plate_no ='苏E273GY')  where p.obj_id = i.quote_record and  p.id = 281532 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13842015397'), i.auto = (select max(id) from auto where license_plate_no ='苏E273GY')  where p.obj_id = i.quote_record and p.id =  281532 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13842015397'), qr.auto = (select max(id) from auto where license_plate_no = '苏E273GY') where p.obj_id = qr.id and p.id = 281532 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13842015397') where pay.purchase_order = p.id and p.id = 281532 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15548457718', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('B4HG005016', '危达福', 'LS5A2ABE3BA509085', '京FFK899', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15548457718'), (select max(id) from auto where license_plate_no = '京FFK899'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15548457718'), p.auto = (select max(id) from auto where license_plate_no ='京FFK899') where  p.id = 281533 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15548457718'), i.auto = (select max(id) from auto where license_plate_no ='京FFK899')  where p.obj_id = i.quote_record and  p.id = 281533 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15548457718'), i.auto = (select max(id) from auto where license_plate_no ='京FFK899')  where p.obj_id = i.quote_record and p.id =  281533 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15548457718'), qr.auto = (select max(id) from auto where license_plate_no = '京FFK899') where p.obj_id = qr.id and p.id = 281533 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15548457718') where pay.purchase_order = p.id and p.id = 281533 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13569474230', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('80286633', '蒋佳节', 'LFPM4ACC4A1E96663', '沪C3U478', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13569474230'), (select max(id) from auto where license_plate_no = '沪C3U478'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13569474230'), p.auto = (select max(id) from auto where license_plate_no ='沪C3U478') where  p.id = 281534 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13569474230'), i.auto = (select max(id) from auto where license_plate_no ='沪C3U478')  where p.obj_id = i.quote_record and  p.id = 281534 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13569474230'), i.auto = (select max(id) from auto where license_plate_no ='沪C3U478')  where p.obj_id = i.quote_record and p.id =  281534 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13569474230'), qr.auto = (select max(id) from auto where license_plate_no = '沪C3U478') where p.obj_id = qr.id and p.id = 281534 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13569474230') where pay.purchase_order = p.id and p.id = 281534 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18133934805', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('E04052055', '鱼杰', 'LZWACAGA3E2031784', '京D1F551', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18133934805'), (select max(id) from auto where license_plate_no = '京D1F551'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18133934805'), p.auto = (select max(id) from auto where license_plate_no ='京D1F551') where  p.id = 281535 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18133934805'), i.auto = (select max(id) from auto where license_plate_no ='京D1F551')  where p.obj_id = i.quote_record and  p.id = 281535 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18133934805'), i.auto = (select max(id) from auto where license_plate_no ='京D1F551')  where p.obj_id = i.quote_record and p.id =  281535 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18133934805'), qr.auto = (select max(id) from auto where license_plate_no = '京D1F551') where p.obj_id = qr.id and p.id = 281535 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18133934805') where pay.purchase_order = p.id and p.id = 281535 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13249781507', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('F919406', '昆山阿尔文电子材料有限公司', 'LVGBH42K9CG702334', '苏E566XD', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13249781507'), (select max(id) from auto where license_plate_no = '苏E566XD'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13249781507'), p.auto = (select max(id) from auto where license_plate_no ='苏E566XD') where  p.id = 281536 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13249781507'), i.auto = (select max(id) from auto where license_plate_no ='苏E566XD')  where p.obj_id = i.quote_record and  p.id = 281536 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13249781507'), i.auto = (select max(id) from auto where license_plate_no ='苏E566XD')  where p.obj_id = i.quote_record and p.id =  281536 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13249781507'), qr.auto = (select max(id) from auto where license_plate_no = '苏E566XD') where p.obj_id = qr.id and p.id = 281536 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13249781507') where pay.purchase_order = p.id and p.id = 281536 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15700313896', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('133624430', '杨小东', 'LSGJA52H7ES012521', '京CS3063', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15700313896'), (select max(id) from auto where license_plate_no = '京CS3063'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15700313896'), p.auto = (select max(id) from auto where license_plate_no ='京CS3063') where  p.id = 281537 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15700313896'), i.auto = (select max(id) from auto where license_plate_no ='京CS3063')  where p.obj_id = i.quote_record and  p.id = 281537 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15700313896'), i.auto = (select max(id) from auto where license_plate_no ='京CS3063')  where p.obj_id = i.quote_record and p.id =  281537 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15700313896'), qr.auto = (select max(id) from auto where license_plate_no = '京CS3063') where p.obj_id = qr.id and p.id = 281537 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15700313896') where pay.purchase_order = p.id and p.id = 281537 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18981733703', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('706342008', '关朝龙', 'LB37624S47L018407', '京FQ5129', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18981733703'), (select max(id) from auto where license_plate_no = '京FQ5129'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18981733703'), p.auto = (select max(id) from auto where license_plate_no ='京FQ5129') where  p.id = 281538 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18981733703'), i.auto = (select max(id) from auto where license_plate_no ='京FQ5129')  where p.obj_id = i.quote_record and  p.id = 281538 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18981733703'), i.auto = (select max(id) from auto where license_plate_no ='京FQ5129')  where p.obj_id = i.quote_record and p.id =  281538 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18981733703'), qr.auto = (select max(id) from auto where license_plate_no = '京FQ5129') where p.obj_id = qr.id and p.id = 281538 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18981733703') where pay.purchase_order = p.id and p.id = 281538 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13600564770', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('012146387', '惠霞', 'LGDYF82F3BG502118', '京A2NX70', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13600564770'), (select max(id) from auto where license_plate_no = '京A2NX70'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13600564770'), p.auto = (select max(id) from auto where license_plate_no ='京A2NX70') where  p.id = 281539 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13600564770'), i.auto = (select max(id) from auto where license_plate_no ='京A2NX70')  where p.obj_id = i.quote_record and  p.id = 281539 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13600564770'), i.auto = (select max(id) from auto where license_plate_no ='京A2NX70')  where p.obj_id = i.quote_record and p.id =  281539 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13600564770'), qr.auto = (select max(id) from auto where license_plate_no = '京A2NX70') where p.obj_id = qr.id and p.id = 281539 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13600564770') where pay.purchase_order = p.id and p.id = 281539 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15876988250', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('630288A', '曹智民', 'LGBP12E2XBY024093', '京EYD656', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15876988250'), (select max(id) from auto where license_plate_no = '京EYD656'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15876988250'), p.auto = (select max(id) from auto where license_plate_no ='京EYD656') where  p.id = 281540 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15876988250'), i.auto = (select max(id) from auto where license_plate_no ='京EYD656')  where p.obj_id = i.quote_record and  p.id = 281540 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15876988250'), i.auto = (select max(id) from auto where license_plate_no ='京EYD656')  where p.obj_id = i.quote_record and p.id =  281540 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15876988250'), qr.auto = (select max(id) from auto where license_plate_no = '京EYD656') where p.obj_id = qr.id and p.id = 281540 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15876988250') where pay.purchase_order = p.id and p.id = 281540 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18982683718', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('40402576Z', '刘延凯', 'LTA1222L6E2017772', '京JYK368', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18982683718'), (select max(id) from auto where license_plate_no = '京JYK368'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18982683718'), p.auto = (select max(id) from auto where license_plate_no ='京JYK368') where  p.id = 281548 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18982683718'), i.auto = (select max(id) from auto where license_plate_no ='京JYK368')  where p.obj_id = i.quote_record and  p.id = 281548 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18982683718'), i.auto = (select max(id) from auto where license_plate_no ='京JYK368')  where p.obj_id = i.quote_record and p.id =  281548 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18982683718'), qr.auto = (select max(id) from auto where license_plate_no = '京JYK368') where p.obj_id = qr.id and p.id = 281548 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18982683718') where pay.purchase_order = p.id and p.id = 281548 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18756419169', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('B58566', '深圳市桑格尔科技有限公司', 'LFV3A23C9E3059588', '粤BH61M7', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18756419169'), (select max(id) from auto where license_plate_no = '粤BH61M7'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18756419169'), p.auto = (select max(id) from auto where license_plate_no ='粤BH61M7') where  p.id = 281551 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18756419169'), i.auto = (select max(id) from auto where license_plate_no ='粤BH61M7')  where p.obj_id = i.quote_record and  p.id = 281551 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18756419169'), i.auto = (select max(id) from auto where license_plate_no ='粤BH61M7')  where p.obj_id = i.quote_record and p.id =  281551 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18756419169'), qr.auto = (select max(id) from auto where license_plate_no = '粤BH61M7') where p.obj_id = qr.id and p.id = 281551 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18756419169') where pay.purchase_order = p.id and p.id = 281551 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18991814263', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('3L87D5308', '杨伟', 'LH17CKJF18H227957', '京EK6923', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18991814263'), (select max(id) from auto where license_plate_no = '京EK6923'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18991814263'), p.auto = (select max(id) from auto where license_plate_no ='京EK6923') where  p.id = 281553 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18991814263'), i.auto = (select max(id) from auto where license_plate_no ='京EK6923')  where p.obj_id = i.quote_record and  p.id = 281553 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18991814263'), i.auto = (select max(id) from auto where license_plate_no ='京EK6923')  where p.obj_id = i.quote_record and p.id =  281553 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18991814263'), qr.auto = (select max(id) from auto where license_plate_no = '京EK6923') where p.obj_id = qr.id and p.id = 281553 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18991814263') where pay.purchase_order = p.id and p.id = 281553 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18746540014', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('305877', '帝德电子（深圳）有限公司', 'LFV2A11G7A3053844', '粤B579DD', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18746540014'), (select max(id) from auto where license_plate_no = '粤B579DD'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18746540014'), p.auto = (select max(id) from auto where license_plate_no ='粤B579DD') where  p.id = 281554 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18746540014'), i.auto = (select max(id) from auto where license_plate_no ='粤B579DD')  where p.obj_id = i.quote_record and  p.id = 281554 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18746540014'), i.auto = (select max(id) from auto where license_plate_no ='粤B579DD')  where p.obj_id = i.quote_record and p.id =  281554 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18746540014'), qr.auto = (select max(id) from auto where license_plate_no = '粤B579DD') where p.obj_id = qr.id and p.id = 281554 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18746540014') where pay.purchase_order = p.id and p.id = 281554 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15247547114', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('458165X', '师红雨', 'LGBP12E02DY167248', '京DM8023', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15247547114'), (select max(id) from auto where license_plate_no = '京DM8023'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15247547114'), p.auto = (select max(id) from auto where license_plate_no ='京DM8023') where  p.id = 281560 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15247547114'), i.auto = (select max(id) from auto where license_plate_no ='京DM8023')  where p.obj_id = i.quote_record and  p.id = 281560 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15247547114'), i.auto = (select max(id) from auto where license_plate_no ='京DM8023')  where p.obj_id = i.quote_record and p.id =  281560 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15247547114'), qr.auto = (select max(id) from auto where license_plate_no = '京DM8023') where p.obj_id = qr.id and p.id = 281560 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15247547114') where pay.purchase_order = p.id and p.id = 281560 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18024660175', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('C20312383A', '昆山市开发区江隆商行', 'LGDXH81D9CA123124', '苏EZC965', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18024660175'), (select max(id) from auto where license_plate_no = '苏EZC965'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18024660175'), p.auto = (select max(id) from auto where license_plate_no ='苏EZC965') where  p.id = 281566 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18024660175'), i.auto = (select max(id) from auto where license_plate_no ='苏EZC965')  where p.obj_id = i.quote_record and  p.id = 281566 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18024660175'), i.auto = (select max(id) from auto where license_plate_no ='苏EZC965')  where p.obj_id = i.quote_record and p.id =  281566 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18024660175'), qr.auto = (select max(id) from auto where license_plate_no = '苏EZC965') where p.obj_id = qr.id and p.id = 281566 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18024660175') where pay.purchase_order = p.id and p.id = 281566 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13802281554', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('89B1610684', '张红文', 'LZWACAGA494231390', '京EK0551', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13802281554'), (select max(id) from auto where license_plate_no = '京EK0551'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13802281554'), p.auto = (select max(id) from auto where license_plate_no ='京EK0551') where  p.id = 281568 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13802281554'), i.auto = (select max(id) from auto where license_plate_no ='京EK0551')  where p.obj_id = i.quote_record and  p.id = 281568 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13802281554'), i.auto = (select max(id) from auto where license_plate_no ='京EK0551')  where p.obj_id = i.quote_record and p.id =  281568 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13802281554'), qr.auto = (select max(id) from auto where license_plate_no = '京EK0551') where p.obj_id = qr.id and p.id = 281568 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13802281554') where pay.purchase_order = p.id and p.id = 281568 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15591182183', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('373084', '江苏麦宝隆实业有限公司', 'LNJCBG3P74L650755', '苏E716HD', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15591182183'), (select max(id) from auto where license_plate_no = '苏E716HD'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15591182183'), p.auto = (select max(id) from auto where license_plate_no ='苏E716HD') where  p.id = 281569 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15591182183'), i.auto = (select max(id) from auto where license_plate_no ='苏E716HD')  where p.obj_id = i.quote_record and  p.id = 281569 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15591182183'), i.auto = (select max(id) from auto where license_plate_no ='苏E716HD')  where p.obj_id = i.quote_record and p.id =  281569 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15591182183'), qr.auto = (select max(id) from auto where license_plate_no = '苏E716HD') where p.obj_id = qr.id and p.id = 281569 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15591182183') where pay.purchase_order = p.id and p.id = 281569 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18158236819', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('E7120340', '苏州一通电力工程有限公司', 'LEFAFCG3XEHN60865', '苏E3N682', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18158236819'), (select max(id) from auto where license_plate_no = '苏E3N682'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18158236819'), p.auto = (select max(id) from auto where license_plate_no ='苏E3N682') where  p.id = 281570 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18158236819'), i.auto = (select max(id) from auto where license_plate_no ='苏E3N682')  where p.obj_id = i.quote_record and  p.id = 281570 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18158236819'), i.auto = (select max(id) from auto where license_plate_no ='苏E3N682')  where p.obj_id = i.quote_record and p.id =  281570 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18158236819'), qr.auto = (select max(id) from auto where license_plate_no = '苏E3N682') where p.obj_id = qr.id and p.id = 281570 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18158236819') where pay.purchase_order = p.id and p.id = 281570 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18047960646', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('140930184', '深圳市华泰建设工程有限公司', 'LSGUA83B7EE042271', '粤BY94E2', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18047960646'), (select max(id) from auto where license_plate_no = '粤BY94E2'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18047960646'), p.auto = (select max(id) from auto where license_plate_no ='粤BY94E2') where  p.id = 281575 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18047960646'), i.auto = (select max(id) from auto where license_plate_no ='粤BY94E2')  where p.obj_id = i.quote_record and  p.id = 281575 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18047960646'), i.auto = (select max(id) from auto where license_plate_no ='粤BY94E2')  where p.obj_id = i.quote_record and p.id =  281575 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18047960646'), qr.auto = (select max(id) from auto where license_plate_no = '粤BY94E2') where p.obj_id = qr.id and p.id = 281575 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18047960646') where pay.purchase_order = p.id and p.id = 281575 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15549017829', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('C110612', '深圳市长安大厦实业有限公司', 'LFMBF85BX60019907', '粤BRJ510', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15549017829'), (select max(id) from auto where license_plate_no = '粤BRJ510'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15549017829'), p.auto = (select max(id) from auto where license_plate_no ='粤BRJ510') where  p.id = 281576 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15549017829'), i.auto = (select max(id) from auto where license_plate_no ='粤BRJ510')  where p.obj_id = i.quote_record and  p.id = 281576 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15549017829'), i.auto = (select max(id) from auto where license_plate_no ='粤BRJ510')  where p.obj_id = i.quote_record and p.id =  281576 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15549017829'), qr.auto = (select max(id) from auto where license_plate_no = '粤BRJ510') where p.obj_id = qr.id and p.id = 281576 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15549017829') where pay.purchase_order = p.id and p.id = 281576 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15332887044', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('8D53020155', '杜国建', 'LZWADAGA0D4116078', '京DM9699', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15332887044'), (select max(id) from auto where license_plate_no = '京DM9699'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15332887044'), p.auto = (select max(id) from auto where license_plate_no ='京DM9699') where  p.id = 281581 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15332887044'), i.auto = (select max(id) from auto where license_plate_no ='京DM9699')  where p.obj_id = i.quote_record and  p.id = 281581 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15332887044'), i.auto = (select max(id) from auto where license_plate_no ='京DM9699')  where p.obj_id = i.quote_record and p.id =  281581 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15332887044'), qr.auto = (select max(id) from auto where license_plate_no = '京DM9699') where p.obj_id = qr.id and p.id = 281581 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15332887044') where pay.purchase_order = p.id and p.id = 281581 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13012579005', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('09049187', '姑苏区富宁居蔬果经营部', 'LNYADDA289K303859', '苏E9D7Y9', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13012579005'), (select max(id) from auto where license_plate_no = '苏E9D7Y9'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13012579005'), p.auto = (select max(id) from auto where license_plate_no ='苏E9D7Y9') where  p.id = 281586 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13012579005'), i.auto = (select max(id) from auto where license_plate_no ='苏E9D7Y9')  where p.obj_id = i.quote_record and  p.id = 281586 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13012579005'), i.auto = (select max(id) from auto where license_plate_no ='苏E9D7Y9')  where p.obj_id = i.quote_record and p.id =  281586 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13012579005'), qr.auto = (select max(id) from auto where license_plate_no = '苏E9D7Y9') where p.obj_id = qr.id and p.id = 281586 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13012579005') where pay.purchase_order = p.id and p.id = 281586 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13073449418', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('C03509741', '张兴学', 'LZWACAGA2C1045341', '京FZY002', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13073449418'), (select max(id) from auto where license_plate_no = '京FZY002'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13073449418'), p.auto = (select max(id) from auto where license_plate_no ='京FZY002') where  p.id = 281587 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13073449418'), i.auto = (select max(id) from auto where license_plate_no ='京FZY002')  where p.obj_id = i.quote_record and  p.id = 281587 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13073449418'), i.auto = (select max(id) from auto where license_plate_no ='京FZY002')  where p.obj_id = i.quote_record and p.id =  281587 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13073449418'), qr.auto = (select max(id) from auto where license_plate_no = '京FZY002') where p.obj_id = qr.id and p.id = 281587 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13073449418') where pay.purchase_order = p.id and p.id = 281587 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13833461507', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('153499', '杨万年', 'LFV3A24F193046638', '京V29826', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13833461507'), (select max(id) from auto where license_plate_no = '京V29826'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13833461507'), p.auto = (select max(id) from auto where license_plate_no ='京V29826') where  p.id = 281588 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13833461507'), i.auto = (select max(id) from auto where license_plate_no ='京V29826')  where p.obj_id = i.quote_record and  p.id = 281588 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13833461507'), i.auto = (select max(id) from auto where license_plate_no ='京V29826')  where p.obj_id = i.quote_record and p.id =  281588 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13833461507'), qr.auto = (select max(id) from auto where license_plate_no = '京V29826') where p.obj_id = qr.id and p.id = 281588 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13833461507') where pay.purchase_order = p.id and p.id = 281588 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13719489869', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('WB459706', '阮利峰', 'LFNA4HB47CTA45622', '京A3H560', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13719489869'), (select max(id) from auto where license_plate_no = '京A3H560'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13719489869'), p.auto = (select max(id) from auto where license_plate_no ='京A3H560') where  p.id = 281591 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13719489869'), i.auto = (select max(id) from auto where license_plate_no ='京A3H560')  where p.obj_id = i.quote_record and  p.id = 281591 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13719489869'), i.auto = (select max(id) from auto where license_plate_no ='京A3H560')  where p.obj_id = i.quote_record and p.id =  281591 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13719489869'), qr.auto = (select max(id) from auto where license_plate_no = '京A3H560') where p.obj_id = qr.id and p.id = 281591 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13719489869') where pay.purchase_order = p.id and p.id = 281591 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13542841636', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('802026228A', '昆山艾达电器有限公司', 'LZWACAGA685010642', '苏EM3S52', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13542841636'), (select max(id) from auto where license_plate_no = '苏EM3S52'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13542841636'), p.auto = (select max(id) from auto where license_plate_no ='苏EM3S52') where  p.id = 281600 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13542841636'), i.auto = (select max(id) from auto where license_plate_no ='苏EM3S52')  where p.obj_id = i.quote_record and  p.id = 281600 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13542841636'), i.auto = (select max(id) from auto where license_plate_no ='苏EM3S52')  where p.obj_id = i.quote_record and p.id =  281600 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13542841636'), qr.auto = (select max(id) from auto where license_plate_no = '苏EM3S52') where p.obj_id = qr.id and p.id = 281600 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13542841636') where pay.purchase_order = p.id and p.id = 281600 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13142325597', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('FD9A03457', '郭增强', 'LVVDB12A49D041704', '京KGQ322', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13142325597'), (select max(id) from auto where license_plate_no = '京KGQ322'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13142325597'), p.auto = (select max(id) from auto where license_plate_no ='京KGQ322') where  p.id = 281601 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13142325597'), i.auto = (select max(id) from auto where license_plate_no ='京KGQ322')  where p.obj_id = i.quote_record and  p.id = 281601 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13142325597'), i.auto = (select max(id) from auto where license_plate_no ='京KGQ322')  where p.obj_id = i.quote_record and p.id =  281601 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13142325597'), qr.auto = (select max(id) from auto where license_plate_no = '京KGQ322') where p.obj_id = qr.id and p.id = 281601 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13142325597') where pay.purchase_order = p.id and p.id = 281601 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15339445568', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('8F32820955', '赵翔', 'LZWADAGA9F4062315', '京A9LX15', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15339445568'), (select max(id) from auto where license_plate_no = '京A9LX15'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15339445568'), p.auto = (select max(id) from auto where license_plate_no ='京A9LX15') where  p.id = 281602 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15339445568'), i.auto = (select max(id) from auto where license_plate_no ='京A9LX15')  where p.obj_id = i.quote_record and  p.id = 281602 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15339445568'), i.auto = (select max(id) from auto where license_plate_no ='京A9LX15')  where p.obj_id = i.quote_record and p.id =  281602 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15339445568'), qr.auto = (select max(id) from auto where license_plate_no = '京A9LX15') where p.obj_id = qr.id and p.id = 281602 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15339445568') where pay.purchase_order = p.id and p.id = 281602 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15065842690', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('12086644', '刘建平', 'LVBV3JBB7CE131308', '京JG9175', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15065842690'), (select max(id) from auto where license_plate_no = '京JG9175'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15065842690'), p.auto = (select max(id) from auto where license_plate_no ='京JG9175') where  p.id = 281616 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15065842690'), i.auto = (select max(id) from auto where license_plate_no ='京JG9175')  where p.obj_id = i.quote_record and  p.id = 281616 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15065842690'), i.auto = (select max(id) from auto where license_plate_no ='京JG9175')  where p.obj_id = i.quote_record and p.id =  281616 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15065842690'), qr.auto = (select max(id) from auto where license_plate_no = '京JG9175') where p.obj_id = qr.id and p.id = 281616 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15065842690') where pay.purchase_order = p.id and p.id = 281616 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13730573447', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('144379', '深圳市鼎胜投资有限公司', 'LFV3B28RXC3029636', '粤BH771U', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13730573447'), (select max(id) from auto where license_plate_no = '粤BH771U'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13730573447'), p.auto = (select max(id) from auto where license_plate_no ='粤BH771U') where  p.id = 281619 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13730573447'), i.auto = (select max(id) from auto where license_plate_no ='粤BH771U')  where p.obj_id = i.quote_record and  p.id = 281619 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13730573447'), i.auto = (select max(id) from auto where license_plate_no ='粤BH771U')  where p.obj_id = i.quote_record and p.id =  281619 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13730573447'), qr.auto = (select max(id) from auto where license_plate_no = '粤BH771U') where p.obj_id = qr.id and p.id = 281619 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13730573447') where pay.purchase_order = p.id and p.id = 281619 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18928893228', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('801334107', '吕建锋', 'LJU7522S78S003860', '京AQ551N', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18928893228'), (select max(id) from auto where license_plate_no = '京AQ551N'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18928893228'), p.auto = (select max(id) from auto where license_plate_no ='京AQ551N') where  p.id = 281621 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18928893228'), i.auto = (select max(id) from auto where license_plate_no ='京AQ551N')  where p.obj_id = i.quote_record and  p.id = 281621 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18928893228'), i.auto = (select max(id) from auto where license_plate_no ='京AQ551N')  where p.obj_id = i.quote_record and p.id =  281621 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18928893228'), qr.auto = (select max(id) from auto where license_plate_no = '京AQ551N') where p.obj_id = qr.id and p.id = 281621 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18928893228') where pay.purchase_order = p.id and p.id = 281621 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18909529552', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('12002289', '梁瑞利', 'LGKG42G94C9S04330', '京CH2782', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18909529552'), (select max(id) from auto where license_plate_no = '京CH2782'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18909529552'), p.auto = (select max(id) from auto where license_plate_no ='京CH2782') where  p.id = 281629 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18909529552'), i.auto = (select max(id) from auto where license_plate_no ='京CH2782')  where p.obj_id = i.quote_record and  p.id = 281629 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18909529552'), i.auto = (select max(id) from auto where license_plate_no ='京CH2782')  where p.obj_id = i.quote_record and p.id =  281629 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18909529552'), qr.auto = (select max(id) from auto where license_plate_no = '京CH2782') where p.obj_id = qr.id and p.id = 281629 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18909529552') where pay.purchase_order = p.id and p.id = 281629 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18510887538', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('BB011043', '陈军华', 'LBEHDAFB8BY636785', '京KZ5360', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18510887538'), (select max(id) from auto where license_plate_no = '京KZ5360'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18510887538'), p.auto = (select max(id) from auto where license_plate_no ='京KZ5360') where  p.id = 281630 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18510887538'), i.auto = (select max(id) from auto where license_plate_no ='京KZ5360')  where p.obj_id = i.quote_record and  p.id = 281630 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18510887538'), i.auto = (select max(id) from auto where license_plate_no ='京KZ5360')  where p.obj_id = i.quote_record and p.id =  281630 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18510887538'), qr.auto = (select max(id) from auto where license_plate_no = '京KZ5360') where p.obj_id = qr.id and p.id = 281630 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18510887538') where pay.purchase_order = p.id and p.id = 281630 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13011319555', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('6030803', '深圳市优纳思科技有限公司', 'LJNMDV1E2BN040559', '粤BF6Q94', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13011319555'), (select max(id) from auto where license_plate_no = '粤BF6Q94'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13011319555'), p.auto = (select max(id) from auto where license_plate_no ='粤BF6Q94') where  p.id = 281631 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13011319555'), i.auto = (select max(id) from auto where license_plate_no ='粤BF6Q94')  where p.obj_id = i.quote_record and  p.id = 281631 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13011319555'), i.auto = (select max(id) from auto where license_plate_no ='粤BF6Q94')  where p.obj_id = i.quote_record and p.id =  281631 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13011319555'), qr.auto = (select max(id) from auto where license_plate_no = '粤BF6Q94') where p.obj_id = qr.id and p.id = 281631 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13011319555') where pay.purchase_order = p.id and p.id = 281631 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15164282733', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('93028176', '苏州市吴中区甪直东孚通风设备经营部', 'LJ12GAS3994006236', '苏EA9T26', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15164282733'), (select max(id) from auto where license_plate_no = '苏EA9T26'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15164282733'), p.auto = (select max(id) from auto where license_plate_no ='苏EA9T26') where  p.id = 281633 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15164282733'), i.auto = (select max(id) from auto where license_plate_no ='苏EA9T26')  where p.obj_id = i.quote_record and  p.id = 281633 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15164282733'), i.auto = (select max(id) from auto where license_plate_no ='苏EA9T26')  where p.obj_id = i.quote_record and p.id =  281633 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15164282733'), qr.auto = (select max(id) from auto where license_plate_no = '苏EA9T26') where p.obj_id = qr.id and p.id = 281633 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15164282733') where pay.purchase_order = p.id and p.id = 281633 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15024919020', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('C665964', '杜新虎', 'LVGBE40K39G434014', '京A088D7', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15024919020'), (select max(id) from auto where license_plate_no = '京A088D7'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15024919020'), p.auto = (select max(id) from auto where license_plate_no ='京A088D7') where  p.id = 281634 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15024919020'), i.auto = (select max(id) from auto where license_plate_no ='京A088D7')  where p.obj_id = i.quote_record and  p.id = 281634 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15024919020'), i.auto = (select max(id) from auto where license_plate_no ='京A088D7')  where p.obj_id = i.quote_record and p.id =  281634 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15024919020'), qr.auto = (select max(id) from auto where license_plate_no = '京A088D7') where p.obj_id = qr.id and p.id = 281634 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15024919020') where pay.purchase_order = p.id and p.id = 281634 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13299404527', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('UD42220225', '史颖超', 'LZWADAGA7D4097075', '京A8S599', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13299404527'), (select max(id) from auto where license_plate_no = '京A8S599'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13299404527'), p.auto = (select max(id) from auto where license_plate_no ='京A8S599') where  p.id = 281636 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13299404527'), i.auto = (select max(id) from auto where license_plate_no ='京A8S599')  where p.obj_id = i.quote_record and  p.id = 281636 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13299404527'), i.auto = (select max(id) from auto where license_plate_no ='京A8S599')  where p.obj_id = i.quote_record and p.id =  281636 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13299404527'), qr.auto = (select max(id) from auto where license_plate_no = '京A8S599') where p.obj_id = qr.id and p.id = 281636 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13299404527') where pay.purchase_order = p.id and p.id = 281636 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18058694450', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('609797', '深圳市瑞丽鑫源科技有限公司', 'LFV3A21K873038423', '粤BYW910', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18058694450'), (select max(id) from auto where license_plate_no = '粤BYW910'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18058694450'), p.auto = (select max(id) from auto where license_plate_no ='粤BYW910') where  p.id = 281638 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18058694450'), i.auto = (select max(id) from auto where license_plate_no ='粤BYW910')  where p.obj_id = i.quote_record and  p.id = 281638 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18058694450'), i.auto = (select max(id) from auto where license_plate_no ='粤BYW910')  where p.obj_id = i.quote_record and p.id =  281638 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18058694450'), qr.auto = (select max(id) from auto where license_plate_no = '粤BYW910') where p.obj_id = qr.id and p.id = 281638 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18058694450') where pay.purchase_order = p.id and p.id = 281638 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15099303459', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('B1NE03356', '戴亚南', 'LB37824S4BX004891', '京DY6837', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15099303459'), (select max(id) from auto where license_plate_no = '京DY6837'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15099303459'), p.auto = (select max(id) from auto where license_plate_no ='京DY6837') where  p.id = 281639 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15099303459'), i.auto = (select max(id) from auto where license_plate_no ='京DY6837')  where p.obj_id = i.quote_record and  p.id = 281639 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15099303459'), i.auto = (select max(id) from auto where license_plate_no ='京DY6837')  where p.obj_id = i.quote_record and p.id =  281639 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15099303459'), qr.auto = (select max(id) from auto where license_plate_no = '京DY6837') where p.obj_id = qr.id and p.id = 281639 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15099303459') where pay.purchase_order = p.id and p.id = 281639 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13180188175', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('0023096', '任璐', 'LDC621P2970578492', '京AMA731', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13180188175'), (select max(id) from auto where license_plate_no = '京AMA731'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13180188175'), p.auto = (select max(id) from auto where license_plate_no ='京AMA731') where  p.id = 281640 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13180188175'), i.auto = (select max(id) from auto where license_plate_no ='京AMA731')  where p.obj_id = i.quote_record and  p.id = 281640 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13180188175'), i.auto = (select max(id) from auto where license_plate_no ='京AMA731')  where p.obj_id = i.quote_record and p.id =  281640 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13180188175'), qr.auto = (select max(id) from auto where license_plate_no = '京AMA731') where p.obj_id = qr.id and p.id = 281640 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13180188175') where pay.purchase_order = p.id and p.id = 281640 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15926353299', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('09044843', '昆山锦欣和电子精密机械有限公司', 'LJ11KDBCX99003750', '苏EM9866', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15926353299'), (select max(id) from auto where license_plate_no = '苏EM9866'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15926353299'), p.auto = (select max(id) from auto where license_plate_no ='苏EM9866') where  p.id = 281641 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15926353299'), i.auto = (select max(id) from auto where license_plate_no ='苏EM9866')  where p.obj_id = i.quote_record and  p.id = 281641 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15926353299'), i.auto = (select max(id) from auto where license_plate_no ='苏EM9866')  where p.obj_id = i.quote_record and p.id =  281641 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15926353299'), qr.auto = (select max(id) from auto where license_plate_no = '苏EM9866') where p.obj_id = qr.id and p.id = 281641 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15926353299') where pay.purchase_order = p.id and p.id = 281641 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18509191145', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('W72250', '樊发信', 'LFP83ACC2D1G06845', '京EZ8558', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18509191145'), (select max(id) from auto where license_plate_no = '京EZ8558'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18509191145'), p.auto = (select max(id) from auto where license_plate_no ='京EZ8558') where  p.id = 281642 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18509191145'), i.auto = (select max(id) from auto where license_plate_no ='京EZ8558')  where p.obj_id = i.quote_record and  p.id = 281642 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18509191145'), i.auto = (select max(id) from auto where license_plate_no ='京EZ8558')  where p.obj_id = i.quote_record and p.id =  281642 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18509191145'), qr.auto = (select max(id) from auto where license_plate_no = '京EZ8558') where p.obj_id = qr.id and p.id = 281642 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18509191145') where pay.purchase_order = p.id and p.id = 281642 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18904895609', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('76051205', '深圳市宝华泰贸易有限公司', 'LEFYECG257HN20690', '粤B4PE15', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18904895609'), (select max(id) from auto where license_plate_no = '粤B4PE15'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18904895609'), p.auto = (select max(id) from auto where license_plate_no ='粤B4PE15') where  p.id = 281643 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18904895609'), i.auto = (select max(id) from auto where license_plate_no ='粤B4PE15')  where p.obj_id = i.quote_record and  p.id = 281643 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18904895609'), i.auto = (select max(id) from auto where license_plate_no ='粤B4PE15')  where p.obj_id = i.quote_record and p.id =  281643 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18904895609'), qr.auto = (select max(id) from auto where license_plate_no = '粤B4PE15') where p.obj_id = qr.id and p.id = 281643 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18904895609') where pay.purchase_order = p.id and p.id = 281643 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18076748202', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('022266', '毛英赞', 'LFV3A28K4B3058098', '沪A152M8', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18076748202'), (select max(id) from auto where license_plate_no = '沪A152M8'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18076748202'), p.auto = (select max(id) from auto where license_plate_no ='沪A152M8') where  p.id = 281645 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18076748202'), i.auto = (select max(id) from auto where license_plate_no ='沪A152M8')  where p.obj_id = i.quote_record and  p.id = 281645 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18076748202'), i.auto = (select max(id) from auto where license_plate_no ='沪A152M8')  where p.obj_id = i.quote_record and p.id =  281645 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18076748202'), qr.auto = (select max(id) from auto where license_plate_no = '沪A152M8') where p.obj_id = qr.id and p.id = 281645 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18076748202') where pay.purchase_order = p.id and p.id = 281645 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18018189669', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('AT267932', '昆山九华电子设备厂', '3D4PG6FD2AT267932', '苏E061ZV', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18018189669'), (select max(id) from auto where license_plate_no = '苏E061ZV'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18018189669'), p.auto = (select max(id) from auto where license_plate_no ='苏E061ZV') where  p.id = 281652 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18018189669'), i.auto = (select max(id) from auto where license_plate_no ='苏E061ZV')  where p.obj_id = i.quote_record and  p.id = 281652 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18018189669'), i.auto = (select max(id) from auto where license_plate_no ='苏E061ZV')  where p.obj_id = i.quote_record and p.id =  281652 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18018189669'), qr.auto = (select max(id) from auto where license_plate_no = '苏E061ZV') where p.obj_id = qr.id and p.id = 281652 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18018189669') where pay.purchase_order = p.id and p.id = 281652 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15374300151', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('F16D359230272', '吴越', 'LSGJS52U45H038730', '沪C6H263', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15374300151'), (select max(id) from auto where license_plate_no = '沪C6H263'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15374300151'), p.auto = (select max(id) from auto where license_plate_no ='沪C6H263') where  p.id = 281654 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15374300151'), i.auto = (select max(id) from auto where license_plate_no ='沪C6H263')  where p.obj_id = i.quote_record and  p.id = 281654 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15374300151'), i.auto = (select max(id) from auto where license_plate_no ='沪C6H263')  where p.obj_id = i.quote_record and p.id =  281654 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15374300151'), qr.auto = (select max(id) from auto where license_plate_no = '沪C6H263') where p.obj_id = qr.id and p.id = 281654 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15374300151') where pay.purchase_order = p.id and p.id = 281654 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15909698667', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('A11026', '贺候珍', 'LVAV2MW5XAC022542', '京JWM199', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15909698667'), (select max(id) from auto where license_plate_no = '京JWM199'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15909698667'), p.auto = (select max(id) from auto where license_plate_no ='京JWM199') where  p.id = 281663 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15909698667'), i.auto = (select max(id) from auto where license_plate_no ='京JWM199')  where p.obj_id = i.quote_record and  p.id = 281663 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15909698667'), i.auto = (select max(id) from auto where license_plate_no ='京JWM199')  where p.obj_id = i.quote_record and p.id =  281663 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15909698667'), qr.auto = (select max(id) from auto where license_plate_no = '京JWM199') where p.obj_id = qr.id and p.id = 281663 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15909698667') where pay.purchase_order = p.id and p.id = 281663 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18131405684', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('163753', '江苏恒达城建开发集团有限公司', 'LFPH4ABC369028464', '苏ETH898', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18131405684'), (select max(id) from auto where license_plate_no = '苏ETH898'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18131405684'), p.auto = (select max(id) from auto where license_plate_no ='苏ETH898') where  p.id = 281664 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18131405684'), i.auto = (select max(id) from auto where license_plate_no ='苏ETH898')  where p.obj_id = i.quote_record and  p.id = 281664 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18131405684'), i.auto = (select max(id) from auto where license_plate_no ='苏ETH898')  where p.obj_id = i.quote_record and p.id =  281664 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18131405684'), qr.auto = (select max(id) from auto where license_plate_no = '苏ETH898') where p.obj_id = qr.id and p.id = 281664 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18131405684') where pay.purchase_order = p.id and p.id = 281664 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15077761969', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('FB672220', '曹伟', 'LBEMDAFB9FZ596960', '京CFW896', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15077761969'), (select max(id) from auto where license_plate_no = '京CFW896'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15077761969'), p.auto = (select max(id) from auto where license_plate_no ='京CFW896') where  p.id = 281672 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15077761969'), i.auto = (select max(id) from auto where license_plate_no ='京CFW896')  where p.obj_id = i.quote_record and  p.id = 281672 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15077761969'), i.auto = (select max(id) from auto where license_plate_no ='京CFW896')  where p.obj_id = i.quote_record and p.id =  281672 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15077761969'), qr.auto = (select max(id) from auto where license_plate_no = '京CFW896') where p.obj_id = qr.id and p.id = 281672 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15077761969') where pay.purchase_order = p.id and p.id = 281672 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15045062790', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('UE32120453', '张腾博', 'LZWCCAGA8E7043442', '京A808RZ', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15045062790'), (select max(id) from auto where license_plate_no = '京A808RZ'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15045062790'), p.auto = (select max(id) from auto where license_plate_no ='京A808RZ') where  p.id = 281687 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15045062790'), i.auto = (select max(id) from auto where license_plate_no ='京A808RZ')  where p.obj_id = i.quote_record and  p.id = 281687 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15045062790'), i.auto = (select max(id) from auto where license_plate_no ='京A808RZ')  where p.obj_id = i.quote_record and p.id =  281687 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15045062790'), qr.auto = (select max(id) from auto where license_plate_no = '京A808RZ') where p.obj_id = qr.id and p.id = 281687 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15045062790') where pay.purchase_order = p.id and p.id = 281687 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15296227839', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('CG4B001625', '任新才', 'LS5A2ABEXCA503351', '京E5929G', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15296227839'), (select max(id) from auto where license_plate_no = '京E5929G'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15296227839'), p.auto = (select max(id) from auto where license_plate_no ='京E5929G') where  p.id = 281688 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15296227839'), i.auto = (select max(id) from auto where license_plate_no ='京E5929G')  where p.obj_id = i.quote_record and  p.id = 281688 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15296227839'), i.auto = (select max(id) from auto where license_plate_no ='京E5929G')  where p.obj_id = i.quote_record and p.id =  281688 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15296227839'), qr.auto = (select max(id) from auto where license_plate_no = '京E5929G') where p.obj_id = qr.id and p.id = 281688 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15296227839') where pay.purchase_order = p.id and p.id = 281688 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13327768355', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('B48178', '田会兵', 'LFV3A23C0E3047197', '京A892TX', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13327768355'), (select max(id) from auto where license_plate_no = '京A892TX'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13327768355'), p.auto = (select max(id) from auto where license_plate_no ='京A892TX') where  p.id = 281689 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13327768355'), i.auto = (select max(id) from auto where license_plate_no ='京A892TX')  where p.obj_id = i.quote_record and  p.id = 281689 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13327768355'), i.auto = (select max(id) from auto where license_plate_no ='京A892TX')  where p.obj_id = i.quote_record and p.id =  281689 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13327768355'), qr.auto = (select max(id) from auto where license_plate_no = '京A892TX') where p.obj_id = qr.id and p.id = 281689 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13327768355') where pay.purchase_order = p.id and p.id = 281689 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13124696362', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('AACC03284', '段小花', 'LVVDB11B1CD136786', '京CS2625', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13124696362'), (select max(id) from auto where license_plate_no = '京CS2625'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13124696362'), p.auto = (select max(id) from auto where license_plate_no ='京CS2625') where  p.id = 281690 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13124696362'), i.auto = (select max(id) from auto where license_plate_no ='京CS2625')  where p.obj_id = i.quote_record and  p.id = 281690 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13124696362'), i.auto = (select max(id) from auto where license_plate_no ='京CS2625')  where p.obj_id = i.quote_record and p.id =  281690 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13124696362'), qr.auto = (select max(id) from auto where license_plate_no = '京CS2625') where p.obj_id = qr.id and p.id = 281690 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13124696362') where pay.purchase_order = p.id and p.id = 281690 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18037618917', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('8A61710504', '张丽华', 'LZWACAGA6A8198745', '沪CH6823', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18037618917'), (select max(id) from auto where license_plate_no = '沪CH6823'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18037618917'), p.auto = (select max(id) from auto where license_plate_no ='沪CH6823') where  p.id = 281692 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18037618917'), i.auto = (select max(id) from auto where license_plate_no ='沪CH6823')  where p.obj_id = i.quote_record and  p.id = 281692 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18037618917'), i.auto = (select max(id) from auto where license_plate_no ='沪CH6823')  where p.obj_id = i.quote_record and p.id =  281692 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18037618917'), qr.auto = (select max(id) from auto where license_plate_no = '沪CH6823') where p.obj_id = qr.id and p.id = 281692 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18037618917') where pay.purchase_order = p.id and p.id = 281692 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15058564710', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('909810T', '王月战', 'LGBL2AE00EY151248', '京EWA190', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15058564710'), (select max(id) from auto where license_plate_no = '京EWA190'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15058564710'), p.auto = (select max(id) from auto where license_plate_no ='京EWA190') where  p.id = 281693 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15058564710'), i.auto = (select max(id) from auto where license_plate_no ='京EWA190')  where p.obj_id = i.quote_record and  p.id = 281693 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15058564710'), i.auto = (select max(id) from auto where license_plate_no ='京EWA190')  where p.obj_id = i.quote_record and p.id =  281693 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15058564710'), qr.auto = (select max(id) from auto where license_plate_no = '京EWA190') where p.obj_id = qr.id and p.id = 281693 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15058564710') where pay.purchase_order = p.id and p.id = 281693 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13874918003', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('DA02905', '杨剑', 'LVSHJCAC7DE187694', '京A087CK', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13874918003'), (select max(id) from auto where license_plate_no = '京A087CK'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13874918003'), p.auto = (select max(id) from auto where license_plate_no ='京A087CK') where  p.id = 281694 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13874918003'), i.auto = (select max(id) from auto where license_plate_no ='京A087CK')  where p.obj_id = i.quote_record and  p.id = 281694 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13874918003'), i.auto = (select max(id) from auto where license_plate_no ='京A087CK')  where p.obj_id = i.quote_record and p.id =  281694 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13874918003'), qr.auto = (select max(id) from auto where license_plate_no = '京A087CK') where p.obj_id = qr.id and p.id = 281694 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13874918003') where pay.purchase_order = p.id and p.id = 281694 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15036371127', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('LJ462QE1609164081', '庄明全', 'LZWACAGAX61111011', '沪CB9763', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15036371127'), (select max(id) from auto where license_plate_no = '沪CB9763'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15036371127'), p.auto = (select max(id) from auto where license_plate_no ='沪CB9763') where  p.id = 281696 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15036371127'), i.auto = (select max(id) from auto where license_plate_no ='沪CB9763')  where p.obj_id = i.quote_record and  p.id = 281696 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15036371127'), i.auto = (select max(id) from auto where license_plate_no ='沪CB9763')  where p.obj_id = i.quote_record and p.id =  281696 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15036371127'), qr.auto = (select max(id) from auto where license_plate_no = '沪CB9763') where p.obj_id = qr.id and p.id = 281696 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15036371127') where pay.purchase_order = p.id and p.id = 281696 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15639490976', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('UD41521153', '尚四刚', 'LZWADAGA6D8090224', '京D0F997', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15639490976'), (select max(id) from auto where license_plate_no = '京D0F997'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15639490976'), p.auto = (select max(id) from auto where license_plate_no ='京D0F997') where  p.id = 281699 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15639490976'), i.auto = (select max(id) from auto where license_plate_no ='京D0F997')  where p.obj_id = i.quote_record and  p.id = 281699 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15639490976'), i.auto = (select max(id) from auto where license_plate_no ='京D0F997')  where p.obj_id = i.quote_record and p.id =  281699 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15639490976'), qr.auto = (select max(id) from auto where license_plate_no = '京D0F997') where p.obj_id = qr.id and p.id = 281699 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15639490976') where pay.purchase_order = p.id and p.id = 281699 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15565163366', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('E32DA021840', '刘晓军', 'LCFHTKG2XA0Z09132', '京A8947学', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15565163366'), (select max(id) from auto where license_plate_no = '京A8947学'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15565163366'), p.auto = (select max(id) from auto where license_plate_no ='京A8947学') where  p.id = 281702 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15565163366'), i.auto = (select max(id) from auto where license_plate_no ='京A8947学')  where p.obj_id = i.quote_record and  p.id = 281702 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15565163366'), i.auto = (select max(id) from auto where license_plate_no ='京A8947学')  where p.obj_id = i.quote_record and p.id =  281702 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15565163366'), qr.auto = (select max(id) from auto where license_plate_no = '京A8947学') where p.obj_id = qr.id and p.id = 281702 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15565163366') where pay.purchase_order = p.id and p.id = 281702 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18589644554', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('50705100103', '苏州市万年运输有限公司', 'LZ5N2CD397B004523', '苏ER3986', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18589644554'), (select max(id) from auto where license_plate_no = '苏ER3986'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18589644554'), p.auto = (select max(id) from auto where license_plate_no ='苏ER3986') where  p.id = 281703 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18589644554'), i.auto = (select max(id) from auto where license_plate_no ='苏ER3986')  where p.obj_id = i.quote_record and  p.id = 281703 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18589644554'), i.auto = (select max(id) from auto where license_plate_no ='苏ER3986')  where p.obj_id = i.quote_record and p.id =  281703 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18589644554'), qr.auto = (select max(id) from auto where license_plate_no = '苏ER3986') where p.obj_id = qr.id and p.id = 281703 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18589644554') where pay.purchase_order = p.id and p.id = 281703 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13704190066', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('41221713', '咸阳威迪机电科技有限公司', 'LSGDC82C65E012540', '京D63906', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13704190066'), (select max(id) from auto where license_plate_no = '京D63906'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13704190066'), p.auto = (select max(id) from auto where license_plate_no ='京D63906') where  p.id = 281705 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13704190066'), i.auto = (select max(id) from auto where license_plate_no ='京D63906')  where p.obj_id = i.quote_record and  p.id = 281705 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13704190066'), i.auto = (select max(id) from auto where license_plate_no ='京D63906')  where p.obj_id = i.quote_record and p.id =  281705 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13704190066'), qr.auto = (select max(id) from auto where license_plate_no = '京D63906') where p.obj_id = qr.id and p.id = 281705 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13704190066') where pay.purchase_order = p.id and p.id = 281705 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13708831544', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('3287145', '汤斌', 'LVSHCAMB7DE220940', '京FTH628', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13708831544'), (select max(id) from auto where license_plate_no = '京FTH628'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13708831544'), p.auto = (select max(id) from auto where license_plate_no ='京FTH628') where  p.id = 281706 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13708831544'), i.auto = (select max(id) from auto where license_plate_no ='京FTH628')  where p.obj_id = i.quote_record and  p.id = 281706 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13708831544'), i.auto = (select max(id) from auto where license_plate_no ='京FTH628')  where p.obj_id = i.quote_record and p.id =  281706 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13708831544'), qr.auto = (select max(id) from auto where license_plate_no = '京FTH628') where p.obj_id = qr.id and p.id = 281706 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13708831544') where pay.purchase_order = p.id and p.id = 281706 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18943561519', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('904439451', '马明翠', 'LZWACAGA791021870', '京G82629', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18943561519'), (select max(id) from auto where license_plate_no = '京G82629'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18943561519'), p.auto = (select max(id) from auto where license_plate_no ='京G82629') where  p.id = 281707 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18943561519'), i.auto = (select max(id) from auto where license_plate_no ='京G82629')  where p.obj_id = i.quote_record and  p.id = 281707 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18943561519'), i.auto = (select max(id) from auto where license_plate_no ='京G82629')  where p.obj_id = i.quote_record and p.id =  281707 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18943561519'), qr.auto = (select max(id) from auto where license_plate_no = '京G82629') where p.obj_id = qr.id and p.id = 281707 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18943561519') where pay.purchase_order = p.id and p.id = 281707 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18516356630', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('E32E5C00052', '西安市灞桥区人民政府新筑街道办事处', 'LGAW1A128CC003239', '京AL2410', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18516356630'), (select max(id) from auto where license_plate_no = '京AL2410'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18516356630'), p.auto = (select max(id) from auto where license_plate_no ='京AL2410') where  p.id = 281710 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18516356630'), i.auto = (select max(id) from auto where license_plate_no ='京AL2410')  where p.obj_id = i.quote_record and  p.id = 281710 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18516356630'), i.auto = (select max(id) from auto where license_plate_no ='京AL2410')  where p.obj_id = i.quote_record and p.id =  281710 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18516356630'), qr.auto = (select max(id) from auto where license_plate_no = '京AL2410') where p.obj_id = qr.id and p.id = 281710 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18516356630') where pay.purchase_order = p.id and p.id = 281710 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15503896249', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('4004046', '深圳市南翔科技有限公司', 'LDNP4LFE670145452', '粤BYC693', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15503896249'), (select max(id) from auto where license_plate_no = '粤BYC693'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15503896249'), p.auto = (select max(id) from auto where license_plate_no ='粤BYC693') where  p.id = 281713 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15503896249'), i.auto = (select max(id) from auto where license_plate_no ='粤BYC693')  where p.obj_id = i.quote_record and  p.id = 281713 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15503896249'), i.auto = (select max(id) from auto where license_plate_no ='粤BYC693')  where p.obj_id = i.quote_record and p.id =  281713 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15503896249'), qr.auto = (select max(id) from auto where license_plate_no = '粤BYC693') where p.obj_id = qr.id and p.id = 281713 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15503896249') where pay.purchase_order = p.id and p.id = 281713 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18820600678', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('117728T', '余传宝', 'LGBH1AE039Y091657', '京A677US', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18820600678'), (select max(id) from auto where license_plate_no = '京A677US'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18820600678'), p.auto = (select max(id) from auto where license_plate_no ='京A677US') where  p.id = 281722 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18820600678'), i.auto = (select max(id) from auto where license_plate_no ='京A677US')  where p.obj_id = i.quote_record and  p.id = 281722 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18820600678'), i.auto = (select max(id) from auto where license_plate_no ='京A677US')  where p.obj_id = i.quote_record and p.id =  281722 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18820600678'), qr.auto = (select max(id) from auto where license_plate_no = '京A677US') where p.obj_id = qr.id and p.id = 281722 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18820600678') where pay.purchase_order = p.id and p.id = 281722 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13549793942', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('B4DC15297', '李西锋', 'LS5W3ABE4BB158040', '京A3M288', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13549793942'), (select max(id) from auto where license_plate_no = '京A3M288'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13549793942'), p.auto = (select max(id) from auto where license_plate_no ='京A3M288') where  p.id = 281723 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13549793942'), i.auto = (select max(id) from auto where license_plate_no ='京A3M288')  where p.obj_id = i.quote_record and  p.id = 281723 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13549793942'), i.auto = (select max(id) from auto where license_plate_no ='京A3M288')  where p.obj_id = i.quote_record and p.id =  281723 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13549793942'), qr.auto = (select max(id) from auto where license_plate_no = '京A3M288') where p.obj_id = qr.id and p.id = 281723 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13549793942') where pay.purchase_order = p.id and p.id = 281723 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13490917909', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('CMD001834', '江苏联冠高新技术有限公司', 'WAURGB4H8BN017940', '苏EH789U', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13490917909'), (select max(id) from auto where license_plate_no = '苏EH789U'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13490917909'), p.auto = (select max(id) from auto where license_plate_no ='苏EH789U') where  p.id = 281724 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13490917909'), i.auto = (select max(id) from auto where license_plate_no ='苏EH789U')  where p.obj_id = i.quote_record and  p.id = 281724 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13490917909'), i.auto = (select max(id) from auto where license_plate_no ='苏EH789U')  where p.obj_id = i.quote_record and p.id =  281724 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13490917909'), qr.auto = (select max(id) from auto where license_plate_no = '苏EH789U') where p.obj_id = qr.id and p.id = 281724 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13490917909') where pay.purchase_order = p.id and p.id = 281724 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13870089153', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('0373520', '无锡大盛基础工程有限公司昆山分公司', 'LSVA1033692158686', '苏EX0998', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13870089153'), (select max(id) from auto where license_plate_no = '苏EX0998'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13870089153'), p.auto = (select max(id) from auto where license_plate_no ='苏EX0998') where  p.id = 281728 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13870089153'), i.auto = (select max(id) from auto where license_plate_no ='苏EX0998')  where p.obj_id = i.quote_record and  p.id = 281728 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13870089153'), i.auto = (select max(id) from auto where license_plate_no ='苏EX0998')  where p.obj_id = i.quote_record and p.id =  281728 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13870089153'), qr.auto = (select max(id) from auto where license_plate_no = '苏EX0998') where p.obj_id = qr.id and p.id = 281728 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13870089153') where pay.purchase_order = p.id and p.id = 281728 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18511447425', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('A4050936', '深圳市正印元兴商贸有限公司', 'LEFYECG23AHN21697', '粤B105X2', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18511447425'), (select max(id) from auto where license_plate_no = '粤B105X2'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18511447425'), p.auto = (select max(id) from auto where license_plate_no ='粤B105X2') where  p.id = 281730 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18511447425'), i.auto = (select max(id) from auto where license_plate_no ='粤B105X2')  where p.obj_id = i.quote_record and  p.id = 281730 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18511447425'), i.auto = (select max(id) from auto where license_plate_no ='粤B105X2')  where p.obj_id = i.quote_record and p.id =  281730 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18511447425'), qr.auto = (select max(id) from auto where license_plate_no = '粤B105X2') where p.obj_id = qr.id and p.id = 281730 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18511447425') where pay.purchase_order = p.id and p.id = 281730 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13180745492', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('F1000433', '高铭', 'LGAX5DF49F3000469', '京F38911', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13180745492'), (select max(id) from auto where license_plate_no = '京F38911'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13180745492'), p.auto = (select max(id) from auto where license_plate_no ='京F38911') where  p.id = 281742 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13180745492'), i.auto = (select max(id) from auto where license_plate_no ='京F38911')  where p.obj_id = i.quote_record and  p.id = 281742 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13180745492'), i.auto = (select max(id) from auto where license_plate_no ='京F38911')  where p.obj_id = i.quote_record and p.id =  281742 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13180745492'), qr.auto = (select max(id) from auto where license_plate_no = '京F38911') where p.obj_id = qr.id and p.id = 281742 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13180745492') where pay.purchase_order = p.id and p.id = 281742 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15386250969', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('10232310', '刘小行', 'LVBV3PBB5AE057385', '京JB8050', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15386250969'), (select max(id) from auto where license_plate_no = '京JB8050'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15386250969'), p.auto = (select max(id) from auto where license_plate_no ='京JB8050') where  p.id = 281752 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15386250969'), i.auto = (select max(id) from auto where license_plate_no ='京JB8050')  where p.obj_id = i.quote_record and  p.id = 281752 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15386250969'), i.auto = (select max(id) from auto where license_plate_no ='京JB8050')  where p.obj_id = i.quote_record and p.id =  281752 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15386250969'), qr.auto = (select max(id) from auto where license_plate_no = '京JB8050') where p.obj_id = qr.id and p.id = 281752 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15386250969') where pay.purchase_order = p.id and p.id = 281752 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15067737997', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('E4LH06799', '郭岭生', 'LS5A3ABE8EB026154', '京A8Z687', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15067737997'), (select max(id) from auto where license_plate_no = '京A8Z687'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15067737997'), p.auto = (select max(id) from auto where license_plate_no ='京A8Z687') where  p.id = 281758 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15067737997'), i.auto = (select max(id) from auto where license_plate_no ='京A8Z687')  where p.obj_id = i.quote_record and  p.id = 281758 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15067737997'), i.auto = (select max(id) from auto where license_plate_no ='京A8Z687')  where p.obj_id = i.quote_record and p.id =  281758 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15067737997'), qr.auto = (select max(id) from auto where license_plate_no = '京A8Z687') where p.obj_id = qr.id and p.id = 281758 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15067737997') where pay.purchase_order = p.id and p.id = 281758 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15543472706', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('912925801', '刘小军', 'LJPSBA1129B027042', '京A269P0', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15543472706'), (select max(id) from auto where license_plate_no = '京A269P0'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15543472706'), p.auto = (select max(id) from auto where license_plate_no ='京A269P0') where  p.id = 281760 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15543472706'), i.auto = (select max(id) from auto where license_plate_no ='京A269P0')  where p.obj_id = i.quote_record and  p.id = 281760 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15543472706'), i.auto = (select max(id) from auto where license_plate_no ='京A269P0')  where p.obj_id = i.quote_record and p.id =  281760 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15543472706'), qr.auto = (select max(id) from auto where license_plate_no = '京A269P0') where p.obj_id = qr.id and p.id = 281760 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15543472706') where pay.purchase_order = p.id and p.id = 281760 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13162006253', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('3919912-E', '舒刚', 'LVFAB2AB1DG051600', '京DSG562', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13162006253'), (select max(id) from auto where license_plate_no = '京DSG562'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13162006253'), p.auto = (select max(id) from auto where license_plate_no ='京DSG562') where  p.id = 281773 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13162006253'), i.auto = (select max(id) from auto where license_plate_no ='京DSG562')  where p.obj_id = i.quote_record and  p.id = 281773 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13162006253'), i.auto = (select max(id) from auto where license_plate_no ='京DSG562')  where p.obj_id = i.quote_record and p.id =  281773 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13162006253'), qr.auto = (select max(id) from auto where license_plate_no = '京DSG562') where p.obj_id = qr.id and p.id = 281773 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13162006253') where pay.purchase_order = p.id and p.id = 281773 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13357823068', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('E03D01286', '胡治全', 'LNBMDLAA2EU019991', '京A676WX', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13357823068'), (select max(id) from auto where license_plate_no = '京A676WX'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13357823068'), p.auto = (select max(id) from auto where license_plate_no ='京A676WX') where  p.id = 281774 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13357823068'), i.auto = (select max(id) from auto where license_plate_no ='京A676WX')  where p.obj_id = i.quote_record and  p.id = 281774 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13357823068'), i.auto = (select max(id) from auto where license_plate_no ='京A676WX')  where p.obj_id = i.quote_record and p.id =  281774 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13357823068'), qr.auto = (select max(id) from auto where license_plate_no = '京A676WX') where p.obj_id = qr.id and p.id = 281774 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13357823068') where pay.purchase_order = p.id and p.id = 281774 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18832063418', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('WA204458', '李红军', 'LWU2PM2C6EKM02357', '京E63698', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18832063418'), (select max(id) from auto where license_plate_no = '京E63698'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18832063418'), p.auto = (select max(id) from auto where license_plate_no ='京E63698') where  p.id = 281776 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18832063418'), i.auto = (select max(id) from auto where license_plate_no ='京E63698')  where p.obj_id = i.quote_record and  p.id = 281776 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18832063418'), i.auto = (select max(id) from auto where license_plate_no ='京E63698')  where p.obj_id = i.quote_record and p.id =  281776 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18832063418'), qr.auto = (select max(id) from auto where license_plate_no = '京E63698') where p.obj_id = qr.id and p.id = 281776 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18832063418') where pay.purchase_order = p.id and p.id = 281776 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13443214180', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('110703153', '昆山开发区江南古典家具经营部', 'LCR6U3110BX605975', '苏EN03H1', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13443214180'), (select max(id) from auto where license_plate_no = '苏EN03H1'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13443214180'), p.auto = (select max(id) from auto where license_plate_no ='苏EN03H1') where  p.id = 281780 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13443214180'), i.auto = (select max(id) from auto where license_plate_no ='苏EN03H1')  where p.obj_id = i.quote_record and  p.id = 281780 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13443214180'), i.auto = (select max(id) from auto where license_plate_no ='苏EN03H1')  where p.obj_id = i.quote_record and p.id =  281780 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13443214180'), qr.auto = (select max(id) from auto where license_plate_no = '苏EN03H1') where p.obj_id = qr.id and p.id = 281780 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13443214180') where pay.purchase_order = p.id and p.id = 281780 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18729512092', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('01074888', '苏州市相城区黄桥永盛电子经营部', 'LFWDSUMX85AB02245', '苏ER2685', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18729512092'), (select max(id) from auto where license_plate_no = '苏ER2685'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18729512092'), p.auto = (select max(id) from auto where license_plate_no ='苏ER2685') where  p.id = 281781 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18729512092'), i.auto = (select max(id) from auto where license_plate_no ='苏ER2685')  where p.obj_id = i.quote_record and  p.id = 281781 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18729512092'), i.auto = (select max(id) from auto where license_plate_no ='苏ER2685')  where p.obj_id = i.quote_record and p.id =  281781 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18729512092'), qr.auto = (select max(id) from auto where license_plate_no = '苏ER2685') where p.obj_id = qr.id and p.id = 281781 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18729512092') where pay.purchase_order = p.id and p.id = 281781 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13335909559', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('D131119298', '吴起方达技术服务有限责任公司', 'LGWDB2170DC004869', '京JQ5279', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13335909559'), (select max(id) from auto where license_plate_no = '京JQ5279'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13335909559'), p.auto = (select max(id) from auto where license_plate_no ='京JQ5279') where  p.id = 281782 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13335909559'), i.auto = (select max(id) from auto where license_plate_no ='京JQ5279')  where p.obj_id = i.quote_record and  p.id = 281782 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13335909559'), i.auto = (select max(id) from auto where license_plate_no ='京JQ5279')  where p.obj_id = i.quote_record and p.id =  281782 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13335909559'), qr.auto = (select max(id) from auto where license_plate_no = '京JQ5279') where p.obj_id = qr.id and p.id = 281782 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13335909559') where pay.purchase_order = p.id and p.id = 281782 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15131300352', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('056696', '温斯顿电池制造有限公司', 'LWLNKRHF5AL043375', '粤B654L3', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15131300352'), (select max(id) from auto where license_plate_no = '粤B654L3'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15131300352'), p.auto = (select max(id) from auto where license_plate_no ='粤B654L3') where  p.id = 281783 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15131300352'), i.auto = (select max(id) from auto where license_plate_no ='粤B654L3')  where p.obj_id = i.quote_record and  p.id = 281783 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15131300352'), i.auto = (select max(id) from auto where license_plate_no ='粤B654L3')  where p.obj_id = i.quote_record and p.id =  281783 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15131300352'), qr.auto = (select max(id) from auto where license_plate_no = '粤B654L3') where p.obj_id = qr.id and p.id = 281783 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15131300352') where pay.purchase_order = p.id and p.id = 281783 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15253169948', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('X040029650', '殷海亭', 'LRH12R2D4C0001566', '京A8JN29', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15253169948'), (select max(id) from auto where license_plate_no = '京A8JN29'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15253169948'), p.auto = (select max(id) from auto where license_plate_no ='京A8JN29') where  p.id = 281788 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15253169948'), i.auto = (select max(id) from auto where license_plate_no ='京A8JN29')  where p.obj_id = i.quote_record and  p.id = 281788 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15253169948'), i.auto = (select max(id) from auto where license_plate_no ='京A8JN29')  where p.obj_id = i.quote_record and p.id =  281788 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15253169948'), qr.auto = (select max(id) from auto where license_plate_no = '京A8JN29') where p.obj_id = qr.id and p.id = 281788 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15253169948') where pay.purchase_order = p.id and p.id = 281788 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15369505007', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('AF9M12801', '郑军峰', 'LVTDH12A89B047539', '京A905J2', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15369505007'), (select max(id) from auto where license_plate_no = '京A905J2'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15369505007'), p.auto = (select max(id) from auto where license_plate_no ='京A905J2') where  p.id = 281791 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15369505007'), i.auto = (select max(id) from auto where license_plate_no ='京A905J2')  where p.obj_id = i.quote_record and  p.id = 281791 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15369505007'), i.auto = (select max(id) from auto where license_plate_no ='京A905J2')  where p.obj_id = i.quote_record and p.id =  281791 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15369505007'), qr.auto = (select max(id) from auto where license_plate_no = '京A905J2') where p.obj_id = qr.id and p.id = 281791 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15369505007') where pay.purchase_order = p.id and p.id = 281791 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18727161230', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('FF6H01039', '李红新', 'LVVDB11B86D167876', '京DM6303', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18727161230'), (select max(id) from auto where license_plate_no = '京DM6303'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18727161230'), p.auto = (select max(id) from auto where license_plate_no ='京DM6303') where  p.id = 281792 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18727161230'), i.auto = (select max(id) from auto where license_plate_no ='京DM6303')  where p.obj_id = i.quote_record and  p.id = 281792 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18727161230'), i.auto = (select max(id) from auto where license_plate_no ='京DM6303')  where p.obj_id = i.quote_record and p.id =  281792 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18727161230'), qr.auto = (select max(id) from auto where license_plate_no = '京DM6303') where p.obj_id = qr.id and p.id = 281792 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18727161230') where pay.purchase_order = p.id and p.id = 281792 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15636414452', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('D01450198', '袁乐', 'LZWACAGA9D9000464', '京E53281', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15636414452'), (select max(id) from auto where license_plate_no = '京E53281'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15636414452'), p.auto = (select max(id) from auto where license_plate_no ='京E53281') where  p.id = 281799 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15636414452'), i.auto = (select max(id) from auto where license_plate_no ='京E53281')  where p.obj_id = i.quote_record and  p.id = 281799 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15636414452'), i.auto = (select max(id) from auto where license_plate_no ='京E53281')  where p.obj_id = i.quote_record and p.id =  281799 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15636414452'), qr.auto = (select max(id) from auto where license_plate_no = '京E53281') where p.obj_id = qr.id and p.id = 281799 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15636414452') where pay.purchase_order = p.id and p.id = 281799 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18064950772', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('Q120410354H', '深圳市富润祥光电有限公司', 'LJ11RBAB2C6016297', '粤B0PW05', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18064950772'), (select max(id) from auto where license_plate_no = '粤B0PW05'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18064950772'), p.auto = (select max(id) from auto where license_plate_no ='粤B0PW05') where  p.id = 281810 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18064950772'), i.auto = (select max(id) from auto where license_plate_no ='粤B0PW05')  where p.obj_id = i.quote_record and  p.id = 281810 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18064950772'), i.auto = (select max(id) from auto where license_plate_no ='粤B0PW05')  where p.obj_id = i.quote_record and p.id =  281810 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18064950772'), qr.auto = (select max(id) from auto where license_plate_no = '粤B0PW05') where p.obj_id = qr.id and p.id = 281810 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18064950772') where pay.purchase_order = p.id and p.id = 281810 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15011463170', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('A8GD4290391', '乔雄伟', 'LSJA16E32DG053009', '京JN2119', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15011463170'), (select max(id) from auto where license_plate_no = '京JN2119'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15011463170'), p.auto = (select max(id) from auto where license_plate_no ='京JN2119') where  p.id = 281820 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15011463170'), i.auto = (select max(id) from auto where license_plate_no ='京JN2119')  where p.obj_id = i.quote_record and  p.id = 281820 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15011463170'), i.auto = (select max(id) from auto where license_plate_no ='京JN2119')  where p.obj_id = i.quote_record and p.id =  281820 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15011463170'), qr.auto = (select max(id) from auto where license_plate_no = '京JN2119') where p.obj_id = qr.id and p.id = 281820 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15011463170') where pay.purchase_order = p.id and p.id = 281820 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15359997566', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('D1140693', '李伟焘', 'LSGJA52U9CH306302', '京JL9528', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15359997566'), (select max(id) from auto where license_plate_no = '京JL9528'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15359997566'), p.auto = (select max(id) from auto where license_plate_no ='京JL9528') where  p.id = 281822 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15359997566'), i.auto = (select max(id) from auto where license_plate_no ='京JL9528')  where p.obj_id = i.quote_record and  p.id = 281822 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15359997566'), i.auto = (select max(id) from auto where license_plate_no ='京JL9528')  where p.obj_id = i.quote_record and p.id =  281822 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15359997566'), qr.auto = (select max(id) from auto where license_plate_no = '京JL9528') where p.obj_id = qr.id and p.id = 281822 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15359997566') where pay.purchase_order = p.id and p.id = 281822 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15133082713', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('AWB084074', '吴礼仁', 'LFVBA21J543047420', '沪C111F2', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15133082713'), (select max(id) from auto where license_plate_no = '沪C111F2'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15133082713'), p.auto = (select max(id) from auto where license_plate_no ='沪C111F2') where  p.id = 281840 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15133082713'), i.auto = (select max(id) from auto where license_plate_no ='沪C111F2')  where p.obj_id = i.quote_record and  p.id = 281840 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15133082713'), i.auto = (select max(id) from auto where license_plate_no ='沪C111F2')  where p.obj_id = i.quote_record and p.id =  281840 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15133082713'), qr.auto = (select max(id) from auto where license_plate_no = '沪C111F2') where p.obj_id = qr.id and p.id = 281840 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15133082713') where pay.purchase_order = p.id and p.id = 281840 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15691798486', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('AACC01409', '汪志良', 'LVMZ1A1B6CB040127', '京FJ1889', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15691798486'), (select max(id) from auto where license_plate_no = '京FJ1889'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15691798486'), p.auto = (select max(id) from auto where license_plate_no ='京FJ1889') where  p.id = 281849 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15691798486'), i.auto = (select max(id) from auto where license_plate_no ='京FJ1889')  where p.obj_id = i.quote_record and  p.id = 281849 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15691798486'), i.auto = (select max(id) from auto where license_plate_no ='京FJ1889')  where p.obj_id = i.quote_record and p.id =  281849 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15691798486'), qr.auto = (select max(id) from auto where license_plate_no = '京FJ1889') where p.obj_id = qr.id and p.id = 281849 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15691798486') where pay.purchase_order = p.id and p.id = 281849 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13122084018', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('C05549421', '姚玉彩', 'LZWACAGA2C1084592', '沪CCM713', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13122084018'), (select max(id) from auto where license_plate_no = '沪CCM713'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13122084018'), p.auto = (select max(id) from auto where license_plate_no ='沪CCM713') where  p.id = 281856 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13122084018'), i.auto = (select max(id) from auto where license_plate_no ='沪CCM713')  where p.obj_id = i.quote_record and  p.id = 281856 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13122084018'), i.auto = (select max(id) from auto where license_plate_no ='沪CCM713')  where p.obj_id = i.quote_record and p.id =  281856 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13122084018'), qr.auto = (select max(id) from auto where license_plate_no = '沪CCM713') where p.obj_id = qr.id and p.id = 281856 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13122084018') where pay.purchase_order = p.id and p.id = 281856 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13872049071', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('AWL012679', '新上海国际园艺有限公司', 'LSVCC49F112121996', '沪BT5137', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13872049071'), (select max(id) from auto where license_plate_no = '沪BT5137'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13872049071'), p.auto = (select max(id) from auto where license_plate_no ='沪BT5137') where  p.id = 281857 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13872049071'), i.auto = (select max(id) from auto where license_plate_no ='沪BT5137')  where p.obj_id = i.quote_record and  p.id = 281857 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13872049071'), i.auto = (select max(id) from auto where license_plate_no ='沪BT5137')  where p.obj_id = i.quote_record and p.id =  281857 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13872049071'), qr.auto = (select max(id) from auto where license_plate_no = '沪BT5137') where p.obj_id = qr.id and p.id = 281857 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13872049071') where pay.purchase_order = p.id and p.id = 281857 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15509570198', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('CC120386', '蔡布波', 'LSGJA52U9CS331008', '沪CF8361', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15509570198'), (select max(id) from auto where license_plate_no = '沪CF8361'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15509570198'), p.auto = (select max(id) from auto where license_plate_no ='沪CF8361') where  p.id = 281864 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15509570198'), i.auto = (select max(id) from auto where license_plate_no ='沪CF8361')  where p.obj_id = i.quote_record and  p.id = 281864 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15509570198'), i.auto = (select max(id) from auto where license_plate_no ='沪CF8361')  where p.obj_id = i.quote_record and p.id =  281864 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15509570198'), qr.auto = (select max(id) from auto where license_plate_no = '沪CF8361') where p.obj_id = qr.id and p.id = 281864 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15509570198') where pay.purchase_order = p.id and p.id = 281864 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15251432165', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('C2150545', '张小曼', 'LSGJA52U1CS094983', '京A32M13', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15251432165'), (select max(id) from auto where license_plate_no = '京A32M13'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15251432165'), p.auto = (select max(id) from auto where license_plate_no ='京A32M13') where  p.id = 281867 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15251432165'), i.auto = (select max(id) from auto where license_plate_no ='京A32M13')  where p.obj_id = i.quote_record and  p.id = 281867 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15251432165'), i.auto = (select max(id) from auto where license_plate_no ='京A32M13')  where p.obj_id = i.quote_record and p.id =  281867 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15251432165'), qr.auto = (select max(id) from auto where license_plate_no = '京A32M13') where p.obj_id = qr.id and p.id = 281867 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15251432165') where pay.purchase_order = p.id and p.id = 281867 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15904400155', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('3MZ0543179', '苏州顺昌照明镀膜科技有限公司', 'JTJHW31U372039276', '苏EQW940', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15904400155'), (select max(id) from auto where license_plate_no = '苏EQW940'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15904400155'), p.auto = (select max(id) from auto where license_plate_no ='苏EQW940') where  p.id = 281868 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15904400155'), i.auto = (select max(id) from auto where license_plate_no ='苏EQW940')  where p.obj_id = i.quote_record and  p.id = 281868 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15904400155'), i.auto = (select max(id) from auto where license_plate_no ='苏EQW940')  where p.obj_id = i.quote_record and p.id =  281868 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15904400155'), qr.auto = (select max(id) from auto where license_plate_no = '苏EQW940') where p.obj_id = qr.id and p.id = 281868 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15904400155') where pay.purchase_order = p.id and p.id = 281868 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15247238908', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('6001341', '张建峰', 'LJNMDV1EXAN001913', '京A3NG68', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15247238908'), (select max(id) from auto where license_plate_no = '京A3NG68'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15247238908'), p.auto = (select max(id) from auto where license_plate_no ='京A3NG68') where  p.id = 281870 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15247238908'), i.auto = (select max(id) from auto where license_plate_no ='京A3NG68')  where p.obj_id = i.quote_record and  p.id = 281870 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15247238908'), i.auto = (select max(id) from auto where license_plate_no ='京A3NG68')  where p.obj_id = i.quote_record and p.id =  281870 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15247238908'), qr.auto = (select max(id) from auto where license_plate_no = '京A3NG68') where p.obj_id = qr.id and p.id = 281870 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15247238908') where pay.purchase_order = p.id and p.id = 281870 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15001927298', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('20B20A', '深圳市星益达科技有限公司', 'WBAWX3108E0G36713', '粤BN44D8', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15001927298'), (select max(id) from auto where license_plate_no = '粤BN44D8'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15001927298'), p.auto = (select max(id) from auto where license_plate_no ='粤BN44D8') where  p.id = 281873 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15001927298'), i.auto = (select max(id) from auto where license_plate_no ='粤BN44D8')  where p.obj_id = i.quote_record and  p.id = 281873 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15001927298'), i.auto = (select max(id) from auto where license_plate_no ='粤BN44D8')  where p.obj_id = i.quote_record and p.id =  281873 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15001927298'), qr.auto = (select max(id) from auto where license_plate_no = '粤BN44D8') where p.obj_id = qr.id and p.id = 281873 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15001927298') where pay.purchase_order = p.id and p.id = 281873 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18982892560', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('01747982', '上海雅峰物流有限公司', 'LFWABRJM5AAC06194', '沪BD4709', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18982892560'), (select max(id) from auto where license_plate_no = '沪BD4709'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18982892560'), p.auto = (select max(id) from auto where license_plate_no ='沪BD4709') where  p.id = 281882 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18982892560'), i.auto = (select max(id) from auto where license_plate_no ='沪BD4709')  where p.obj_id = i.quote_record and  p.id = 281882 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18982892560'), i.auto = (select max(id) from auto where license_plate_no ='沪BD4709')  where p.obj_id = i.quote_record and p.id =  281882 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18982892560'), qr.auto = (select max(id) from auto where license_plate_no = '沪BD4709') where p.obj_id = qr.id and p.id = 281882 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18982892560') where pay.purchase_order = p.id and p.id = 281882 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15705120667', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('C6NK04941', '孙永红', 'LJU8824S4CS027406', '京EZ2020', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15705120667'), (select max(id) from auto where license_plate_no = '京EZ2020'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15705120667'), p.auto = (select max(id) from auto where license_plate_no ='京EZ2020') where  p.id = 281888 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15705120667'), i.auto = (select max(id) from auto where license_plate_no ='京EZ2020')  where p.obj_id = i.quote_record and  p.id = 281888 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15705120667'), i.auto = (select max(id) from auto where license_plate_no ='京EZ2020')  where p.obj_id = i.quote_record and p.id =  281888 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15705120667'), qr.auto = (select max(id) from auto where license_plate_no = '京EZ2020') where p.obj_id = qr.id and p.id = 281888 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15705120667') where pay.purchase_order = p.id and p.id = 281888 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15746081287', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('9508611_HN3K', '苏州市电讯工程有限公司', 'LKHGF1AH49AC37897', '苏E2977X', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15746081287'), (select max(id) from auto where license_plate_no = '苏E2977X'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15746081287'), p.auto = (select max(id) from auto where license_plate_no ='苏E2977X') where  p.id = 281906 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15746081287'), i.auto = (select max(id) from auto where license_plate_no ='苏E2977X')  where p.obj_id = i.quote_record and  p.id = 281906 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15746081287'), i.auto = (select max(id) from auto where license_plate_no ='苏E2977X')  where p.obj_id = i.quote_record and p.id =  281906 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15746081287'), qr.auto = (select max(id) from auto where license_plate_no = '苏E2977X') where p.obj_id = qr.id and p.id = 281906 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15746081287') where pay.purchase_order = p.id and p.id = 281906 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15881743510', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('080075', '天华化工机械及自动化研究设计院有限公司苏州研究所', 'LCR6U51428L065194', '苏EQ6X06', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15881743510'), (select max(id) from auto where license_plate_no = '苏EQ6X06'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15881743510'), p.auto = (select max(id) from auto where license_plate_no ='苏EQ6X06') where  p.id = 281908 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15881743510'), i.auto = (select max(id) from auto where license_plate_no ='苏EQ6X06')  where p.obj_id = i.quote_record and  p.id = 281908 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15881743510'), i.auto = (select max(id) from auto where license_plate_no ='苏EQ6X06')  where p.obj_id = i.quote_record and p.id =  281908 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15881743510'), qr.auto = (select max(id) from auto where license_plate_no = '苏EQ6X06') where p.obj_id = qr.id and p.id = 281908 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15881743510') where pay.purchase_order = p.id and p.id = 281908 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13903904960', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('EW107812', '郭毅', 'LBECFAHC5EZ063692', '京A696VR', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13903904960'), (select max(id) from auto where license_plate_no = '京A696VR'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13903904960'), p.auto = (select max(id) from auto where license_plate_no ='京A696VR') where  p.id = 281910 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13903904960'), i.auto = (select max(id) from auto where license_plate_no ='京A696VR')  where p.obj_id = i.quote_record and  p.id = 281910 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13903904960'), i.auto = (select max(id) from auto where license_plate_no ='京A696VR')  where p.obj_id = i.quote_record and p.id =  281910 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13903904960'), qr.auto = (select max(id) from auto where license_plate_no = '京A696VR') where p.obj_id = qr.id and p.id = 281910 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13903904960') where pay.purchase_order = p.id and p.id = 281910 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15762836652', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('51523106', '刘应宝', 'LFNA4NB989HA34022', '京AVE269', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15762836652'), (select max(id) from auto where license_plate_no = '京AVE269'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15762836652'), p.auto = (select max(id) from auto where license_plate_no ='京AVE269') where  p.id = 281911 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15762836652'), i.auto = (select max(id) from auto where license_plate_no ='京AVE269')  where p.obj_id = i.quote_record and  p.id = 281911 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15762836652'), i.auto = (select max(id) from auto where license_plate_no ='京AVE269')  where p.obj_id = i.quote_record and p.id =  281911 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15762836652'), qr.auto = (select max(id) from auto where license_plate_no = '京AVE269') where p.obj_id = qr.id and p.id = 281911 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15762836652') where pay.purchase_order = p.id and p.id = 281911 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13994251265', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('B2115652', '庞俊虎', 'LZ0BFPD46C1036245', '京D82773', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13994251265'), (select max(id) from auto where license_plate_no = '京D82773'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13994251265'), p.auto = (select max(id) from auto where license_plate_no ='京D82773') where  p.id = 281912 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13994251265'), i.auto = (select max(id) from auto where license_plate_no ='京D82773')  where p.obj_id = i.quote_record and  p.id = 281912 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13994251265'), i.auto = (select max(id) from auto where license_plate_no ='京D82773')  where p.obj_id = i.quote_record and p.id =  281912 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13994251265'), qr.auto = (select max(id) from auto where license_plate_no = '京D82773') where p.obj_id = qr.id and p.id = 281912 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13994251265') where pay.purchase_order = p.id and p.id = 281912 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18167265532', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('76046042', '操坛生', 'LJXBMCHCX7T060780', '沪C38078', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18167265532'), (select max(id) from auto where license_plate_no = '沪C38078'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18167265532'), p.auto = (select max(id) from auto where license_plate_no ='沪C38078') where  p.id = 281913 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18167265532'), i.auto = (select max(id) from auto where license_plate_no ='沪C38078')  where p.obj_id = i.quote_record and  p.id = 281913 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18167265532'), i.auto = (select max(id) from auto where license_plate_no ='沪C38078')  where p.obj_id = i.quote_record and p.id =  281913 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18167265532'), qr.auto = (select max(id) from auto where license_plate_no = '沪C38078') where p.obj_id = qr.id and p.id = 281913 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18167265532') where pay.purchase_order = p.id and p.id = 281913 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13725917110', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('1305018769', '周光跃', 'LGWEF4A5XDF239779', '京A790GH', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13725917110'), (select max(id) from auto where license_plate_no = '京A790GH'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13725917110'), p.auto = (select max(id) from auto where license_plate_no ='京A790GH') where  p.id = 281915 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13725917110'), i.auto = (select max(id) from auto where license_plate_no ='京A790GH')  where p.obj_id = i.quote_record and  p.id = 281915 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13725917110'), i.auto = (select max(id) from auto where license_plate_no ='京A790GH')  where p.obj_id = i.quote_record and p.id =  281915 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13725917110'), qr.auto = (select max(id) from auto where license_plate_no = '京A790GH') where p.obj_id = qr.id and p.id = 281915 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13725917110') where pay.purchase_order = p.id and p.id = 281915 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13762706999', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('032361', '张新员', 'LSVNJ49J672067476', '沪CG3399', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13762706999'), (select max(id) from auto where license_plate_no = '沪CG3399'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13762706999'), p.auto = (select max(id) from auto where license_plate_no ='沪CG3399') where  p.id = 281916 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13762706999'), i.auto = (select max(id) from auto where license_plate_no ='沪CG3399')  where p.obj_id = i.quote_record and  p.id = 281916 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13762706999'), i.auto = (select max(id) from auto where license_plate_no ='沪CG3399')  where p.obj_id = i.quote_record and p.id =  281916 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13762706999'), qr.auto = (select max(id) from auto where license_plate_no = '沪CG3399') where p.obj_id = qr.id and p.id = 281916 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13762706999') where pay.purchase_order = p.id and p.id = 281916 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15956208796', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('UBC0521187', '徐全民', 'LZWCBAGA3B7203564', '京DG3231', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15956208796'), (select max(id) from auto where license_plate_no = '京DG3231'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15956208796'), p.auto = (select max(id) from auto where license_plate_no ='京DG3231') where  p.id = 281917 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15956208796'), i.auto = (select max(id) from auto where license_plate_no ='京DG3231')  where p.obj_id = i.quote_record and  p.id = 281917 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15956208796'), i.auto = (select max(id) from auto where license_plate_no ='京DG3231')  where p.obj_id = i.quote_record and p.id =  281917 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15956208796'), qr.auto = (select max(id) from auto where license_plate_no = '京DG3231') where p.obj_id = qr.id and p.id = 281917 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15956208796') where pay.purchase_order = p.id and p.id = 281917 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13087591868', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('12121083', '深圳市国通长达优速递有限公司', 'LEFYEDR56DHN12364', '粤BT5956', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13087591868'), (select max(id) from auto where license_plate_no = '粤BT5956'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13087591868'), p.auto = (select max(id) from auto where license_plate_no ='粤BT5956') where  p.id = 281920 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13087591868'), i.auto = (select max(id) from auto where license_plate_no ='粤BT5956')  where p.obj_id = i.quote_record and  p.id = 281920 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13087591868'), i.auto = (select max(id) from auto where license_plate_no ='粤BT5956')  where p.obj_id = i.quote_record and p.id =  281920 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13087591868'), qr.auto = (select max(id) from auto where license_plate_no = '粤BT5956') where p.obj_id = qr.id and p.id = 281920 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13087591868') where pay.purchase_order = p.id and p.id = 281920 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18993161007', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('D0001215', '姚志英', 'LJ8A2A5C5D0001025', '京CS2939', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18993161007'), (select max(id) from auto where license_plate_no = '京CS2939'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18993161007'), p.auto = (select max(id) from auto where license_plate_no ='京CS2939') where  p.id = 281921 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18993161007'), i.auto = (select max(id) from auto where license_plate_no ='京CS2939')  where p.obj_id = i.quote_record and  p.id = 281921 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18993161007'), i.auto = (select max(id) from auto where license_plate_no ='京CS2939')  where p.obj_id = i.quote_record and p.id =  281921 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18993161007'), qr.auto = (select max(id) from auto where license_plate_no = '京CS2939') where p.obj_id = qr.id and p.id = 281921 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18993161007') where pay.purchase_order = p.id and p.id = 281921 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13039230893', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('J4108704456', '上海途漫商贸有限公司', 'LS3T1CF1170202597', '沪BB9126', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13039230893'), (select max(id) from auto where license_plate_no = '沪BB9126'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13039230893'), p.auto = (select max(id) from auto where license_plate_no ='沪BB9126') where  p.id = 281922 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13039230893'), i.auto = (select max(id) from auto where license_plate_no ='沪BB9126')  where p.obj_id = i.quote_record and  p.id = 281922 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13039230893'), i.auto = (select max(id) from auto where license_plate_no ='沪BB9126')  where p.obj_id = i.quote_record and p.id =  281922 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13039230893'), qr.auto = (select max(id) from auto where license_plate_no = '沪BB9126') where p.obj_id = qr.id and p.id = 281922 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13039230893') where pay.purchase_order = p.id and p.id = 281922 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13957859058', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('051036', '上海医药工业有限公司', 'LSYAAAAA9AK135112', '沪KT5237', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13957859058'), (select max(id) from auto where license_plate_no = '沪KT5237'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13957859058'), p.auto = (select max(id) from auto where license_plate_no ='沪KT5237') where  p.id = 281923 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13957859058'), i.auto = (select max(id) from auto where license_plate_no ='沪KT5237')  where p.obj_id = i.quote_record and  p.id = 281923 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13957859058'), i.auto = (select max(id) from auto where license_plate_no ='沪KT5237')  where p.obj_id = i.quote_record and p.id =  281923 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13957859058'), qr.auto = (select max(id) from auto where license_plate_no = '沪KT5237') where p.obj_id = qr.id and p.id = 281923 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13957859058') where pay.purchase_order = p.id and p.id = 281923 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15019036430', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('037002', '深圳市威勒达科技开发有限公司', 'LSYBCAAA9AK047739', '粤B541M3', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15019036430'), (select max(id) from auto where license_plate_no = '粤B541M3'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15019036430'), p.auto = (select max(id) from auto where license_plate_no ='粤B541M3') where  p.id = 281924 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15019036430'), i.auto = (select max(id) from auto where license_plate_no ='粤B541M3')  where p.obj_id = i.quote_record and  p.id = 281924 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15019036430'), i.auto = (select max(id) from auto where license_plate_no ='粤B541M3')  where p.obj_id = i.quote_record and p.id =  281924 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15019036430'), qr.auto = (select max(id) from auto where license_plate_no = '粤B541M3') where p.obj_id = qr.id and p.id = 281924 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15019036430') where pay.purchase_order = p.id and p.id = 281924 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18152276893', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('BPL002381', '冯彪', 'LSVLD41T752193936', '沪CBS431', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18152276893'), (select max(id) from auto where license_plate_no = '沪CBS431'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18152276893'), p.auto = (select max(id) from auto where license_plate_no ='沪CBS431') where  p.id = 281925 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18152276893'), i.auto = (select max(id) from auto where license_plate_no ='沪CBS431')  where p.obj_id = i.quote_record and  p.id = 281925 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18152276893'), i.auto = (select max(id) from auto where license_plate_no ='沪CBS431')  where p.obj_id = i.quote_record and p.id =  281925 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18152276893'), qr.auto = (select max(id) from auto where license_plate_no = '沪CBS431') where p.obj_id = qr.id and p.id = 281925 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18152276893') where pay.purchase_order = p.id and p.id = 281925 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15062721473', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('AW192331', '宋中华', 'LJDGAA227A0137193', '沪CJZ780', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15062721473'), (select max(id) from auto where license_plate_no = '沪CJZ780'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15062721473'), p.auto = (select max(id) from auto where license_plate_no ='沪CJZ780') where  p.id = 281926 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15062721473'), i.auto = (select max(id) from auto where license_plate_no ='沪CJZ780')  where p.obj_id = i.quote_record and  p.id = 281926 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15062721473'), i.auto = (select max(id) from auto where license_plate_no ='沪CJZ780')  where p.obj_id = i.quote_record and p.id =  281926 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15062721473'), qr.auto = (select max(id) from auto where license_plate_no = '沪CJZ780') where p.obj_id = qr.id and p.id = 281926 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15062721473') where pay.purchase_order = p.id and p.id = 281926 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13425789596', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('4C91A0220', '雒路', 'LGXC16AF590024052', '京A021UN', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13425789596'), (select max(id) from auto where license_plate_no = '京A021UN'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13425789596'), p.auto = (select max(id) from auto where license_plate_no ='京A021UN') where  p.id = 281927 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13425789596'), i.auto = (select max(id) from auto where license_plate_no ='京A021UN')  where p.obj_id = i.quote_record and  p.id = 281927 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13425789596'), i.auto = (select max(id) from auto where license_plate_no ='京A021UN')  where p.obj_id = i.quote_record and p.id =  281927 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13425789596'), qr.auto = (select max(id) from auto where license_plate_no = '京A021UN') where p.obj_id = qr.id and p.id = 281927 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13425789596') where pay.purchase_order = p.id and p.id = 281927 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18621855543', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('ABDJ00743', '王全明', 'LVMZ1A1B3DB080442', '京HC5989', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18621855543'), (select max(id) from auto where license_plate_no = '京HC5989'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18621855543'), p.auto = (select max(id) from auto where license_plate_no ='京HC5989') where  p.id = 281928 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18621855543'), i.auto = (select max(id) from auto where license_plate_no ='京HC5989')  where p.obj_id = i.quote_record and  p.id = 281928 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18621855543'), i.auto = (select max(id) from auto where license_plate_no ='京HC5989')  where p.obj_id = i.quote_record and p.id =  281928 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18621855543'), qr.auto = (select max(id) from auto where license_plate_no = '京HC5989') where p.obj_id = qr.id and p.id = 281928 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18621855543') where pay.purchase_order = p.id and p.id = 281928 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18003633450', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('408881', '深圳市天惠达净化科技有限公司', 'LGWCA2G765A000859', '粤BHH067', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18003633450'), (select max(id) from auto where license_plate_no = '粤BHH067'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18003633450'), p.auto = (select max(id) from auto where license_plate_no ='粤BHH067') where  p.id = 281929 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18003633450'), i.auto = (select max(id) from auto where license_plate_no ='粤BHH067')  where p.obj_id = i.quote_record and  p.id = 281929 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18003633450'), i.auto = (select max(id) from auto where license_plate_no ='粤BHH067')  where p.obj_id = i.quote_record and p.id =  281929 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18003633450'), qr.auto = (select max(id) from auto where license_plate_no = '粤BHH067') where p.obj_id = qr.id and p.id = 281929 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18003633450') where pay.purchase_order = p.id and p.id = 281929 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15911938250', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('A01551018', '张文红', 'LZWACAGA0A4122803', '京JZW899', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15911938250'), (select max(id) from auto where license_plate_no = '京JZW899'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15911938250'), p.auto = (select max(id) from auto where license_plate_no ='京JZW899') where  p.id = 281931 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15911938250'), i.auto = (select max(id) from auto where license_plate_no ='京JZW899')  where p.obj_id = i.quote_record and  p.id = 281931 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15911938250'), i.auto = (select max(id) from auto where license_plate_no ='京JZW899')  where p.obj_id = i.quote_record and p.id =  281931 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15911938250'), qr.auto = (select max(id) from auto where license_plate_no = '京JZW899') where p.obj_id = qr.id and p.id = 281931 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15911938250') where pay.purchase_order = p.id and p.id = 281931 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15089468310', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('09040433', '黄建华', 'LGKH32G7199228051', '京DHF188', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15089468310'), (select max(id) from auto where license_plate_no = '京DHF188'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15089468310'), p.auto = (select max(id) from auto where license_plate_no ='京DHF188') where  p.id = 281938 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15089468310'), i.auto = (select max(id) from auto where license_plate_no ='京DHF188')  where p.obj_id = i.quote_record and  p.id = 281938 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15089468310'), i.auto = (select max(id) from auto where license_plate_no ='京DHF188')  where p.obj_id = i.quote_record and p.id =  281938 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15089468310'), qr.auto = (select max(id) from auto where license_plate_no = '京DHF188') where p.obj_id = qr.id and p.id = 281938 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15089468310') where pay.purchase_order = p.id and p.id = 281938 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13826547947', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('D120121927', '高志荣', 'LGWCA2170CB000257', '京JX6690', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13826547947'), (select max(id) from auto where license_plate_no = '京JX6690'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13826547947'), p.auto = (select max(id) from auto where license_plate_no ='京JX6690') where  p.id = 281943 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13826547947'), i.auto = (select max(id) from auto where license_plate_no ='京JX6690')  where p.obj_id = i.quote_record and  p.id = 281943 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13826547947'), i.auto = (select max(id) from auto where license_plate_no ='京JX6690')  where p.obj_id = i.quote_record and p.id =  281943 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13826547947'), qr.auto = (select max(id) from auto where license_plate_no = '京JX6690') where p.obj_id = qr.id and p.id = 281943 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13826547947') where pay.purchase_order = p.id and p.id = 281943 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13494275850', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('138406318', '中交第一公路勘察设计研究院有限公司', 'LSGUA84B3EE012814', '京A335HW', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13494275850'), (select max(id) from auto where license_plate_no = '京A335HW'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13494275850'), p.auto = (select max(id) from auto where license_plate_no ='京A335HW') where  p.id = 281945 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13494275850'), i.auto = (select max(id) from auto where license_plate_no ='京A335HW')  where p.obj_id = i.quote_record and  p.id = 281945 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13494275850'), i.auto = (select max(id) from auto where license_plate_no ='京A335HW')  where p.obj_id = i.quote_record and p.id =  281945 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13494275850'), qr.auto = (select max(id) from auto where license_plate_no = '京A335HW') where p.obj_id = qr.id and p.id = 281945 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13494275850') where pay.purchase_order = p.id and p.id = 281945 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15977896504', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('045846', '唐永德', 'LSYBCAAA1AK068570', '沪C181U2', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15977896504'), (select max(id) from auto where license_plate_no = '沪C181U2'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15977896504'), p.auto = (select max(id) from auto where license_plate_no ='沪C181U2') where  p.id = 281947 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15977896504'), i.auto = (select max(id) from auto where license_plate_no ='沪C181U2')  where p.obj_id = i.quote_record and  p.id = 281947 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15977896504'), i.auto = (select max(id) from auto where license_plate_no ='沪C181U2')  where p.obj_id = i.quote_record and p.id =  281947 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15977896504'), qr.auto = (select max(id) from auto where license_plate_no = '沪C181U2') where p.obj_id = qr.id and p.id = 281947 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15977896504') where pay.purchase_order = p.id and p.id = 281947 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13915791122', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('C297282', '常熟市佳恒化纤有限公司', 'LVGBE40K87G130013', '苏EW0103', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13915791122'), (select max(id) from auto where license_plate_no = '苏EW0103'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13915791122'), p.auto = (select max(id) from auto where license_plate_no ='苏EW0103') where  p.id = 281956 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13915791122'), i.auto = (select max(id) from auto where license_plate_no ='苏EW0103')  where p.obj_id = i.quote_record and  p.id = 281956 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13915791122'), i.auto = (select max(id) from auto where license_plate_no ='苏EW0103')  where p.obj_id = i.quote_record and p.id =  281956 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13915791122'), qr.auto = (select max(id) from auto where license_plate_no = '苏EW0103') where p.obj_id = qr.id and p.id = 281956 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13915791122') where pay.purchase_order = p.id and p.id = 281956 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15291187378', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('CA11530', '张如意', 'LVSHBFDC8CF271428', '京EX6635', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15291187378'), (select max(id) from auto where license_plate_no = '京EX6635'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15291187378'), p.auto = (select max(id) from auto where license_plate_no ='京EX6635') where  p.id = 281957 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15291187378'), i.auto = (select max(id) from auto where license_plate_no ='京EX6635')  where p.obj_id = i.quote_record and  p.id = 281957 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15291187378'), i.auto = (select max(id) from auto where license_plate_no ='京EX6635')  where p.obj_id = i.quote_record and p.id =  281957 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15291187378'), qr.auto = (select max(id) from auto where license_plate_no = '京EX6635') where p.obj_id = qr.id and p.id = 281957 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15291187378') where pay.purchase_order = p.id and p.id = 281957 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13758507336', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('UBC1621521', '京西华萃路桥工程有限责任公司', 'LZWADAGA3B4594315', '京A442S3', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13758507336'), (select max(id) from auto where license_plate_no = '京A442S3'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13758507336'), p.auto = (select max(id) from auto where license_plate_no ='京A442S3') where  p.id = 281958 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13758507336'), i.auto = (select max(id) from auto where license_plate_no ='京A442S3')  where p.obj_id = i.quote_record and  p.id = 281958 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13758507336'), i.auto = (select max(id) from auto where license_plate_no ='京A442S3')  where p.obj_id = i.quote_record and p.id =  281958 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13758507336'), qr.auto = (select max(id) from auto where license_plate_no = '京A442S3') where p.obj_id = qr.id and p.id = 281958 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13758507336') where pay.purchase_order = p.id and p.id = 281958 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13500885890', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('U86573', '谈佳锋', 'LSVCH6A45DN176879', '沪AEK935', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13500885890'), (select max(id) from auto where license_plate_no = '沪AEK935'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13500885890'), p.auto = (select max(id) from auto where license_plate_no ='沪AEK935') where  p.id = 281969 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13500885890'), i.auto = (select max(id) from auto where license_plate_no ='沪AEK935')  where p.obj_id = i.quote_record and  p.id = 281969 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13500885890'), i.auto = (select max(id) from auto where license_plate_no ='沪AEK935')  where p.obj_id = i.quote_record and p.id =  281969 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13500885890'), qr.auto = (select max(id) from auto where license_plate_no = '沪AEK935') where p.obj_id = qr.id and p.id = 281969 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13500885890') where pay.purchase_order = p.id and p.id = 281969 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18980327219', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('LB862060394', '上海亚达发搅拌设备有限公司', 'LSGWL52D36S115093', '沪E69622', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18980327219'), (select max(id) from auto where license_plate_no = '沪E69622'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18980327219'), p.auto = (select max(id) from auto where license_plate_no ='沪E69622') where  p.id = 281971 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18980327219'), i.auto = (select max(id) from auto where license_plate_no ='沪E69622')  where p.obj_id = i.quote_record and  p.id = 281971 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18980327219'), i.auto = (select max(id) from auto where license_plate_no ='沪E69622')  where p.obj_id = i.quote_record and p.id =  281971 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18980327219'), qr.auto = (select max(id) from auto where license_plate_no = '沪E69622') where p.obj_id = qr.id and p.id = 281971 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18980327219') where pay.purchase_order = p.id and p.id = 281971 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13061706865', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('B22117', '苏州道奇机械设备有限公司', 'LSVAB4BR7EN171580', '苏E5371H', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13061706865'), (select max(id) from auto where license_plate_no = '苏E5371H'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13061706865'), p.auto = (select max(id) from auto where license_plate_no ='苏E5371H') where  p.id = 281973 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13061706865'), i.auto = (select max(id) from auto where license_plate_no ='苏E5371H')  where p.obj_id = i.quote_record and  p.id = 281973 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13061706865'), i.auto = (select max(id) from auto where license_plate_no ='苏E5371H')  where p.obj_id = i.quote_record and p.id =  281973 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13061706865'), qr.auto = (select max(id) from auto where license_plate_no = '苏E5371H') where p.obj_id = qr.id and p.id = 281973 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13061706865') where pay.purchase_order = p.id and p.id = 281973 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13656020339', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('DA4G18D000050', '李晓帆', 'LDNP4LFE570132403', '京CC6016', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13656020339'), (select max(id) from auto where license_plate_no = '京CC6016'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13656020339'), p.auto = (select max(id) from auto where license_plate_no ='京CC6016') where  p.id = 281975 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13656020339'), i.auto = (select max(id) from auto where license_plate_no ='京CC6016')  where p.obj_id = i.quote_record and  p.id = 281975 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13656020339'), i.auto = (select max(id) from auto where license_plate_no ='京CC6016')  where p.obj_id = i.quote_record and p.id =  281975 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13656020339'), qr.auto = (select max(id) from auto where license_plate_no = '京CC6016') where p.obj_id = qr.id and p.id = 281975 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13656020339') where pay.purchase_order = p.id and p.id = 281975 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15853169646', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('A7BB020069', '京西三秦路桥有限责任公司', 'LS4AAB3R0AA515021', '京AVM358', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15853169646'), (select max(id) from auto where license_plate_no = '京AVM358'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15853169646'), p.auto = (select max(id) from auto where license_plate_no ='京AVM358') where  p.id = 281976 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15853169646'), i.auto = (select max(id) from auto where license_plate_no ='京AVM358')  where p.obj_id = i.quote_record and  p.id = 281976 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15853169646'), i.auto = (select max(id) from auto where license_plate_no ='京AVM358')  where p.obj_id = i.quote_record and p.id =  281976 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15853169646'), qr.auto = (select max(id) from auto where license_plate_no = '京AVM358') where p.obj_id = qr.id and p.id = 281976 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15853169646') where pay.purchase_order = p.id and p.id = 281976 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18860879438', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('F1001612', '深圳市安达运输有限公司', 'LJDDAA221F0652393', '粤B0U5G3', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18860879438'), (select max(id) from auto where license_plate_no = '粤B0U5G3'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18860879438'), p.auto = (select max(id) from auto where license_plate_no ='粤B0U5G3') where  p.id = 281978 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18860879438'), i.auto = (select max(id) from auto where license_plate_no ='粤B0U5G3')  where p.obj_id = i.quote_record and  p.id = 281978 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18860879438'), i.auto = (select max(id) from auto where license_plate_no ='粤B0U5G3')  where p.obj_id = i.quote_record and p.id =  281978 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18860879438'), qr.auto = (select max(id) from auto where license_plate_no = '粤B0U5G3') where p.obj_id = qr.id and p.id = 281978 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18860879438') where pay.purchase_order = p.id and p.id = 281978 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13522995862', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('10303887', '深圳市创宝齐化工有限公司', 'LEFADAD141P002331', '粤BU2502', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13522995862'), (select max(id) from auto where license_plate_no = '粤BU2502'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13522995862'), p.auto = (select max(id) from auto where license_plate_no ='粤BU2502') where  p.id = 281980 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13522995862'), i.auto = (select max(id) from auto where license_plate_no ='粤BU2502')  where p.obj_id = i.quote_record and  p.id = 281980 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13522995862'), i.auto = (select max(id) from auto where license_plate_no ='粤BU2502')  where p.obj_id = i.quote_record and p.id =  281980 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13522995862'), qr.auto = (select max(id) from auto where license_plate_no = '粤BU2502') where p.obj_id = qr.id and p.id = 281980 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13522995862') where pay.purchase_order = p.id and p.id = 281980 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15843459484', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('371918', '张庆平', 'LSVDM49F472464456', '沪C9N715', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15843459484'), (select max(id) from auto where license_plate_no = '沪C9N715'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15843459484'), p.auto = (select max(id) from auto where license_plate_no ='沪C9N715') where  p.id = 281982 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15843459484'), i.auto = (select max(id) from auto where license_plate_no ='沪C9N715')  where p.obj_id = i.quote_record and  p.id = 281982 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15843459484'), i.auto = (select max(id) from auto where license_plate_no ='沪C9N715')  where p.obj_id = i.quote_record and p.id =  281982 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15843459484'), qr.auto = (select max(id) from auto where license_plate_no = '沪C9N715') where p.obj_id = qr.id and p.id = 281982 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15843459484') where pay.purchase_order = p.id and p.id = 281982 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18808478212', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('L13A33500522', '王辉', 'LHGGD182562000545', '沪C57T45', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18808478212'), (select max(id) from auto where license_plate_no = '沪C57T45'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18808478212'), p.auto = (select max(id) from auto where license_plate_no ='沪C57T45') where  p.id = 281983 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18808478212'), i.auto = (select max(id) from auto where license_plate_no ='沪C57T45')  where p.obj_id = i.quote_record and  p.id = 281983 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18808478212'), i.auto = (select max(id) from auto where license_plate_no ='沪C57T45')  where p.obj_id = i.quote_record and p.id =  281983 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18808478212'), qr.auto = (select max(id) from auto where license_plate_no = '沪C57T45') where p.obj_id = qr.id and p.id = 281983 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18808478212') where pay.purchase_order = p.id and p.id = 281983 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15292730194', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('FB3QA900145', '上海云金家用电器有限公司苏州分公司', 'LKLSAAS27AB501344', '苏E2ZT08', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15292730194'), (select max(id) from auto where license_plate_no = '苏E2ZT08'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15292730194'), p.auto = (select max(id) from auto where license_plate_no ='苏E2ZT08') where  p.id = 281985 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15292730194'), i.auto = (select max(id) from auto where license_plate_no ='苏E2ZT08')  where p.obj_id = i.quote_record and  p.id = 281985 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15292730194'), i.auto = (select max(id) from auto where license_plate_no ='苏E2ZT08')  where p.obj_id = i.quote_record and p.id =  281985 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15292730194'), qr.auto = (select max(id) from auto where license_plate_no = '苏E2ZT08') where p.obj_id = qr.id and p.id = 281985 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15292730194') where pay.purchase_order = p.id and p.id = 281985 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15782997022', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('005020K', '郑国强', 'LJU8824S79S038585', '京J53807', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15782997022'), (select max(id) from auto where license_plate_no = '京J53807'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15782997022'), p.auto = (select max(id) from auto where license_plate_no ='京J53807') where  p.id = 281987 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15782997022'), i.auto = (select max(id) from auto where license_plate_no ='京J53807')  where p.obj_id = i.quote_record and  p.id = 281987 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15782997022'), i.auto = (select max(id) from auto where license_plate_no ='京J53807')  where p.obj_id = i.quote_record and p.id =  281987 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15782997022'), qr.auto = (select max(id) from auto where license_plate_no = '京J53807') where p.obj_id = qr.id and p.id = 281987 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15782997022') where pay.purchase_order = p.id and p.id = 281987 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15537719051', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('1012544', '深圳市帝力冷冻设备有限公司', 'LHGTF3859D8012545', '粤BK357L', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15537719051'), (select max(id) from auto where license_plate_no = '粤BK357L'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15537719051'), p.auto = (select max(id) from auto where license_plate_no ='粤BK357L') where  p.id = 281988 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15537719051'), i.auto = (select max(id) from auto where license_plate_no ='粤BK357L')  where p.obj_id = i.quote_record and  p.id = 281988 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15537719051'), i.auto = (select max(id) from auto where license_plate_no ='粤BK357L')  where p.obj_id = i.quote_record and p.id =  281988 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15537719051'), qr.auto = (select max(id) from auto where license_plate_no = '粤BK357L') where p.obj_id = qr.id and p.id = 281988 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15537719051') where pay.purchase_order = p.id and p.id = 281988 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15930224911', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('AW132909', '曹全亮', 'LJDGAA220A0098480', '京AYJ505', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15930224911'), (select max(id) from auto where license_plate_no = '京AYJ505'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15930224911'), p.auto = (select max(id) from auto where license_plate_no ='京AYJ505') where  p.id = 281993 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15930224911'), i.auto = (select max(id) from auto where license_plate_no ='京AYJ505')  where p.obj_id = i.quote_record and  p.id = 281993 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15930224911'), i.auto = (select max(id) from auto where license_plate_no ='京AYJ505')  where p.obj_id = i.quote_record and p.id =  281993 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15930224911'), qr.auto = (select max(id) from auto where license_plate_no = '京AYJ505') where p.obj_id = qr.id and p.id = 281993 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15930224911') where pay.purchase_order = p.id and p.id = 281993 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13224586516', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('10B000036-HUB', '海保真', 'LKJHB1AD3DF010012', '京CZ6805', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13224586516'), (select max(id) from auto where license_plate_no = '京CZ6805'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13224586516'), p.auto = (select max(id) from auto where license_plate_no ='京CZ6805') where  p.id = 282011 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13224586516'), i.auto = (select max(id) from auto where license_plate_no ='京CZ6805')  where p.obj_id = i.quote_record and  p.id = 282011 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13224586516'), i.auto = (select max(id) from auto where license_plate_no ='京CZ6805')  where p.obj_id = i.quote_record and p.id =  282011 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13224586516'), qr.auto = (select max(id) from auto where license_plate_no = '京CZ6805') where p.obj_id = qr.id and p.id = 282011 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13224586516') where pay.purchase_order = p.id and p.id = 282011 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18635314920', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('A028536-5', '罗明辉', 'LVFAB2AD8AG037061', '京V33589', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18635314920'), (select max(id) from auto where license_plate_no = '京V33589'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18635314920'), p.auto = (select max(id) from auto where license_plate_no ='京V33589') where  p.id = 282012 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18635314920'), i.auto = (select max(id) from auto where license_plate_no ='京V33589')  where p.obj_id = i.quote_record and  p.id = 282012 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18635314920'), i.auto = (select max(id) from auto where license_plate_no ='京V33589')  where p.obj_id = i.quote_record and p.id =  282012 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18635314920'), qr.auto = (select max(id) from auto where license_plate_no = '京V33589') where p.obj_id = qr.id and p.id = 282012 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18635314920') where pay.purchase_order = p.id and p.id = 282012 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13754138722', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('801258', '留坝县江口中心卫生院', 'LVCA15WA58B002596', '京F73628', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13754138722'), (select max(id) from auto where license_plate_no = '京F73628'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13754138722'), p.auto = (select max(id) from auto where license_plate_no ='京F73628') where  p.id = 282013 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13754138722'), i.auto = (select max(id) from auto where license_plate_no ='京F73628')  where p.obj_id = i.quote_record and  p.id = 282013 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13754138722'), i.auto = (select max(id) from auto where license_plate_no ='京F73628')  where p.obj_id = i.quote_record and p.id =  282013 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13754138722'), qr.auto = (select max(id) from auto where license_plate_no = '京F73628') where p.obj_id = qr.id and p.id = 282013 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13754138722') where pay.purchase_order = p.id and p.id = 282013 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15889065593', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('SLB6257', '曹卫红', 'LTA12H2P3C2021958', '京AQ098P', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15889065593'), (select max(id) from auto where license_plate_no = '京AQ098P'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15889065593'), p.auto = (select max(id) from auto where license_plate_no ='京AQ098P') where  p.id = 282019 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15889065593'), i.auto = (select max(id) from auto where license_plate_no ='京AQ098P')  where p.obj_id = i.quote_record and  p.id = 282019 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15889065593'), i.auto = (select max(id) from auto where license_plate_no ='京AQ098P')  where p.obj_id = i.quote_record and p.id =  282019 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15889065593'), qr.auto = (select max(id) from auto where license_plate_no = '京AQ098P') where p.obj_id = qr.id and p.id = 282019 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15889065593') where pay.purchase_order = p.id and p.id = 282019 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13928913595', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('DA4G18L007641', '董红军', 'LDNB4LAE950080532', '沪C2H405', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13928913595'), (select max(id) from auto where license_plate_no = '沪C2H405'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13928913595'), p.auto = (select max(id) from auto where license_plate_no ='沪C2H405') where  p.id = 282029 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13928913595'), i.auto = (select max(id) from auto where license_plate_no ='沪C2H405')  where p.obj_id = i.quote_record and  p.id = 282029 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13928913595'), i.auto = (select max(id) from auto where license_plate_no ='沪C2H405')  where p.obj_id = i.quote_record and p.id =  282029 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13928913595'), qr.auto = (select max(id) from auto where license_plate_no = '沪C2H405') where p.obj_id = qr.id and p.id = 282029 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13928913595') where pay.purchase_order = p.id and p.id = 282029 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13797385724', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('D11523', '陈本文', 'LSVNV2181E2135732', '京GY6226', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13797385724'), (select max(id) from auto where license_plate_no = '京GY6226'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13797385724'), p.auto = (select max(id) from auto where license_plate_no ='京GY6226') where  p.id = 282031 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13797385724'), i.auto = (select max(id) from auto where license_plate_no ='京GY6226')  where p.obj_id = i.quote_record and  p.id = 282031 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13797385724'), i.auto = (select max(id) from auto where license_plate_no ='京GY6226')  where p.obj_id = i.quote_record and p.id =  282031 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13797385724'), qr.auto = (select max(id) from auto where license_plate_no = '京GY6226') where p.obj_id = qr.id and p.id = 282031 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13797385724') where pay.purchase_order = p.id and p.id = 282031 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18595391896', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('008823', '上海华东木器厂', 'LSYBCAAA2FK006408', '沪AUT992', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18595391896'), (select max(id) from auto where license_plate_no = '沪AUT992'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18595391896'), p.auto = (select max(id) from auto where license_plate_no ='沪AUT992') where  p.id = 282035 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18595391896'), i.auto = (select max(id) from auto where license_plate_no ='沪AUT992')  where p.obj_id = i.quote_record and  p.id = 282035 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18595391896'), i.auto = (select max(id) from auto where license_plate_no ='沪AUT992')  where p.obj_id = i.quote_record and p.id =  282035 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18595391896'), qr.auto = (select max(id) from auto where license_plate_no = '沪AUT992') where p.obj_id = qr.id and p.id = 282035 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18595391896') where pay.purchase_order = p.id and p.id = 282035 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18966511136', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('110079347', '刘佳', 'LGXC14AA3A1128689', '京A6SG71', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18966511136'), (select max(id) from auto where license_plate_no = '京A6SG71'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18966511136'), p.auto = (select max(id) from auto where license_plate_no ='京A6SG71') where  p.id = 282048 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18966511136'), i.auto = (select max(id) from auto where license_plate_no ='京A6SG71')  where p.obj_id = i.quote_record and  p.id = 282048 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18966511136'), i.auto = (select max(id) from auto where license_plate_no ='京A6SG71')  where p.obj_id = i.quote_record and p.id =  282048 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18966511136'), qr.auto = (select max(id) from auto where license_plate_no = '京A6SG71') where p.obj_id = qr.id and p.id = 282048 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18966511136') where pay.purchase_order = p.id and p.id = 282048 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18846860380', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('4G63S4MSCD1639', '史丹利东铁（上海）五金有限公司', 'LDNL70YH450117612', '沪BP2549', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18846860380'), (select max(id) from auto where license_plate_no = '沪BP2549'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18846860380'), p.auto = (select max(id) from auto where license_plate_no ='沪BP2549') where  p.id = 282049 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18846860380'), i.auto = (select max(id) from auto where license_plate_no ='沪BP2549')  where p.obj_id = i.quote_record and  p.id = 282049 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18846860380'), i.auto = (select max(id) from auto where license_plate_no ='沪BP2549')  where p.obj_id = i.quote_record and p.id =  282049 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18846860380'), qr.auto = (select max(id) from auto where license_plate_no = '沪BP2549') where p.obj_id = qr.id and p.id = 282049 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18846860380') where pay.purchase_order = p.id and p.id = 282049 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18134849947', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('6066155', '张天权', 'LDC933L3580843379', '京G81966', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18134849947'), (select max(id) from auto where license_plate_no = '京G81966'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18134849947'), p.auto = (select max(id) from auto where license_plate_no ='京G81966') where  p.id = 282051 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18134849947'), i.auto = (select max(id) from auto where license_plate_no ='京G81966')  where p.obj_id = i.quote_record and  p.id = 282051 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18134849947'), i.auto = (select max(id) from auto where license_plate_no ='京G81966')  where p.obj_id = i.quote_record and p.id =  282051 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18134849947'), qr.auto = (select max(id) from auto where license_plate_no = '京G81966') where p.obj_id = qr.id and p.id = 282051 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18134849947') where pay.purchase_order = p.id and p.id = 282051 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13663685776', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('93013820', '欣龙昌电子科技（深圳）有限公司', 'LEFYFCG289HN08226', '粤B26Y28', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13663685776'), (select max(id) from auto where license_plate_no = '粤B26Y28'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13663685776'), p.auto = (select max(id) from auto where license_plate_no ='粤B26Y28') where  p.id = 282052 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13663685776'), i.auto = (select max(id) from auto where license_plate_no ='粤B26Y28')  where p.obj_id = i.quote_record and  p.id = 282052 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13663685776'), i.auto = (select max(id) from auto where license_plate_no ='粤B26Y28')  where p.obj_id = i.quote_record and p.id =  282052 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13663685776'), qr.auto = (select max(id) from auto where license_plate_no = '粤B26Y28') where p.obj_id = qr.id and p.id = 282052 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13663685776') where pay.purchase_order = p.id and p.id = 282052 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18548571613', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('8C41311266', '白林峰', 'LZWACAGA0C4182194', '京K6637D', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18548571613'), (select max(id) from auto where license_plate_no = '京K6637D'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18548571613'), p.auto = (select max(id) from auto where license_plate_no ='京K6637D') where  p.id = 282053 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18548571613'), i.auto = (select max(id) from auto where license_plate_no ='京K6637D')  where p.obj_id = i.quote_record and  p.id = 282053 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18548571613'), i.auto = (select max(id) from auto where license_plate_no ='京K6637D')  where p.obj_id = i.quote_record and p.id =  282053 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18548571613'), qr.auto = (select max(id) from auto where license_plate_no = '京K6637D') where p.obj_id = qr.id and p.id = 282053 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18548571613') where pay.purchase_order = p.id and p.id = 282053 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15937099070', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('C28073', '岳媛', 'LSVNU4187E2203188', '京A9CD65', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15937099070'), (select max(id) from auto where license_plate_no = '京A9CD65'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15937099070'), p.auto = (select max(id) from auto where license_plate_no ='京A9CD65') where  p.id = 282054 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15937099070'), i.auto = (select max(id) from auto where license_plate_no ='京A9CD65')  where p.obj_id = i.quote_record and  p.id = 282054 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15937099070'), i.auto = (select max(id) from auto where license_plate_no ='京A9CD65')  where p.obj_id = i.quote_record and p.id =  282054 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15937099070'), qr.auto = (select max(id) from auto where license_plate_no = '京A9CD65') where p.obj_id = qr.id and p.id = 282054 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15937099070') where pay.purchase_order = p.id and p.id = 282054 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15247780951', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('90046933', '李浩', 'LJ11KBBC4E6016848', '京CZ6828', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15247780951'), (select max(id) from auto where license_plate_no = '京CZ6828'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15247780951'), p.auto = (select max(id) from auto where license_plate_no ='京CZ6828') where  p.id = 282056 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15247780951'), i.auto = (select max(id) from auto where license_plate_no ='京CZ6828')  where p.obj_id = i.quote_record and  p.id = 282056 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15247780951'), i.auto = (select max(id) from auto where license_plate_no ='京CZ6828')  where p.obj_id = i.quote_record and p.id =  282056 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15247780951'), qr.auto = (select max(id) from auto where license_plate_no = '京CZ6828') where p.obj_id = qr.id and p.id = 282056 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15247780951') where pay.purchase_order = p.id and p.id = 282056 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18171408663', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('A010005919', '深圳市力通宏实业发展有限公司', 'LSJW16N357J016582', '粤BXM591', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18171408663'), (select max(id) from auto where license_plate_no = '粤BXM591'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18171408663'), p.auto = (select max(id) from auto where license_plate_no ='粤BXM591') where  p.id = 282060 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18171408663'), i.auto = (select max(id) from auto where license_plate_no ='粤BXM591')  where p.obj_id = i.quote_record and  p.id = 282060 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18171408663'), i.auto = (select max(id) from auto where license_plate_no ='粤BXM591')  where p.obj_id = i.quote_record and p.id =  282060 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18171408663'), qr.auto = (select max(id) from auto where license_plate_no = '粤BXM591') where p.obj_id = qr.id and p.id = 282060 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18171408663') where pay.purchase_order = p.id and p.id = 282060 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15982044079', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('J1AE1B60006', '舒贵芝', 'LS3T1CF32C0100043', '京AM9168', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15982044079'), (select max(id) from auto where license_plate_no = '京AM9168'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15982044079'), p.auto = (select max(id) from auto where license_plate_no ='京AM9168') where  p.id = 282069 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15982044079'), i.auto = (select max(id) from auto where license_plate_no ='京AM9168')  where p.obj_id = i.quote_record and  p.id = 282069 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15982044079'), i.auto = (select max(id) from auto where license_plate_no ='京AM9168')  where p.obj_id = i.quote_record and p.id =  282069 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15982044079'), qr.auto = (select max(id) from auto where license_plate_no = '京AM9168') where p.obj_id = qr.id and p.id = 282069 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15982044079') where pay.purchase_order = p.id and p.id = 282069 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15761955524', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('C240874', '无锡大盛基础工程有限公司昆山分公司', 'LFMBD84B780082194', '苏EN8800', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15761955524'), (select max(id) from auto where license_plate_no = '苏EN8800'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15761955524'), p.auto = (select max(id) from auto where license_plate_no ='苏EN8800') where  p.id = 282071 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15761955524'), i.auto = (select max(id) from auto where license_plate_no ='苏EN8800')  where p.obj_id = i.quote_record and  p.id = 282071 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15761955524'), i.auto = (select max(id) from auto where license_plate_no ='苏EN8800')  where p.obj_id = i.quote_record and p.id =  282071 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15761955524'), qr.auto = (select max(id) from auto where license_plate_no = '苏EN8800') where p.obj_id = qr.id and p.id = 282071 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15761955524') where pay.purchase_order = p.id and p.id = 282071 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15617945197', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('T85615', '延长县人民法院', 'LSVCH2A46DN050085', '京JM6322', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15617945197'), (select max(id) from auto where license_plate_no = '京JM6322'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15617945197'), p.auto = (select max(id) from auto where license_plate_no ='京JM6322') where  p.id = 282073 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15617945197'), i.auto = (select max(id) from auto where license_plate_no ='京JM6322')  where p.obj_id = i.quote_record and  p.id = 282073 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15617945197'), i.auto = (select max(id) from auto where license_plate_no ='京JM6322')  where p.obj_id = i.quote_record and p.id =  282073 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15617945197'), qr.auto = (select max(id) from auto where license_plate_no = '京JM6322') where p.obj_id = qr.id and p.id = 282073 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15617945197') where pay.purchase_order = p.id and p.id = 282073 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18594444347', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('5011918', '深圳市迅达汽车运输有限公司', 'LJDDAA225B0475759', '粤BL4F81', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18594444347'), (select max(id) from auto where license_plate_no = '粤BL4F81'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18594444347'), p.auto = (select max(id) from auto where license_plate_no ='粤BL4F81') where  p.id = 282074 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18594444347'), i.auto = (select max(id) from auto where license_plate_no ='粤BL4F81')  where p.obj_id = i.quote_record and  p.id = 282074 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18594444347'), i.auto = (select max(id) from auto where license_plate_no ='粤BL4F81')  where p.obj_id = i.quote_record and p.id =  282074 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18594444347'), qr.auto = (select max(id) from auto where license_plate_no = '粤BL4F81') where p.obj_id = qr.id and p.id = 282074 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18594444347') where pay.purchase_order = p.id and p.id = 282074 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15682311650', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('12591240', '张广军', 'LGK022K66C9427473', '京AR218T', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15682311650'), (select max(id) from auto where license_plate_no = '京AR218T'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15682311650'), p.auto = (select max(id) from auto where license_plate_no ='京AR218T') where  p.id = 282075 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15682311650'), i.auto = (select max(id) from auto where license_plate_no ='京AR218T')  where p.obj_id = i.quote_record and  p.id = 282075 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15682311650'), i.auto = (select max(id) from auto where license_plate_no ='京AR218T')  where p.obj_id = i.quote_record and p.id =  282075 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15682311650'), qr.auto = (select max(id) from auto where license_plate_no = '京AR218T') where p.obj_id = qr.id and p.id = 282075 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15682311650') where pay.purchase_order = p.id and p.id = 282075 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15515763378', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('94CN013619', '陈明清', 'LS4AAB3RX9A044359', '京FH5083', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15515763378'), (select max(id) from auto where license_plate_no = '京FH5083'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15515763378'), p.auto = (select max(id) from auto where license_plate_no ='京FH5083') where  p.id = 282082 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15515763378'), i.auto = (select max(id) from auto where license_plate_no ='京FH5083')  where p.obj_id = i.quote_record and  p.id = 282082 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15515763378'), i.auto = (select max(id) from auto where license_plate_no ='京FH5083')  where p.obj_id = i.quote_record and p.id =  282082 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15515763378'), qr.auto = (select max(id) from auto where license_plate_no = '京FH5083') where p.obj_id = qr.id and p.id = 282082 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15515763378') where pay.purchase_order = p.id and p.id = 282082 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15555447007', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('B5066422', '苏州市相城区黄桥木巷电讯配件有限公司', 'LEFYFCG24BHN28902', '苏E7KQ32', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15555447007'), (select max(id) from auto where license_plate_no = '苏E7KQ32'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15555447007'), p.auto = (select max(id) from auto where license_plate_no ='苏E7KQ32') where  p.id = 282088 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15555447007'), i.auto = (select max(id) from auto where license_plate_no ='苏E7KQ32')  where p.obj_id = i.quote_record and  p.id = 282088 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15555447007'), i.auto = (select max(id) from auto where license_plate_no ='苏E7KQ32')  where p.obj_id = i.quote_record and p.id =  282088 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15555447007'), qr.auto = (select max(id) from auto where license_plate_no = '苏E7KQ32') where p.obj_id = qr.id and p.id = 282088 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15555447007') where pay.purchase_order = p.id and p.id = 282088 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18563697538', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('630412', '深圳市风之旅运输有限公司', 'LSGUA83B1BE081210', '粤BR1W99', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18563697538'), (select max(id) from auto where license_plate_no = '粤BR1W99'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18563697538'), p.auto = (select max(id) from auto where license_plate_no ='粤BR1W99') where  p.id = 282089 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18563697538'), i.auto = (select max(id) from auto where license_plate_no ='粤BR1W99')  where p.obj_id = i.quote_record and  p.id = 282089 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18563697538'), i.auto = (select max(id) from auto where license_plate_no ='粤BR1W99')  where p.obj_id = i.quote_record and p.id =  282089 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18563697538'), qr.auto = (select max(id) from auto where license_plate_no = '粤BR1W99') where p.obj_id = qr.id and p.id = 282089 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18563697538') where pay.purchase_order = p.id and p.id = 282089 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13536697780', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('E12J2706512', '深圳市杰通物流有限公司', 'LJ11R9DD2A8008918', '粤BU0705', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13536697780'), (select max(id) from auto where license_plate_no = '粤BU0705'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13536697780'), p.auto = (select max(id) from auto where license_plate_no ='粤BU0705') where  p.id = 282091 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13536697780'), i.auto = (select max(id) from auto where license_plate_no ='粤BU0705')  where p.obj_id = i.quote_record and  p.id = 282091 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13536697780'), i.auto = (select max(id) from auto where license_plate_no ='粤BU0705')  where p.obj_id = i.quote_record and p.id =  282091 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13536697780'), qr.auto = (select max(id) from auto where license_plate_no = '粤BU0705') where p.obj_id = qr.id and p.id = 282091 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13536697780') where pay.purchase_order = p.id and p.id = 282091 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13693669851', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('L0120706114', '左林', 'LSGSJ82N02S183490', '沪CEN591', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13693669851'), (select max(id) from auto where license_plate_no = '沪CEN591'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13693669851'), p.auto = (select max(id) from auto where license_plate_no ='沪CEN591') where  p.id = 282100 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13693669851'), i.auto = (select max(id) from auto where license_plate_no ='沪CEN591')  where p.obj_id = i.quote_record and  p.id = 282100 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13693669851'), i.auto = (select max(id) from auto where license_plate_no ='沪CEN591')  where p.obj_id = i.quote_record and p.id =  282100 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13693669851'), qr.auto = (select max(id) from auto where license_plate_no = '沪CEN591') where p.obj_id = qr.id and p.id = 282100 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13693669851') where pay.purchase_order = p.id and p.id = 282100 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18770087504', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('AB529911', '张家港市朝阳工业设备制造有限公司', 'LBEHDAFB2AY477664', '苏EF560Z', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18770087504'), (select max(id) from auto where license_plate_no = '苏EF560Z'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18770087504'), p.auto = (select max(id) from auto where license_plate_no ='苏EF560Z') where  p.id = 282109 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18770087504'), i.auto = (select max(id) from auto where license_plate_no ='苏EF560Z')  where p.obj_id = i.quote_record and  p.id = 282109 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18770087504'), i.auto = (select max(id) from auto where license_plate_no ='苏EF560Z')  where p.obj_id = i.quote_record and p.id =  282109 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18770087504'), qr.auto = (select max(id) from auto where license_plate_no = '苏EF560Z') where p.obj_id = qr.id and p.id = 282109 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18770087504') where pay.purchase_order = p.id and p.id = 282109 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13030673224', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('B04137402', '付国强', 'LZWACAGA1B2054105', '京DF1265', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13030673224'), (select max(id) from auto where license_plate_no = '京DF1265'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13030673224'), p.auto = (select max(id) from auto where license_plate_no ='京DF1265') where  p.id = 282111 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13030673224'), i.auto = (select max(id) from auto where license_plate_no ='京DF1265')  where p.obj_id = i.quote_record and  p.id = 282111 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13030673224'), i.auto = (select max(id) from auto where license_plate_no ='京DF1265')  where p.obj_id = i.quote_record and p.id =  282111 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13030673224'), qr.auto = (select max(id) from auto where license_plate_no = '京DF1265') where p.obj_id = qr.id and p.id = 282111 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13030673224') where pay.purchase_order = p.id and p.id = 282111 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13785664628', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('03004154', '太仓市顺发装潢钣金加工厂', 'LGAG4C1D23A012622', '苏EJ6908', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13785664628'), (select max(id) from auto where license_plate_no = '苏EJ6908'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13785664628'), p.auto = (select max(id) from auto where license_plate_no ='苏EJ6908') where  p.id = 282112 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13785664628'), i.auto = (select max(id) from auto where license_plate_no ='苏EJ6908')  where p.obj_id = i.quote_record and  p.id = 282112 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13785664628'), i.auto = (select max(id) from auto where license_plate_no ='苏EJ6908')  where p.obj_id = i.quote_record and p.id =  282112 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13785664628'), qr.auto = (select max(id) from auto where license_plate_no = '苏EJ6908') where p.obj_id = qr.id and p.id = 282112 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13785664628') where pay.purchase_order = p.id and p.id = 282112 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13218061143', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('N55B30A', '深圳市宝泽投资集团有限公司', 'WBAZV4101DL937598', '粤B5NM95', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13218061143'), (select max(id) from auto where license_plate_no = '粤B5NM95'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13218061143'), p.auto = (select max(id) from auto where license_plate_no ='粤B5NM95') where  p.id = 282113 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13218061143'), i.auto = (select max(id) from auto where license_plate_no ='粤B5NM95')  where p.obj_id = i.quote_record and  p.id = 282113 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13218061143'), i.auto = (select max(id) from auto where license_plate_no ='粤B5NM95')  where p.obj_id = i.quote_record and p.id =  282113 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13218061143'), qr.auto = (select max(id) from auto where license_plate_no = '粤B5NM95') where p.obj_id = qr.id and p.id = 282113 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13218061143') where pay.purchase_order = p.id and p.id = 282113 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13842064296', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('015229', '深圳市荣兴润不锈钢制品有限公司', 'LWLNHR8F3AL036780', '粤B230K5', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13842064296'), (select max(id) from auto where license_plate_no = '粤B230K5'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13842064296'), p.auto = (select max(id) from auto where license_plate_no ='粤B230K5') where  p.id = 282118 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13842064296'), i.auto = (select max(id) from auto where license_plate_no ='粤B230K5')  where p.obj_id = i.quote_record and  p.id = 282118 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13842064296'), i.auto = (select max(id) from auto where license_plate_no ='粤B230K5')  where p.obj_id = i.quote_record and p.id =  282118 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13842064296'), qr.auto = (select max(id) from auto where license_plate_no = '粤B230K5') where p.obj_id = qr.id and p.id = 282118 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13842064296') where pay.purchase_order = p.id and p.id = 282118 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18649512032', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('876381', '深圳市冠通汽车驾驶培训有限公司', 'LFV2A11G9D3321152', '粤B5550学', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18649512032'), (select max(id) from auto where license_plate_no = '粤B5550学'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18649512032'), p.auto = (select max(id) from auto where license_plate_no ='粤B5550学') where  p.id = 282119 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18649512032'), i.auto = (select max(id) from auto where license_plate_no ='粤B5550学')  where p.obj_id = i.quote_record and  p.id = 282119 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18649512032'), i.auto = (select max(id) from auto where license_plate_no ='粤B5550学')  where p.obj_id = i.quote_record and p.id =  282119 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18649512032'), qr.auto = (select max(id) from auto where license_plate_no = '粤B5550学') where p.obj_id = qr.id and p.id = 282119 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18649512032') where pay.purchase_order = p.id and p.id = 282119 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13020245524', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('802313854', '贾利柱', 'LZWACAGA684078137', '京JF7831', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13020245524'), (select max(id) from auto where license_plate_no = '京JF7831'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13020245524'), p.auto = (select max(id) from auto where license_plate_no ='京JF7831') where  p.id = 282120 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13020245524'), i.auto = (select max(id) from auto where license_plate_no ='京JF7831')  where p.obj_id = i.quote_record and  p.id = 282120 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13020245524'), i.auto = (select max(id) from auto where license_plate_no ='京JF7831')  where p.obj_id = i.quote_record and p.id =  282120 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13020245524'), qr.auto = (select max(id) from auto where license_plate_no = '京JF7831') where p.obj_id = qr.id and p.id = 282120 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13020245524') where pay.purchase_order = p.id and p.id = 282120 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15302107054', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('D8JF01484', '丁琰', 'L108DBZ54D2071245', '沪ADX756', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15302107054'), (select max(id) from auto where license_plate_no = '沪ADX756'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15302107054'), p.auto = (select max(id) from auto where license_plate_no ='沪ADX756') where  p.id = 282126 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15302107054'), i.auto = (select max(id) from auto where license_plate_no ='沪ADX756')  where p.obj_id = i.quote_record and  p.id = 282126 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15302107054'), i.auto = (select max(id) from auto where license_plate_no ='沪ADX756')  where p.obj_id = i.quote_record and p.id =  282126 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15302107054'), qr.auto = (select max(id) from auto where license_plate_no = '沪ADX756') where p.obj_id = qr.id and p.id = 282126 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15302107054') where pay.purchase_order = p.id and p.id = 282126 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13607743339', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('10114214', '常熟市皓帝商贸有限责任公司', 'LNYAEDA20AK502275', '苏EE7839', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13607743339'), (select max(id) from auto where license_plate_no = '苏EE7839'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13607743339'), p.auto = (select max(id) from auto where license_plate_no ='苏EE7839') where  p.id = 282133 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13607743339'), i.auto = (select max(id) from auto where license_plate_no ='苏EE7839')  where p.obj_id = i.quote_record and  p.id = 282133 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13607743339'), i.auto = (select max(id) from auto where license_plate_no ='苏EE7839')  where p.obj_id = i.quote_record and p.id =  282133 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13607743339'), qr.auto = (select max(id) from auto where license_plate_no = '苏EE7839') where p.obj_id = qr.id and p.id = 282133 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13607743339') where pay.purchase_order = p.id and p.id = 282133 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13560631228', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('G325046', '深圳市迅达汽车运输有限公司', 'LFMAP22CXE0663244', '粤BN74Z5', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13560631228'), (select max(id) from auto where license_plate_no = '粤BN74Z5'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13560631228'), p.auto = (select max(id) from auto where license_plate_no ='粤BN74Z5') where  p.id = 282136 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13560631228'), i.auto = (select max(id) from auto where license_plate_no ='粤BN74Z5')  where p.obj_id = i.quote_record and  p.id = 282136 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13560631228'), i.auto = (select max(id) from auto where license_plate_no ='粤BN74Z5')  where p.obj_id = i.quote_record and p.id =  282136 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13560631228'), qr.auto = (select max(id) from auto where license_plate_no = '粤BN74Z5') where p.obj_id = qr.id and p.id = 282136 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13560631228') where pay.purchase_order = p.id and p.id = 282136 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15131644083', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('031364V', '李小芹', 'LGBM4AE4XES031820', '京E65160', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15131644083'), (select max(id) from auto where license_plate_no = '京E65160'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15131644083'), p.auto = (select max(id) from auto where license_plate_no ='京E65160') where  p.id = 282137 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15131644083'), i.auto = (select max(id) from auto where license_plate_no ='京E65160')  where p.obj_id = i.quote_record and  p.id = 282137 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15131644083'), i.auto = (select max(id) from auto where license_plate_no ='京E65160')  where p.obj_id = i.quote_record and p.id =  282137 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15131644083'), qr.auto = (select max(id) from auto where license_plate_no = '京E65160') where p.obj_id = qr.id and p.id = 282137 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15131644083') where pay.purchase_order = p.id and p.id = 282137 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18698701741', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('H405398', '深圳市万众联合网络科技有限公司', 'LVGBD54KXEG011279', '粤BH07K8', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18698701741'), (select max(id) from auto where license_plate_no = '粤BH07K8'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18698701741'), p.auto = (select max(id) from auto where license_plate_no ='粤BH07K8') where  p.id = 282138 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18698701741'), i.auto = (select max(id) from auto where license_plate_no ='粤BH07K8')  where p.obj_id = i.quote_record and  p.id = 282138 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18698701741'), i.auto = (select max(id) from auto where license_plate_no ='粤BH07K8')  where p.obj_id = i.quote_record and p.id =  282138 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18698701741'), qr.auto = (select max(id) from auto where license_plate_no = '粤BH07K8') where p.obj_id = qr.id and p.id = 282138 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18698701741') where pay.purchase_order = p.id and p.id = 282138 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13400245776', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('6077510', '张弟', 'LHGCP1681A2077550', '沪KE0256', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13400245776'), (select max(id) from auto where license_plate_no = '沪KE0256'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13400245776'), p.auto = (select max(id) from auto where license_plate_no ='沪KE0256') where  p.id = 282144 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13400245776'), i.auto = (select max(id) from auto where license_plate_no ='沪KE0256')  where p.obj_id = i.quote_record and  p.id = 282144 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13400245776'), i.auto = (select max(id) from auto where license_plate_no ='沪KE0256')  where p.obj_id = i.quote_record and p.id =  282144 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13400245776'), qr.auto = (select max(id) from auto where license_plate_no = '沪KE0256') where p.obj_id = qr.id and p.id = 282144 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13400245776') where pay.purchase_order = p.id and p.id = 282144 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15243839653', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('J42D1706929', '尹亮亮', 'L38CDHVC69A009749', '京EG3902', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15243839653'), (select max(id) from auto where license_plate_no = '京EG3902'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15243839653'), p.auto = (select max(id) from auto where license_plate_no ='京EG3902') where  p.id = 282146 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15243839653'), i.auto = (select max(id) from auto where license_plate_no ='京EG3902')  where p.obj_id = i.quote_record and  p.id = 282146 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15243839653'), i.auto = (select max(id) from auto where license_plate_no ='京EG3902')  where p.obj_id = i.quote_record and p.id =  282146 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15243839653'), qr.auto = (select max(id) from auto where license_plate_no = '京EG3902') where p.obj_id = qr.id and p.id = 282146 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15243839653') where pay.purchase_order = p.id and p.id = 282146 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18502728422', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('140751721', '王进荣', 'LGWCBD194EB004809', '京E5405H', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18502728422'), (select max(id) from auto where license_plate_no = '京E5405H'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18502728422'), p.auto = (select max(id) from auto where license_plate_no ='京E5405H') where  p.id = 282148 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18502728422'), i.auto = (select max(id) from auto where license_plate_no ='京E5405H')  where p.obj_id = i.quote_record and  p.id = 282148 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18502728422'), i.auto = (select max(id) from auto where license_plate_no ='京E5405H')  where p.obj_id = i.quote_record and p.id =  282148 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18502728422'), qr.auto = (select max(id) from auto where license_plate_no = '京E5405H') where p.obj_id = qr.id and p.id = 282148 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18502728422') where pay.purchase_order = p.id and p.id = 282148 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15685460171', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('100417073187', '京西秦通达汽车运输有限公司', 'LZZTBXNF4CJ051951', '京AL0195', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15685460171'), (select max(id) from auto where license_plate_no = '京AL0195'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15685460171'), p.auto = (select max(id) from auto where license_plate_no ='京AL0195') where  p.id = 282150 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15685460171'), i.auto = (select max(id) from auto where license_plate_no ='京AL0195')  where p.obj_id = i.quote_record and  p.id = 282150 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15685460171'), i.auto = (select max(id) from auto where license_plate_no ='京AL0195')  where p.obj_id = i.quote_record and p.id =  282150 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15685460171'), qr.auto = (select max(id) from auto where license_plate_no = '京AL0195') where p.obj_id = qr.id and p.id = 282150 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15685460171') where pay.purchase_order = p.id and p.id = 282150 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13655975463', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('93130069', '苏州易得电子有限公司', 'LSGUD82C89E006354', '苏E1XF37', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13655975463'), (select max(id) from auto where license_plate_no = '苏E1XF37'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13655975463'), p.auto = (select max(id) from auto where license_plate_no ='苏E1XF37') where  p.id = 282153 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13655975463'), i.auto = (select max(id) from auto where license_plate_no ='苏E1XF37')  where p.obj_id = i.quote_record and  p.id = 282153 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13655975463'), i.auto = (select max(id) from auto where license_plate_no ='苏E1XF37')  where p.obj_id = i.quote_record and p.id =  282153 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13655975463'), qr.auto = (select max(id) from auto where license_plate_no = '苏E1XF37') where p.obj_id = qr.id and p.id = 282153 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13655975463') where pay.purchase_order = p.id and p.id = 282153 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18136073154', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('092540541', '徐通', 'LSGGA53X5AH054130', '沪J62799', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18136073154'), (select max(id) from auto where license_plate_no = '沪J62799'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18136073154'), p.auto = (select max(id) from auto where license_plate_no ='沪J62799') where  p.id = 282155 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18136073154'), i.auto = (select max(id) from auto where license_plate_no ='沪J62799')  where p.obj_id = i.quote_record and  p.id = 282155 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18136073154'), i.auto = (select max(id) from auto where license_plate_no ='沪J62799')  where p.obj_id = i.quote_record and p.id =  282155 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18136073154'), qr.auto = (select max(id) from auto where license_plate_no = '沪J62799') where p.obj_id = qr.id and p.id = 282155 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18136073154') where pay.purchase_order = p.id and p.id = 282155 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15853867679', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('SKL5373', '狄建明', 'LGWEF3A5XBF007139', '沪L97705', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15853867679'), (select max(id) from auto where license_plate_no = '沪L97705'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15853867679'), p.auto = (select max(id) from auto where license_plate_no ='沪L97705') where  p.id = 282156 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15853867679'), i.auto = (select max(id) from auto where license_plate_no ='沪L97705')  where p.obj_id = i.quote_record and  p.id = 282156 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15853867679'), i.auto = (select max(id) from auto where license_plate_no ='沪L97705')  where p.obj_id = i.quote_record and p.id =  282156 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15853867679'), qr.auto = (select max(id) from auto where license_plate_no = '沪L97705') where p.obj_id = qr.id and p.id = 282156 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15853867679') where pay.purchase_order = p.id and p.id = 282156 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13259787842', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('3272805', '苏州市祥隆达贸易有限公司', 'LVSHBFAFXBF181520', '苏E7NM83', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13259787842'), (select max(id) from auto where license_plate_no = '苏E7NM83'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13259787842'), p.auto = (select max(id) from auto where license_plate_no ='苏E7NM83') where  p.id = 282157 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13259787842'), i.auto = (select max(id) from auto where license_plate_no ='苏E7NM83')  where p.obj_id = i.quote_record and  p.id = 282157 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13259787842'), i.auto = (select max(id) from auto where license_plate_no ='苏E7NM83')  where p.obj_id = i.quote_record and p.id =  282157 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13259787842'), qr.auto = (select max(id) from auto where license_plate_no = '苏E7NM83') where p.obj_id = qr.id and p.id = 282157 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13259787842') where pay.purchase_order = p.id and p.id = 282157 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13127575776', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('E1082214', '李敏', 'LJDSAA121E0002311', '京JLM883', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13127575776'), (select max(id) from auto where license_plate_no = '京JLM883'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13127575776'), p.auto = (select max(id) from auto where license_plate_no ='京JLM883') where  p.id = 282158 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13127575776'), i.auto = (select max(id) from auto where license_plate_no ='京JLM883')  where p.obj_id = i.quote_record and  p.id = 282158 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13127575776'), i.auto = (select max(id) from auto where license_plate_no ='京JLM883')  where p.obj_id = i.quote_record and p.id =  282158 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13127575776'), qr.auto = (select max(id) from auto where license_plate_no = '京JLM883') where p.obj_id = qr.id and p.id = 282158 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13127575776') where pay.purchase_order = p.id and p.id = 282158 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18157518367', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('1014323', '深圳市临泉印刷器材贸易有限公司', 'LHGGK5852F2014250', '粤BN91Z2', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18157518367'), (select max(id) from auto where license_plate_no = '粤BN91Z2'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18157518367'), p.auto = (select max(id) from auto where license_plate_no ='粤BN91Z2') where  p.id = 282162 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18157518367'), i.auto = (select max(id) from auto where license_plate_no ='粤BN91Z2')  where p.obj_id = i.quote_record and  p.id = 282162 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18157518367'), i.auto = (select max(id) from auto where license_plate_no ='粤BN91Z2')  where p.obj_id = i.quote_record and p.id =  282162 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18157518367'), qr.auto = (select max(id) from auto where license_plate_no = '粤BN91Z2') where p.obj_id = qr.id and p.id = 282162 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18157518367') where pay.purchase_order = p.id and p.id = 282162 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18815057978', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('E3040116', '华福森服饰（深圳）有限公司', 'LJ166A344E7103560', '粤BE87Z7', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18815057978'), (select max(id) from auto where license_plate_no = '粤BE87Z7'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18815057978'), p.auto = (select max(id) from auto where license_plate_no ='粤BE87Z7') where  p.id = 282167 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18815057978'), i.auto = (select max(id) from auto where license_plate_no ='粤BE87Z7')  where p.obj_id = i.quote_record and  p.id = 282167 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18815057978'), i.auto = (select max(id) from auto where license_plate_no ='粤BE87Z7')  where p.obj_id = i.quote_record and p.id =  282167 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18815057978'), qr.auto = (select max(id) from auto where license_plate_no = '粤BE87Z7') where p.obj_id = qr.id and p.id = 282167 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18815057978') where pay.purchase_order = p.id and p.id = 282167 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13777732777', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('C338056', '陈兰粉', 'LVGBE40K17G156694', '沪C78T97', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13777732777'), (select max(id) from auto where license_plate_no = '沪C78T97'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13777732777'), p.auto = (select max(id) from auto where license_plate_no ='沪C78T97') where  p.id = 282179 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13777732777'), i.auto = (select max(id) from auto where license_plate_no ='沪C78T97')  where p.obj_id = i.quote_record and  p.id = 282179 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13777732777'), i.auto = (select max(id) from auto where license_plate_no ='沪C78T97')  where p.obj_id = i.quote_record and p.id =  282179 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13777732777'), qr.auto = (select max(id) from auto where license_plate_no = '沪C78T97') where p.obj_id = qr.id and p.id = 282179 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13777732777') where pay.purchase_order = p.id and p.id = 282179 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15560110316', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('09038991', '上海运坤贸易有限公司', 'LJ11RBBC896003960', '沪HP3065', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15560110316'), (select max(id) from auto where license_plate_no = '沪HP3065'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15560110316'), p.auto = (select max(id) from auto where license_plate_no ='沪HP3065') where  p.id = 282187 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15560110316'), i.auto = (select max(id) from auto where license_plate_no ='沪HP3065')  where p.obj_id = i.quote_record and  p.id = 282187 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15560110316'), i.auto = (select max(id) from auto where license_plate_no ='沪HP3065')  where p.obj_id = i.quote_record and p.id =  282187 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15560110316'), qr.auto = (select max(id) from auto where license_plate_no = '沪HP3065') where p.obj_id = qr.id and p.id = 282187 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15560110316') where pay.purchase_order = p.id and p.id = 282187 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15753084550', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('8794237', '马宏刚', 'LDCC13L26C1010440', '京A419S9', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15753084550'), (select max(id) from auto where license_plate_no = '京A419S9'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15753084550'), p.auto = (select max(id) from auto where license_plate_no ='京A419S9') where  p.id = 282189 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15753084550'), i.auto = (select max(id) from auto where license_plate_no ='京A419S9')  where p.obj_id = i.quote_record and  p.id = 282189 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15753084550'), i.auto = (select max(id) from auto where license_plate_no ='京A419S9')  where p.obj_id = i.quote_record and p.id =  282189 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15753084550'), qr.auto = (select max(id) from auto where license_plate_no = '京A419S9') where p.obj_id = qr.id and p.id = 282189 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15753084550') where pay.purchase_order = p.id and p.id = 282189 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13273796802', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('A51273', '田忠平', 'LSYAFAAM9EG264360', '京FZP099', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13273796802'), (select max(id) from auto where license_plate_no = '京FZP099'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13273796802'), p.auto = (select max(id) from auto where license_plate_no ='京FZP099') where  p.id = 282191 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13273796802'), i.auto = (select max(id) from auto where license_plate_no ='京FZP099')  where p.obj_id = i.quote_record and  p.id = 282191 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13273796802'), i.auto = (select max(id) from auto where license_plate_no ='京FZP099')  where p.obj_id = i.quote_record and p.id =  282191 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13273796802'), qr.auto = (select max(id) from auto where license_plate_no = '京FZP099') where p.obj_id = qr.id and p.id = 282191 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13273796802') where pay.purchase_order = p.id and p.id = 282191 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13541470294', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('84027856', '太仓誉和五金机电有限公司', 'LJXCMCCB08T042213', '苏EJZ220', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13541470294'), (select max(id) from auto where license_plate_no = '苏EJZ220'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13541470294'), p.auto = (select max(id) from auto where license_plate_no ='苏EJZ220') where  p.id = 282193 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13541470294'), i.auto = (select max(id) from auto where license_plate_no ='苏EJZ220')  where p.obj_id = i.quote_record and  p.id = 282193 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13541470294'), i.auto = (select max(id) from auto where license_plate_no ='苏EJZ220')  where p.obj_id = i.quote_record and p.id =  282193 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13541470294'), qr.auto = (select max(id) from auto where license_plate_no = '苏EJZ220') where p.obj_id = qr.id and p.id = 282193 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13541470294') where pay.purchase_order = p.id and p.id = 282193 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18571182564', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('UC41120842', '苏州肯达装饰有限公司', 'LZWACAGA0C7082322', '苏E9JW62', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18571182564'), (select max(id) from auto where license_plate_no = '苏E9JW62'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18571182564'), p.auto = (select max(id) from auto where license_plate_no ='苏E9JW62') where  p.id = 282194 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18571182564'), i.auto = (select max(id) from auto where license_plate_no ='苏E9JW62')  where p.obj_id = i.quote_record and  p.id = 282194 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18571182564'), i.auto = (select max(id) from auto where license_plate_no ='苏E9JW62')  where p.obj_id = i.quote_record and p.id =  282194 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18571182564'), qr.auto = (select max(id) from auto where license_plate_no = '苏E9JW62') where p.obj_id = qr.id and p.id = 282194 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18571182564') where pay.purchase_order = p.id and p.id = 282194 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15105432339', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('019313', '刘矿群', 'LSVAA2BR2DN061820', '京JN1395', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15105432339'), (select max(id) from auto where license_plate_no = '京JN1395'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15105432339'), p.auto = (select max(id) from auto where license_plate_no ='京JN1395') where  p.id = 282203 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15105432339'), i.auto = (select max(id) from auto where license_plate_no ='京JN1395')  where p.obj_id = i.quote_record and  p.id = 282203 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15105432339'), i.auto = (select max(id) from auto where license_plate_no ='京JN1395')  where p.obj_id = i.quote_record and p.id =  282203 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15105432339'), qr.auto = (select max(id) from auto where license_plate_no = '京JN1395') where p.obj_id = qr.id and p.id = 282203 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15105432339') where pay.purchase_order = p.id and p.id = 282203 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15691657701', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('05053426', '张家港市三源日化喷雾器制造有限公司', 'LGDTH81G55A120006', '苏EG4638', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15691657701'), (select max(id) from auto where license_plate_no = '苏EG4638'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15691657701'), p.auto = (select max(id) from auto where license_plate_no ='苏EG4638') where  p.id = 282209 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15691657701'), i.auto = (select max(id) from auto where license_plate_no ='苏EG4638')  where p.obj_id = i.quote_record and  p.id = 282209 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15691657701'), i.auto = (select max(id) from auto where license_plate_no ='苏EG4638')  where p.obj_id = i.quote_record and p.id =  282209 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15691657701'), qr.auto = (select max(id) from auto where license_plate_no = '苏EG4638') where p.obj_id = qr.id and p.id = 282209 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15691657701') where pay.purchase_order = p.id and p.id = 282209 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15843545118', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('7030903', '马吉华', 'LDC943L24B1748222', '沪L97913', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15843545118'), (select max(id) from auto where license_plate_no = '沪L97913'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15843545118'), p.auto = (select max(id) from auto where license_plate_no ='沪L97913') where  p.id = 282213 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15843545118'), i.auto = (select max(id) from auto where license_plate_no ='沪L97913')  where p.obj_id = i.quote_record and  p.id = 282213 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15843545118'), i.auto = (select max(id) from auto where license_plate_no ='沪L97913')  where p.obj_id = i.quote_record and p.id =  282213 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15843545118'), qr.auto = (select max(id) from auto where license_plate_no = '沪L97913') where p.obj_id = qr.id and p.id = 282213 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15843545118') where pay.purchase_order = p.id and p.id = 282213 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18515737388', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('30915058', '常熟市天星冶金机械制造有限公司', 'LSGWL52D73S208968', '苏ED7916', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18515737388'), (select max(id) from auto where license_plate_no = '苏ED7916'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18515737388'), p.auto = (select max(id) from auto where license_plate_no ='苏ED7916') where  p.id = 282216 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18515737388'), i.auto = (select max(id) from auto where license_plate_no ='苏ED7916')  where p.obj_id = i.quote_record and  p.id = 282216 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18515737388'), i.auto = (select max(id) from auto where license_plate_no ='苏ED7916')  where p.obj_id = i.quote_record and p.id =  282216 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18515737388'), qr.auto = (select max(id) from auto where license_plate_no = '苏ED7916') where p.obj_id = qr.id and p.id = 282216 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18515737388') where pay.purchase_order = p.id and p.id = 282216 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15965374673', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('1110352', '宋江艳', 'LHGGM363192010338', '沪CS0623', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15965374673'), (select max(id) from auto where license_plate_no = '沪CS0623'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15965374673'), p.auto = (select max(id) from auto where license_plate_no ='沪CS0623') where  p.id = 282221 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15965374673'), i.auto = (select max(id) from auto where license_plate_no ='沪CS0623')  where p.obj_id = i.quote_record and  p.id = 282221 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15965374673'), i.auto = (select max(id) from auto where license_plate_no ='沪CS0623')  where p.obj_id = i.quote_record and p.id =  282221 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15965374673'), qr.auto = (select max(id) from auto where license_plate_no = '沪CS0623') where p.obj_id = qr.id and p.id = 282221 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15965374673') where pay.purchase_order = p.id and p.id = 282221 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13071294089', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('E3047595', '深圳市华旭科技开发有限公司', 'LEFYFCG25EHN26676', '粤BA48M5', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13071294089'), (select max(id) from auto where license_plate_no = '粤BA48M5'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13071294089'), p.auto = (select max(id) from auto where license_plate_no ='粤BA48M5') where  p.id = 282224 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13071294089'), i.auto = (select max(id) from auto where license_plate_no ='粤BA48M5')  where p.obj_id = i.quote_record and  p.id = 282224 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13071294089'), i.auto = (select max(id) from auto where license_plate_no ='粤BA48M5')  where p.obj_id = i.quote_record and p.id =  282224 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13071294089'), qr.auto = (select max(id) from auto where license_plate_no = '粤BA48M5') where p.obj_id = qr.id and p.id = 282224 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13071294089') where pay.purchase_order = p.id and p.id = 282224 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15303043032', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('D02400', '深圳市亿鹏达玻璃制品有限公司', 'LGGR2BG48DL826009', '粤BV0513', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15303043032'), (select max(id) from auto where license_plate_no = '粤BV0513'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15303043032'), p.auto = (select max(id) from auto where license_plate_no ='粤BV0513') where  p.id = 282230 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15303043032'), i.auto = (select max(id) from auto where license_plate_no ='粤BV0513')  where p.obj_id = i.quote_record and  p.id = 282230 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15303043032'), i.auto = (select max(id) from auto where license_plate_no ='粤BV0513')  where p.obj_id = i.quote_record and p.id =  282230 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15303043032'), qr.auto = (select max(id) from auto where license_plate_no = '粤BV0513') where p.obj_id = qr.id and p.id = 282230 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15303043032') where pay.purchase_order = p.id and p.id = 282230 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13662510794', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('87794678', '子长县鹏达混凝土搅拌有限责任公司', 'LGAX4DS36A3035222', '京J34270', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13662510794'), (select max(id) from auto where license_plate_no = '京J34270'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13662510794'), p.auto = (select max(id) from auto where license_plate_no ='京J34270') where  p.id = 282235 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13662510794'), i.auto = (select max(id) from auto where license_plate_no ='京J34270')  where p.obj_id = i.quote_record and  p.id = 282235 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13662510794'), i.auto = (select max(id) from auto where license_plate_no ='京J34270')  where p.obj_id = i.quote_record and p.id =  282235 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13662510794'), qr.auto = (select max(id) from auto where license_plate_no = '京J34270') where p.obj_id = qr.id and p.id = 282235 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13662510794') where pay.purchase_order = p.id and p.id = 282235 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13493718352', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('8D50320092', '马俊亭', 'LZWADAGA9D4098146', '京E8468C', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13493718352'), (select max(id) from auto where license_plate_no = '京E8468C'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13493718352'), p.auto = (select max(id) from auto where license_plate_no ='京E8468C') where  p.id = 282237 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13493718352'), i.auto = (select max(id) from auto where license_plate_no ='京E8468C')  where p.obj_id = i.quote_record and  p.id = 282237 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13493718352'), i.auto = (select max(id) from auto where license_plate_no ='京E8468C')  where p.obj_id = i.quote_record and p.id =  282237 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13493718352'), qr.auto = (select max(id) from auto where license_plate_no = '京E8468C') where p.obj_id = qr.id and p.id = 282237 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13493718352') where pay.purchase_order = p.id and p.id = 282237 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13557719883', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('A8102403', '苏州市吴中区永顺毛衫织造有限公司', 'LJXCMCCB3AT082601', '苏E3QZ70', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13557719883'), (select max(id) from auto where license_plate_no = '苏E3QZ70'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13557719883'), p.auto = (select max(id) from auto where license_plate_no ='苏E3QZ70') where  p.id = 282239 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13557719883'), i.auto = (select max(id) from auto where license_plate_no ='苏E3QZ70')  where p.obj_id = i.quote_record and  p.id = 282239 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13557719883'), i.auto = (select max(id) from auto where license_plate_no ='苏E3QZ70')  where p.obj_id = i.quote_record and p.id =  282239 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13557719883'), qr.auto = (select max(id) from auto where license_plate_no = '苏E3QZ70') where p.obj_id = qr.id and p.id = 282239 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13557719883') where pay.purchase_order = p.id and p.id = 282239 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13243482066', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('D7VA016398', '李军', 'LS5A2BBR4DH022609', '京A7S935', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13243482066'), (select max(id) from auto where license_plate_no = '京A7S935'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13243482066'), p.auto = (select max(id) from auto where license_plate_no ='京A7S935') where  p.id = 282241 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13243482066'), i.auto = (select max(id) from auto where license_plate_no ='京A7S935')  where p.obj_id = i.quote_record and  p.id = 282241 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13243482066'), i.auto = (select max(id) from auto where license_plate_no ='京A7S935')  where p.obj_id = i.quote_record and p.id =  282241 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13243482066'), qr.auto = (select max(id) from auto where license_plate_no = '京A7S935') where p.obj_id = qr.id and p.id = 282241 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13243482066') where pay.purchase_order = p.id and p.id = 282241 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13044993248', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('A06183297', '王波', 'LZWACAGA5A1098578', '京A412N8', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13044993248'), (select max(id) from auto where license_plate_no = '京A412N8'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13044993248'), p.auto = (select max(id) from auto where license_plate_no ='京A412N8') where  p.id = 282243 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13044993248'), i.auto = (select max(id) from auto where license_plate_no ='京A412N8')  where p.obj_id = i.quote_record and  p.id = 282243 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13044993248'), i.auto = (select max(id) from auto where license_plate_no ='京A412N8')  where p.obj_id = i.quote_record and p.id =  282243 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13044993248'), qr.auto = (select max(id) from auto where license_plate_no = '京A412N8') where p.obj_id = qr.id and p.id = 282243 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13044993248') where pay.purchase_order = p.id and p.id = 282243 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13114653553', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('B3047966', '常熟市辛庄镇恒达箱包配件厂', 'LEFYECG25BHN22125', '苏E163WF', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13114653553'), (select max(id) from auto where license_plate_no = '苏E163WF'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13114653553'), p.auto = (select max(id) from auto where license_plate_no ='苏E163WF') where  p.id = 282246 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13114653553'), i.auto = (select max(id) from auto where license_plate_no ='苏E163WF')  where p.obj_id = i.quote_record and  p.id = 282246 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13114653553'), i.auto = (select max(id) from auto where license_plate_no ='苏E163WF')  where p.obj_id = i.quote_record and p.id =  282246 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13114653553'), qr.auto = (select max(id) from auto where license_plate_no = '苏E163WF') where p.obj_id = qr.id and p.id = 282246 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13114653553') where pay.purchase_order = p.id and p.id = 282246 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18597466293', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('SPS9348', '张永舒', 'LGWDB3190FB000739', '京JZV696', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18597466293'), (select max(id) from auto where license_plate_no = '京JZV696'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18597466293'), p.auto = (select max(id) from auto where license_plate_no ='京JZV696') where  p.id = 282249 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18597466293'), i.auto = (select max(id) from auto where license_plate_no ='京JZV696')  where p.obj_id = i.quote_record and  p.id = 282249 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18597466293'), i.auto = (select max(id) from auto where license_plate_no ='京JZV696')  where p.obj_id = i.quote_record and p.id =  282249 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18597466293'), qr.auto = (select max(id) from auto where license_plate_no = '京JZV696') where p.obj_id = qr.id and p.id = 282249 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18597466293') where pay.purchase_order = p.id and p.id = 282249 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15026860594', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('89C2110376', '刘武杰', 'LZWACAGA792157569', '京A500SY', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15026860594'), (select max(id) from auto where license_plate_no = '京A500SY'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15026860594'), p.auto = (select max(id) from auto where license_plate_no ='京A500SY') where  p.id = 282253 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15026860594'), i.auto = (select max(id) from auto where license_plate_no ='京A500SY')  where p.obj_id = i.quote_record and  p.id = 282253 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15026860594'), i.auto = (select max(id) from auto where license_plate_no ='京A500SY')  where p.obj_id = i.quote_record and p.id =  282253 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15026860594'), qr.auto = (select max(id) from auto where license_plate_no = '京A500SY') where p.obj_id = qr.id and p.id = 282253 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15026860594') where pay.purchase_order = p.id and p.id = 282253 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13471181728', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('B01038627', '王鹏', 'LZWACAGAXB1021450', '京AB808Z', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13471181728'), (select max(id) from auto where license_plate_no = '京AB808Z'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13471181728'), p.auto = (select max(id) from auto where license_plate_no ='京AB808Z') where  p.id = 282254 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13471181728'), i.auto = (select max(id) from auto where license_plate_no ='京AB808Z')  where p.obj_id = i.quote_record and  p.id = 282254 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13471181728'), i.auto = (select max(id) from auto where license_plate_no ='京AB808Z')  where p.obj_id = i.quote_record and p.id =  282254 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13471181728'), qr.auto = (select max(id) from auto where license_plate_no = '京AB808Z') where p.obj_id = qr.id and p.id = 282254 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13471181728') where pay.purchase_order = p.id and p.id = 282254 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15332090779', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('BC725991', '苏州市瑞达医疗器械科技有限公司', '1J4RR4GG2BC725991', '苏E7RR51', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15332090779'), (select max(id) from auto where license_plate_no = '苏E7RR51'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15332090779'), p.auto = (select max(id) from auto where license_plate_no ='苏E7RR51') where  p.id = 282257 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15332090779'), i.auto = (select max(id) from auto where license_plate_no ='苏E7RR51')  where p.obj_id = i.quote_record and  p.id = 282257 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15332090779'), i.auto = (select max(id) from auto where license_plate_no ='苏E7RR51')  where p.obj_id = i.quote_record and p.id =  282257 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15332090779'), qr.auto = (select max(id) from auto where license_plate_no = '苏E7RR51') where p.obj_id = qr.id and p.id = 282257 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15332090779') where pay.purchase_order = p.id and p.id = 282257 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15635750830', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('C64F006677', '李炳宏', 'LSCBB23D2CG171427', '京GEE198', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15635750830'), (select max(id) from auto where license_plate_no = '京GEE198'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15635750830'), p.auto = (select max(id) from auto where license_plate_no ='京GEE198') where  p.id = 282266 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15635750830'), i.auto = (select max(id) from auto where license_plate_no ='京GEE198')  where p.obj_id = i.quote_record and  p.id = 282266 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15635750830'), i.auto = (select max(id) from auto where license_plate_no ='京GEE198')  where p.obj_id = i.quote_record and p.id =  282266 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15635750830'), qr.auto = (select max(id) from auto where license_plate_no = '京GEE198') where p.obj_id = qr.id and p.id = 282266 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15635750830') where pay.purchase_order = p.id and p.id = 282266 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18678959048', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('C1004234', '昆山市大唐通讯设备有限公司', 'LJXCMCHC7CT011826', '苏E821PN', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18678959048'), (select max(id) from auto where license_plate_no = '苏E821PN'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18678959048'), p.auto = (select max(id) from auto where license_plate_no ='苏E821PN') where  p.id = 282269 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18678959048'), i.auto = (select max(id) from auto where license_plate_no ='苏E821PN')  where p.obj_id = i.quote_record and  p.id = 282269 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18678959048'), i.auto = (select max(id) from auto where license_plate_no ='苏E821PN')  where p.obj_id = i.quote_record and p.id =  282269 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18678959048'), qr.auto = (select max(id) from auto where license_plate_no = '苏E821PN') where p.obj_id = qr.id and p.id = 282269 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18678959048') where pay.purchase_order = p.id and p.id = 282269 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18763206443', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('472778', '京西省商洛市洛南县盐业公司', 'LSVCG6A43DN100144', '京HA3012', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18763206443'), (select max(id) from auto where license_plate_no = '京HA3012'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18763206443'), p.auto = (select max(id) from auto where license_plate_no ='京HA3012') where  p.id = 282277 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18763206443'), i.auto = (select max(id) from auto where license_plate_no ='京HA3012')  where p.obj_id = i.quote_record and  p.id = 282277 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18763206443'), i.auto = (select max(id) from auto where license_plate_no ='京HA3012')  where p.obj_id = i.quote_record and p.id =  282277 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18763206443'), qr.auto = (select max(id) from auto where license_plate_no = '京HA3012') where p.obj_id = qr.id and p.id = 282277 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18763206443') where pay.purchase_order = p.id and p.id = 282277 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18875124237', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('3B21CJ6997', '华缨', 'WMEEJ8AA4AK392996', '沪KC5556', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18875124237'), (select max(id) from auto where license_plate_no = '沪KC5556'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18875124237'), p.auto = (select max(id) from auto where license_plate_no ='沪KC5556') where  p.id = 282293 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18875124237'), i.auto = (select max(id) from auto where license_plate_no ='沪KC5556')  where p.obj_id = i.quote_record and  p.id = 282293 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18875124237'), i.auto = (select max(id) from auto where license_plate_no ='沪KC5556')  where p.obj_id = i.quote_record and p.id =  282293 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18875124237'), qr.auto = (select max(id) from auto where license_plate_no = '沪KC5556') where p.obj_id = qr.id and p.id = 282293 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18875124237') where pay.purchase_order = p.id and p.id = 282293 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13003158033', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('07023598', '常熟市皓帝商贸有限责任公司', 'LJ11KBBCX76011317', '苏EE8F80', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13003158033'), (select max(id) from auto where license_plate_no = '苏EE8F80'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13003158033'), p.auto = (select max(id) from auto where license_plate_no ='苏EE8F80') where  p.id = 282311 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13003158033'), i.auto = (select max(id) from auto where license_plate_no ='苏EE8F80')  where p.obj_id = i.quote_record and  p.id = 282311 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13003158033'), i.auto = (select max(id) from auto where license_plate_no ='苏EE8F80')  where p.obj_id = i.quote_record and p.id =  282311 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13003158033'), qr.auto = (select max(id) from auto where license_plate_no = '苏EE8F80') where p.obj_id = qr.id and p.id = 282311 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13003158033') where pay.purchase_order = p.id and p.id = 282311 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15955394857', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('0602972', '苏州澄丰纸业有限公司', 'LDC621P2780773413', '苏E1EC61', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15955394857'), (select max(id) from auto where license_plate_no = '苏E1EC61'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15955394857'), p.auto = (select max(id) from auto where license_plate_no ='苏E1EC61') where  p.id = 282320 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15955394857'), i.auto = (select max(id) from auto where license_plate_no ='苏E1EC61')  where p.obj_id = i.quote_record and  p.id = 282320 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15955394857'), i.auto = (select max(id) from auto where license_plate_no ='苏E1EC61')  where p.obj_id = i.quote_record and p.id =  282320 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15955394857'), qr.auto = (select max(id) from auto where license_plate_no = '苏E1EC61') where p.obj_id = qr.id and p.id = 282320 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15955394857') where pay.purchase_order = p.id and p.id = 282320 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18849051400', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('815966X', '苏州市水上搜救应急处置中心', 'LJNTGU2GXEN100508', '苏E0C158', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18849051400'), (select max(id) from auto where license_plate_no = '苏E0C158'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18849051400'), p.auto = (select max(id) from auto where license_plate_no ='苏E0C158') where  p.id = 282341 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18849051400'), i.auto = (select max(id) from auto where license_plate_no ='苏E0C158')  where p.obj_id = i.quote_record and  p.id = 282341 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18849051400'), i.auto = (select max(id) from auto where license_plate_no ='苏E0C158')  where p.obj_id = i.quote_record and p.id =  282341 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18849051400'), qr.auto = (select max(id) from auto where license_plate_no = '苏E0C158') where p.obj_id = qr.id and p.id = 282341 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18849051400') where pay.purchase_order = p.id and p.id = 282341 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18093863042', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('293658', '深圳市中航盛世模切机械有限公司', 'LFV2A11GXA3040800', '粤B507L2', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18093863042'), (select max(id) from auto where license_plate_no = '粤B507L2'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18093863042'), p.auto = (select max(id) from auto where license_plate_no ='粤B507L2') where  p.id = 282343 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18093863042'), i.auto = (select max(id) from auto where license_plate_no ='粤B507L2')  where p.obj_id = i.quote_record and  p.id = 282343 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18093863042'), i.auto = (select max(id) from auto where license_plate_no ='粤B507L2')  where p.obj_id = i.quote_record and p.id =  282343 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18093863042'), qr.auto = (select max(id) from auto where license_plate_no = '粤B507L2') where p.obj_id = qr.id and p.id = 282343 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18093863042') where pay.purchase_order = p.id and p.id = 282343 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18755864636', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('002355V', '崔庆亚', 'LGBM4AE49ES002986', '京AS1T98', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18755864636'), (select max(id) from auto where license_plate_no = '京AS1T98'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18755864636'), p.auto = (select max(id) from auto where license_plate_no ='京AS1T98') where  p.id = 282359 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18755864636'), i.auto = (select max(id) from auto where license_plate_no ='京AS1T98')  where p.obj_id = i.quote_record and  p.id = 282359 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18755864636'), i.auto = (select max(id) from auto where license_plate_no ='京AS1T98')  where p.obj_id = i.quote_record and p.id =  282359 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18755864636'), qr.auto = (select max(id) from auto where license_plate_no = '京AS1T98') where p.obj_id = qr.id and p.id = 282359 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18755864636') where pay.purchase_order = p.id and p.id = 282359 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13170661299', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('86300124', '苏州盛龙玩具有限公司', 'LSGDC82D88E026145', '苏E1DY56', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13170661299'), (select max(id) from auto where license_plate_no = '苏E1DY56'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13170661299'), p.auto = (select max(id) from auto where license_plate_no ='苏E1DY56') where  p.id = 282361 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13170661299'), i.auto = (select max(id) from auto where license_plate_no ='苏E1DY56')  where p.obj_id = i.quote_record and  p.id = 282361 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13170661299'), i.auto = (select max(id) from auto where license_plate_no ='苏E1DY56')  where p.obj_id = i.quote_record and p.id =  282361 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13170661299'), qr.auto = (select max(id) from auto where license_plate_no = '苏E1DY56') where p.obj_id = qr.id and p.id = 282361 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13170661299') where pay.purchase_order = p.id and p.id = 282361 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13698718080', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('94CN005733', '苏小云', 'LS4AAB3R99A018643', '京DMU666', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13698718080'), (select max(id) from auto where license_plate_no = '京DMU666'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13698718080'), p.auto = (select max(id) from auto where license_plate_no ='京DMU666') where  p.id = 282365 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13698718080'), i.auto = (select max(id) from auto where license_plate_no ='京DMU666')  where p.obj_id = i.quote_record and  p.id = 282365 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13698718080'), i.auto = (select max(id) from auto where license_plate_no ='京DMU666')  where p.obj_id = i.quote_record and p.id =  282365 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13698718080'), qr.auto = (select max(id) from auto where license_plate_no = '京DMU666') where p.obj_id = qr.id and p.id = 282365 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13698718080') where pay.purchase_order = p.id and p.id = 282365 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15247116294', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('EB732295', '武波', 'LBEMDAEC1EZ377015', '京AW7B28', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15247116294'), (select max(id) from auto where license_plate_no = '京AW7B28'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15247116294'), p.auto = (select max(id) from auto where license_plate_no ='京AW7B28') where  p.id = 282367 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15247116294'), i.auto = (select max(id) from auto where license_plate_no ='京AW7B28')  where p.obj_id = i.quote_record and  p.id = 282367 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15247116294'), i.auto = (select max(id) from auto where license_plate_no ='京AW7B28')  where p.obj_id = i.quote_record and p.id =  282367 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15247116294'), qr.auto = (select max(id) from auto where license_plate_no = '京AW7B28') where p.obj_id = qr.id and p.id = 282367 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15247116294') where pay.purchase_order = p.id and p.id = 282367 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18090432766', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('213350978', '王拴', 'LGXC16DF4D0121165', '京JM8523', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18090432766'), (select max(id) from auto where license_plate_no = '京JM8523'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18090432766'), p.auto = (select max(id) from auto where license_plate_no ='京JM8523') where  p.id = 282369 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18090432766'), i.auto = (select max(id) from auto where license_plate_no ='京JM8523')  where p.obj_id = i.quote_record and  p.id = 282369 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18090432766'), i.auto = (select max(id) from auto where license_plate_no ='京JM8523')  where p.obj_id = i.quote_record and p.id =  282369 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18090432766'), qr.auto = (select max(id) from auto where license_plate_no = '京JM8523') where p.obj_id = qr.id and p.id = 282369 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18090432766') where pay.purchase_order = p.id and p.id = 282369 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13591459582', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('E64F000505', '苏州映宇骏企业服务有限公司', 'LSCBBN3D7EG114614', '苏EK589R', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13591459582'), (select max(id) from auto where license_plate_no = '苏EK589R'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13591459582'), p.auto = (select max(id) from auto where license_plate_no ='苏EK589R') where  p.id = 282370 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13591459582'), i.auto = (select max(id) from auto where license_plate_no ='苏EK589R')  where p.obj_id = i.quote_record and  p.id = 282370 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13591459582'), i.auto = (select max(id) from auto where license_plate_no ='苏EK589R')  where p.obj_id = i.quote_record and p.id =  282370 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13591459582'), qr.auto = (select max(id) from auto where license_plate_no = '苏EK589R') where p.obj_id = qr.id and p.id = 282370 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13591459582') where pay.purchase_order = p.id and p.id = 282370 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18843927149', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('EQ486332144', '吴江市中小学素质教育培训中心', 'LGBC1AE083Y006510', '苏ET7368', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18843927149'), (select max(id) from auto where license_plate_no = '苏ET7368'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18843927149'), p.auto = (select max(id) from auto where license_plate_no ='苏ET7368') where  p.id = 282386 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18843927149'), i.auto = (select max(id) from auto where license_plate_no ='苏ET7368')  where p.obj_id = i.quote_record and  p.id = 282386 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18843927149'), i.auto = (select max(id) from auto where license_plate_no ='苏ET7368')  where p.obj_id = i.quote_record and p.id =  282386 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18843927149'), qr.auto = (select max(id) from auto where license_plate_no = '苏ET7368') where p.obj_id = qr.id and p.id = 282386 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18843927149') where pay.purchase_order = p.id and p.id = 282386 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15208137275', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('0220099', '夏志刚', 'LSVAU033882301465', '沪CQ7562', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15208137275'), (select max(id) from auto where license_plate_no = '沪CQ7562'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15208137275'), p.auto = (select max(id) from auto where license_plate_no ='沪CQ7562') where  p.id = 282389 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15208137275'), i.auto = (select max(id) from auto where license_plate_no ='沪CQ7562')  where p.obj_id = i.quote_record and  p.id = 282389 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15208137275'), i.auto = (select max(id) from auto where license_plate_no ='沪CQ7562')  where p.obj_id = i.quote_record and p.id =  282389 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15208137275'), qr.auto = (select max(id) from auto where license_plate_no = '沪CQ7562') where p.obj_id = qr.id and p.id = 282389 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15208137275') where pay.purchase_order = p.id and p.id = 282389 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15686217827', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('D130811001', '昆山丰工港口机械有限公司', 'LGWCA2191DB003087', '苏EF03X1', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15686217827'), (select max(id) from auto where license_plate_no = '苏EF03X1'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15686217827'), p.auto = (select max(id) from auto where license_plate_no ='苏EF03X1') where  p.id = 282404 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15686217827'), i.auto = (select max(id) from auto where license_plate_no ='苏EF03X1')  where p.obj_id = i.quote_record and  p.id = 282404 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15686217827'), i.auto = (select max(id) from auto where license_plate_no ='苏EF03X1')  where p.obj_id = i.quote_record and p.id =  282404 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15686217827'), qr.auto = (select max(id) from auto where license_plate_no = '苏EF03X1') where p.obj_id = qr.id and p.id = 282404 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15686217827') where pay.purchase_order = p.id and p.id = 282404 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18665986347', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('11062666', '余小会', 'LGKZ32G73B9J36305', '京F0180A', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18665986347'), (select max(id) from auto where license_plate_no = '京F0180A'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18665986347'), p.auto = (select max(id) from auto where license_plate_no ='京F0180A') where  p.id = 282406 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18665986347'), i.auto = (select max(id) from auto where license_plate_no ='京F0180A')  where p.obj_id = i.quote_record and  p.id = 282406 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18665986347'), i.auto = (select max(id) from auto where license_plate_no ='京F0180A')  where p.obj_id = i.quote_record and p.id =  282406 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18665986347'), qr.auto = (select max(id) from auto where license_plate_no = '京F0180A') where p.obj_id = qr.id and p.id = 282406 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18665986347') where pay.purchase_order = p.id and p.id = 282406 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15139505784', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('113210892', '延长县电力局', 'LSGUD84XXBE075407', '京JCD208', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15139505784'), (select max(id) from auto where license_plate_no = '京JCD208'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15139505784'), p.auto = (select max(id) from auto where license_plate_no ='京JCD208') where  p.id = 282415 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15139505784'), i.auto = (select max(id) from auto where license_plate_no ='京JCD208')  where p.obj_id = i.quote_record and  p.id = 282415 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15139505784'), i.auto = (select max(id) from auto where license_plate_no ='京JCD208')  where p.obj_id = i.quote_record and p.id =  282415 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15139505784'), qr.auto = (select max(id) from auto where license_plate_no = '京JCD208') where p.obj_id = qr.id and p.id = 282415 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15139505784') where pay.purchase_order = p.id and p.id = 282415 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18642534859', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('8A31710957', '余振田', 'LZWACAGA6A1041970', '京H23779', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18642534859'), (select max(id) from auto where license_plate_no = '京H23779'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18642534859'), p.auto = (select max(id) from auto where license_plate_no ='京H23779') where  p.id = 282428 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18642534859'), i.auto = (select max(id) from auto where license_plate_no ='京H23779')  where p.obj_id = i.quote_record and  p.id = 282428 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18642534859'), i.auto = (select max(id) from auto where license_plate_no ='京H23779')  where p.obj_id = i.quote_record and p.id =  282428 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18642534859'), qr.auto = (select max(id) from auto where license_plate_no = '京H23779') where p.obj_id = qr.id and p.id = 282428 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18642534859') where pay.purchase_order = p.id and p.id = 282428 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13796634545', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('CA4DF2-13 50863526', '昆山市张浦镇友谊塑料制品厂', 'LFNA8UCJ67CA06060', '苏EM6922', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13796634545'), (select max(id) from auto where license_plate_no = '苏EM6922'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13796634545'), p.auto = (select max(id) from auto where license_plate_no ='苏EM6922') where  p.id = 282429 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13796634545'), i.auto = (select max(id) from auto where license_plate_no ='苏EM6922')  where p.obj_id = i.quote_record and  p.id = 282429 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13796634545'), i.auto = (select max(id) from auto where license_plate_no ='苏EM6922')  where p.obj_id = i.quote_record and p.id =  282429 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13796634545'), qr.auto = (select max(id) from auto where license_plate_no = '苏EM6922') where p.obj_id = qr.id and p.id = 282429 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13796634545') where pay.purchase_order = p.id and p.id = 282429 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13018731239', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('N52B25BE 00706251', '丁剑', 'LBVNE39046SA98863', '沪FA1538', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13018731239'), (select max(id) from auto where license_plate_no = '沪FA1538'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13018731239'), p.auto = (select max(id) from auto where license_plate_no ='沪FA1538') where  p.id = 282430 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13018731239'), i.auto = (select max(id) from auto where license_plate_no ='沪FA1538')  where p.obj_id = i.quote_record and  p.id = 282430 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13018731239'), i.auto = (select max(id) from auto where license_plate_no ='沪FA1538')  where p.obj_id = i.quote_record and p.id =  282430 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13018731239'), qr.auto = (select max(id) from auto where license_plate_no = '沪FA1538') where p.obj_id = qr.id and p.id = 282430 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13018731239') where pay.purchase_order = p.id and p.id = 282430 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15177460433', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('61090808', '苏州恒泰商贸有限公司', 'LSGWT52X56S135470', '苏E8Y603', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15177460433'), (select max(id) from auto where license_plate_no = '苏E8Y603'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15177460433'), p.auto = (select max(id) from auto where license_plate_no ='苏E8Y603') where  p.id = 282431 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15177460433'), i.auto = (select max(id) from auto where license_plate_no ='苏E8Y603')  where p.obj_id = i.quote_record and  p.id = 282431 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15177460433'), i.auto = (select max(id) from auto where license_plate_no ='苏E8Y603')  where p.obj_id = i.quote_record and p.id =  282431 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15177460433'), qr.auto = (select max(id) from auto where license_plate_no = '苏E8Y603') where p.obj_id = qr.id and p.id = 282431 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15177460433') where pay.purchase_order = p.id and p.id = 282431 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15063095342', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('G2GLBB00152', '深圳市皇庭酒店管理有限公司', 'LL3BDCDF9BA012134', '粤BN4399', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15063095342'), (select max(id) from auto where license_plate_no = '粤BN4399'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15063095342'), p.auto = (select max(id) from auto where license_plate_no ='粤BN4399') where  p.id = 282432 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15063095342'), i.auto = (select max(id) from auto where license_plate_no ='粤BN4399')  where p.obj_id = i.quote_record and  p.id = 282432 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15063095342'), i.auto = (select max(id) from auto where license_plate_no ='粤BN4399')  where p.obj_id = i.quote_record and p.id =  282432 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15063095342'), qr.auto = (select max(id) from auto where license_plate_no = '粤BN4399') where p.obj_id = qr.id and p.id = 282432 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15063095342') where pay.purchase_order = p.id and p.id = 282432 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15971472139', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('604334839', '周春玲', 'LZWACAGA364062099', '京ACU590', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15971472139'), (select max(id) from auto where license_plate_no = '京ACU590'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15971472139'), p.auto = (select max(id) from auto where license_plate_no ='京ACU590') where  p.id = 282433 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15971472139'), i.auto = (select max(id) from auto where license_plate_no ='京ACU590')  where p.obj_id = i.quote_record and  p.id = 282433 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15971472139'), i.auto = (select max(id) from auto where license_plate_no ='京ACU590')  where p.obj_id = i.quote_record and p.id =  282433 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15971472139'), qr.auto = (select max(id) from auto where license_plate_no = '京ACU590') where p.obj_id = qr.id and p.id = 282433 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15971472139') where pay.purchase_order = p.id and p.id = 282433 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13094728620', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('110170131', '中科智控股集团有限公司', 'LSGUD84X1BE013796', '粤BC830K', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13094728620'), (select max(id) from auto where license_plate_no = '粤BC830K'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13094728620'), p.auto = (select max(id) from auto where license_plate_no ='粤BC830K') where  p.id = 282434 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13094728620'), i.auto = (select max(id) from auto where license_plate_no ='粤BC830K')  where p.obj_id = i.quote_record and  p.id = 282434 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13094728620'), i.auto = (select max(id) from auto where license_plate_no ='粤BC830K')  where p.obj_id = i.quote_record and p.id =  282434 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13094728620'), qr.auto = (select max(id) from auto where license_plate_no = '粤BC830K') where p.obj_id = qr.id and p.id = 282434 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13094728620') where pay.purchase_order = p.id and p.id = 282434 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18632848660', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('IUR0051331', '苏州迈科电器有限公司', 'JTHGM46F675013966', '苏EQR295', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18632848660'), (select max(id) from auto where license_plate_no = '苏EQR295'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18632848660'), p.auto = (select max(id) from auto where license_plate_no ='苏EQR295') where  p.id = 282435 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18632848660'), i.auto = (select max(id) from auto where license_plate_no ='苏EQR295')  where p.obj_id = i.quote_record and  p.id = 282435 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18632848660'), i.auto = (select max(id) from auto where license_plate_no ='苏EQR295')  where p.obj_id = i.quote_record and p.id =  282435 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18632848660'), qr.auto = (select max(id) from auto where license_plate_no = '苏EQR295') where p.obj_id = qr.id and p.id = 282435 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18632848660') where pay.purchase_order = p.id and p.id = 282435 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18924178576', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('7002673', '胡传江', 'LDCC43X3260382930', '沪CK0456', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18924178576'), (select max(id) from auto where license_plate_no = '沪CK0456'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18924178576'), p.auto = (select max(id) from auto where license_plate_no ='沪CK0456') where  p.id = 282436 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18924178576'), i.auto = (select max(id) from auto where license_plate_no ='沪CK0456')  where p.obj_id = i.quote_record and  p.id = 282436 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18924178576'), i.auto = (select max(id) from auto where license_plate_no ='沪CK0456')  where p.obj_id = i.quote_record and p.id =  282436 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18924178576'), qr.auto = (select max(id) from auto where license_plate_no = '沪CK0456') where p.obj_id = qr.id and p.id = 282436 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18924178576') where pay.purchase_order = p.id and p.id = 282436 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13510773680', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('AYJ0313063', '太仓水利控股有限公司', 'LSVJH133442173665', '苏EJ8412', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13510773680'), (select max(id) from auto where license_plate_no = '苏EJ8412'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13510773680'), p.auto = (select max(id) from auto where license_plate_no ='苏EJ8412') where  p.id = 282437 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13510773680'), i.auto = (select max(id) from auto where license_plate_no ='苏EJ8412')  where p.obj_id = i.quote_record and  p.id = 282437 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13510773680'), i.auto = (select max(id) from auto where license_plate_no ='苏EJ8412')  where p.obj_id = i.quote_record and p.id =  282437 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13510773680'), qr.auto = (select max(id) from auto where license_plate_no = '苏EJ8412') where p.obj_id = qr.id and p.id = 282437 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13510773680') where pay.purchase_order = p.id and p.id = 282437 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18599030302', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('0304124', '钱洲', 'LSVAU033482313516', '沪BS2010', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18599030302'), (select max(id) from auto where license_plate_no = '沪BS2010'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18599030302'), p.auto = (select max(id) from auto where license_plate_no ='沪BS2010') where  p.id = 282439 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18599030302'), i.auto = (select max(id) from auto where license_plate_no ='沪BS2010')  where p.obj_id = i.quote_record and  p.id = 282439 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18599030302'), i.auto = (select max(id) from auto where license_plate_no ='沪BS2010')  where p.obj_id = i.quote_record and p.id =  282439 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18599030302'), qr.auto = (select max(id) from auto where license_plate_no = '沪BS2010') where p.obj_id = qr.id and p.id = 282439 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18599030302') where pay.purchase_order = p.id and p.id = 282439 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18801537697', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('C006583', '吴江市对外贸易有限公司', 'LTVBG864150035554', '苏ET9906', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18801537697'), (select max(id) from auto where license_plate_no = '苏ET9906'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18801537697'), p.auto = (select max(id) from auto where license_plate_no ='苏ET9906') where  p.id = 282441 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18801537697'), i.auto = (select max(id) from auto where license_plate_no ='苏ET9906')  where p.obj_id = i.quote_record and  p.id = 282441 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18801537697'), i.auto = (select max(id) from auto where license_plate_no ='苏ET9906')  where p.obj_id = i.quote_record and p.id =  282441 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18801537697'), qr.auto = (select max(id) from auto where license_plate_no = '苏ET9906') where p.obj_id = qr.id and p.id = 282441 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18801537697') where pay.purchase_order = p.id and p.id = 282441 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('18049563866', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('Y43140', '深圳绿禾供应链管理有限公司', 'LFPH3ACC5A1E62008', '粤B29532', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '18049563866'), (select max(id) from auto where license_plate_no = '粤B29532'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '18049563866'), p.auto = (select max(id) from auto where license_plate_no ='粤B29532') where  p.id = 282442 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18049563866'), i.auto = (select max(id) from auto where license_plate_no ='粤B29532')  where p.obj_id = i.quote_record and  p.id = 282442 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '18049563866'), i.auto = (select max(id) from auto where license_plate_no ='粤B29532')  where p.obj_id = i.quote_record and p.id =  282442 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '18049563866'), qr.auto = (select max(id) from auto where license_plate_no = '粤B29532') where p.obj_id = qr.id and p.id = 282442 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '18049563866') where pay.purchase_order = p.id and p.id = 282442 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13629957103', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('UCGE7090559', '张晓', 'LJ8F2C5D5EB015524', '京A279WW', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13629957103'), (select max(id) from auto where license_plate_no = '京A279WW'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13629957103'), p.auto = (select max(id) from auto where license_plate_no ='京A279WW') where  p.id = 282449 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13629957103'), i.auto = (select max(id) from auto where license_plate_no ='京A279WW')  where p.obj_id = i.quote_record and  p.id = 282449 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13629957103'), i.auto = (select max(id) from auto where license_plate_no ='京A279WW')  where p.obj_id = i.quote_record and p.id =  282449 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13629957103'), qr.auto = (select max(id) from auto where license_plate_no = '京A279WW') where p.obj_id = qr.id and p.id = 282449 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13629957103') where pay.purchase_order = p.id and p.id = 282449 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15970854538', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('E69T134025', '白长喜', 'LS4AAB3D8EA556989', '京FVG539', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15970854538'), (select max(id) from auto where license_plate_no = '京FVG539'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15970854538'), p.auto = (select max(id) from auto where license_plate_no ='京FVG539') where  p.id = 282457 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15970854538'), i.auto = (select max(id) from auto where license_plate_no ='京FVG539')  where p.obj_id = i.quote_record and  p.id = 282457 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15970854538'), i.auto = (select max(id) from auto where license_plate_no ='京FVG539')  where p.obj_id = i.quote_record and p.id =  282457 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15970854538'), qr.auto = (select max(id) from auto where license_plate_no = '京FVG539') where p.obj_id = qr.id and p.id = 282457 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15970854538') where pay.purchase_order = p.id and p.id = 282457 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15234165006', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('27294631691379', '苏州俄邦工程塑胶有限公司', 'WDDNG5EBXBA372053', '苏E99J58', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15234165006'), (select max(id) from auto where license_plate_no = '苏E99J58'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15234165006'), p.auto = (select max(id) from auto where license_plate_no ='苏E99J58') where  p.id = 282464 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15234165006'), i.auto = (select max(id) from auto where license_plate_no ='苏E99J58')  where p.obj_id = i.quote_record and  p.id = 282464 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15234165006'), i.auto = (select max(id) from auto where license_plate_no ='苏E99J58')  where p.obj_id = i.quote_record and p.id =  282464 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15234165006'), qr.auto = (select max(id) from auto where license_plate_no = '苏E99J58') where p.obj_id = qr.id and p.id = 282464 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15234165006') where pay.purchase_order = p.id and p.id = 282464 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13110957729', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('A61499', '郑功涛', 'LSVAC2NG7DN043298', '京FTT728', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13110957729'), (select max(id) from auto where license_plate_no = '京FTT728'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13110957729'), p.auto = (select max(id) from auto where license_plate_no ='京FTT728') where  p.id = 282475 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13110957729'), i.auto = (select max(id) from auto where license_plate_no ='京FTT728')  where p.obj_id = i.quote_record and  p.id = 282475 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13110957729'), i.auto = (select max(id) from auto where license_plate_no ='京FTT728')  where p.obj_id = i.quote_record and p.id =  282475 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13110957729'), qr.auto = (select max(id) from auto where license_plate_no = '京FTT728') where p.obj_id = qr.id and p.id = 282475 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13110957729') where pay.purchase_order = p.id and p.id = 282475 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15170284213', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('8E70920726', '李均平', 'LZWADAGA7E8127640', '京D1F687', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15170284213'), (select max(id) from auto where license_plate_no = '京D1F687'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15170284213'), p.auto = (select max(id) from auto where license_plate_no ='京D1F687') where  p.id = 282505 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15170284213'), i.auto = (select max(id) from auto where license_plate_no ='京D1F687')  where p.obj_id = i.quote_record and  p.id = 282505 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15170284213'), i.auto = (select max(id) from auto where license_plate_no ='京D1F687')  where p.obj_id = i.quote_record and p.id =  282505 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15170284213'), qr.auto = (select max(id) from auto where license_plate_no = '京D1F687') where p.obj_id = qr.id and p.id = 282505 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15170284213') where pay.purchase_order = p.id and p.id = 282505 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('15049361409', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('210336533', '朱向林', 'LGXC16DF5A0277498', '沪CKY413', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '15049361409'), (select max(id) from auto where license_plate_no = '沪CKY413'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '15049361409'), p.auto = (select max(id) from auto where license_plate_no ='沪CKY413') where  p.id = 282519 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15049361409'), i.auto = (select max(id) from auto where license_plate_no ='沪CKY413')  where p.obj_id = i.quote_record and  p.id = 282519 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '15049361409'), i.auto = (select max(id) from auto where license_plate_no ='沪CKY413')  where p.obj_id = i.quote_record and p.id =  282519 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '15049361409'), qr.auto = (select max(id) from auto where license_plate_no = '沪CKY413') where p.obj_id = qr.id and p.id = 282519 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '15049361409') where pay.purchase_order = p.id and p.id = 282519 and p.audit != 1;
--
INSERT into user (mobile, create_time, audit, bound, user_type) values ('13266647083', '2017-03-01 12:11:10', 10, 1, 1);
INSERT into auto (engine_no, owner, vin_no, license_plate_no, create_time)  values ('527006', '昆山市通茂金属物资有限公司', 'LGBC1AE0X5Y709027', '苏EN5535', '2017-03-01 12:11:10' );
INSERT into user_auto (user, auto) VALUES ((select id from user where mobile = '13266647083'), (select max(id) from auto where license_plate_no = '苏EN5535'));
update  purchase_order p,auto a set  p.applicant = (select id from user where mobile = '13266647083'), p.auto = (select max(id) from auto where license_plate_no ='苏EN5535') where  p.id = 282529 and p.audit != 1;
update insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13266647083'), i.auto = (select max(id) from auto where license_plate_no ='苏EN5535')  where p.obj_id = i.quote_record and  p.id = 282529 and p.audit != 1;
update compulsory_insurance i ,purchase_order p set i.applicant = (select id from user where mobile = '13266647083'), i.auto = (select max(id) from auto where license_plate_no ='苏EN5535')  where p.obj_id = i.quote_record and p.id =  282529 and p.audit != 1;
update quote_record qr, purchase_order p set qr.applicant = (select id from user where mobile = '13266647083'), qr.auto = (select max(id) from auto where license_plate_no = '苏EN5535') where p.obj_id = qr.id and p.id = 282529 and p.audit != 1;
update payment pay, purchase_order p set pay.user =  (select id from user where mobile = '13266647083') where pay.purchase_order = p.id and p.id = 282529 and p.audit != 1;
--
