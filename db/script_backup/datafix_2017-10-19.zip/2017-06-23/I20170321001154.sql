-- 线下复驶 京NU3941，商业险保单号：10200005003301120170000070；2017-05-18--2017-05-31；261.24元；
INSERT INTO `daily_restart_insurance` (`daily_insurance`,`begin_date`,`end_date`,`effective_date`,`expire_date`,`payable_amount`,`discount_amount`,`paid_amount`,`premium`, `status`,`create_time`,`update_time`,`description`,`wechat_payment_called_times`) 
VALUES (523,'2017-05-18','2017-05-31','2017-05-18','2017-05-31',261.24,0,261.24,261.24,
 5,'2017-05-17 22:00:00','2017-05-17 22:00:00','2017-05-17 22:00:00 安心线下提前复驶，手动同步状态',0);

update daily_insurance set restart_date = '2017-05-18',status = '7',description = CONCAT(description, '2017-05-17 22:00:00 安心线下提前复驶，手动同步状态') where id = 523;