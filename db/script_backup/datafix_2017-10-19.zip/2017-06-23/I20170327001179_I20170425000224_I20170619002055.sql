-- I20170327001179	线下退款

-- 更新订单状态
update purchase_order set status = 9 where order_no = 'I20170327001179';
-- 添加退款记录
insert into `payment` (`amount`, `comments`, `create_time`, `update_time`, `channel`, `purchase_order`, `status`, `user`, `client_type`, `out_trade_no`, `upstream_id`, `payment_type`) values ('4370.97', '支付宝', now(), now(), '1', '93701', '2', '2274201', '4', 'I20170327001179', NULL, '1');
-- 更新出单状态
update order_operation_info set original_status = current_status,current_status = 17,update_time = now(),confirm_order_date = now() where purchase_order = (select id from purchase_order where order_no = 'I20170327001179');
-- 添加日志数据
insert into `order_process_history` ( `purchase_order`, `original_status`, `current_status`, `order_process_type`, `comment`, `create_time`, `operator`) values ( (SELECT id FROM purchase_order WHERE order_no = 'I20170327001179'), '5', '17', '1', '订单状态由[订单完成]改变为[退款成功]', now(), '8');


-- I20170425000224	线下退款

-- 更新订单状态
update purchase_order set status = 9 where order_no = 'I20170425000224';
-- 添加退款记录
insert into `payment` (`amount`, `comments`, `create_time`, `update_time`, `channel`, `purchase_order`, `status`, `user`, `client_type`, `out_trade_no`, `upstream_id`, `payment_type`) values ('3026.38', '支付宝', now(), now(), '1', '245053', '2', '364164', '11', 'I20170425000224', NULL, '1');
-- 更新出单状态
update order_operation_info set original_status = current_status,current_status = 17,update_time = now(),confirm_order_date = now() where purchase_order = (select id from purchase_order where order_no = 'I20170425000224');
-- 添加日志数据
insert into `order_process_history` ( `purchase_order`, `original_status`, `current_status`, `order_process_type`, `comment`, `create_time`, `operator`) values ( (SELECT id FROM purchase_order WHERE order_no = 'I20170425000224'), '5', '17', '1', '订单状态由[订单完成]改变为[退款成功]', now(), '8');


-- I20170619002055	线下退款

-- 更新订单状态
update purchase_order set status = 9 where order_no = 'I20170619002055';
-- 添加退款记录
insert into `payment` (`amount`, `comments`, `create_time`, `update_time`, `channel`, `purchase_order`, `status`, `user`, `client_type`, `out_trade_no`, `upstream_id`, `payment_type`) values ('3619.93', '支付宝', now(), now(), '1', '325184', '2', '2746227', '11', 'I20170619002055', NULL, '1');
-- 更新出单状态
update order_operation_info set original_status = current_status,current_status = 17,update_time = now(),confirm_order_date = now() where purchase_order = (select id from purchase_order where order_no = 'I20170619002055');
-- 添加日志数据
insert into `order_process_history` ( `purchase_order`, `original_status`, `current_status`, `order_process_type`, `comment`, `create_time`, `operator`) values ( (SELECT id FROM purchase_order WHERE order_no = 'I20170619002055'), '5', '17', '1', '订单状态由[订单完成]改变为[退款成功]', now(), '8');