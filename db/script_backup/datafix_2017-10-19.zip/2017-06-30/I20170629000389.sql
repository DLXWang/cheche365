-- 应玉万要求，将订单  I20170629000389 转到 2767684 （13720057186）底下 ，请旭威执行以下脚本：

update user_auto set user = 2767684  where auto  = (select po.auto from purchase_order po where po.order_no = 'I20170629000389' );
update address set applicant = 2767684  where id = (select po.delivery_address from purchase_order po where po.order_no = 'I20170629000389' );
update quote_record set applicant = 2767684  where id = (select po.obj_id from purchase_order po where po.order_no = 'I20170629000389' );
update payment set user = 2767684  where purchase_order=(select po.id from purchase_order po where po.order_no = 'I20170629000389' );
update insurance set applicant=2767684  where quote_record=(select po.obj_id from purchase_order po where po.order_no = 'I20170629000389' );
update compulsory_insurance set applicant=2767684  where quote_record=(select po.obj_id from purchase_order po where po.order_no = 'I20170629000389' );
update daily_insurance_offer set user = 2767684   where purchase_order = (select po.id from purchase_order po where po.order_no = 'I20170629000389' );
update purchase_order set applicant = 2767684  where order_no = 'I20170629000389';
