update purchase_order set create_time='2017-05-31 19:05:24' where order_no='I20170701000933';
