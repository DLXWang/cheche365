-- 代理人系统订单支付状态切换I20170703000830(已支付->未支付)  I20170706000278(未支付->已支付)

update purchase_order set status = 1,status_display = NULL where order_no = 'I20170703000830';
update purchase_order set status = 3,status_display = '核保中' where order_no = 'I20170706000278';

update payment set thirdparty_payment_no = null,status = 1, out_trade_no = null, mch_id = null, app_id = null where id = 350757;
update payment set thirdparty_payment_no = '4005532001201707038658384541',status = 2,out_trade_no = 'I20170703000830Z001', mch_id = '1232068902', app_id = 'wxcf02994504264506' where id = 350986;

-- 更新出单状态

update order_operation_info
set original_status = current_status,current_status = 1,update_time = now(),confirm_order_date = now()
where purchase_order = (select id from purchase_order where order_no = 'I20170706000278');

update order_operation_info
set original_status = NULL,current_status = 20,update_time = now(),confirm_order_date = now()
where purchase_order = (select id from purchase_order where order_no = 'I20170703000830');
