update user set bound = 0 where id = 2006664;
