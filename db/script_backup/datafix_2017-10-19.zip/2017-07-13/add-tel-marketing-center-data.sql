INSERT INTO tel_marketing_center (
	mobile,
	priority,
	expire_time,
	create_time,
	update_time,
	user_name,
	STATUS,
	source,
	display,
	source_create_time
)
SELECT
	vc.mobile,
	1,
	vl.enroll_date,
	now(),
	now(),
	vl.OWNER,
	1,
	41,
	1,
	vc.create_time
FROM
	vehicle_contact vc
JOIN vehicle_license vl ON vc.vehicle_license = vl.id
WHERE
	MONTH (vl.enroll_date) = '08'
AND NOT EXISTS (
	SELECT
		1
	FROM
		tel_marketing_center tmc
	WHERE
		vc.mobile = tmc.mobile
)
LIMIT 10000;




INSERT INTO tel_marketing_center_repeat (
	mobile,
	create_time,
	user_name,
	source,
	source_create_time
) SELECT
	mobile,
	create_time,
	user_name,
	source,
	source_create_time
FROM
	tel_marketing_center
WHERE
	source = 41
AND TO_DAYS(create_time) = TO_DAYS(now());



INSERT INTO tel_marketing_center_history (
	tel_marketing_center,
	deal_result,
	create_time,
	COMMENT,
	operator,
	type,
	STATUS
) SELECT
	DISTINCT tmc.id,
	'其他',
	now(),
	concat(
		'车牌:',
		vl.license_plate_no,
		'发动机号:',
		vl.engine_no,
		'车架号:',
		vin_no,
		'初登日期',
		vl.enroll_date,
		'车主身份证',
		vl.identity ,
		'品牌型号',
		vl.brand_code
	),
	8,
	5,
	1
FROM
	tel_marketing_center tmc
JOIN vehicle_contact vc ON vc.mobile = tmc.mobile
JOIN vehicle_license vl ON vc.vehicle_license = vl.id
WHERE
	tmc.source = 41
AND TO_DAYS(tmc.create_time) = TO_DAYS(now());
