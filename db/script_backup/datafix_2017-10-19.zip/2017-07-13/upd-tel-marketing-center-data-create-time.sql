update tel_marketing_center_repeat tmcr set tmcr.create_time =now() where tmcr.source=41 and TO_DAYS(tmcr.create_time) = TO_DAYS(now());
