--订单I20170707001728  投保人、被保人变更为 :王冰  110103197710120915
UPDATE insurance SET insured_name='王冰', applicant_name='王冰', applicant_id_no='110103197710120915', insured_id_no='110103197710120915' WHERE quote_record=(SELECT obj_id FROM purchase_order WHERE order_no = 'I20170707001728');
UPDATE compulsory_insurance SET insured_name='王冰', applicant_name='王冰', applicant_id_no='110103197710120915', insured_id_no='110103197710120915' WHERE quote_record=(SELECT obj_id FROM purchase_order WHERE order_no = 'I20170707001728');
--订单I20170617000783 修改车主、投保人、被保人身份证号码：440507197905160013
UPDATE insurance SET applicant_id_no='440507197905160013', insured_id_no='440507197905160013' WHERE quote_record=(SELECT obj_id FROM purchase_order WHERE order_no = 'I20170617000783');
UPDATE compulsory_insurance SET applicant_id_no='440507197905160013', insured_id_no='440507197905160013' WHERE quote_record=(SELECT obj_id FROM purchase_order WHERE order_no = 'I20170617000783');
UPDATE auto SET identity='440507197905160013' WHERE id = (SELECT auto FROM purchase_order WHERE order_no = 'I20170617000783');
--订单I20170613001517 修改被保险人身份证：110101196111214525
UPDATE insurance SET insured_id_no='110101196111214525' WHERE quote_record=(SELECT obj_id FROM purchase_order WHERE order_no = 'I20170613001517');
UPDATE compulsory_insurance SET insured_id_no='110101196111214525' WHERE quote_record=(SELECT obj_id FROM purchase_order WHERE order_no = 'I20170613001517');
-- 订单I20170322002274 修改车牌：京N5D212,车主姓名：武元，车主身份证号：610103198301233217
UPDATE auto SET license_plate_no='京N5D212',owner='武元',identity='610103198301233217' WHERE id = (SELECT auto FROM purchase_order WHERE order_no = 'I20170322002274');
--订单I20170630000985  初登日期修改为：2015年8月4日
UPDATE auto SET enroll_date='2015-08-04' WHERE id = (SELECT auto FROM purchase_order WHERE order_no = 'I20170630000985');