UPDATE `insurance` SET `proportion`='1' WHERE `id`='220309';
UPDATE `insurance` SET `proportion`='1' WHERE `id`='220351';
UPDATE `insurance` SET `proportion`='1' WHERE `id`='221136';