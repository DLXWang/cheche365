UPDATE `bank` SET `short_name`='COMM' WHERE `id`='5';
UPDATE `bank` SET `short_name`='BJB' WHERE `id`='10';
