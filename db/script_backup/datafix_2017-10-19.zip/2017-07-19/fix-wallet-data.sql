update wallet set balance=0,unbalance=0 where balance < 0 and (balance + unbalance) = 0 ;
update wallet set balance=6.89,unbalance=0 where user_id=1009417;
update wallet set balance=9.82,unbalance=0 where user_id=1085142;
update wallet set balance=6.96,unbalance=0 where user_id=2435388;