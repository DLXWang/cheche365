UPDATE `sms_template` SET `content`='尊敬的用户，您的车辆${Auto.LicensePlateNo}已成功投保车车按天车险，您可以下载车车app http://www.cheche365.com/m/share.html ，进入首页设置您的停驶计划。如有问题请咨询 4000-150-999' WHERE (`id`='212');
UPDATE `sms_template` SET `content`='您成功领取了按天车险体验金，购买按天买车险后，返还现金给您的账户！建议下载车车app http://www.cheche365.com/m/share.html ，购买并设置停驶计划。只要停驶就返钱，最多363天！如有问题请咨询 4000-150-999' WHERE (`id`='213');
UPDATE `sms_template` SET `content`='尊敬的用户，您的车辆${Auto.LicensePlateNo}已成功投保停驶返钱车险，您可以下载车车app http://www.cheche365.com/m/share.html ，登录后在首页可看到车辆状态，点击进入可设置停驶，就能收到钱啦！如有问题请咨询 4000-150-999' WHERE (`id`='215');
