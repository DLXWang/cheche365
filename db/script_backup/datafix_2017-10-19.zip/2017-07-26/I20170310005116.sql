update order_operation_info set original_status=current_status,current_status=15 where purchase_order =92676;

insert into order_process_history ( purchase_order, original_status, current_status, order_process_type, comment, create_time, operator) values ( '92676', '1', '15', '1', '订单状态由[未确认]改变为[录单完成]', now(), '8');
                                                                                                                                                 

