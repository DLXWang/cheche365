update order_operation_info set original_status=current_status,current_status=15 where purchase_order =91898;
update order_operation_info set original_status=current_status,current_status=15 where purchase_order =92407;
update order_operation_info set original_status=current_status,current_status=15 where purchase_order =92490;
update order_operation_info set original_status=current_status,current_status=15 where purchase_order =93174;
update order_operation_info set original_status=current_status,current_status=15 where purchase_order =93346;
update order_operation_info set original_status=current_status,current_status=15 where purchase_order =93387;
update order_operation_info set original_status=current_status,current_status=15 where purchase_order =93604;
update order_operation_info set original_status=current_status,current_status=15 where purchase_order =93641;
update order_operation_info set original_status=current_status,current_status=15 where purchase_order =243565;
update order_operation_info set original_status=current_status,current_status=15 where purchase_order =282688;
update order_operation_info set original_status=current_status,current_status=15 where purchase_order =282722;
update order_operation_info set original_status=current_status,current_status=15 where purchase_order =283144;
update order_operation_info set original_status=current_status,current_status=15 where purchase_order =283160;
update order_operation_info set original_status=current_status,current_status=15 where purchase_order =283186;
update order_operation_info set original_status=current_status,current_status=15 where purchase_order =320636;
update order_operation_info set original_status=current_status,current_status=15 where purchase_order =323668;

insert into order_process_history ( purchase_order, original_status, current_status, order_process_type, comment, create_time, operator) values ( '91898', '1', '15', '1', '订单状态由[未确认]改变为[录单完成]', now(), '8');
insert into order_process_history ( purchase_order, original_status, current_status, order_process_type, comment, create_time, operator) values ( '92407', '1', '15', '1', '订单状态由[未确认]改变为[录单完成]', now(), '8');
insert into order_process_history ( purchase_order, original_status, current_status, order_process_type, comment, create_time, operator) values ( '92490', '1', '15', '1', '订单状态由[未确认]改变为[录单完成]', now(), '8');
insert into order_process_history ( purchase_order, original_status, current_status, order_process_type, comment, create_time, operator) values ( '93174', '1', '15', '1', '订单状态由[未确认]改变为[录单完成]', now(), '8');
insert into order_process_history ( purchase_order, original_status, current_status, order_process_type, comment, create_time, operator) values ( '93346', '1', '15', '1', '订单状态由[未确认]改变为[录单完成]', now(), '8');
insert into order_process_history ( purchase_order, original_status, current_status, order_process_type, comment, create_time, operator) values ( '93387', '1', '15', '1', '订单状态由[未确认]改变为[录单完成]', now(), '8');
insert into order_process_history ( purchase_order, original_status, current_status, order_process_type, comment, create_time, operator) values ( '93604', '1', '15', '1', '订单状态由[未确认]改变为[录单完成]', now(), '8');
insert into order_process_history ( purchase_order, original_status, current_status, order_process_type, comment, create_time, operator) values ( '93641', '1', '15', '1', '订单状态由[未确认]改变为[录单完成]', now(), '8');
insert into order_process_history ( purchase_order, original_status, current_status, order_process_type, comment, create_time, operator) values ( '243565', '1', '15', '1', '订单状态由[未确认]改变为[录单完成]', now(), '8');
insert into order_process_history ( purchase_order, original_status, current_status, order_process_type, comment, create_time, operator) values ( '282688', '1', '15', '1', '订单状态由[未确认]改变为[录单完成]', now(), '8');
insert into order_process_history ( purchase_order, original_status, current_status, order_process_type, comment, create_time, operator) values ( '282722', '1', '15', '1', '订单状态由[未确认]改变为[录单完成]', now(), '8');
insert into order_process_history ( purchase_order, original_status, current_status, order_process_type, comment, create_time, operator) values ( '283144', '1', '15', '1', '订单状态由[未确认]改变为[录单完成]', now(), '8');
insert into order_process_history ( purchase_order, original_status, current_status, order_process_type, comment, create_time, operator) values ( '283160', '1', '15', '1', '订单状态由[未确认]改变为[录单完成]', now(), '8');
insert into order_process_history ( purchase_order, original_status, current_status, order_process_type, comment, create_time, operator) values ( '283186', '1', '15', '1', '订单状态由[未确认]改变为[录单完成]', now(), '8');
insert into order_process_history ( purchase_order, original_status, current_status, order_process_type, comment, create_time, operator) values ( '320636', '1', '15', '1', '订单状态由[未确认]改变为[录单完成]', now(), '8');
insert into order_process_history ( purchase_order, original_status, current_status, order_process_type, comment, create_time, operator) values ( '323668', '1', '15', '1', '订单状态由[未确认]改变为[录单完成]', now(), '8');
                                                                                                                                                   

