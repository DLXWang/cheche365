-- ����Ϊ�û��б�ʧ�ܵĶ�����Ϣ����
-- ���±�����
update compulsory_insurance set proposal_no = '00200005003000120170059548',policy_no = '10200005003000120170005277' where quote_record =  (select obj_id from purchase_order where order_no = 'I20170728000421');
update insurance set proposal_no = '00200005003301120170064146',policy_no = '10200005003301120170003897' where quote_record = (select obj_id from purchase_order where order_no = 'I20170728000421');

-- ���¶���״̬
update purchase_order set status = 5 where order_no = 'I20170728000421';
-- ���³���״̬
update order_operation_info set original_status = current_status,current_status = 15,update_time = now(),confirm_order_date = now() where purchase_order = (select id from purchase_order where order_no = 'I20170728000421');