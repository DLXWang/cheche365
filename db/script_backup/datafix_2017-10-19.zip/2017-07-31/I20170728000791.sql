delete from purchase_order_image where obj_id = 413023;

delete from purchase_order_image_status where purchase_order = 413023;

insert into purchase_order_image(image_scene,image_type,obj_id,create_time,update_time,channel,source,status,url)
values(null,4001,413023,'2017-07-31 12:00:00','2017-07-31 12:00:00',11,1,0,'');

insert into purchase_order_image(image_scene,image_type,obj_id,create_time,update_time,channel,source,status,url)
values(null,4002,413023,'2017-07-31 12:00:00','2017-07-31 12:00:00',11,1,0,'');

insert into purchase_order_image(image_scene,image_type,obj_id,create_time,update_time,channel,source,status,url)
values(null,4025,413023,'2017-07-31 12:00:00','2017-07-31 12:00:00',11,1,0,'');

insert into purchase_order_image(image_scene,image_type,obj_id,create_time,update_time,channel,source,status,url)
values(null,4026,413023,'2017-07-31 12:00:00','2017-07-31 12:00:00',11,1,0,'');

insert into purchase_order_image(image_scene,image_type,obj_id,create_time,update_time,channel,source,status,url)
values(null,4028,413023,'2017-07-31 12:00:00','2017-07-31 12:00:00',11,1,0,'');

insert into purchase_order_image(image_scene,image_type,obj_id,create_time,update_time,channel,source,status,url)
values(null,4029,413023,'2017-07-31 12:00:00','2017-07-31 12:00:00',11,1,0,'');

 update purchase_order set status_display = '核保中(需完善信息)' where id = 413023;
