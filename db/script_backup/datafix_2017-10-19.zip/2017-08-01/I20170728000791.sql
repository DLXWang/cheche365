update purchase_order set status = 5,status_display = null where order_no = 'I20170728000791';
update insurance set policy_no = 'ASUZ530Y1417B047528J' where quote_record = (select obj_id from purchase_order where order_no = 'I20170728000791');
update compulsory_insurance set policy_no = 'ASUZ530CTP17B048910B' where quote_record = (select obj_id from purchase_order where order_no = 'I20170728000791');
update order_operation_info set original_status = current_status,current_status = 15,update_time = now(),confirm_order_date = now() where purchase_order = (select id from purchase_order where order_no = 'I20170728000791');
