update wechat_user_info set user = null where id = 263665;
