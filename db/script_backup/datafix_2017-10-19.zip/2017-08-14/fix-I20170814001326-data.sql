-- 车车为用户承保失败的订单信息更新
-- 更新保单号
update compulsory_insurance set policy_no = '10200005003000120170005709' where quote_record =  (select obj_id from purchase_order where order_no = 'I20170814001326');
update insurance set policy_no = '10200005003301120170004331' where quote_record = (select obj_id from purchase_order where order_no = 'I20170814001326');

-- 更新订单状态,支付状态
update purchase_order set status = 5 where order_no = 'I20170814001326';
update payment set status = 2 where purchase_order = (select id from purchase_order where order_no = 'I20170814001326');
-- 更新出单状态
update order_operation_info set original_status = current_status,current_status = 15,update_time = now(),confirm_order_date = now() where purchase_order = (select id from purchase_order where order_no = 'I20170814001326');