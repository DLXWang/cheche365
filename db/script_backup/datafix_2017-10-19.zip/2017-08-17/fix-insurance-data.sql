update insurance set proportion=0.5 where quote_record = (select  obj_id from purchase_order where order_no='I20170815002051');
update insurance set proportion=0.5 where quote_record = (select  obj_id from purchase_order where order_no='I20170814002128');
update insurance set proportion=0.5 where quote_record = (select  obj_id from purchase_order where order_no='I20170814001326');
update insurance set proportion=0.5 where quote_record = (select  obj_id from purchase_order where order_no='I20170811000164');
update insurance set proportion=0.5 where quote_record = (select  obj_id from purchase_order where order_no='I20170809001600');
update insurance set proportion=0.5 where quote_record = (select  obj_id from purchase_order where order_no='I20170807000645');
update insurance set proportion=0.5 where quote_record = (select  obj_id from purchase_order where order_no='I20170728000421');