update order_operation_info set original_status=current_status,current_status=1 where purchase_order=413967;
insert into order_process_history ( purchase_order, original_status, current_status, order_process_type, comment, create_time, operator) values ( '413967', '22', '1', '1', '订单状态由[追加付款中]改变为[未确认]', now(), '8');
