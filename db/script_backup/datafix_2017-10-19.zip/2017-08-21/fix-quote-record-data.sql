update quote_record set channel=8 where channel is null;
