-- 车车为用户承保失败的订单信息更新
-- 更新保单号
update compulsory_insurance set proposal_no = '00200005003000120170085361',policy_no = '10200005003000120170006126' where quote_record =  (select obj_id from purchase_order where order_no = 'I20170827000884');
update insurance set proposal_no = '00200005003301120170092601',policy_no = '10200005003301120170004673',proportion=0.50 where quote_record = (select obj_id from purchase_order where order_no = 'I20170827000884');

-- 更新订单状态,支付状态
update purchase_order set status = 5 where order_no = 'I20170827000884';
update payment set status = 2,thirdparty_payment_no='4008882001201708288676629646' where purchase_order = (select id from purchase_order where order_no = 'I20170827000884');
-- 更新出单状态
update order_operation_info set original_status = current_status,current_status = 15,update_time = now(),confirm_order_date = now() where purchase_order = (select id from purchase_order where order_no = 'I20170827000884');