INSERT INTO `wallet_trade` (`wallet_id`,`user_id`,`trade_no`,`trade_date`,`trade_flag`,`trade_type`,`trade_source_id`,`status`,
	`amount`,`trade_fee`,`balance`,`remark`,`channel`,`create_time`,`update_time`)
VALUES (888,378123,'T17082816455635628','2017-08-28 16:45:56',1,4,414433,2,
	719.00,0.00,719.00,NULL,67,'2017-08-28 16:45:56',NULL);
UPDATE `wallet` SET `balance`= 719.00 WHERE id = 888;
