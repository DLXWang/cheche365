INSERT INTO `wallet_trade` (`wallet_id`,`user_id`,`trade_no`,`trade_date`,`trade_flag`,`trade_type`,`trade_source_id`,`status`,
	`amount`,`trade_fee`,`balance`,`remark`,`channel`,`create_time`,`update_time`)
VALUES (856,368152,'T17090117414902609','2017-09-01 17:41:49',1,4,414744,2,
	2018.87,0.00,2018.87,NULL,67,'2017-09-01 17:41:49',NULL);
UPDATE `wallet` SET `balance`= 2018.87 WHERE id = 856;