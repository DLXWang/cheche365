INSERT INTO `wallet_trade` (`wallet_id`,`user_id`,`trade_no`,`trade_date`,`trade_flag`,`trade_type`,`trade_source_id`,`status`,
	`amount`,`trade_fee`,`balance`,`remark`,`channel`,`create_time`,`update_time`)
VALUES (710,368152,'T17090415114902571','2017-09-04 15:11:49',1,4,414829,2,
	1395.09,0.00,1395.09,NULL,NULL,'2017-09-04 15:11:49',NULL);
UPDATE `wallet` SET `balance`= 1395.09 WHERE id = 710;