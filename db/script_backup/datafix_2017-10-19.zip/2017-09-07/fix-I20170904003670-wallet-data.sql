INSERT INTO `wallet_trade` (`wallet_id`,`user_id`,`trade_no`,`trade_date`,`trade_flag`,`trade_type`,`trade_source_id`,`status`,
	`amount`,`trade_fee`,`balance`,`remark`,`channel`,`create_time`,`update_time`)
VALUES (1177,2925311,'T17090417011303670','2017-09-04 17:01:13',1,4,414850,2,
	302.64,0.00,302.64,NULL,67,'2017-09-04 17:01:13',NULL);
UPDATE `wallet` SET `balance`= 302.64 WHERE id = 1177;