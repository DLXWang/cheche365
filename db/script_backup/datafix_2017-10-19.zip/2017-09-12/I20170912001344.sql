update purchase_order set applicant=348312 where id=415259;
update payment set `user`=348312 where purchase_order=415259;
update quote_record set `applicant`=348312 ,owner_mobile='18510666660' where id=460490;
delete from  order_agent where purchase_order=415259;
update insurance_purchase_order_rebate set up_commercial_amount=0 ,up_commercial_rebate=0,up_compulsory_amount=0,up_compulsory_rebate=0 where purchase_order=415259;
update user_auto set user=348312 where auto=924680;
update insurance set applicant=348312 where quote_record=460490;
update compulsory_insurance set applicant=348312 where quote_record=460490;