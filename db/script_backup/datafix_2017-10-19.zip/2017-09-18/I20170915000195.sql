update order_operation_info set original_status = current_status,current_status = 1,update_time = now()  where purchase_order = 415394;
update purchase_order set status=3 where id=415394;
