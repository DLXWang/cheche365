update user set mobile = null, bound = 0 where mobile = '18921321589';
delete from partner_order_sync where partner_order = 15944;
delete from partner_order where partner_user_id = 650506;
delete from partner_user where user = 2366545;
delete from wechat_user_channel where wechat_user_info = 264748;
delete from wechat_user_info where user = 2366545;
