INSERT INTO `wallet_trade` (`wallet_id`,`user_id`,`trade_no`,`trade_date`,`trade_flag`,`trade_type`,`trade_source_id`,`status`,
	`amount`,`trade_fee`,`balance`,`remark`,`channel`,`create_time`,`update_time`)
VALUES (710,368152,'T17090515065401492','2017-09-05 15:06:54',1,4,414890,2,
	1233.44,0.00,1233.44,NULL,NULL,'2017-09-05 15:06:54',NULL);	
UPDATE `wallet` SET `balance`= 1233.44 WHERE id = 710;