INSERT INTO `wallet_trade` (`wallet_id`,`user_id`,`trade_no`,`trade_date`,`trade_flag`,`trade_type`,`trade_source_id`,`status`,
	`amount`,`trade_fee`,`balance`,`remark`,`channel`,`create_time`,`update_time`)
VALUES (710,368152,'T17090710575800721','2017-09-07 10:57:58',1,4,414990,2,
	1044.42,0.00,1044.42,NULL,NULL,'2017-09-07 10:57:58',NULL);	
UPDATE `wallet` SET `balance`= 1044.42 WHERE id = 710;