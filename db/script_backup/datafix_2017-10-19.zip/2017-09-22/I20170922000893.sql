UPDATE `purchase_order` SET `paid_amount`='2510.43', `payable_amount`='2510.43', `update_time`=now()  WHERE `id`='415769';
UPDATE `payment` SET `amount`='2510.43' where `purchase_order` ='415769';
