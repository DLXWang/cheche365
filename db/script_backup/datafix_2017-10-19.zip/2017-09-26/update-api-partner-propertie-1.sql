update api_partner_properties set `value`='cad7-4197-b0d9-4ddc6df1de2d' where `key`='production.sync.app.secret' and partner=3;
