update api_partner_properties set `value`='8231-44af-8d53-e624f0433949' where `key`='production.sync.app.secret' and partner=3;
