update `order_operation_info` set `owner`=23 where `purchase_order`=416001;
update `payment` set `amount`=1960.79 where `id`=442239;
update `payment` set `status`=2 where `id`=442240;
update `purchase_order` set `paid_amount`=1960.79 where `id`=416001;
insert into `purchase_order_gift` (`purchase_order`,`gift`,`given_after_order`) values(416001,203425,0);
update `gift` set `status`=3 where `id`=203425;