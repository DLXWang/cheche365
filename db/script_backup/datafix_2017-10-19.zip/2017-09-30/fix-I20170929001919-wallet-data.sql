INSERT INTO `wallet_trade` (`wallet_id`,`user_id`,`trade_no`,`trade_date`,`trade_flag`,`trade_type`,`trade_source_id`,`status`,
	`amount`,`trade_fee`,`balance`,`remark`,`channel`,`create_time`,`update_time`)
VALUES (1177,2925311,'T17093012000023721','2017-09-30 12:00:00',1,4,416168,2,
	325.31,0.00,325.31,NULL,NULL,'2017-09-30 12:00:00',NULL);
UPDATE `wallet` SET `balance`= 325.31 WHERE id = 1177;
