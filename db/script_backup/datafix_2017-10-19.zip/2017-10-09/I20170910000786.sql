-- I20170910000786	线下退款

-- 更新订单状态
update purchase_order set status = 9 where order_no = 'I20170910000786';
-- 添加退款记录
insert into `payment` (`amount`, `comments`, `create_time`, `update_time`, `channel`, `purchase_order`, `status`, `user`, `client_type`, `out_trade_no`, `upstream_id`, `payment_type`) values ('1477.06', '支付宝', '2017-09-29 16:00:00', now(), '1', '415160', '2', '1891112', '11', NULL, NULL, '1');
-- 更新出单状态
update order_operation_info set original_status = current_status,current_status = 17,update_time = now(),confirm_order_date = now() where purchase_order = (select id from purchase_order where order_no = 'I20170910000786');
-- 添加日志数据
insert into `order_process_history` ( `purchase_order`, `original_status`, `current_status`, `order_process_type`, `comment`, `create_time`, `operator`) values ( (SELECT id FROM purchase_order WHERE order_no = 'I20170910000786'), '5', '17', '1', '订单状态由[订单完成]改变为[退款成功]', now(), '8');
