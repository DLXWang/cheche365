INSERT INTO `wallet_trade` (`wallet_id`,`user_id`,`trade_no`,`trade_date`,`trade_flag`,`trade_type`,`trade_source_id`,`status`,`amount`,`trade_fee`,`balance`,
	`remark`,`channel`,`create_time`)
VALUES (710,368152,'T17101012000000721','2017-10-10 12:00:00',0,5,2484,2,503.12,0.00,541.30,
	'9月4号由于安心订单未返代理费，手动添加脚本，未扣税费，手动将9月税费一并扣除',68,'2017-10-10 12:00:00');

update wallet set balance = 541.30,update_time = '2017-10-10 12:00:00' where id = 710;
