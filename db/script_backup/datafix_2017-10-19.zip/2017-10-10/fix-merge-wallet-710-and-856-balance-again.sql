-- 新加的扣税记录没有合并过去
update wallet_trade set wallet_id = 856, channel = 67 where  wallet_id = 710 and id in (1888,2475,2476,2477,2484,3407);
