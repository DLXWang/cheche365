-- 新加的扣税记录时间为9月份
update wallet_trade
set trade_date = '2017-09-30 12:00:00', create_time = '2017-09-30 12:00:00'
where id  = 3407;
