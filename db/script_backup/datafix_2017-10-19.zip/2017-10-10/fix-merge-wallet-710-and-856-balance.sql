update wallet set balance = 0.00,update_time = '2017-10-10 12:00:00' where id = 710;
update wallet set balance = 541.30,update_time = '2017-10-10 12:00:00' where id = 856;
update wallet_trade set wallet_id = 856, channel = 67 where  wallet_id = 710 and id in (1888,2475,2476,2477,2484);
