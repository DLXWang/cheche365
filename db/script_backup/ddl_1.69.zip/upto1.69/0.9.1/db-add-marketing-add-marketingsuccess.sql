CREATE TABLE IF NOT EXISTS `marketing` (
  `id` bigint(20) NOT NULL COMMENT '营销活动主表',
  `name` varchar(100) NOT NULL,
  `code` varchar(9) NOT NULL,
  `begin_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `valid_month` int(3) NOT NULL,
  `channel` varchar(100) DEFAULT NULL,
  `value` decimal(18,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of marketing
-- ----------------------------
INSERT INTO `marketing` VALUES ('1', '2015年4月送代金券', '201504001', '2015-05-01 00:00:00', '2015-05-31 23:59:59', '12', null, '100.00');

-- ----------------------------
-- Table structure for `marketing_success`
-- ----------------------------
CREATE TABLE IF NOT EXISTS `marketing_success` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `marketing_id` bigint(20) NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `mobile` varchar(11) COLLATE utf8_bin DEFAULT NULL,
  `effect_date` datetime NOT NULL,
  `failure_date` datetime NOT NULL,
  `value` decimal(18,2) DEFAULT NULL,
  `max_use_count` int(5) NOT NULL,
  `used_count` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of marketing_success
-- ----------------------------
