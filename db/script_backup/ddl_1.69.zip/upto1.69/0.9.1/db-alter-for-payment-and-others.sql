
-- 为auto表添加是否可用标记位
ALTER TABLE  `auto`
ADD COLUMN `disable` TINYINT(1) NULL DEFAULT 0 AFTER `update_time`;


-- 为address表添加是否可用标记位
ALTER TABLE  `address`
ADD COLUMN `disable` TINYINT(1) NULL DEFAULT 0 AFTER `area`;

-- 修改purchase_order表，将原金额字段拆成应付金额和实付金额两个字段
ALTER TABLE `purchase_order`
CHANGE COLUMN `amount` `payable_amount` DECIMAL(18,2) NULL DEFAULT NULL COMMENT '应付金额' ,
ADD COLUMN `paid_amount` DECIMAL(18,2) NULL COMMENT '实付金额' AFTER `payable_amount`;

INSERT INTO  `payment_channel` (`id`, `channel`, `description`) VALUES ('8', '代金券抵扣', '使用代金券支付部分订单金额');


-- 为purchase_order表添加对channel 表的外键关联，以纪录不同渠道所下订单
ALTER TABLE  `purchase_order`
ADD COLUMN `source_channel` BIGINT(20) NULL AFTER `channel`,
ADD INDEX `FK_PURCHASE_ORDER_REF_CHANNEL_idx` (`source_channel` ASC);
ALTER TABLE  `purchase_order`
ADD CONSTRAINT `FK_PURCHASE_ORDER_REF_CHANNEL`
  FOREIGN KEY (`source_channel`)
  REFERENCES  `channel` (`id`)
  ON DELETE RESTRICT
  ON UPDATE RESTRICT;

-- 为quote表添加对channel 表的外键关联，以纪录不同渠道所下报价
ALTER TABLE  `quote`
ADD COLUMN `source_channel` BIGINT(20) NULL AFTER `status`,
ADD INDEX `FK_QUOTE_REF_CHANNEL_idx` (`source_channel` ASC);
ALTER TABLE  `quote`
ADD CONSTRAINT `FK_QUOTE_REF_CHANNEL`
  FOREIGN KEY (`source_channel`)
  REFERENCES  `channel` (`id`)
  ON DELETE RESTRICT
  ON UPDATE RESTRICT;

-- 添加更多渠道
UPDATE  `channel` SET `description`='微信公众号', `name`='微信' WHERE `id`='3';
INSERT INTO  `channel` (`description`, `name`) VALUES ('IOS相关设备', 'IOS');
INSERT INTO  `channel` (`description`, `name`) VALUES ('PC版应用', 'PC');
INSERT INTO  `channel` (`description`, `name`) VALUES ('ANDROID相关设备', 'ANDROID');
INSERT INTO  `channel` (`description`, `name`) VALUES ('其他', '其他');

-- 添加礼物类型，代金券
INSERT INTO `gift_type` (`id`, `name`, `description`) VALUES ('3', '代金券', '代金券');
