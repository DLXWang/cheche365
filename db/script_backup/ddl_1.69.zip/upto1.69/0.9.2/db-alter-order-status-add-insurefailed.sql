
-- 添加核保失败状态
INSERT INTO `order_status` (`description`, `status`) VALUES ('核保失败', '核保失败');


-- 修改application_log， log_message字段长度
ALTER TABLE `application_log`
CHANGE COLUMN `log_message` `log_message` TEXT NULL DEFAULT NULL ;


-- 创建log_type表
CREATE TABLE IF NOT EXISTS `log_type` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(20) NOT NULL,
  `description` VARCHAR(45)  NOT NULL,
  PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 添加log type纪录
INSERT INTO `log_type` (`name`, `description`) VALUES ('核保失败', '核保失败');


  ALTER TABLE `application_log`
  ADD COLUMN `log_type` BIGINT(20) NULL DEFAULT NULL AFTER `log_message`,
  ADD INDEX `FK_APPLICATION_LOG_REF_LOG_TYPE` (`log_type` ASC);
  ALTER TABLE `application_log`
  ADD CONSTRAINT `FK_APPLICATION_LOG_REF_LOG_TYPE`
    FOREIGN KEY (`log_type`)
    REFERENCES `log_type` (`id`)
    ON DELETE RESTRICT
    ON UPDATE RESTRICT;
