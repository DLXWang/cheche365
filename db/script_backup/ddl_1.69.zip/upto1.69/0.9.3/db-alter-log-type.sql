INSERT INTO `log_type` (`name`, `description`) VALUES ('商业险套餐变更', '商业险套餐变更');
INSERT INTO `log_type` (`name`, `description`) VALUES ('交强险套餐变更', '交强险套餐变更');
INSERT INTO `log_type` (`name`, `description`) VALUES ('出单状态变更', '出单状态变更');
