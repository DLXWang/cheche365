insert into internal_user (email, name, user_id, password) values ('18611403703@163.com', '朱俊', 'zhujun', '8658758c03e472ea4b335b05a9f77046');

insert into internal_user (email, name, user_id, password) values ('13699296638@163.com', '周丹', 'zhoudan', '6f9416ce228a2769ca0346b0e7a3b51b');

insert into internal_user (email, name, user_id, password) values ('18611437037@163.com', '王美娜', 'wangmn', '403547aea70113db8b79dd06726592dd');
