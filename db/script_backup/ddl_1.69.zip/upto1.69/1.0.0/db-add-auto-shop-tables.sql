CREATE TABLE IF NOT EXISTS `auto_shop_address` (
    `id` bigint(20) NOT NULL AUTO_INCREMENT,
    `city` varchar(45) DEFAULT NULL,
    `district` varchar(45) DEFAULT NULL,
    `mobile` varchar(45) DEFAULT NULL,
    `name` varchar(45) DEFAULT NULL,
    `postalcode` varchar(6) DEFAULT NULL,
    `province` varchar(45) DEFAULT NULL,
    `street` varchar(400) DEFAULT NULL,
    `telephone` varchar(45) DEFAULT NULL,
    `area` bigint(20) DEFAULT NULL,
    `disable` tinyint(1) DEFAULT '0',
    PRIMARY KEY (`id`),
    KEY `FK_AUTO_SHOP_ADDRESS_REF_AREA` (`area`),
    CONSTRAINT `FK_AUTO_SHOP_ADDRESS_REF_AREA` FOREIGN KEY (`area`) REFERENCES `area` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `auto_shop` (
    `id` bigint(20) NOT NULL AUTO_INCREMENT,
    `name` varchar(200) NOT NULL,
    `address` bigint(20) NOT NULL,
    `description` varchar(2000) DEFAULT NULL,
    `longitude` decimal(18,6) DEFAULT NULL,
    `latitude` decimal(18,6) DEFAULT NULL,
    `altitude` decimal(18,6) DEFAULT NULL,
    `reserve_service_phone` varchar(45) DEFAULT NULL,
    `contact_person` varchar(45) DEFAULT NULL,
    `contact_person_phone` varchar(45) DEFAULT NULL,
    `wifi_service` tinyint(1) DEFAULT NULL,
    `car_service` tinyint(1) DEFAULT NULL,
    `logo` varchar(300) DEFAULT NULL,
    `star` decimal(18,6) DEFAULT NULL,
    `brands` varchar(300) DEFAULT NULL,
    `create_time` datetime DEFAULT NULL,
    `update_time` datetime DEFAULT NULL,
    `disabled` tinyint(1) DEFAULT 0,
    PRIMARY KEY (`id`),
    KEY `FK_AUTO_SHOP_REF_ADDRESS` (`address`),
    CONSTRAINT `FK_AUTO_SHOP_REF_ADDRESS` FOREIGN KEY (`address`) REFERENCES `auto_shop_address` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `auto_shop_picture` (
    `id` bigint(20) NOT NULL AUTO_INCREMENT,
    `auto_shop` bigint(20) NOT NULL,
    `url` varchar(300) DEFAULT NULL,
    `description` varchar(2000) DEFAULT NULL,
    PRIMARY KEY (`id`),
    KEY `FK_AUTO_SHOP_PICTURE_REF_AUTO_SHOP` (`auto_shop`),
    CONSTRAINT `FK_AUTO_SHOP_PICTURE_REF_AUTO_SHOP` FOREIGN KEY (`auto_shop`) REFERENCES `auto_shop` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `auto_shop_insurance_company` (
    `auto_shop` bigint(20) NOT NULL,
    `insurance_company` bigint(20) NOT NULL,
    PRIMARY KEY (`auto_shop`,`insurance_company`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;