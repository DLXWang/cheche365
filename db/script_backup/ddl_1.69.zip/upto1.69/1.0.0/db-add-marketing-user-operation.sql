-- ----------------------------
-- Table structure for `marketing_user_operation`
-- ----------------------------
CREATE TABLE IF NOT EXISTS `marketing_user_operation` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `marketing_id` bigint(20) NOT NULL,
  `mobile` varchar(11) COLLATE utf8_bin DEFAULT NULL,  
  `user_code` varchar(100) DEFAULT NULL,
  `user_type` varchar(100) DEFAULT NULL,
  `operate_date` datetime NOT NULL,
  `operate_type` varchar(100) DEFAULT NULL,
  `operate_channel` varchar(100) DEFAULT NULL,
  `target_channel` varchar(100) DEFAULT NULL,
  `remarks` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX index_MMO (marketing_id,mobile,operate_type),
  INDEX index_MO (marketing_id,operate_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;