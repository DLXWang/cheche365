INSERT INTO `log_type` (`name`, `description`) VALUES ('微信支付签名失败', '微信支付签名验证失败');
INSERT INTO `log_type` (`name`, `description`) VALUES ('微信支付失败', '微信支付失败');
INSERT INTO `log_type` (`name`, `description`) VALUES ('微信支付成功', '微信支付成功');
INSERT INTO `log_type` (`name`, `description`) VALUES ('微信支付非预期回调状态', '微信支付非预期回调状态');

