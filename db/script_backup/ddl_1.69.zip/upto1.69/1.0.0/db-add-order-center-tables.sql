-- ----------------------------
-- Table structure for order_transmission_status
-- ----------------------------
CREATE TABLE IF NOT EXISTS `order_transmission_status` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `status` varchar(45) DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for order_operation_info
-- ----------------------------
CREATE TABLE IF NOT EXISTS `order_operation_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `purchase_order` bigint(20) DEFAULT NULL,
  `original_status` bigint(20) DEFAULT NULL,
  `current_status` bigint(20) DEFAULT NULL,
  `assigner` bigint(20) DEFAULT NULL,
  `operator` bigint(20) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `re_confirm_date` date DEFAULT NULL,
  `pay_time` date DEFAULT NULL,
  `send_time` date DEFAULT NULL,
  `pay_period` varchar(20) DEFAULT NULL,
  `send_period` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_ORDER_OPERATION_INFO_REF_ORDER` (`purchase_order`),
  KEY `FK_ORDER_OPERATION_INFO_ORIGINAL_REF_INSURE_STATUS` (`original_status`),
  KEY `FK_ORDER_OPERATION_INFO_CURRENT_REF_INSURE_STATUS` (`current_status`),
  KEY `FK_ORDER_OPERATION_INFO_ASSIGNER_REF_INTERNAL_USER` (`assigner`),
  KEY `FK_ORDER_OPERATION_INFO_OPERATOR_REF_INTERNAL_USER` (`operator`),
  CONSTRAINT `FK_ORDER_OPERATION_INFO_REF_ORDER` FOREIGN KEY (`purchase_order`) REFERENCES `purchase_order` (`id`),
  CONSTRAINT `FK_ORDER_OPERATION_INFO_ORIGINAL_REF_INSURE_STATUS` FOREIGN KEY (`original_status`) REFERENCES `order_transmission_status` (`id`),
  CONSTRAINT `FK_ORDER_OPERATION_INFO_CURRENT_REF_INSURE_STATUS` FOREIGN KEY (`current_status`) REFERENCES `order_transmission_status` (`id`),
  CONSTRAINT `FK_ORDER_OPERATION_INFO_ASSIGNER_REF_INTERNAL_USER` FOREIGN KEY (`assigner`) REFERENCES `internal_user` (`id`),
  CONSTRAINT `FK_ORDER_OPERATION_INFO_OPERATOR_REF_INTERNAL_USER` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for internal_user_relation
-- ----------------------------
CREATE TABLE IF NOT EXISTS `internal_user_relation` (
  `id` bigint(20) NOT NULL,
  `customer_user` bigint(20) DEFAULT NULL,
  `internal_user` bigint(20) DEFAULT NULL,
  `external_user` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_RELATION_CUSTOMER_REF_INTERNAL_USER` (`customer_user`),
  KEY `FK_RELATION_INTERNAL_REF_INTERNAL_USER` (`internal_user`),
  KEY `FK_RELATION_EXTERNAL_REF_INTERNAL_USER` (`external_user`),
  CONSTRAINT `FK_RELATION_CUSTOMER_REF_INTERNAL_USER` FOREIGN KEY (`customer_user`) REFERENCES `internal_user` (`id`),
  CONSTRAINT `FK_RELATION_EXTERNAL_REF_INTERNAL_USER` FOREIGN KEY (`external_user`) REFERENCES `internal_user` (`id`),
  CONSTRAINT `FK_RELATION_INTERNAL_REF_INTERNAL_USER` FOREIGN KEY (`internal_user`) REFERENCES `internal_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
