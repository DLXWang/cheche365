-- 新增字段
  ALTER TABLE `agent`
  ADD COLUMN `rebate` decimal(18,2) default null,
  ADD COLUMN `create_time` datetime default null,
  ADD COLUMN `update_time` datetime default null
  ;
