-- 新增字段
  ALTER TABLE `internal_user`
  ADD COLUMN `disable` tinyint(1) default 0
  ;
