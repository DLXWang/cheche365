-- 新增字段
  ALTER TABLE `order_operation_info`
  ADD COLUMN `confirm_no` varchar(20) DEFAULT NULL
  ;
