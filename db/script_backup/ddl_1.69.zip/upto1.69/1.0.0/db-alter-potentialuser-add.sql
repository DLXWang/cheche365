
-- 新增字段
  ALTER TABLE `potential_user`
  ADD COLUMN `create_time` datetime not null,
  ADD COLUMN `update_time` datetime not null,
  ADD COLUMN `user` varchar(100) not null,
  ADD COLUMN `comment` varchar(200) null,
  ADD COLUMN `operator` bigint null
  ;
