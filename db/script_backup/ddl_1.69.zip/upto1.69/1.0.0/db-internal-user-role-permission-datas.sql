-- 权限：客服
insert into permission(id, name, type) values (1, 'PERMISSION_CUSTOMER', '2');

-- 权限：内勤
insert into permission(id, name, type) values (2, 'PERMISSION_INTERNAL', '2');

-- 权限：管理员
insert into permission(id, name, type) values (3, 'PERMISSION_ADMIN', '2');

-- 角色：客服
insert into role(id, name, type) values (1, 'ROLE_INTERNAL_USER_CUSTOMER', '2');

-- 角色：内勤
insert into role(id, name, type) values (2, 'ROLE_INTERNAL_USER_INTERNAL', '2');

-- 角色：管理员
insert into role(id, name, type) values (3, 'ROLE_INTERNAL_USER_ADMIN', '2');

-- 角色权限：客服
insert into role_permission(id, role, permission) values(1, 1, 1);

-- 角色权限：内勤
insert into role_permission(id, role, permission) values(2, 2, 2);

-- 角色权限：管理员
insert into role_permission(id, role, permission) values(3, 3, 3);
