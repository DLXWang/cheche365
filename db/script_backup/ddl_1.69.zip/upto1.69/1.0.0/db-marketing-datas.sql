-- ----------------------------
-- Records of marketing
-- ----------------------------
insert into marketing (id,name,code,begin_date,end_date,valid_month)values(2,'2015年5月抽奖送代金券','201505001','2015-05-01 00:00:00','2015-06-30 23:59:59',12);