  ALTER TABLE `marketing_success`
  ADD COLUMN `user_code` varchar(100) default null,
  ADD COLUMN `user_type` varchar(100) default null
  ;