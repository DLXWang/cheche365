-- ----------------------------
-- Records of order_transmission_status
-- ----------------------------
INSERT INTO `order_transmission_status` VALUES ('1', '未确认', '未确认');
INSERT INTO `order_transmission_status` VALUES ('2', '等待再次确认', '等待再次确认');
INSERT INTO `order_transmission_status` VALUES ('3', '出单', '出单');
INSERT INTO `order_transmission_status` VALUES ('4', '核保完成', '核保完成');
INSERT INTO `order_transmission_status` VALUES ('5', '收款', '收款');
INSERT INTO `order_transmission_status` VALUES ('6', '再次收款', '再次收款');
INSERT INTO `order_transmission_status` VALUES ('7', '出单完成', '出单完成');
INSERT INTO `order_transmission_status` VALUES ('8', '派送', '派送');
INSERT INTO `order_transmission_status` VALUES ('9', '再次派送', '再次派送');
INSERT INTO `order_transmission_status` VALUES ('10', '录入保单', '录入保单');
INSERT INTO `order_transmission_status` VALUES ('11', '订单完成', '订单完成');
INSERT INTO `order_transmission_status` VALUES ('12', '用户取消', '用户取消');
