-- ----------------------------
-- Table structure for cps_channel
-- ----------------------------
CREATE TABLE IF NOT EXISTS `cps_channel` (
    `id` bigint(20) NOT NULL AUTO_INCREMENT,
    `name` varchar(45) DEFAULT NULL,
    `channel_no` varchar(45) DEFAULT NULL,
    `rebate` DECIMAL(18,2) DEFAULT NULL,
    `wap_url` varchar(45) DEFAULT NULL,
    `start_date` DATE DEFAULT NULL,
    `end_date` DATE DEFAULT NULL,
    `link_man` varchar(45) DEFAULT NULL,
    `mobile` varchar(45) DEFAULT NULL,
    `email` varchar(45) DEFAULT NULL,
    `frequency` tinyint(1) DEFAULT NULL,
    `create_time` DATETIME DEFAULT NULL,
    `update_time` DATETIME DEFAULT NULL,
    `operator` bigint(20) DEFAULT NULL,
    PRIMARY KEY (`id`),
    KEY `FK_CPS_CHANNEL_REF_INTERNAL_USER` (`operator`),
    CONSTRAINT `FK_CPS_CHANNEL_REF_INTERNAL_USER` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
