-- ----------------------------
-- Table structure for feedback
-- ----------------------------
CREATE TABLE IF NOT EXISTS `feedback` (
    `id` bigint(20) NOT NULL AUTO_INCREMENT,
      `content` varchar(500) DEFAULT '',
      `user_id` bigint(20) DEFAULT '0',
      `create_time` datetime DEFAULT NULL,
      `status` bigint(20) DEFAULT '1',
      PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
