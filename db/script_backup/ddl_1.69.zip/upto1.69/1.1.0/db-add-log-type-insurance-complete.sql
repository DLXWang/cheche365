INSERT INTO `log_type` (`name`, `description`) VALUES ('出单时间', '订单出单完成时间');

