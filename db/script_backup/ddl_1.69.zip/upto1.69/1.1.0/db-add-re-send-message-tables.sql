-- ----------------------------
-- Table structure for re_send_message
-- ----------------------------
CREATE TABLE IF NOT EXISTS `re_send_message` (
    `id` bigint(20) NOT NULL AUTO_INCREMENT,
    `send_type` varchar(10) DEFAULT NULL,
    `status` varchar(10) DEFAULT NULL,
    `title` varchar(1000) DEFAULT NULL,
    `content` varchar(5000) DEFAULT NULL,
    `tos` varchar(100) DEFAULT NULL,
    `send_date` DATE DEFAULT NULL,
    `unique_string` varchar(32) DEFAULT NULL,
    `count` tinyint(3) DEFAULT 0,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
