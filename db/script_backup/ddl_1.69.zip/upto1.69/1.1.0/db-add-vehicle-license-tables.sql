-- ----------------------------
-- Table structure for vehicle_license
-- ----------------------------
CREATE TABLE IF NOT EXISTS `vehicle_license` (
    `id` bigint(20) NOT NULL AUTO_INCREMENT,
    `license_plate_no` varchar(45) DEFAULT NULL,
    `engine_no` varchar(45) DEFAULT NULL,
    `owner` varchar(45) DEFAULT NULL,
    `vin_no` varchar(45) DEFAULT NULL,
    `enroll_date` DATE DEFAULT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Vehicle License INDEX
create index idx_vehicle_license_licenseno on vehicle_license(license_plate_no);
