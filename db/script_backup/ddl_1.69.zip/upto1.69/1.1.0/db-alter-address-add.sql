-- 新增字段
  ALTER TABLE `address`
  ADD COLUMN `default_address` tinyint(1) null
  ;
update address t set t.default_address = 0 where t.default_address is null;