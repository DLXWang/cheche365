-- 权限：合作渠道
insert into permission(id, name, type) values (4, 'PERMISSION_CPS', '2');

-- 角色：合作渠道
insert into role(id, name, type) values (4, 'ROLE_INTERNAL_USER_CPS', '2');

-- 角色权限：合作渠道
insert into role_permission(id, role, permission) values(4, 4, 4);

-- 内部员工：合作渠道角色
insert into internal_user_role(internal_user, role) values (4, 4);
