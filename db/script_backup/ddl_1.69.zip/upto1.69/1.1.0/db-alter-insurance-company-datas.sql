INSERT INTO insurance_company VALUES(20000, 'PINGAN', '平安保险');
