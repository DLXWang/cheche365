-- set mobile of internal_user
update internal_user set mobile = '18611403703' where email = '18611403703@163.com';

update internal_user set mobile = '18614067037' where email = '13699296638@163.com';

update internal_user set mobile = '18611437037' where email = '18611437037@163.com';

-- set role of internal user.

delete from internal_user_role where id = 2;

update internal_user_role set role = 1 where id = 1;

-- set relation of internal user,include customer, internal and external.

delete from internal_user_relation where id = 1;

insert into internal_user_relation(customer_user, internal_user, external_user) values (4, 4, 4);
