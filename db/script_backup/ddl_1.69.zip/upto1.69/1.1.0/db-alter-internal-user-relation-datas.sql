alter table internal_user_relation change id id bigint(20) not null auto_increment;
