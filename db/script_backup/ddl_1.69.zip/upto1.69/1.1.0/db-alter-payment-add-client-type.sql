ALTER TABLE `payment` ADD COLUMN `client_type` bigint(20) DEFAULT NULL;
ALTER TABLE `payment` ADD CONSTRAINT `FK_PAYMENT_REF_CHANNEL` FOREIGN KEY (`client_type`) REFERENCES `channel` (`id`);
