alter table `re_send_message` drop column title;
alter table `re_send_message` drop column content;
alter table `re_send_message` ADD COLUMN `param` text DEFAULT NULL;
alter table `re_send_message` ADD COLUMN `message_no` varchar(15) DEFAULT NULL;
alter table `re_send_message` modify COLUMN `count` tinyint(2) DEFAULT 0;
alter table `re_send_message` modify COLUMN `unique_string` varchar(45) DEFAULT NULL;
