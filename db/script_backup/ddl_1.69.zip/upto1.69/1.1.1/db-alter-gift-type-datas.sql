INSERT INTO `gift_type` (`id`, `name`, `description`) VALUES (4, '礼品卡', '车车赠送，不跟系统任何单据活动关联');
