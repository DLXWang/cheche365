INSERT INTO `payment_channel` (`id`, `channel`, `description`) VALUES (9, '代理人返点', '代理人返点');
