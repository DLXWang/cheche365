-- 新增字段
ALTER TABLE `user`
  ADD COLUMN `birthday` date null
;