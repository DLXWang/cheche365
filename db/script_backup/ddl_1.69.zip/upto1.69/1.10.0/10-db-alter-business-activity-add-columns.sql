-- 联系人
ALTER TABLE business_activity ADD COLUMN link_man varchar(45) DEFAULT NULL COMMENT '联系人';

-- 联系人手机号
ALTER TABLE business_activity ADD COLUMN mobile varchar(45) DEFAULT NULL COMMENT '联系人手机号';

-- 联系人邮箱
ALTER TABLE business_activity ADD COLUMN email varchar(45) DEFAULT NULL COMMENT '联系人邮箱';

-- 发送频率，1-每周；2-每月
ALTER TABLE business_activity ADD COLUMN frequency tinyint(1) DEFAULT 1 COMMENT '发送频率';

-- 是否使用优惠券,true-使用，false-不使用
ALTER TABLE business_activity ADD COLUMN enable tinyint(1) DEFAULT 0 COMMENT '是否使用优惠券';

-- 是否显示"回到首页"、"我的"等按钮 true-显示  false-不显示
ALTER TABLE business_activity ADD COLUMN display tinyint(1) DEFAULT 0 COMMENT '是否显示回到首页、我的等按钮';

