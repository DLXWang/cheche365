-- CPS转商务活动：添加合作商
insert into partner(name, cooperation_time, partner_type, enable, comment, create_time, update_time, operator)
select name, start_date, 1, 1, name, now(), now(), operator from cps_channel;

-- CPS转商务活动：添加合作商合作类型
insert into partner_cooperation_mode(partner, cooperation_mode)
select id, 2 from partner where name in (select name from cps_channel);

-- CPS转商务活动：添加商务活动
insert into business_activity(name, partner, cooperation_mode, rebate, budget, start_time, end_time, landing_page, comment,
create_time, update_time, operator, refresh_time, refresh_flag,
link_man, mobile, email, frequency, enable, display)
select tab.name, tab.partnerId, 2, tab.rebate, 0.00, tab.start_date, tab.end_date, tab.wap_url, tab.name,
tab.create_time, tab.update_time, tab.operator, null, 1,
tab.link_man, tab.mobile, tab.email, tab.frequency, tab.enable, tab.display
from
(
select cps.*, partner.id as partnerId
from cps_channel cps, partner partner
where cps.name = partner.name
) tab;

-- CPS转商务活动：添加商务活动支持的城市
insert into activity_area(business_activity, area)
select tab.activityId, tab.areaId
from
(
select activity.id as activityId, area.id as areaId
from business_activity activity, area area
where activity.name in (select name from cps_channel) and area.active = 1
) tab;
