-- 商务活动编号
ALTER TABLE business_activity ADD COLUMN code varchar(45) DEFAULT NULL COMMENT '商务活动编号' AFTER `name`;

-- 对象表名
ALTER TABLE business_activity ADD COLUMN obj_table varchar(45) DEFAULT NULL COMMENT '对象表名';

-- 对象id
ALTER TABLE business_activity ADD COLUMN obj_id varchar(45) DEFAULT NULL COMMENT '对象id';

-- BusinessActivity
create unique index idx_business_activity_code on business_activity(code);
