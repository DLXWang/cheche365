-- 修改商务活动
update business_activity act, cps_channel cps set act.code = cps.channel_no where act.name = cps.name;
