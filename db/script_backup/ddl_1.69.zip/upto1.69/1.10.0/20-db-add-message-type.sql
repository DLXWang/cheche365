-- 添加message_type，对应IOS图片类型
-- DROP TABLE IF EXISTS `message_type`;
CREATE TABLE IF NOT EXISTS `message_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `type` varchar(10) DEFAULT NULL,
  `description` varchar(400) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of message_type
-- ----------------------------
INSERT INTO `message_type` VALUES (1, '10', '首页banner', '首页banner');
INSERT INTO `message_type` VALUES (2, '11', '首页banner: 640x298(iPhone 4及 5系列） 750x350(iPhone 6系列） 828x386 (iPhone 6P系列）；', '首页运营推广位');
INSERT INTO `message_type` VALUES (3, '12', '活动列表页banner', '活动列表页banner');
INSERT INTO `message_type` VALUES (4, '13', '内页运营位', '内页运营位');
INSERT INTO `message_type` VALUES (5, '131', '内页运营位-买车险', '内页运营位-买车险');
INSERT INTO `message_type` VALUES (6, '132', '内页运营位-比价', '内页运营位-比价');
INSERT INTO `message_type` VALUES (7, '133', '内页运营位-预约', '内页运营位-预约');
