-- IOS设备屏幕和图片映射表，Android后续可以考虑使用device_pixel_radio做匹配
-- ----------------------------
-- Table structure for mobile_device_pic_rule
-- ----------------------------
CREATE TABLE IF NOT EXISTS `mobile_device_pic_rule` (
    `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
    `screen_size` varchar(500) NOT NULL COMMENT '屏幕尺寸（支持多个）',
    `image_size` varchar(50) DEFAULT NULL COMMENT '目标图片尺寸',
    `device_pixel_radio` varchar(200) DEFAULT NULL COMMENT '屏幕密度比（支持多个）',
    `default_rule` tinyint(10) DEFAULT NULL COMMENT '是否默认（每个类别应该有一个默认）',
    `message_type` bigint(20) NOT NULL COMMENT '图片显示类别',
    `description` varchar(400) DEFAULT NULL,
    PRIMARY KEY (`id`),
    KEY `pk_message_type` (`message_type`),
    CONSTRAINT `pk_message_type` FOREIGN KEY (`message_type`) REFERENCES `message_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of mobile_device_pic_rule
-- ----------------------------
INSERT INTO `mobile_device_pic_rule` VALUES ('1', '320_480', '640_298', '2', '0', '1', '首页banner,iphone4');
INSERT INTO `mobile_device_pic_rule` VALUES ('2', '320_568', '640_298', '2', '0', '1', '首页banner,iphone5');
INSERT INTO `mobile_device_pic_rule` VALUES ('3', '375_667', '750_350', '2', '0', '1', '首页banner,iphone6');
INSERT INTO `mobile_device_pic_rule` VALUES ('4', '414_736', '828_386', '3', '1', '1', '首页banner,iphone6 plus');
INSERT INTO `mobile_device_pic_rule` VALUES ('5', '320_480,320_568,375_667,414_736', '', null, '1', '2', '首页运营推广位');
INSERT INTO `mobile_device_pic_rule` VALUES ('6', '320_480', '640_298', '2', '0', '3', '活动列表页banner,iphone4');
INSERT INTO `mobile_device_pic_rule` VALUES ('7', '320_568', '640_298', '2', '0', '3', '活动列表页banner,iphone5');
INSERT INTO `mobile_device_pic_rule` VALUES ('8', '375_667', '750_350', '2', '0', '3', '活动列表页banner,iphone6');
INSERT INTO `mobile_device_pic_rule` VALUES ('9', '414_736', '828_386', '3', '1', '3', '活动列表页banner,iphone6 plus');
INSERT INTO `mobile_device_pic_rule` VALUES ('10', '320_480,320_568', '640_170', '2', '0', '5', '内页运营位-买车险；,iphone4');
INSERT INTO `mobile_device_pic_rule` VALUES ('11', '375_667', '750_200', '2', '0', '5', '内页运营位-买车险；iphone5');
INSERT INTO `mobile_device_pic_rule` VALUES ('12', '414_736', '828_220', '3', '1', '5', '内页运营位-买车险；iphone6,iphone6 plus');
INSERT INTO `mobile_device_pic_rule` VALUES ('13', '320_480,320_568', '640_170', '2', '0', '6', '内页运营位-比价；,iphone4');
INSERT INTO `mobile_device_pic_rule` VALUES ('14', '375_667', '640_170', '2', '0', '6', '内页运营位-比价；,iphone4');
INSERT INTO `mobile_device_pic_rule` VALUES ('15', '414_736', '828_220', '3', '1', '6', '内页运营位-比价；iphone6,iphone6 plus');
INSERT INTO `mobile_device_pic_rule` VALUES ('16', '320_480,320_568', '640_170', '2', '0', '7', '内页运营位-预约；,iphone4');
INSERT INTO `mobile_device_pic_rule` VALUES ('17', '375_667', '640_170', '2', '0', '7', '内页运营位-预约；,iphone4');
INSERT INTO `mobile_device_pic_rule` VALUES ('18', '414_736', '828_220', '3', '1', '7', '内页运营位-预约；iphone6,iphone6 plus');

