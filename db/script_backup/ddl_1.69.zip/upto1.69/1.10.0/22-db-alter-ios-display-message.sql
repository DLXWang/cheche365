-- 添加order字段
-- DROP TABLE IF EXISTS `ios_display_message`;
/*
CREATE TABLE IF NOT EXISTS `ios_display_message` (
  `id` bigint(20) NOT NULL,
  `url` varchar(400) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `icon_url` varchar(400) DEFAULT NULL,
  `description` varchar(400) DEFAULT NULL,
  `message_type` bigint(20) NOT NULL,
  `order` int(10) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `ios_display_message_ibfk_1` (`message_type`),
  CONSTRAINT `ios_display_message_ibfk_1` FOREIGN KEY (`message_type`) REFERENCES `message_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
*/
ALTER TABLE ios_display_message ADD COLUMN `order` int(10) default 0;

-- ----------------------------
-- Records of ios_display_message
-- ----------------------------
-- 测试数据
INSERT INTO `ios_display_message` VALUES ('1', 'http://182.92.10.68/marketing/201508002/index_IOSAPP.html', '首页banner-车船税优惠券', '首页banner-车船税优惠券', '20150911/banner/banner_marking_autogift.png', null, '1', '1');
INSERT INTO `ios_display_message` VALUES ('2', '', '内页运营位-买车险', '内页运营位-买车险', '20150911/innerpage/131.png', null, '5', '1');
INSERT INTO `ios_display_message` VALUES ('3', '', '内页运营位-比价', '内页运营位-比价', '20150911/innerpage/132.png', null, '6', '1');
INSERT INTO `ios_display_message` VALUES ('4', '', '内页运营位-预约', '内页运营位-预约', '20150911/innerpage/133.png', null, '7', '1');
INSERT INTO `ios_display_message` VALUES ('5', '', '首页banner-第1个品牌banner图', '首页banner-第1个品牌banner图', '20150911/banner/banner_1.png', null, '1', '2');
INSERT INTO `ios_display_message` VALUES ('6', '', '首页banner-第2个品牌banner图', '首页banner-第2个品牌banner图', '20150911/banner/banner_2.png', null, '1', '3');
INSERT INTO `ios_display_message` VALUES ('7', '', '首页banner-第3个品牌banner图', '首页banner-第3个品牌banner图', '20150911/banner/banner_3.png', null, '1', '4');
INSERT INTO `ios_display_message` VALUES ('8', '', '首页banner-第4个品牌banner图', '首页banner-第4个品牌banner图', '20150911/banner/banner_4.png', null, '1', '5');

