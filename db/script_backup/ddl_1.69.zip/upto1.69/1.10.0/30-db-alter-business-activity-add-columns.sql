-- 是否可以回到首页，默认为true，true-可以，false-不可以
ALTER TABLE business_activity ADD COLUMN home tinyint(1) DEFAULT 1 COMMENT '是否可以回到首页' AFTER `display`;

-- 是否显示底部公司标识，默认为false，true-显示，false-不显示
ALTER TABLE business_activity ADD COLUMN footer tinyint(1) DEFAULT 0 COMMENT '是否显示底部公司标识' AFTER `home`;

-- 是否可以显示我的，默认为true，true-显示，false-不显示
ALTER TABLE business_activity ADD COLUMN mine tinyint(1) DEFAULT 1 COMMENT '是否可以显示我的' AFTER `footer`;

-- 成功提交订单后是否显示按钮，默认为true，true-显示，false-不显示
ALTER TABLE business_activity ADD COLUMN btn tinyint(1) DEFAULT 1 COMMENT '成功提交订单后是否显示按钮' AFTER `mine`;

-- 成功提交订单后是否显示公司微信二维码，默认为false，true-显示，false-不显示
ALTER TABLE business_activity ADD COLUMN app tinyint(1) DEFAULT 0 COMMENT '成功提交订单后是否显示公司微信二维码' AFTER `btn`;
