-- ----------------------------
-- Table structure for activity_payment_channel
-- ----------------------------
CREATE TABLE IF NOT EXISTS `activity_payment_channel` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `business_activity` bigint(20) DEFAULT NULL,
  `payment_channel` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_ACTIVITY_PAYMENT_CHANNEL_REF_BUSINESS_ACTIVITY` (`business_activity`),
  KEY `FK_ACTIVITY_PAYMENT_CHANNEL_REF_PAYMENT_CHANNEL` (`payment_channel`),
  CONSTRAINT `FK_ACTIVITY_PAYMENT_CHANNEL_REF_BUSINESS_ACTIVITY` FOREIGN KEY (`business_activity`) REFERENCES `business_activity` (`id`),
  CONSTRAINT `FK_ACTIVITY_PAYMENT_CHANNEL_REF_PAYMENT_CHANNEL` FOREIGN KEY (`payment_channel`) REFERENCES `payment_channel` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
