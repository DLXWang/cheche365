update business_activity set display=0, home=0, footer=1, mine=0, enable=0, btn=0, app=1 where code = 'niuche';
