-- 牛车网支持的支付方式
insert into activity_payment_channel (business_activity, payment_channel)
select activity.id, payment.id
from business_activity activity, payment_channel payment
where activity.code = 'niuche'
and payment.id in (1,2,3,4);

-- 其他CPS类型的支付方式
insert into activity_payment_channel (business_activity, payment_channel)
select activity.id, payment.id
from business_activity activity, payment_channel payment
where activity.code <> 'niuche' and activity.cooperation_mode in (1,2)
and payment.customer_pay = 1
order by activity.id, payment.id;
