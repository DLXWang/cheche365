-- 数据更新标记
ALTER TABLE marketing_success ADD COLUMN license_plate_no varchar(45) COMMENT '车牌号';
ALTER TABLE marketing_success ADD COLUMN area bigint(10) COMMENT '所属地区';