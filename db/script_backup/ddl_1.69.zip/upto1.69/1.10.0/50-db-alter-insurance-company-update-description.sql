alter table insurance_company add description varchar(4500);

update insurance_company set description = "全国通赔、专享电子查勘理赔,5000元以下小额单方事故、极速理赔,全国范围内不限次数50公里内免费故障车救援服务,万元以下案件一小时通知赔付,全国7X24小时全天候查勘和理赔咨询服务" where id = 10000;

update insurance_company set description = "全国通赔、理赔无限制,故障车辆免费救援,5000元以下非人伤免单证24小时赔付,旅行医疗救援服务" where id = 15000;

update insurance_company set description = "全国通赔、理赔无限制,先赔付再修车、万元以下三天到账,7*24小时、百公里免费非事故道路救援服务,上门代收理赔资料、车险理赔进度实时查询" where id = 20000;

update insurance_company set description = "免费道路救援,车险在线支付、即可享受双重好礼" where id = 25000;
