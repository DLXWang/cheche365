-- 是否显示，1-显示，0-不显示
ALTER TABLE monitor_data_type ADD COLUMN show_flag tinyint(1) DEFAULT 1 COMMENT '是否显示';
