INSERT INTO monitor_data_type VALUES(10, '预算', '预算', 0);
INSERT INTO monitor_data_type VALUES(11, '佣金', '佣金', 0);
