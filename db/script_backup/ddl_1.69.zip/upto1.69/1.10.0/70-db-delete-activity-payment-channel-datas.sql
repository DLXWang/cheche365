delete from activity_payment_channel
where business_activity in (select id from business_activity where code = 'niuche')
and payment_channel = 2;
