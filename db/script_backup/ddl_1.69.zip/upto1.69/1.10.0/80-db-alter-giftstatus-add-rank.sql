ALTER TABLE gift_status add rank VARCHAR(20);

update gift_status set rank=1 where id =1;
update gift_status set rank=4 where id =2;
update gift_status set rank=3 where id =3;
update gift_status set rank=2 where id =4;
update gift_status set rank=5 where id =5;
update gift_status set rank=6 where id =6;
