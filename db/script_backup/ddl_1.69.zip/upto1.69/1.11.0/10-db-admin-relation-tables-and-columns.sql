-- 注册渠道
ALTER TABLE user ADD COLUMN register_ip varchar(45) DEFAULT NULL COMMENT '注册IP';

-- 注册渠道
ALTER TABLE user ADD COLUMN register_channel bigint(20) DEFAULT NULL COMMENT '注册渠道';
ALTER TABLE `user` ADD CONSTRAINT `FK_USER_REF_CHANNEL` FOREIGN KEY (`register_channel`) REFERENCES `channel` (`id`);

-- ----------------------------
-- Table structure for user_login_info
-- ----------------------------
CREATE TABLE IF NOT EXISTS `user_login_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user` bigint(20) DEFAULT NULL,
  `last_login_time` datetime DEFAULT NULL COMMENT '最后登录时间',
  `last_login_ip` varchar(45) DEFAULT NULL COMMENT '最后登录IP',
  PRIMARY KEY (`id`),
  KEY `FK_USER_LOGIN_INFO_REF_USER` (`user`),
  CONSTRAINT `FK_USER_LOGIN_INFO_REF_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 微信用户unionid
ALTER TABLE wechat_user_info ADD COLUMN union_id varchar(100) DEFAULT NULL;

-- 系统用户类型
ALTER TABLE internal_user ADD COLUMN internal_user_type tinyint(1) DEFAULT NULL COMMENT '系统用户类型';

-- 角色禁用标记
ALTER TABLE role ADD COLUMN disable tinyint(1) DEFAULT 1 COMMENT '角色禁用标记';

-- ----------------------------
-- Table structure for permission_types
-- ----------------------------
CREATE TABLE IF NOT EXISTS `permission_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 权限类型
ALTER TABLE `permission` ADD COLUMN `permission_type` bigint(20) DEFAULT NULL COMMENT '权限类型';
ALTER TABLE `permission` ADD CONSTRAINT `FK_PERMISSION_REF_PERMISSION_TYPE` FOREIGN KEY (`permission_type`) REFERENCES `permission_type` (`id`);

-- ----------------------------
-- Table structure for resource_type
-- ----------------------------
CREATE TABLE IF NOT EXISTS `resource_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for resource
-- ----------------------------
CREATE TABLE IF NOT EXISTS `resource` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL COMMENT '资源名称',
  `parent` bigint(20) DEFAULT NULL COMMENT '上级资源',
  `resource_type` bigint(20) DEFAULT NULL COMMENT '资源类型',
  `level` tinyint(1) DEFAULT NULL COMMENT '资源等级',
  PRIMARY KEY (`id`),
  KEY `FK_RESOURCE_REF_PARENT_RESOURCE` (`parent`),
  KEY `FK_RESOURCE_REF_RESOURCE_TYPE` (`resource_type`),
  CONSTRAINT `FK_RESOURCE_REF_PARENT_RESOURCE` FOREIGN KEY (`parent`) REFERENCES `resource` (`id`),
  CONSTRAINT `FK_RESOURCE_REF_RESOURCE_TYPE` FOREIGN KEY (`resource_type`) REFERENCES `resource_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for permission_resource
-- ----------------------------
CREATE TABLE IF NOT EXISTS `permission_resource` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `permission` bigint(20) DEFAULT NULL,
  `resource` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_PERMISSION_RESOURCE_REF_PERMISSION` (`permission`),
  KEY `FK_PERMISSION_RESOURCE_REF_RESOURCE` (`resource`),
  CONSTRAINT `FK_PERMISSION_RESOURCE_REF_PERMISSION` FOREIGN KEY (`permission`) REFERENCES `permission` (`id`),
  CONSTRAINT `FK_PERMISSION_RESOURCE_REF_RESOURCE` FOREIGN KEY (`resource`) REFERENCES `resource` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
