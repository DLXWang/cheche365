-- 权限类型
INSERT INTO `permission_type` VALUES ('1', 'PC', 'PC');

-- 资源类型
INSERT INTO `resource_type` VALUES ('1', '菜单', '菜单');
INSERT INTO `resource_type` VALUES ('2', '操作', '操作');
INSERT INTO `resource_type` VALUES ('3', '方法', '方法');
INSERT INTO `resource_type` VALUES ('4', '数据', '数据');


