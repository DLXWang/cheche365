-- 更新ios_display_message url不带域名
UPDATE ios_display_message SET `url` = '/marketing/201508002/index_IOSAPP.html' WHERE `id` = '1';
