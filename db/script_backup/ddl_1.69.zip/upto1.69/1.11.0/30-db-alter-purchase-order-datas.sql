-- 将CPS订单转到合作方式为CPS的商务活动下
update purchase_order po, cps_channel cps, business_activity ba
set po.order_source_id = ba.id
where po.order_source_id = cps.id and po.order_source_type = 1
and cps.channel_no = ba.code and ba.cooperation_mode = 2;
