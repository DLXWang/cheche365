-- 修改运算符标识
update arithmetic_operator set name = '×' where id = 3;
update arithmetic_operator set name = '÷' where id = 4;
