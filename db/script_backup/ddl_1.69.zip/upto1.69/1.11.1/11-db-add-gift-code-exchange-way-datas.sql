INSERT INTO `gift_code_exchange_way`
(`id`, `name`, `exchange_class`, `common_exchange`, `amount`, `operator`, `create_time`, `update_time`,
`description`,`effective_date` ,`expire_date` ,
`amount_param` ,`full_limit_param`)
VALUES ('10', '​理财范合作发券', 'com.cheche365.cheche.core.service.giftcode.CommonGiftCodeExchange', '1', null, null, now(), null,
'每个兑换码包含100、200、300、400、500、600这5种优惠券，根据用户订单金额自动使用并扣减', null, null,
'100;200;300;400;500;600', '100_1000;200_2000;300_3000;400_4000;500_5000;600_6000');
