-- update message_type
UPDATE `message_type` SET `description` = '首页运营推广位' WHERE `id` = '2';
UPDATE `message_type` SET `description` = '内页运营位(不挂具体图片)' WHERE `id` = '4';
