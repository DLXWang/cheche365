-- alter ios_display_message
ALTER TABLE `ios_display_message` ADD COLUMN start_date DATE;
ALTER TABLE `ios_display_message` ADD COLUMN end_date DATE;
ALTER TABLE `ios_display_message` CHANGE `order` weight INT(10);

-- update ios_display_message
DELETE FROM ios_display_message WHERE id in (1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16);
-- 轮转banner
INSERT INTO `ios_display_message` VALUES (8, '', '帆船赛', '帆船赛', '20150911/banner/ab_fc.png', NULL, 1, 12, NULL, NULL);
INSERT INTO `ios_display_message` VALUES (5, '', '丝绸之路拉力赛', '丝绸之路拉力赛', '20150911/banner/ab_lls.png', NULL, 1, 10, NULL, NULL);
INSERT INTO `ios_display_message` VALUES (6, '', '代言-毕胜', '代言-毕胜', '20150911/banner/banner_bisheng.png', NULL, 1, 1, NULL, NULL);
INSERT INTO `ios_display_message` VALUES (7, '', '代言-陈中', '代言-陈中', '20150911/banner/banner_chenzhong.png', NULL, 1, 2, NULL, NULL);
INSERT INTO `ios_display_message` VALUES (12, '', '代言-海兰', '代言-海兰', '20150911/banner/banner_hailan.png', NULL, 1, 3, NULL, NULL);
INSERT INTO `ios_display_message` VALUES (13, '', '代言-杨伟庆', '代言-杨伟庆', '20150911/banner/banner_ywq.png', NULL, 1, 4, NULL, NULL);
INSERT INTO `ios_display_message` VALUES (14, '', '代言-张默', '代言-张默', '20150911/banner/banner_zhangmo.png', NULL, 1, 5, NULL, NULL);
-- 内页运营
INSERT INTO `ios_display_message` VALUES (2, '', '买车险', '买车险', '20150911/innerpage/131.png', NULL, 5, 1, NULL, NULL);
INSERT INTO `ios_display_message` VALUES (3, '', '比价', '比价', '20150911/innerpage/132.png', NULL, 6, 1, NULL, NULL);
INSERT INTO `ios_display_message` VALUES (4, '', '预约', '预约', '20150911/innerpage/133.png', NULL, 7, 1, NULL, NULL);
-- 首页中间推广
INSERT INTO `ios_display_message` VALUES (9, '/marketing/201508001/index_IOSAPP.action', '5500元车险红包，点击领取！', '5500元车险红包，点击领取！', '20150911/promotion/bj-l1_IOSAPP.png', NULL, 2, 3, NULL, NULL);
INSERT INTO `ios_display_message` VALUES (10, 'http://mp.weixin.qq.com/s?__biz=MzAwODE2NDk5NA==&mid=207972236&idx=1&sn=168f7c7824ca024fb521f26b0d48093f#rd', '不买车险也能领，预约就送上门按摩、洗车、保养等价值500元礼包', '不买车险也能领，预约就送上门按摩、洗车、保养等价值500元礼包', '20150911/promotion/bj-r2_IOSAPP.png', NULL, 2, 2, NULL, NULL);
INSERT INTO `ios_display_message` VALUES (11, '/marketing/201508003/index_IOSAPP.action', '非北京用户专享，200元车险红包，快来领取','非北京用户专享，200元车险红包，快来领取', '20150911/promotion/bj-r3_IOSAPP.png', NULL, 2, 1, NULL, NULL);
-- 活动
INSERT INTO `ios_display_message` VALUES (15, '/marketing/201508003/index_IOSAPP.action', '非北京地区200元优惠券', '非北京地区200元优惠券', '20150911/activity/200gift.png', NULL, 3, 1, '2015-8-20', '2015-10-10');
INSERT INTO `ios_display_message` VALUES (16, '/marketing/201508001/index_IOSAPP.action', '上车车，买车险，送5500红包，人保、平安、太平洋任你选！', '上车车，买车险，送5500红包，人保、平安、太平洋任你选！', '20150911/activity/5500gift.png', NULL, 3, 2, '2015-7-15', '2015-12-31');
INSERT INTO `ios_display_message` VALUES (1, '/marketing/201508002/index_IOSAPP.action', '上车车买车险，立减车船税', '上车车买车险，立减车船税', '20150911/activity/free_ccs.png', NULL, 3, 11, '2015-8-25', '2015-9-30');
