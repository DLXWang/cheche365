UPDATE `order_cancel_reason_type` SET `reason` = '选错险种或保额' WHERE id = 1;
