-- 修改 marketing_img title文字内容
UPDATE marketing_img SET NAME = '5500元车险红包，点击领取！' WHERE id = 1;
UPDATE marketing_img SET NAME = '不买车险也能领，预约就送上门按摩、洗车、保养等价值500元礼包' WHERE id = 2;
UPDATE marketing_img SET NAME = '非北京用户专享，200元车险红包，快来领取' WHERE id = 3;
