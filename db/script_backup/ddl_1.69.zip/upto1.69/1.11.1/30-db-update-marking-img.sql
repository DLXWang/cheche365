UPDATE marketing_img SET NAME = '非北京用户专享，200元车险红包，快来领取' WHERE id = 1;
UPDATE marketing_img SET NAME = '5500元车险红包，点击领取！' WHERE id = 3;
