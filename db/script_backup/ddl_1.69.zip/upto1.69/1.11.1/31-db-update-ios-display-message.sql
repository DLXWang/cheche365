DELETE FROM ios_display_message WHERE `message_type` = 1;

INSERT INTO `ios_display_message` (`id`, `url`, `name`, `title`, `icon_url`, `description`, `message_type`, `weight`, `start_date`, `end_date`) VALUES('5','','丝绸之路拉力赛','丝绸之路拉力赛','20150911/banner/ab_lls.png',NULL,'1','11',NULL,NULL);
INSERT INTO `ios_display_message` (`id`, `url`, `name`, `title`, `icon_url`, `description`, `message_type`, `weight`, `start_date`, `end_date`) VALUES('8','','帆船赛','帆船赛','20150911/banner/ab_fc.png',NULL,'1','10',NULL,NULL);
INSERT INTO `ios_display_message` (`id`, `url`, `name`, `title`, `icon_url`, `description`, `message_type`, `weight`, `start_date`, `end_date`) VALUES('12','/marketing/201508002/index_IOSAPP.action','车船税活动','车船税活动','20150911/activity/free_ccs.png',NULL,'1','12',NULL,NULL);
INSERT INTO `ios_display_message` (`id`, `url`, `name`, `title`, `icon_url`, `description`, `message_type`, `weight`, `start_date`, `end_date`) VALUES('13','','代言-杨伟庆','代言-杨伟庆','20150911/banner/banner_ywq.png',NULL,'1','5',NULL,NULL);
INSERT INTO `ios_display_message` (`id`, `url`, `name`, `title`, `icon_url`, `description`, `message_type`, `weight`, `start_date`, `end_date`) VALUES('14','','代言-张默','代言-张默','20150911/banner/banner_zhangmo.png',NULL,'1','4',NULL,NULL);

