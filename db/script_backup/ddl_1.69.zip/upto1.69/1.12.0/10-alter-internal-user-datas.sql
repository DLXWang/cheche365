update internal_user set internal_user_type = 1 where internal_user_type is null;
