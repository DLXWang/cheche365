-- 添加外部用户角色类型
INSERT INTO role_type VALUES(5, '外部用户', '外部用户');
