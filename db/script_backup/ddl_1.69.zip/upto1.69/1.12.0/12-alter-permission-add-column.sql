ALTER TABLE permission ADD code varchar(20) DEFAULT NULL COMMENT '权限值';
