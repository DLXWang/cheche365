-- 添加权限条目菜单
INSERT INTO `resource` VALUES ('1', '运营系统', null, '1', '1');
INSERT INTO `resource` VALUES ('2', '管理系统', null, '1', '1');
INSERT INTO `resource` VALUES ('3', '合作商管理', '1', '1', '2');
INSERT INTO `resource` VALUES ('4', '合作商管理', '3', '1', '3');
INSERT INTO `resource` VALUES ('5', '商务活动管理', '3', '1', '3');
INSERT INTO `resource` VALUES ('6', '用户管理', '2', '1', '2');
INSERT INTO `resource` VALUES ('7', '用户管理', '6', '1', '3');
INSERT INTO `resource` VALUES ('8', '车辆管理', '2', '1', '2');
INSERT INTO `resource` VALUES ('9', '车辆管理', '8', '1', '3');
INSERT INTO `resource` VALUES ('10', '系统账号', '2', '1', '2');
INSERT INTO `resource` VALUES ('11', '内部账号', '10', '1', '3');
INSERT INTO `resource` VALUES ('12', '外部账号', '10', '1', '3');
INSERT INTO `resource` VALUES ('13', '角色管理', '2', '1', '2');
INSERT INTO `resource` VALUES ('14', '角色属性', '13', '1', '3');
INSERT INTO `resource` VALUES ('15', '权限条目', '13', '1', '3');
