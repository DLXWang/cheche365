-- 添加管理员角色
INSERT INTO `role` VALUES ('8', null, '管理员', '2', '0');
