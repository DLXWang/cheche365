-- 添加管理员角色权限
INSERT INTO `role_permission` VALUES ('8', '41', '8');
INSERT INTO `role_permission` VALUES ('9', '42', '8');
INSERT INTO `role_permission` VALUES ('10', '43', '8');
INSERT INTO `role_permission` VALUES ('11', '44', '8');
INSERT INTO `role_permission` VALUES ('12', '45', '8');
INSERT INTO `role_permission` VALUES ('13', '46', '8');
INSERT INTO `role_permission` VALUES ('14', '47', '8');
INSERT INTO `role_permission` VALUES ('15', '48', '8');
INSERT INTO `role_permission` VALUES ('16', '49', '8');
INSERT INTO `role_permission` VALUES ('17', '50', '8');
INSERT INTO `role_permission` VALUES ('18', '51', '8');
INSERT INTO `role_permission` VALUES ('19', '52', '8');
INSERT INTO `role_permission` VALUES ('20', '53', '8');
INSERT INTO `role_permission` VALUES ('21', '54', '8');
INSERT INTO `role_permission` VALUES ('22', '55', '8');
INSERT INTO `role_permission` VALUES ('23', '56', '8');
INSERT INTO `role_permission` VALUES ('24', '57', '8');
INSERT INTO `role_permission` VALUES ('25', '58', '8');
INSERT INTO `role_permission` VALUES ('26', '59', '8');
INSERT INTO `role_permission` VALUES ('27', '60', '8');
INSERT INTO `role_permission` VALUES ('28', '61', '8');
INSERT INTO `role_permission` VALUES ('29', '62', '8');
INSERT INTO `role_permission` VALUES ('30', '63', '8');
INSERT INTO `role_permission` VALUES ('31', '64', '8');
INSERT INTO `role_permission` VALUES ('32', '65', '8');

