update area set active=1 where id in (420100);
