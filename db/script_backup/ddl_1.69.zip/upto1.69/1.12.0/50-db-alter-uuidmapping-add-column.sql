ALTER TABLE uuidmapping ADD client_type VARCHAR(45) DEFAULT NULL;

-- 将现有生产数据客户端类型设置为IOS
update uuidmapping
set client_type = 'IOS'
where client_type is null;
