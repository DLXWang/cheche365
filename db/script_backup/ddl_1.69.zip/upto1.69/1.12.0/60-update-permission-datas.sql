-- 合并启用禁用权限
delete from role_permission where permission in(15,48,54,60,64);
delete from permission_resource where permission in(15,48,54,60,64);
delete from permission where id in(15,48,54,60,64);
update permission set description='运营系统/合作商管理/合作商管理/启用或禁用合作商',name='启用/禁用合作商' where id=14;
update permission set description='管理系统/系统账号/内部账号/启用或禁用内部账号',name='启用/禁用内部账号' where id=47;
update permission set description='管理系统/系统账号/外部账号/启用或禁用外部账号',name='启用/禁用外部账号' where id=53;
update permission set description='管理系统/角色权限管理/角色属性/启用或禁用角色',name='启用/禁用角色' where id=59;
update permission set description='管理系统/角色权限管理/权限条目/启用或禁用权限条目',name='启用/禁用权限条目' where id=63;

