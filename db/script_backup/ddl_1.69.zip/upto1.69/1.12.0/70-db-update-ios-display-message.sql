-- 删除内页活动显示图片
DELETE FROM ios_display_message WHERE id IN (2,3,4);
-- 添加banner轮播200红包
INSERT INTO `ios_display_message` VALUES (17, '/marketing/201508003/index_IOSAPP.action', '非北京用户专享，200元车险红包，快来领取','非北京用户专享，200元车险红包，快来领取', '20150911/activity/200gift.png', NULL, 1, 13, NULL, NULL);
-- 更新车船税banner轮播图和活动图片
UPDATE ios_display_message SET icon_url = '20150918/activity/free_ccs.png' WHERE icon_url = '20150911/activity/free_ccs.png';
