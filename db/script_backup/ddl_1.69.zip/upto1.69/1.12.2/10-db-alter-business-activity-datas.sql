-- 牛车网直接跳到购买页 添加#base
update business_activity
set landing_page = 'http://www.cheche365.com/m/channel/niuche#base'
where landing_page = 'http://www.cheche365.com/m/channel/niuche'
and code = 'niuche';

-- 太平洋汽车网直接跳到主页 去掉#base
update business_activity
set landing_page = 'http://www.cheche365.com/m/channel/pcauto'
where landing_page = 'http://www.cheche365.com/m/channel/pcauto#base'
and code = 'pcauto';

-- 太平洋汽车网之前没有配置支付方式：微信，支付宝，银联，线下付款刷卡
insert into activity_payment_channel (business_activity, payment_channel)
select ba.id, pc.id
from business_activity ba, payment_channel pc
where ba.code = 'pcauto' and pc.id in (1, 3, 4, 6);

-- 太平洋汽车网CPS参数
update business_activity set display = 0, footer = 1, btn = 0, app = 0, enable = 0, rebate = 0
where code = 'pcauto';
