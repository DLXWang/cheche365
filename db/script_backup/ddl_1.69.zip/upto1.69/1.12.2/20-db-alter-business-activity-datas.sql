-- 牛车网直接跳到购买页 添加#base
update business_activity
set landing_page = 'http://182.92.1.136/m/channel/niuche#base'
where landing_page = 'http://182.92.1.136/m/channel/niuche'
and code = 'niuche';

-- 太平洋汽车网直接跳到主页 去掉#base
update business_activity
set landing_page = 'http://182.92.1.136/m/channel/pcauto'
where landing_page = 'http://182.92.1.136/m/channel/pcauto#base'
and code = 'pcauto';
