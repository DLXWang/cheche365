﻿delete from marketing where id=11;
insert into marketing (id,name,code,begin_date,end_date,amount_class,amount_class_param,failure_date_class,failure_date_class_param,describle,channel,gift_class,full_limit_param)
values
(11,'中秋节活动','201509001','2015-09-24 00:00:00','2015-10-07 23:59:59','com.cheche365.cheche.rest.service.marketing.FixedAmount',
'0','com.cheche365.cheche.rest.service.marketing.FixedDate','2015-12-31 23:59:59','中秋节活动','','','');