﻿update marketing t set t.end_date = '2015-10-31 23:59:59' where t.id=9;
update marketing t set t.end_date = '2015-10-31 23:59:59' where t.id=10;