-- 修改200非北京地区优惠券截至日期和图片
UPDATE `ios_display_message` SET `start_date` = '2015-08-20', `end_date` = '2015-10-31' WHERE id IN (15,17);
UPDATE `ios_display_message` SET `icon_url`='20150924/activity/200gift.jpg' WHERE id IN (15,17);
