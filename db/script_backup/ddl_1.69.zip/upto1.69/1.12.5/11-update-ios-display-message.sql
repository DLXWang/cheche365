-- 去掉丝绸之路越野拉力赛banner
DELETE FROM ios_display_message WHERE id = 5;
-- 添加中秋节banner
INSERT INTO ios_display_message VALUES (18, '/marketing/201509001/index_IOSAPP.action', '中秋节，送车船税，送流量！', '中秋节，送车船税，送流量！', '20150925/activity/mid-autumn.jpg', NULL, 1, 11, '2015-09-24', '2015-10-07');
INSERT INTO ios_display_message VALUES (19, '/marketing/201509001/index_IOSAPP.action', '中秋节，送车船税，送流量！', '中秋节，送车船税，送流量！', '20150925/activity/mid-autumn.jpg', NULL, 3, 12, '2015-09-24', '2015-10-07');
