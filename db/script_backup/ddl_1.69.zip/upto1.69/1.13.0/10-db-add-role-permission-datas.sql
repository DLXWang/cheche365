-- 添加管理员角色权限：登录管理系统的权限
INSERT INTO `role_permission`(permission, role) VALUES ('9', '8');
