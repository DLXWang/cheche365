ALTER TABLE auto_type ADD brand_logo varchar(45) DEFAULT NULL COMMENT '品牌logo文件名';
