CREATE TABLE IF NOT EXISTS `autohome_brand` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `logo` varchar(100) DEFAULT NULL,
  `logo_hash` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_autohome_brand_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `autohome_family` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `brand` bigint(20) NOT NULL,
  `manufacturer` varchar(45) DEFAULT NULL,
  `logo` varchar(100) DEFAULT NULL,
  `logo_hash` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_AH_FAMILY_REF_AH_BRAND` (`brand`),
  KEY `idx_autohome_family_name` (`name`),
  CONSTRAINT `FK_AH_FAMILY_REF_AH_BRAND` FOREIGN KEY (`brand`) REFERENCES `autohome_brand` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



CREATE TABLE IF NOT EXISTS `autohome_auto_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `brand` bigint(20) NOT NULL,
  `family` bigint(20) NOT NULL,
  `code` varchar(45) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  `current_price` decimal(18,2) DEFAULT NULL,
  `new_price` decimal(18,2) DEFAULT NULL,
  `exhaust_scale` varchar(10) DEFAULT NULL,
  `manufacturer` varchar(45) DEFAULT NULL,
  `model` varchar(120) DEFAULT NULL,
  `seats` tinyint(3) DEFAULT NULL,
  `engine` varchar(45) DEFAULT NULL,
  `year` varchar(10) DEFAULT NULL,
  `status` char(1) DEFAULT NULL,
  `logo` varchar(100) DEFAULT NULL,
  `logo_hash` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_AH_AUTO_TYPE_REF_AH_BRAND` (`brand`),
  KEY `FK_AH_AUTO_TYPE_REF_AH_FAMILY` (`family`),
  KEY `idx_autohome_auto_type_name` (`name`),
  CONSTRAINT `FK_AH_AUTO_TYPE_REF_AH_BRAND` FOREIGN KEY (`brand`) REFERENCES `autohome_brand` (`id`),
  CONSTRAINT `FK_AH_AUTO_TYPE_REF_AH_FAMILY` FOREIGN KEY (`family`) REFERENCES `autohome_family` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


