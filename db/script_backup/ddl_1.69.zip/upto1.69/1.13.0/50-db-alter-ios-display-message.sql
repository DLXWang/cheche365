-- add column enable, tab
ALTER TABLE `ios_display_message` ADD COLUMN `enable` TINYINT DEFAULT 1 COMMENT '是否启用';
ALTER TABLE `ios_display_message` ADD COLUMN `tag` VARCHAR(200) DEFAULT '' COMMENT '标记字段';
