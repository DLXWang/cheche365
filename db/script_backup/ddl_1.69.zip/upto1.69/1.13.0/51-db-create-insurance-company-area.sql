-- 添加保险公司 区域 关联表
CREATE TABLE IF NOT EXISTS `insurance_company_area` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `insurance_company_id` BIGINT(20) NOT NULL,
  `area_id` BIGINT(20) NOT NULL,
  `weight` INT(10) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `fk_insurance_company_id` (`insurance_company_id`),
  KEY `fk_area_id` (`area_id`),
  CONSTRAINT `fk_insurance_company_id` FOREIGN KEY (`insurance_company_id`) REFERENCES `insurance_company` (`id`),
  CONSTRAINT `fk_area_id` FOREIGN KEY (`area_id`) REFERENCES `area` (`id`)
) ENGINE=INNODB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8 COLLATE=utf8_bin
