-- 人保财险
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 110000); -- 北京市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 120000); -- 天津市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 310000); -- 上海市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 320500); -- 苏州市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 330100); -- 杭州市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 410100); -- 郑州市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 420100); -- 武汉市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 440100); -- 广州市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 440300); -- 深圳市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 500000); -- 重庆市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 510100); -- 成都市

-- 阳光保险
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (15000, 110000); -- 北京市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (15000, 120000); -- 天津市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (15000, 310000); -- 上海市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (15000, 320500); -- 苏州市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (15000, 330100); -- 杭州市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (15000, 410100); -- 郑州市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (15000, 420100); -- 武汉市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (15000, 440100); -- 广州市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (15000, 440300); -- 深圳市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (15000, 500000); -- 重庆市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (15000, 510100); -- 成都市

-- 平安保险
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 110000); -- 北京市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 120000); -- 天津市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 310000); -- 上海市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 320500); -- 苏州市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 330100); -- 杭州市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 410100); -- 郑州市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 420100); -- 武汉市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 440100); -- 广州市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 440300); -- 深圳市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 500000); -- 重庆市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 510100); -- 成都市

-- 太平洋保险
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 110000); -- 北京市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 120000); -- 天津市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 310000); -- 上海市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 320500); -- 苏州市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 330100); -- 杭州市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 410100); -- 郑州市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 420100); -- 武汉市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 440100); -- 广州市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 440300); -- 深圳市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 500000); -- 重庆市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 510100); -- 成都市

-- 中国太平
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (30000, 110000); -- 北京市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (30000, 310000); -- 上海市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (30000, 440100); -- 广州市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (30000, 440300); -- 深圳市
