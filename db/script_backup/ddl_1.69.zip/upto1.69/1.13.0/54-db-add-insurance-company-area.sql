-- 删除中国太平数据
DELETE FROM `insurance_company_area` WHERE `insurance_company_id` = 30000;

-- 添加国寿财数据
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (40000, 110000); -- 北京市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (40000, 310000); -- 上海市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (40000, 440100); -- 广州市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (40000, 440300); -- 深圳市
