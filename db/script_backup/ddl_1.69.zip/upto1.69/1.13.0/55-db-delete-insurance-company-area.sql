-- 国寿财只保留北京，删除上海，广州，深圳
DELETE FROM `insurance_company_area` WHERE `insurance_company_id` = 40000 AND `area_id` = 310000; -- 上海市
DELETE FROM `insurance_company_area` WHERE `insurance_company_id` = 40000 AND `area_id` = 440100; -- 广州市
DELETE FROM `insurance_company_area` WHERE `insurance_company_id` = 40000 AND `area_id` = 440300; -- 深圳市
