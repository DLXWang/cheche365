-- 添加国寿财数据 上海
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (40000, 310000); -- 上海市
