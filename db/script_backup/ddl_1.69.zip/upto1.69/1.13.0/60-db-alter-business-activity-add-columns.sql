-- 添加落地页类型
ALTER TABLE business_activity ADD COLUMN landing_page_type tinyint(1) DEFAULT NULL COMMENT '落地页类型，1-M站首页；2-M站购买页；3-M端活动页；4-PC端活动页';
