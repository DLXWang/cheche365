-- 修改当前已有商务活动的落地页类型值
update business_activity set landing_page_type = 1
where instr(landing_page, '/m/channel/') > 0 and instr(landing_page, '#base') = 0;

update business_activity set landing_page_type = 2
where instr(landing_page, '/m/channel/') > 0 and instr(landing_page, '#base') > 0;

update business_activity set landing_page_type = 3
where instr(landing_page, '/marketing/') > 0;
