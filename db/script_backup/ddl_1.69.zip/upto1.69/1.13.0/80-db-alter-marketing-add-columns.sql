-- 活动类型
ALTER TABLE marketing ADD COLUMN marketing_type varchar(10) DEFAULT NULL COMMENT '活动类型';
