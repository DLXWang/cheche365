-- 修改当前活动类型为M端
update marketing set marketing_type = 'm' where id <= 11;

-- 添加PC端活动
delete from marketing where id=12;
insert into marketing (id,name,code,begin_date,end_date,marketing_type)
values (12,'上车车，买车险，立减车船税','p1','2015-09-01 00:00:00','2015-09-30 23:59:59','web');

delete from marketing where id=13;
insert into marketing (id,name,code,begin_date,end_date,marketing_type)
values (13,'上车车，买车险，送5500元红包，人保、平安、太平洋，车险任你选','p2','2015-09-01 00:00:00','2015-09-30 23:59:59','web');

delete from marketing where id=14;
insert into marketing (id,name,code,begin_date,end_date,marketing_type)
values (14,'非京地区200元优惠券','p3','2015-09-01 00:00:00','2015-09-30 23:59:59','web');
