-- 不包含车船税金额字段
ALTER TABLE activity_monitor_data ADD COLUMN no_auto_tax_amount DECIMAL(18,2) DEFAULT NULL COMMENT '不包含车船税金额';
