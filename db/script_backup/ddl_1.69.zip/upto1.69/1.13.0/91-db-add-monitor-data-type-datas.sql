INSERT INTO monitor_data_type VALUES(12, '不含车船税金额', '不含车船税金额', 1);
