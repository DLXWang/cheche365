update monitor_data_type set name = '不含车船税总额', description = '不含车船税总额' where id = 12;
