-- 添加管理员角色：liuyw@cheche365.com
INSERT INTO internal_user_role(internal_user, role)
select id, 8 from internal_user where email = 'liuyw@cheche365.com';

-- 添加管理员角色：dongyw@cheche365.com
INSERT INTO internal_user_role(internal_user, role)
select id, 8 from internal_user where email = 'dongyw@cheche365.com';
