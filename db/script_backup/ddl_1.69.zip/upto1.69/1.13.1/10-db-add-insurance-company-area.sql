INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (40000, 440100); -- 广州市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (40000, 440300); -- 深圳市
