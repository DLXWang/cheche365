-- 添加国寿财其他7个城市数据
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (40000, 120000); -- 天津市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (40000, 320500); -- 苏州市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (40000, 330100); -- 杭州市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (40000, 410100); -- 郑州市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (40000, 420100); -- 武汉市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (40000, 500000); -- 重庆市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (40000, 510100); -- 成都市
