-- 删除国寿财其他7个城市数据
DELETE FROM `insurance_company_area`
WHERE `insurance_company_id` = 40000
AND `area_id` in (
120000, -- 天津市
320500, -- 苏州市
330100, -- 杭州市
410100, -- 郑州市
420100, -- 武汉市
500000, -- 重庆市
510100 -- 成都市
);
