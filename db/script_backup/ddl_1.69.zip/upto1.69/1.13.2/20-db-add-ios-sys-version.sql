INSERT INTO `sys_version` (`channel`, `version`, `update_advice`, `reason`) VALUES ('4', '1.1.1', 'option', '完美适配iOS 9的车车车险上线啦！更加省时、省心、省钱，还能分享给小伙伴，赶快更新吧！');
