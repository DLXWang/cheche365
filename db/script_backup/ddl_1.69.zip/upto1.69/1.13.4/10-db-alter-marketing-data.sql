update marketing set end_date = '2015-10-31 23:59:59' where id in (12,13,14);
