-- 修改车船税活动结束日期显示
UPDATE `ios_display_message` SET `end_date` = '2015-10-31' WHERE id = 1;
