﻿INSERT INTO vip_company(id,code,name,create_time,update_time) VALUES(21, 'picc', '人保财险',now(),now());
