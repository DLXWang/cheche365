INSERT INTO vip_company_activity(id,code,name,company,insurance_url,error_url,begin_date,end_date,rule_class,unsupport_company,payment_channel_channel) VALUES
(21,'picc_1','人保财险-活动1',21,'picc.html','','2015-10-08','2016-10-08','com.cheche365.cheche.core.service.factory.NicVipActivityHandler','10000','4');

