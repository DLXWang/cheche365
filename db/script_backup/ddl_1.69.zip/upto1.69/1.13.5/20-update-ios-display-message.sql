-- 替换9月车船税图片
UPDATE `ios_display_message` SET `icon_url` = '20151009/activity/free_ccs.jpg' WHERE `icon_url` = '20150918/activity/free_ccs.png' AND ENABLE  = 1;
