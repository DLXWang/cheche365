INSERT INTO `sys_version` (`channel`, `version`, `update_advice`, `reason`) VALUES ('4', '1.1.2', 'option', '体验更流畅的新版本发布啦，赶快升级吧~');
