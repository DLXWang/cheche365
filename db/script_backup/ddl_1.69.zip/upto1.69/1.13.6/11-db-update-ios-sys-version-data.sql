update `sys_version` set reason = '更流畅的新版本发布啦，赶快升级吧~'
where version = '1.1.2';
