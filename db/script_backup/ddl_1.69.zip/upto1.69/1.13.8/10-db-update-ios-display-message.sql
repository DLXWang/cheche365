-- 去掉banner代言
UPDATE `ios_display_message` SET `enable` = 0 WHERE NAME IN ('代言-杨伟庆', '代言-张默');
-- 修改车船税图片
UPDATE `ios_display_message` SET `icon_url` = '20151014/activity/free_ccs.jpg' WHERE `icon_url` = '20150918/activity/free_ccs.png';
-- 修改200红包图片
UPDATE `ios_display_message` SET `icon_url` = '20151014/activity/200gift.jpg' WHERE `icon_url` = '20150911/activity/200gift.png';
-- 修改帆船赛图片
UPDATE `ios_display_message` SET `icon_url` = '20151014/banner/ab_fc.jpg' WHERE `icon_url` = '20150911/banner/ab_fc.png';
