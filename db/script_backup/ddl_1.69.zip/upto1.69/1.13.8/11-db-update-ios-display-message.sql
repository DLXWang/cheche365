-- 去掉banner中秋节活动
UPDATE `ios_display_message` SET `enable` = 0 WHERE id = 18 AND `message_type` = 1;
