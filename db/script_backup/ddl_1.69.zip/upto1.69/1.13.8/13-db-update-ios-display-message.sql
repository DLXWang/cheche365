-- 添加太平洋车友会banner
INSERT INTO `ios_display_message` (`id`, `url`, `name`, `title`, `icon_url`, `description`, `message_type`, `weight`, `start_date`, `end_date`, `enable`, `tag`)
VALUES
('20',
'http://activity.pcauto.com.cn/auto150914/use.jsp?couponsName=%E6%B5%81%E9%87%8F%E5%AE%9D%E5%85%8D%E8%B4%B9%E5%85%A8%E5%9B%BD%E6%B5%81%E9%87%8F&couponsCode=dhqwrls117',
'车车联合太平洋车友会送福利！',
'车车联合太平洋车友会送福利！',
'20151014/banner/cheyouhui.jpg',
'车车联合太平洋车友会送福利！',
'1',
'9',
NULL,
NULL,
1,
'20151014');
