INSERT INTO `gift_code_exchange_way`
(`id`, `name`, `exchange_class`, `common_exchange`, `amount`, `operator`, `create_time`, `update_time`,
`description`,`effective_date` ,`expire_date` ,
`amount_param` ,`full_limit_param`)
VALUES ('11', '​车车赠送', 'com.cheche365.cheche.core.service.giftcode.CheCheGiftCodeExchange', '1', 1000.00, null, now(), null,
'每个优惠码兑换一张1000元优惠券', null, null,
'1000', null);
