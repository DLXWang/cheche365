UPDATE `ios_display_message` SET `icon_url` = '20151020/banner/ab_fc.jpg' WHERE id = 8;
