-- 添加大客户消息类型
INSERT INTO `message_type` VALUES (8, 14, '大客户LOGO', '大客户LOGO');
