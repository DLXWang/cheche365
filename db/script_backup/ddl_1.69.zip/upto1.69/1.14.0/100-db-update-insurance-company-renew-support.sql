update insurance_company set renew_support = 0 where id = 15000;
