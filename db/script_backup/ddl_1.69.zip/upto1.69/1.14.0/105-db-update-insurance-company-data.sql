-- 开通11个城市
UPDATE area SET short_code = '冀A',active = 1 WHERE id = '130100';
UPDATE area SET short_code = '蒙A',active = 1 WHERE id = '150100';
UPDATE area SET short_code = '鲁A',active = 1 WHERE id = '370100';
UPDATE area SET short_code = '琼A',active = 1 WHERE id = '460100';
UPDATE area SET short_code = '云A',active = 1 WHERE id = '530100';
UPDATE area SET short_code = '陕A',active = 1 WHERE id = '610100';
UPDATE area SET short_code = '青A',active = 1 WHERE id = '630100';
UPDATE area SET short_code = '宁A',active = 1 WHERE id = '640100';
UPDATE area SET short_code = '黑A',active = 1 WHERE id = '230100';
UPDATE area SET short_code = '闽A',active = 1 WHERE id = '350100';
UPDATE area SET short_code = '苏A',active = 1 WHERE id = '320100';
