-- 人保财险
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 130100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 150100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 370100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 460100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 530100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 610100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 630100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 640100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 230100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 350100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 320100);

-- 平安保险
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 130100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 150100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 370100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 460100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 530100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 610100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 630100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 640100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 230100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 350100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 320100);

-- 太平洋保险
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 130100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 150100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 370100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 460100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 530100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 610100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 630100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 640100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 230100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 350100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 320100);
