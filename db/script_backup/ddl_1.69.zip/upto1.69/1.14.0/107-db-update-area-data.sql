-- 再开通11个城市
UPDATE area SET short_code = '晋A',active = 1 WHERE id = '140100';
UPDATE area SET short_code = '辽A',active = 1 WHERE id = '210100';
UPDATE area SET short_code = '吉A',active = 1 WHERE id = '220100';
UPDATE area SET short_code = '皖A',active = 1 WHERE id = '340100';
UPDATE area SET short_code = '赣A',active = 1 WHERE id = '360100';
UPDATE area SET short_code = '湘A',active = 1 WHERE id = '430100';
UPDATE area SET short_code = '桂A',active = 1 WHERE id = '450100';
UPDATE area SET short_code = '贵A',active = 1 WHERE id = '520100';
UPDATE area SET short_code = '藏A',active = 1 WHERE id = '540100';
UPDATE area SET short_code = '甘A',active = 1 WHERE id = '620100';
UPDATE area SET short_code = '新A',active = 1 WHERE id = '650100';
