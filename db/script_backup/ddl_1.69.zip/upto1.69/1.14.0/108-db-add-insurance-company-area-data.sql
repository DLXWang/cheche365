
-- 人保财险
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 140100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 210100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 220100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 340100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 360100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 430100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 450100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 520100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 540100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 620100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 650100);

-- 平安保险
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 140100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 210100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 220100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 340100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 360100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 430100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 450100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 520100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 540100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 620100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 650100);

-- 太平洋保险
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 140100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 210100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 220100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 340100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 360100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 430100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 450100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 520100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 540100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 620100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 650100);
