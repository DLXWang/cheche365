-- 添加大客户logo映射规则
INSERT INTO `mobile_device_pic_rule` VALUES (19, '320_480,320_568,375_667', '192_66', 2, 0, 8, '大客户4x，5x，6');
INSERT INTO `mobile_device_pic_rule` VALUES (20, '414_736', '288_99', 2, 1, 8, '大客户6p');
