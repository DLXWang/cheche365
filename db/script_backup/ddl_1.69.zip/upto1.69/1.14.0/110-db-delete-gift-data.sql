-- 删除之前领取的上广深的gift表数据，查询时会重新加载，加载后所有开通城市均可使用
DELETE FROM gift
WHERE source_type = 2 AND status = 1
AND EXISTS (
	SELECT 1 FROM marketing_success b
	WHERE source = b.id AND b.marketing_id = 10
);
