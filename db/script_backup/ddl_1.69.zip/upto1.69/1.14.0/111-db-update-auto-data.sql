update auto a
set a.update_time = a.create_time
where a.create_time is not null and a.update_time is null;
