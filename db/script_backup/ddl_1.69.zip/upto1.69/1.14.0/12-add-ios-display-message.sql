-- 修改ios_display_message 设置主键自增开始值30
ALTER TABLE `ios_display_message` CHANGE `id` `id` BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
-- 添加大客户logo数据
INSERT INTO `ios_display_message` (`name`, `title`, `icon_url`, `description`, `message_type`, `weight`, `enable`, `tag`) VALUES ('神州泰岳', '神州泰岳', 'vipcompany/ultrapower.png', '神州泰岳', 8, 5, 1, 'vip_20150928');
INSERT INTO `ios_display_message` (`name`, `title`, `icon_url`, `description`, `message_type`, `weight`, `enable`, `tag`) VALUES ('凤凰网', '凤凰网', 'vipcompany/ifeng.png', '凤凰网', 8, 4, 1, 'vip_20150928');
INSERT INTO `ios_display_message` (`name`, `title`, `icon_url`, `description`, `message_type`, `weight`, `enable`, `tag`) VALUES ('乐视网', '乐视网', 'vipcompany/letv.png', '乐视网', 8, 3, 1, 'vip_20150928');
INSERT INTO `ios_display_message` (`name`, `title`, `icon_url`, `description`, `message_type`, `weight`, `enable`, `tag`) VALUES ('滴滴', '滴滴', 'vipcompany/didi.png', '滴滴', 8, 2, 1, 'vip_20150928');
INSERT INTO `ios_display_message` (`name`, `title`, `icon_url`, `description`, `message_type`, `weight`, `enable`, `tag`) VALUES ('汽车之家', '汽车之家', 'vipcompany/autohome.png', '汽车之家', 8, 1, 1, 'vip_20150928');
