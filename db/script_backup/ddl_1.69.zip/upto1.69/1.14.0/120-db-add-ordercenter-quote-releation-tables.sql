-- 电话报价记录表
CREATE TABLE IF NOT EXISTS `quote_phone` (
    `id`                    BIGINT(20)     NOT NULL     AUTO_INCREMENT  COMMENT '主键',
    `license_plate_no`      VARCHAR(45)    DEFAULT NULL                 COMMENT '车牌号',
    `owner` 				VARCHAR(45)    DEFAULT NULL                 COMMENT '车主',
	`identity` 				VARCHAR(45)    DEFAULT NULL                 COMMENT '车主身份证号',
	`insured_name` 			VARCHAR(45)    DEFAULT NULL                 COMMENT '被保险人姓名',
	`insured_id_no` 	    VARCHAR(45)    DEFAULT NULL                 COMMENT '被保险人身份证号',
	`vin_no` 				VARCHAR(45)    DEFAULT NULL                 COMMENT 'VIN码',
	`engine_no` 			VARCHAR(45)    DEFAULT NULL                 COMMENT '发动机号',
	`enroll_date` 			DATE    	   DEFAULT NULL                 COMMENT '初登日期',
	`model` 				VARCHAR(120)   DEFAULT NULL                 COMMENT '车型',
	`code` 					VARCHAR(45)	   DEFAULT NULL                 COMMENT '品牌型号',
	`expire_date` 			DATE	   	   DEFAULT NULL                 COMMENT '保险到期日',
	`visited` 				tinyint(1)	   DEFAULT NULL                 COMMENT '是否需回访 1已回访 0需回访',
	`comment` 				VARCHAR(200)   DEFAULT NULL                 COMMENT '备注',
	`user` 					BIGINT(20)	   DEFAULT NULL                 COMMENT '用户',
	`create_time` 			DATETIME	   DEFAULT NULL                 COMMENT '创建时间',
	`update_time` 			DATETIME	   DEFAULT NULL                 COMMENT '更新时间',
  PRIMARY KEY (`id`), KEY `FK_QUOTE_PHONE_REF_USER` (`user`),
  CONSTRAINT `FK_QUOTE_PHONE_REF_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- 拍照报价记录表
CREATE TABLE IF NOT EXISTS `quote_photo` (
    `id`                    BIGINT(20)     NOT NULL     AUTO_INCREMENT  COMMENT '主键',
    `license_plate_no`      VARCHAR(45)    DEFAULT NULL                 COMMENT '车牌号',
    `owner` 				VARCHAR(45)    DEFAULT NULL                 COMMENT '车主',
	`identity` 				VARCHAR(45)    DEFAULT NULL                 COMMENT '车主身份证号',
	`insured_name` 			VARCHAR(45)    DEFAULT NULL                 COMMENT '被保险人姓名',
	`insured_id_no` 	    VARCHAR(45)    DEFAULT NULL                 COMMENT '被保险人身份证号',
	`vin_no` 				VARCHAR(45)    DEFAULT NULL                 COMMENT 'VIN码',
	`engine_no` 			VARCHAR(45)    DEFAULT NULL                 COMMENT '发动机号',
	`enroll_date` 			DATE    	   DEFAULT NULL                 COMMENT '初登日期',
	`model` 				VARCHAR(120)   DEFAULT NULL                 COMMENT '车型',
	`code` 					VARCHAR(45)	   DEFAULT NULL                 COMMENT '品牌型号',
	`expire_date` 			DATE	   	   DEFAULT NULL                 COMMENT '保险到期日',
	`disable` 				tinyint(1)	   DEFAULT NULL                 COMMENT '是否有效 1无效 0有效',
	`visited` 				tinyint(1)	   DEFAULT NULL                 COMMENT '是否需回访 1已回访 0需回访',
	`comment` 				VARCHAR(200)   DEFAULT NULL                 COMMENT '备注',
	`user` 					BIGINT(20)	   DEFAULT NULL                 COMMENT '用户',
	`user_img` 				BIGINT(20)	   DEFAULT NULL                 COMMENT '用户上传图片',
	`create_time` 			DATETIME	   DEFAULT NULL                 COMMENT '创建时间',
	`update_time` 			DATETIME	   DEFAULT NULL                 COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `FK_QUOTE_PHOTO_USER_REF_USER` (`user`),
  KEY `FK_QUOTE_PHOTO_USER_IMG_REF_USER_IMG` (`user_img`),
  CONSTRAINT `FK_QUOTE_PHOTO_USER_REF_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`),
  CONSTRAINT `FK_QUOTE_PHOTO_USER_IMG_REF_USER_IMG` FOREIGN KEY (`user_img`) REFERENCES `user_img` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
