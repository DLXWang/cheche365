-- 电话报价车牌号索引
create index idx_quote_phone_license_plate_no on quote_phone(license_plate_no);

-- 拍照报价车牌号索引
create index idx_quote_photo_license_plate_no on quote_photo(license_plate_no);
