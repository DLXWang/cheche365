INSERT INTO schedule_condition(id, name) VALUES(1, '请求验证码');
INSERT INTO schedule_condition(id, name) VALUES(2, '未支付订单短信提醒');
INSERT INTO schedule_condition(id, name) VALUES(3, '通知客户上门收款');
INSERT INTO schedule_condition(id, name) VALUES(4, '通知客户派送保单');
INSERT INTO schedule_condition(id, name) VALUES(5, '支付成功');
INSERT INTO schedule_condition(id, name) VALUES(6, '订单取消');
