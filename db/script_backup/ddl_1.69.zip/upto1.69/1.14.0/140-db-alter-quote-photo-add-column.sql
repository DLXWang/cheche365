-- 拍照报价表增加活动字段
ALTER TABLE quote_photo ADD COLUMN activity varchar(45) DEFAULT null COMMENT '活动';

-- 拍照报价活动索引
create index idx_quote_photo_activity on quote_photo(activity);
