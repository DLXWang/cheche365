-- user_img表增加更新时间字段
ALTER TABLE user_img ADD COLUMN update_time datetime DEFAULT null COMMENT '更新时间';

