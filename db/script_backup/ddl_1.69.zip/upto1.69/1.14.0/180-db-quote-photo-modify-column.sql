alter table quote_photo modify column activity  BIGINT(20);

ALTER TABLE quote_photo ADD CONSTRAINT `FK_QUOTE_PHOTO_MARKING_REF_MARKING` FOREIGN KEY (`activity`)  REFERENCES `marketing` (`id`);
