-- 再次开通请参考1.14.0下105、106、107、108文件
-- 屏蔽22个城市
UPDATE area SET active = 0 WHERE
   id = '130100' or id = '150100' or id = '370100' or id = '460100' or id = '530100'
or id = '610100' or id = '630100' or id = '640100' or id = '230100' or id = '350100'
or id = '320100' or id = '140100' or id = '210100' or id = '220100' or id = '340100'
or id = '360100' or id = '430100' or id = '450100' or id = '520100' or id = '540100'
or id = '620100' or id = '650100';

-- 删除22个城市所支持的保险公司（目前均支持人保、平安、太平洋）
delete from insurance_company_area
where (insurance_company_id = 10000 or insurance_company_id = 20000 or insurance_company_id = 25000)
and (
area_id = '130100' or area_id = '150100' or area_id = '370100' or area_id = '460100' or area_id = '530100'
or area_id = '610100' or area_id = '630100' or area_id = '640100' or area_id = '230100' or area_id = '350100'
or area_id = '320100' or area_id = '140100' or area_id = '210100' or area_id = '220100' or area_id = '340100'
or area_id = '360100' or area_id = '430100' or area_id = '450100' or area_id = '520100' or area_id = '540100'
or area_id = '620100' or area_id = '650100'
);
