-- ----------------------------
-- Table structure for quote_flow_type
-- ----------------------------
CREATE TABLE IF NOT EXISTS `quote_flow_type` (
`id`  bigint(20) NOT NULL AUTO_INCREMENT ,
`description`  varchar(2000) DEFAULT NULL ,
`name`  varchar(45) DEFAULT NULL ,
PRIMARY KEY (`id`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- add quote_flow_type dataa
INSERT INTO `quote_flow_type` VALUES(1, '通用流程', '通用流程');
INSERT INTO `quote_flow_type` VALUES(2, '续保流程', '续保流程');

-- quote_record表增加报价通道类型
ALTER TABLE quote_record ADD COLUMN quote_flow_type bigint(20) DEFAULT 1 COMMENT '报价通道类型';

ALTER TABLE quote_record ADD FOREIGN KEY (quote_flow_type) REFERENCES quote_flow_type(id) ON DELETE RESTRICT ON UPDATE RESTRICT;
