INSERT INTO channel VALUES(9, '未知', '未知');
