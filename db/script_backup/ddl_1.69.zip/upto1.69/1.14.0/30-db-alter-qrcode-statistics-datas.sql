-- 删除扫描数和关注数为0的二维码统计
delete from qrcode_statistics where scan_count = 0 and subscribe_count = 0;
