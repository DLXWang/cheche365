-- 是否显示车车顶部品牌（涉及品牌） true-显示  false-不显示
ALTER TABLE business_activity ADD COLUMN top_brand tinyint(1) DEFAULT 1 COMMENT '车车顶部品牌（涉及品牌）';
-- 是否显示我的中心 true-显示  false-不显示
ALTER TABLE business_activity ADD COLUMN my_center tinyint(1) DEFAULT 1 COMMENT '我的中心';
-- 是否显示顶部轮播图（涉及品牌） true-显示  false-不显示
ALTER TABLE business_activity ADD COLUMN top_carousel tinyint(1) DEFAULT 1 COMMENT '顶部轮播图（涉及品牌）';
-- 是否显示活动入口 true-显示  false-不显示
ALTER TABLE business_activity ADD COLUMN activity_entry tinyint(1) DEFAULT 1 COMMENT '活动入口';
-- 是否显示我们的客户 true-显示  false-不显示
ALTER TABLE business_activity ADD COLUMN our_customer tinyint(1) DEFAULT 1 COMMENT '我们的客户';
-- 是否显示底部轮播图（涉及品牌） true-显示  false-不显示
ALTER TABLE business_activity ADD COLUMN bottom_carousel tinyint(1) DEFAULT 1 COMMENT '底部轮播图（涉及品牌）';
-- 是否显示底部信息（涉及品牌） true-显示  false-不显示
ALTER TABLE business_activity ADD COLUMN bottom_info tinyint(1) DEFAULT 1 COMMENT '底部信息（涉及品牌）';
-- 是否显示底部下载（涉及品牌） true-显示  false-不显示
ALTER TABLE business_activity ADD COLUMN bottom_download tinyint(1) DEFAULT 1 COMMENT '底部下载（涉及品牌）';
