
DROP TABLE IF EXISTS `user_img`;
CREATE TABLE `user_img` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user` bigint(20) DEFAULT NULL,
  `driving_license_path` varchar(1024) DEFAULT NULL COMMENT '行驶证图片URL',
  `owner_identity_path` varchar(1024) DEFAULT NULL COMMENT '驾驶身份证图片URL',
  `create_time` datetime DEFAULT NULL,
  `comment` varchar(2000) DEFAULT NULL,
  `active` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `FK_USER_IMG_REF_USER` (`user`),
  CONSTRAINT `FK_USER_IMG_REF_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
