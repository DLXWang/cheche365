update insurance_company set description = "电话一拨就通,全国一套标准,赔款一天支付,投诉一站解决,流程一路透明",slogan = "快速理赔，便利贴心" WHERE id = 40000;
