CREATE TABLE IF NOT EXISTS `variable` (
    `id` 			bigint(20) 		NOT NULL        AUTO_INCREMENT		COMMENT '主键',
    `name`			varchar(45) 	DEFAULT NULL	                    COMMENT '变量名称',
    `property`  	varchar(45) 	DEFAULT NULL	                    COMMENT '变量属性',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `sql_parameter` (
    `id` 			bigint(20) 		NOT NULL        AUTO_INCREMENT		COMMENT '主键',
    `code` 			varchar(20) 	NOT NULL 		                    COMMENT '编号,例如：${?1}',
    `name`			varchar(45) 	DEFAULT NULL	                    COMMENT '名称，例如：手机号',
    `type`        	varchar(20) 	DEFAULT NULL	                    COMMENT '类型，例如varchar,date,time,number',
    `placeholder`  	varchar(45) 	DEFAULT NULL	                    COMMENT '参数描述',
    `length`  	    smallint(4)	    DEFAULT NULL	                    COMMENT '参数值长度',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `sms_template` (
    `id` 			bigint(20) 		NOT NULL        AUTO_INCREMENT	COMMENT '主键',
    `name` 			varchar(10) 	NOT NULL 		                COMMENT '模板名称',
    `zucp_code`		varchar(30) 	DEFAULT NULL	                COMMENT '漫道模板编号',
    `yxt_code`  	varchar(30) 	DEFAULT NULL	                COMMENT '盈信通模板编号',
    `disable` 		tinyint(1) 		DEFAULT '1'		                COMMENT '是否启用，默认为禁用，0-启用，1-禁用',
    `content` 		varchar(1000) 	NOT NULL 		                COMMENT '短信模板内容，涉及到变量',
    `comment` 		varchar(200) 	DEFAULT NULL	                COMMENT '备注',
    `create_time` 	datetime 		DEFAULT NULL	                COMMENT '创建时间',
    `update_time` 	datetime 		DEFAULT NULL	                COMMENT '修改时间',
    `operator` 		bigint(20) 		DEFAULT NULL	                COMMENT '操作人，关联internal_user表',
    PRIMARY KEY (`id`),
    KEY `FK_SMS_TEMPLATE_REF_OPERATOR` (`operator`),
    CONSTRAINT `FK_SMS_TEMPLATE_REF_OPERATOR` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `sql_template` (
    `id` 	    bigint(20) 		NOT NULL        AUTO_INCREMENT		COMMENT '主键',
    `name`		varchar(45) 	DEFAULT NULL	                    COMMENT '名称',
    `content`  	varchar(1000) 	DEFAULT NULL	                    COMMENT 'SQL语句，可以包含参数',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `filter_user` (
    `id` 			bigint(20) 		NOT NULL        AUTO_INCREMENT		COMMENT '主键',
    `name` 			varchar(20) 	NOT NULL 		                    COMMENT '名称',
    `sql_template`	bigint(20) 		DEFAULT NULL	                    COMMENT 'sql模板，关联sql_template表',
    `paramter`  	varchar(1000) 	DEFAULT NULL	                    COMMENT 'SQL参数，以&分割',
    `disable` 		tinyint(1) 		DEFAULT '1'		                    COMMENT '是否启用，默认为禁用，0-启用，1-禁用',
    `comment` 		varchar(200) 	DEFAULT NULL	                    COMMENT '备注',
    `create_time` 	datetime 		DEFAULT NULL	                    COMMENT '创建时间',
    `update_time` 	datetime 		DEFAULT NULL	                    COMMENT '修改时间',
    `operator` 		bigint(20) 		DEFAULT NULL	                    COMMENT '操作人，关联internal_user表',
    PRIMARY KEY (`id`),
    KEY `FK_FILTER_USER_REF_SQL_TEMPLATE` (`sql_template`),
    KEY `FK_FILTER_USER_REF_OPERATOR` (`operator`),
    CONSTRAINT `FK_FILTER_USER_REF_SQL_TEMPLATE` FOREIGN KEY (`sql_template`) REFERENCES `sql_template` (`id`),
    CONSTRAINT `FK_FILTER_USER_REF_OPERATOR` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `message_status` (
  `id`          BIGINT(20)     NOT NULL     AUTO_INCREMENT  COMMENT '主键',
  `status`      VARCHAR(45)    DEFAULT NULL                 COMMENT '状态',
  `description` VARCHAR(200)   DEFAULT NULL                 COMMENT '描述',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `adhoc_message` (
  `id`                  BIGINT(20)      NOT NULL AUTO_INCREMENT COMMENT '主键',
  `mobile`              VARCHAR(11)     DEFAULT NULL            COMMENT '用户手机号',
  `filter_user`         BIGINT(20)      DEFAULT NULL            COMMENT '筛选用户',
  `sms_template`        BIGINT(20)      DEFAULT NULL            COMMENT '短信模板',
  `parameter`           VARCHAR(1000)   DEFAULT NULL            COMMENT '短信内容参数',
  `send_flag`           TINYINT(1)      DEFAULT NULL            COMMENT '发送短信类型，0-立即发送，1-定时发送',
  `send_time`           DATETIME        DEFAULT NULL            COMMENT '发送短信时间',
  `status`              BIGINT(20)      DEFAULT NULL            COMMENT '发送状态',
  `comment`             VARCHAR(200)    DEFAULT NULL            COMMENT '备注',
  `create_time`         DATETIME        DEFAULT NULL            COMMENT '创建时间',
  `update_time`         DATETIME        DEFAULT NULL            COMMENT '修改时间',
  `operator`            BIGINT(20)      DEFAULT NULL            COMMENT '操作人',
  `sent_count`          INT(10)         DEFAULT NULL            COMMENT '已发送短信数量',
  `total_count`         INT(10)         DEFAULT NULL            COMMENT '总发送短信数量',
  PRIMARY KEY (`id`),
  KEY `FK_ADHOC_MESSAGE_REF_FILTER_USER` (`filter_user`),
  KEY `FK_ADHOC_MESSAGE_REF_SMS_TEMPLATE` (`sms_template`),
  KEY `FK_ADHOC_MESSAGE_REF_MESSAGE_STATUS` (`status`),
  KEY `FK_ADHOC_MESSAGE_REF_OPERATOR` (`operator`),
  CONSTRAINT `FK_ADHOC_MESSAGE_REF_FILTER_USER`     FOREIGN KEY (`filter_user`)     REFERENCES `filter_user` (`id`),
  CONSTRAINT `FK_ADHOC_MESSAGE_REF_SMS_TEMPLATE`    FOREIGN KEY (`sms_template`)    REFERENCES `sms_template` (`id`),
  CONSTRAINT `FK_ADHOC_MESSAGE_REF_MESSAGE_STATUS`  FOREIGN KEY (`status`)          REFERENCES `message_status` (`id`),
  CONSTRAINT `FK_ADHOC_MESSAGE_REF_OPERATOR`   FOREIGN KEY (`operator`)        REFERENCES `internal_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `schedule_condition` (
    `id`        BIGINT(20)      NOT NULL AUTO_INCREMENT     COMMENT '主键',
    `name`      VARCHAR(45)     NOT NULL                    COMMENT '条件名称',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `schedule_message` (
    `id` 			        BIGINT(20) 		NOT NULL  AUTO_INCREMENT	COMMENT '主键',
    `sms_template` 		    BIGINT(20) 		NOT NULL 		            COMMENT '短信模板',
    `schedule_condition`	BIGINT(20) 		DEFAULT NULL	            COMMENT '条件',
    `disable` 		        TINYINT(1) 		DEFAULT '1'		            COMMENT '是否启用，默认为禁用，0-启用，1-禁用',
    `comment` 		        VARCHAR(200) 	DEFAULT NULL	            COMMENT '备注',
    `create_time` 	        DATETIME 		DEFAULT NULL	            COMMENT '创建时间',
    `update_time` 	        DATETIME 		DEFAULT NULL	            COMMENT '修改时间',
    `operator` 		        BIGINT(20) 		DEFAULT NULL	            COMMENT '操作人，关联internal_user表',
    PRIMARY KEY (`id`),
    KEY `FK_SCHEDULE_MESSAGE_REF_SMS_TEMPLATE` (`sms_template`),
    KEY `FK_SCHEDULE_MESSAGE_REF_SCHEDULE_CONDITION` (`schedule_condition`),
    KEY `FK_SCHEDULE_MESSAGE_REF_OPERATOR` (`operator`),
    CONSTRAINT `FK_SCHEDULE_MESSAGE_REF_SMS_TEMPLATE`   FOREIGN KEY (`sms_template`)        REFERENCES `sms_template` (`id`),
    CONSTRAINT `FK_SCHEDULE_MESSAGE_REF_CONDITION`      FOREIGN KEY (`schedule_condition`)  REFERENCES `schedule_condition` (`id`),
    CONSTRAINT `FK_SCHEDULE_MESSAGE_REF_OPERATOR`  FOREIGN KEY (`operator`)            REFERENCES `internal_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `schedule_message_log` (
  `id`                  BIGINT(20)  NOT NULL AUTO_INCREMENT     COMMENT '主键',
  `schedule_message`    BIGINT(20)  NOT NULL                    COMMENT '条件触发短信',
  `mobile`              VARCHAR(11) DEFAULT NULL                COMMENT '手机号',
  `send_time`           DATETIME    DEFAULT NULL                COMMENT '发送时间',
  `status`              TINYINT(1)  DEFAULT NULL                COMMENT '状态1-成功，2-失败',
  PRIMARY KEY (`id`),
  KEY `FK_SCHEDULE_MESSAGE_LOG_REF_SCHEDULE_MESSAGE` (`schedule_message`),
  CONSTRAINT `FK_SCHEDULE_MESSAGE_LOG_REF_SCHEDULE_MESSAGE` FOREIGN KEY (`schedule_message`) REFERENCES `schedule_message` (`id`)
) ENGINE=INNODB DEFAULT CHARSET=utf8;
