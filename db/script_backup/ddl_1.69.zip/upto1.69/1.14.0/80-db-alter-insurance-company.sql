alter table insurance_company add renew_support boolean;
update insurance_company set renew_support = 1 where id = 10000; 
update insurance_company set renew_support = 1 where id = 15000; 
update insurance_company set renew_support = 1 where id = 20000; 
update insurance_company set renew_support = 1 where id = 25000; 
update insurance_company set renew_support = 0 where id = 30000; 
update insurance_company set renew_support = 0 where id = 35000; 
update insurance_company set renew_support = 0 where id = 40000; 
