DROP TABLE IF EXISTS `variable`;

CREATE TABLE IF NOT EXISTS `message_variable` (
    `id` 			bigint(20) 		NOT NULL        AUTO_INCREMENT		COMMENT '主键',
    `code`			varchar(45) 	DEFAULT NULL	                    COMMENT '变量编号',
    `name`			varchar(45) 	DEFAULT NULL	                    COMMENT '变量名称',
    `property`  	varchar(45) 	DEFAULT NULL	                    COMMENT '变量属性',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
