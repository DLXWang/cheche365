alter table filter_user change paramter parameter VARCHAR(1000);
