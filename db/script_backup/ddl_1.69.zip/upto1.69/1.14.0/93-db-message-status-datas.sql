INSERT INTO message_status(id, status, description) VALUES(1, '等待审核', '等待审核');
INSERT INTO message_status(id, status, description) VALUES(2, '审核失败', '审核失败');
INSERT INTO message_status(id, status, description) VALUES(3, '等待发送', '等待发送');
INSERT INTO message_status(id, status, description) VALUES(4, '发送成功', '发送成功');
INSERT INTO message_status(id, status, description) VALUES(5, '发送失败', '发送失败');
