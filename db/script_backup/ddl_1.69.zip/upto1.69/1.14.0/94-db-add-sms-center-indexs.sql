-- message_variable
create unique index idx_message_variable_code on message_variable(code);
create unique index idx_message_variable_name on message_variable(name);

-- sql_parameter
create unique index idx_sql_parameter_code on sql_parameter(code);
create unique index idx_sql_parameter_name on sql_parameter(name);

-- sms_template
create unique index idx_sms_template_name on sms_template(name);

-- filter_user
create unique index idx_filter_user_name on filter_user(name);
