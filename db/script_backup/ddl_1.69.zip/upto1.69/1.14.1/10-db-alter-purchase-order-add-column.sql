ALTER TABLE purchase_order ADD COLUMN audit tinyint(1) default 1;
UPDATE purchase_order set audit = 1;
