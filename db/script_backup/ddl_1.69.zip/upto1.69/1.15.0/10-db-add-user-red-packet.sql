CREATE TABLE  IF NOT EXISTS `user_red_packet` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `license_plate_no` VARCHAR(45) DEFAULT NULL COMMENT '车牌号',
  `mobile` VARCHAR(45) DEFAULT NULL COMMENT '用户手机号码',
  `nick_name` VARCHAR(200) DEFAULT NULL COMMENT '微信用户的别名',
  `open_id` VARCHAR(100) DEFAULT NULL COMMENT '微信的open_id',
  `operate_date` DATE DEFAULT NULL COMMENT '用户预约成功的日期',
  `user` BIGINT(20) DEFAULT NULL COMMENT '用户',
  `quote_photo` BIGINT(20) NOT NULL  COMMENT 'quote_photo表 的主键',
  `status` SMALLINT(1) NOT NULL DEFAULT '1' COMMENT '审核状态',

  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_u_user_red_packet_mobile` (`mobile`),
  UNIQUE KEY `idx_u_user_red_packet_open_id` (`open_id`),
  UNIQUE KEY `idx_u_user_red_packet_license_plate_no` (`license_plate_no`),
  KEY `FK_USER_RED_PACKET_USER_REF_USER` (`user`),
  KEY `FK_USER_RED_PACKET_QUOTE_PHOTO_REF_QUOTE_PHOTO` (`quote_photo`),
  CONSTRAINT `FK_USER_RED_PACKET_QUOTE_PHOTO_REF_QUOTE_PHOTO` FOREIGN KEY (`quote_photo`) REFERENCES `quote_photo` (`id`),
  CONSTRAINT `FK_USER_RED_PACKET_USER_REF_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`)
) ENGINE=INNODB DEFAULT CHARSET=utf8;
