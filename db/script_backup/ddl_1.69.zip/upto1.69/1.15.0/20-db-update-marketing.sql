UPDATE marketing set failure_date_class_param = "2015-12-31 23:59:59",
amount_class = "com.cheche365.cheche.rest.service.marketing.FixedAmount",
failure_date_class = "com.cheche365.cheche.rest.service.marketing.FixedDate",
full_limit_param = "100_1000;200_2000;300_3000;400_4000;500_5000;600_6000;700_7000;800_8000;900_9000;1000_10000;1100_11000;1200_12000;1300_13000;1400_14000;1500_15000",
marketing_type = "m" where id = "15";
