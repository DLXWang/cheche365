-- 变量属性改名为类型
ALTER TABLE `message_variable` change `property` `type` varchar(45) DEFAULT NULL COMMENT '变量类型';
-- 变量解释
ALTER TABLE `message_variable` ADD COLUMN `placeholder` varchar(45) DEFAULT NULL COMMENT '变量解释';
-- 变量长度
ALTER TABLE `message_variable` ADD COLUMN `length` SMALLINT(4) DEFAULT NULL COMMENT '变量长度';
-- 使用到的参数
ALTER TABLE `message_variable` ADD COLUMN `parameter` varchar(45) DEFAULT NULL COMMENT '使用到的参数';
-- 获取值关联的Model类
ALTER TABLE `message_variable` ADD COLUMN `model_class` varchar(100) DEFAULT NULL COMMENT '获取值关联的Model类';
-- 获取值关联的Model类方法
ALTER TABLE `message_variable` ADD COLUMN `model_method` varchar(100) DEFAULT NULL COMMENT '获取值关联的Model类方法';
