-- 发送给用户的短信参数
ALTER TABLE schedule_message_log ADD COLUMN parameter varchar(1000) DEFAULT NULL COMMENT '发送给用户的短信参数';
