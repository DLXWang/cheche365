-- 添加11.11ios活动和banner
INSERT INTO `ios_display_message` (`url`, `name`, `title`, `icon_url`, `description`, `message_type`, `weight`, `start_date`, `end_date`, `enable`, `tag`)
VALUES ('/marketing/m/201511001/index_IOSAPP.action', '双11，车车车险与滴滴代驾联合为您送福！', '双11，车车车险与滴滴代驾联合为您送福！', '20151111/activity/doubleone.jpg', NULL, 1, 14, '20151102', '20151130', 1, '20151111');
INSERT INTO `ios_display_message` (`url`, `name`, `title`, `icon_url`, `description`, `message_type`, `weight`, `start_date`, `end_date`, `enable`, `tag`)
VALUES ('/marketing/m/201511001/index_IOSAPP.action', '双11，车车车险与滴滴代驾联合为您送福！', '双11，车车车险与滴滴代驾联合为您送福！', '20151111/activity/doubleone.jpg', NULL, 3, 13, '20151102', '20151130', 1, '20151111');

-- 替换ios首页中间广告栏
UPDATE `ios_display_message` SET `icon_url` = '20151111/promotion/bj-l1.jpg' WHERE id = 9;
UPDATE `ios_display_message` SET `icon_url` = '20151111/promotion/bj-r1.jpg' WHERE id = 10;
UPDATE `ios_display_message` SET `icon_url` = '20151111/promotion/bj-r2.jpg' WHERE id = 11;
