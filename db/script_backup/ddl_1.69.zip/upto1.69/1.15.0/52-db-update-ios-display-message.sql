-- 下架5500红包，车船税，200元优惠券活动
UPDATE `ios_display_message` SET `end_date` = '2015-11-01', `enable` = 0 WHERE `message_type` = 3 AND `name` IN ('上车车，买车险，送5500红包，人保、平安、太平洋任你选！', '上车车买车险，立减车船税', '非北京地区200元优惠券');
-- 下架5500红包，车船税，200元优惠券banner
UPDATE `ios_display_message` SET `enable` = 0 WHERE `message_type` = 1 AND `name` IN ('非北京用户专享，200元车险红包，快来领取', '车船税活动');
