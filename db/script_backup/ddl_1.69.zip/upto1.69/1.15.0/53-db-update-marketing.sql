-- 活动5500红包，车船税，200元优惠券活动时间延期至2015-11-01 23:59:59
UPDATE `marketing` SET `end_date` = '2015-11-01 23:59:59' WHERE `code` IN ('p1', 'p2', 'p3');
