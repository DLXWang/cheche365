-- add alipay channel
INSERT INTO channel VALUES(10, '支付宝服务窗通道', 'ALIPAY');
