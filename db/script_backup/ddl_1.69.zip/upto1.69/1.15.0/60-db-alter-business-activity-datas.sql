update business_activity set display = 1
where instr(landing_page, '/m/channel/') > 0 and instr(landing_page, '#base') = 0;

update business_activity set display = 0
where instr(landing_page, '/m/channel/') > 0 and instr(landing_page, '#base') > 0;
