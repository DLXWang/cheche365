-- 删除跟双十一红包活动有关的条件触发数据
delete from schedule_message_log where schedule_message in (select id from schedule_message where schedule_condition = 21);
delete from schedule_message where schedule_condition = 21;
delete from schedule_condition where id = 21;
