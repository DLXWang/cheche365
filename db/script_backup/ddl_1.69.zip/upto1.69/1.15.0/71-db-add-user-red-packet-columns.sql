-- 短信发送状态
ALTER TABLE user_red_packet ADD COLUMN sms_flag tinyint(1) DEFAULT NULL COMMENT '短信发送状态';

-- 短信发送结果
ALTER TABLE user_red_packet ADD COLUMN sms_result varchar(45) DEFAULT NULL COMMENT '短信发送结果';

-- 微信红包发放状态
ALTER TABLE user_red_packet ADD COLUMN red_flag tinyint(1) DEFAULT NULL COMMENT '微信红包发放状态';
