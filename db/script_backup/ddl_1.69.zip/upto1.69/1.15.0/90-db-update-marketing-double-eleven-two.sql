UPDATE marketing set name="2015年双11活动",code="201511001",begin_date="2015-10-21 19:00:54",end_date="2015-10-31 19:00:56",
failure_date_class_param="2015-12-31 23:59:59",channel=NULL,amount_class_param="100;200;300;400;500;600;700;800;900;1000;1100;1200;1300;1400;1500",amount_class="com.cheche365.cheche.rest.service.marketing.FixedAmount",
failure_date_class="com.cheche365.cheche.rest.service.marketing.FixedDate",describle="双十一活动",gift_class="com.cheche365.cheche.core.service.market.JsonParamConvertor",
full_limit_param="100_1000;200_2000;300_3000;400_4000;500_5000;600_6000;700_7000;800_8000;900_9000;1000_10000;1100_11000;1200_12000;1300_13000;1400_14000;1500_15000",
marketing_type="m" WHERE id = 15;
