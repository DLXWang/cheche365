-- 红包发放结果
ALTER TABLE user_red_packet ADD COLUMN red_result varchar(45) DEFAULT NULL COMMENT '红包发放结果';
