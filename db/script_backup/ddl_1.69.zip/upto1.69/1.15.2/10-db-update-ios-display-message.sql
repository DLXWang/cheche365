update ios_display_message SET icon_url = '20151111/activity/didi11.jpg' where icon_url = '20151111/activity/doubleone.jpg';
