-- 修改双十一活动的URL地址
update business_activity
set landing_page = REPLACE(landing_page, 'marketing', 'marketing/m')
where landing_page is not null and LOCATE('marketing/201511001', landing_page) > 0;
