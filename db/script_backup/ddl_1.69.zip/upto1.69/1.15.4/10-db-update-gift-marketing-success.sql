update marketing set failure_date_class_param = "2015-11-30 23:59:59" where id = 15;
update marketing_success set failure_date = "2015-11-30 23:59:59" WHERE marketing_id = 15;
update gift t1 set t1.expire_date = "2015-11-30" where EXISTS (
select 1 from  marketing_success t2 where t1.source = t2.id
and t2.marketing_id = 15 and t1.source_type = 2);
