ALTER TABLE user_red_packet ADD COLUMN  `is_satisfied` SMALLINT(1) DEFAULT '1'  COMMENT '是否满足发红包的三个条件' ; 
ALTER TABLE user_red_packet ADD COLUMN  `description` VARCHAR(2000) DEFAULT NULL  COMMENT '不能发送红包的原因' ;
ALTER TABLE user_red_packet DROP INDEX `idx_u_user_red_packet_mobile`, DROP INDEX `idx_u_user_red_packet_open_id`; 
