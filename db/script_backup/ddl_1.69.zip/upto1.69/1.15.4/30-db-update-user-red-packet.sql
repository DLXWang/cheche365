update user_red_packet set is_satisfied = 1;
