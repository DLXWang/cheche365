-- modify 11.11 banner
update ios_display_message SET icon_url = '20151111/activity/doubleone.jpg' where icon_url = '20151111/activity/didi11.jpg';
-- remove pcauto banner
UPDATE `ios_display_message` SET `enable` = 0 WHERE `name` = '车车联合太平洋车友会送福利！';

