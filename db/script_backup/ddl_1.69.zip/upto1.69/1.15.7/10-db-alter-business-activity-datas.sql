update business_activity set refresh_flag = 1 where refresh_time is null and refresh_flag = 0;
