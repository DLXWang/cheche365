-- 删除管理员新建临时二维码权限(27)、下载临时二维码权限(29)、下载永久二维码权限(36)
DELETE FROM `role_permission` 
WHERE `role` = 8 
AND `permission` in(
27, -- 新建临时二维码权限
29, -- 下载临时二维码权限
36 -- 下载永久二维码权限
); 
