-- 微信后台资源
INSERT INTO `resource` VALUES ('16', '微信后台管理-二维码渠道管理', '1', '1', '2');
INSERT INTO `resource` VALUES ('17', '临时二维码', '16', '1', '3');
INSERT INTO `resource` VALUES ('18', '永久二维码', '16', '1', '3');
