-- 微信后台资源权限
INSERT INTO `permission_resource` VALUES ('42', '25', '17');
INSERT INTO `permission_resource` VALUES ('43', '26', '17');
INSERT INTO `permission_resource` VALUES ('44', '28', '17');
INSERT INTO `permission_resource` VALUES ('45', '30', '17');
INSERT INTO `permission_resource` VALUES ('46', '31', '17');
INSERT INTO `permission_resource` VALUES ('47', '32', '18');
INSERT INTO `permission_resource` VALUES ('48', '33', '18');
INSERT INTO `permission_resource` VALUES ('49', '34', '18');
INSERT INTO `permission_resource` VALUES ('50', '35', '18');
INSERT INTO `permission_resource` VALUES ('51', '37', '18');
INSERT INTO `permission_resource` VALUES ('52', '38', '18');
INSERT INTO `permission_resource` VALUES ('53', '39', '18');
INSERT INTO `permission_resource` VALUES ('54', '40', '18');
