INSERT INTO channel VALUES(11, '出单中心通道', 'ORDER_CENTER');
