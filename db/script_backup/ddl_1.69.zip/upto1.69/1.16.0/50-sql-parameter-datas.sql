insert into sql_parameter(id, code, name, type, placeholder, length)
values(1, '${StartTime}', '开始时间', 'time', '请输入开始时间', 19);
insert into sql_parameter(id, code, name, type, placeholder, length)
values(2, '${EndTime}', '结束时间', 'time', '请输入结束时间', 19);
insert into sql_parameter(id, code, name, type, placeholder, length)
values(3, '${Marketing.Single}', '参与单个活动', 'select', '请选择参与活动', 20);
insert into sql_parameter(id, code, name, type, placeholder, length)
values(4, '${Marketing.Multi}', '参与多个活动', 'multiSelect', '请选择参与活动', 20);
