-- 全体有手机号的用户
insert into sql_template(id, name, content)
values(1, '全体有手机号的用户', 'select distinct mobile from user where char_length(mobile) = 11, create_time) >= 0');

-- 领取指定活动优惠券但未使用的用户
insert into sql_template(id, name, content)
values(2, '领取指定活动优惠券但未使用用户', 'select distinct mar.mobile from marketing_success mar right join gift gf on mar.id = gf.source where mar.marketing_id in (${Marketing.Multi}) and gf.source_type = 2 and gf.status = 1 and char_length(mar.mobile) = 11');

-- 车险即将到期的用户(90天内)
insert into sql_template(id, name, content)
values(3, '车险即将到期用户', 'select distinct mobile from (select distinct us.* from appointment_insurance ai, user us where ai.user = us.id and char_length(us.mobile) = 11 and ai.expire_before is not null and ai.expire_before >= now() and datediff(DATE_ADD(now(),INTERVAL 90 DAY), ai.expire_before) >= 0 union select distinct us.* from insurance ins, user us where ins.applicant = us.id and char_length(us.mobile) = 11 and ins.expire_date is not null and ins.expire_date >= now() and datediff(DATE_ADD(now(),INTERVAL 90 DAY), ins.expire_date) >= 0 union select distinct us.* from compulsory_insurance cins, user us where cins.applicant = us.id and char_length(us.mobile) = 11 and cins.expire_date is not null and cins.expire_date >= now() and datediff(DATE_ADD(now(),INTERVAL 90 DAY), cins.expire_date) >= 0) user');

-- 购买过车险的用户
insert into sql_template(id, name, content)
values(4, '购买过车险用户', 'select distinct us.mobile from purchase_order po, user us, payment pay, order_operation_info oop where po.applicant = us.id and po.id = pay.purchase_order and po.id = oop.purchase_order and char_length(us.mobile) = 11 and po.status in (3, 4, 5) and po.channel in (1, 2, 3, 4, 5, 6, 7) and pay.status = 2 and pay.channel in (1, 2, 3, 4, 5, 6, 7) and oop.current_status in (7, 8, 9, 10, 11)');

-- 参与活动或领取优惠券的用户
insert into sql_template(id, name, content)
values(5, '参与活动或领取优惠券的用户', 'select distinct mobile from (select distinct mobile from marketing_success ms where char_length(ms.mobile) = 11 union select distinct us.mobile from gift gift, user us where gift.applicant = us.id and char_length(us.mobile) = 11) tab');
