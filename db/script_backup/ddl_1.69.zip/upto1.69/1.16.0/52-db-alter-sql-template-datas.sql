update sql_template set content = 'select distinct mobile from user where char_length(mobile) = 11' where id = 1;
