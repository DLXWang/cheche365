
ALTER TABLE uuidmapping ADD COLUMN version varchar(512) DEFAULT NULL COMMENT '版本信息';
ALTER TABLE uuidmapping ADD COLUMN appid varchar(512) DEFAULT NULL COMMENT 'appid';

