
DROP TABLE IF EXISTS `appid_mapping`;
CREATE TABLE `appid_mapping` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `appid` varchar(1024) DEFAULT NULL COMMENT 'appid',
  `mchid` varchar(1024) DEFAULT NULL COMMENT '合作伙伴id',
  `ios_cer_file` varchar(1024) DEFAULT NULL COMMENT 'ios 证书路径',
  `ios_cer_pwd` varchar(1024) DEFAULT NULL COMMENT 'ios 证书密码',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

