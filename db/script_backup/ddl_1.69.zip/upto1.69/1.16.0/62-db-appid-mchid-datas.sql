INSERT INTO appid_mapping( appid, mchid,ios_cer_file,ios_cer_pwd) VALUES('wxe3ee23dc2cb2c829','1279385301', 'aps_development.p12', '123456');


