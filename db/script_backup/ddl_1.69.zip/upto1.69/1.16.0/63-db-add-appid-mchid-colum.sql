ALTER TABLE appid_mapping ADD COLUMN user_appid varchar(512) DEFAULT NULL COMMENT 'userappid';

