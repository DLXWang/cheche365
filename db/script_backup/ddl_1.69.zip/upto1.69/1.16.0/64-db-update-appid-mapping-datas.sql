update appid_mapping set user_appid=1055592103 where id=1;
