INSERT INTO `appid_mapping` VALUES ('2', 'wx8f215a7f9024eafe', '1243723002', 'aps_production.p12', '123456', '1008078592');
