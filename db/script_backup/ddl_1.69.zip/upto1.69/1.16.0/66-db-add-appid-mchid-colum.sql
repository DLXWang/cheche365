ALTER TABLE appid_mapping ADD COLUMN dev_ios_cer_file varchar(512) DEFAULT NULL COMMENT ' dev ios cer file ';
ALTER TABLE appid_mapping ADD COLUMN dev_ios_cer_pwd varchar(512) DEFAULT NULL COMMENT ' dev ios cer file pwd ';

