update appid_mapping set dev_ios_cer_file='aps_development.p12' , dev_ios_cer_pwd='123456' , ios_cer_file='aps_production.p12',ios_cer_pwd='123456' where user_appid=1008078592;
