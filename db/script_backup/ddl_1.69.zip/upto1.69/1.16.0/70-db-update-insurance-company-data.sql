update insurance_company set type = 4 where id = 45000;
