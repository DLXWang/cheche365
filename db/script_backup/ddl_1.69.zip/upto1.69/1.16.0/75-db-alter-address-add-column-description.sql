ALTER TABLE address ADD COLUMN description varchar(2000) DEFAULT NULL;
