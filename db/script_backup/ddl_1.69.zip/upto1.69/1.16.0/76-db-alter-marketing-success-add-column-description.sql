ALTER TABLE marketing_success ADD COLUMN description varchar(2000) DEFAULT NULL;
