UPDATE `ios_display_message` SET `url` = '/marketing/m/201511001/index_IOSAPP.action',`name` = '千万车险红包，赢取免单名额！', title = '千万车险红包，赢取免单名额！' WHERE id in (9, 10);
