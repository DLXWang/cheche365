INSERT INTO `sms_template`(name, zucp_code, yxt_code, disable, content, comment, create_time, update_time, operator)
VALUES ('完成订单', '030000038_006', '030000038_006', '0', '您的车险已订购成功。保险公司：${InsuranceCompany.Name}，保费：${Order.PremiumAmount}元。车车将通过官方唯一客服电话4000150999与您联系，请保持电话畅通。', '初始化数据，未设置操作人', now(), now(), NULL);
INSERT INTO `sms_template`(name, zucp_code, yxt_code, disable, content, comment, create_time, update_time, operator)
VALUES ('未支付订单短信提醒', 'PENDING_001', null, '0', '尊敬的车车用户您好，您的订单已提交30分钟啦，请登陆dwz.cn/27T8Rb 尽快付款，车车好继续为您服务。如有疑问，请随时拨打车车客服电话4000150999。感谢您对车车的支持。', '初始化数据，未设置操作人', now(), now(), NULL);
INSERT INTO `sms_template`(name, zucp_code, yxt_code, disable, content, comment, create_time, update_time, operator)
VALUES ('通知客户上门收款', 'PENDING_002', null, '0', '尊敬的车车用户您好，您的订单编号：${Order.OrderNo}，订单总金额：${Order.Premium}元（其中保费金额${Order.PremiumAmount}元，车船税${Quote.AutoTax}元），车车工作人员将于${Order.PayTime}上门刷卡，请您保持手机畅通。感谢您对车车的信任。车车客服电话：4000150999', '初始化数据，未设置操作人', now(), now(), NULL);
INSERT INTO `sms_template`(name, zucp_code, yxt_code, disable, content, comment, create_time, update_time, operator)
VALUES ('通知客户派送保单', 'PENDING_003', null, '0', '尊敬的车车用户您好，您的订单编号：${Order.OrderNo}，将由顺风快递派送保单，快递单号${Order.TrackingNo}，请您保持手机畅通。您亦可登录APP或微信公众账号“我的-电子保单”中查看电子保单，详情请见dwz.cn/27T8Rb 。感谢您对车车的信任，车车客服电话：4000150999', '初始化数据，未设置操作人', now(), now(), NULL);
INSERT INTO `sms_template`(name, zucp_code, yxt_code, disable, content, comment, create_time, update_time, operator)
VALUES ('参与各种活动短信', 'PENDING_006', null, '0', '${Marketing.Name}活动正在进行中！便宜车险快来抢，尊贵服务随意享。车险最高优惠30%，还可尊享车车助手vip专属服务。详情见${Marketing.LandingPage}', '初始化数据，未设置操作人', now(), now(), NULL);
INSERT INTO `sms_template`(name, zucp_code, yxt_code, disable, content, comment, create_time, update_time, operator)
VALUES ('红包提醒使用', 'PENDING_008', null, '0', '亲，车车提醒，您还有车险红包尚未使用。车险快到期，用了能便宜！优惠券可在提交订单时使用，将直接扣减需支付金额；礼品券所带礼品将随保单附送。下载app或关注微信公众号“checheapp”打开“我的车车”-“优惠券”即可查看。详情请登录dwz.cn/27T8Rb ，或随时拨打车车客服专线4000150999。', '初始化数据，未设置操作人', now(), now(), NULL);
INSERT INTO `sms_template`(name, zucp_code, yxt_code, disable, content, comment, create_time, update_time, operator)
VALUES ('短信轰炸营销', 'PENDING_009', null, '0', '亲，车车车险巨惠来袭！红包优惠越来越大，VIP服务越来越爽！车险最高优惠30%，关注微信公众号“checheapp”还可尊享车车助手vip专属服务。详情见dwz.cn/22rJRI', '初始化数据，未设置操作人', now(), now(), NULL);
INSERT INTO `sms_template`(name, zucp_code, yxt_code, disable, content, comment, create_time, update_time, operator)
VALUES ('保单生效出单', 'PENDING_012', null, '0', '尊敬的车车用户您好，您的爱车（车牌号${Auto.LicensePlateNo}）保单已生效，订单编号为：${Order.OrderNo}，投保公司为${InsuranceCompany.Name}，保险起始日为${Order.EffectiveDate}。车车将于${DeliveryInsuranceDays}个工作日内为您递出保单，请您耐心等待。感谢您对车车的信任。车车客服电话：4000150999', '初始化数据，未设置操作人', now(), now(), NULL);
INSERT INTO `sms_template`(name, zucp_code, yxt_code, disable, content, comment, create_time, update_time, operator)
VALUES ('5500红包活动', '030000038_013', '030000038_013', '0', '5500元红包已放入您的${Mobile}账户，关注车车微信号“checheapp”即可使用,询4000-150-999', '初始化数据，未设置操作人', now(), now(), NULL);
INSERT INTO `sms_template`(name, zucp_code, yxt_code, disable, content, comment, create_time, update_time, operator)
VALUES ('雷雨天气关怀', 'PENDING_013', null, '0', '尊敬的车车用户您好，进入雷雨季节请注意行车安全。如遇暴雨，在视线不清楚的情况下，建议打开双闪与雾灯，停靠在安全地带等待雨小后再行驶；如遇路面积水，建议绕道行驶或在安全地带停靠，等待积水褪去后再行驶。车车衷心的祝福您生活和工作开心快乐，关注车车微信号“checheapp”，客服专线4000150999，车车竭诚为您服务dwz.cn/22rJRI 。', '初始化数据，未设置操作人', now(), now(), NULL);
INSERT INTO `sms_template`(name, zucp_code, yxt_code, disable, content, comment, create_time, update_time, operator)
VALUES ('大风天气关怀', 'PENDING_014', null, '0', '尊敬的车车用户您好，近日大风请注意行车安全尽量减速慢行。在停车时，尽量不要停靠在高楼下或树下，尽量避免因大风导致的高空坠物或树木折断而造成车辆受损。车车衷心的祝福您生活和工作开心快乐，关注车车微信号“checheapp”，客服专线4000150999，车车竭诚为您服务dwz.cn/22rJRI 。', '初始化数据，未设置操作人', now(), now(), NULL);
INSERT INTO `sms_template`(name, zucp_code, yxt_code, disable, content, comment, create_time, update_time, operator)
VALUES ('冰雪天气关怀', 'PENDING_015', null, '0', '尊敬的车车用户您好，进入天寒地冻的冬季，在冰雪天中驾车，请务必慢行，打开雾灯，避免急刹车与猛打方向盘的情况。车车衷心的祝福您生活和工作开心快乐，关注车车微信号“checheapp”，客服专线4000150999，车车竭诚为您服务dwz.cn/22rJRI ', '初始化数据，未设置操作人', now(), now(), NULL);
INSERT INTO `sms_template`(name, zucp_code, yxt_code, disable, content, comment, create_time, update_time, operator)
VALUES ('炎热夏季关怀', 'PENDING_016', null, '0', '尊敬的车车用户您好，进入炎热干燥的夏季，请您时常注意车辆水箱中的水位水温是否正常；尽量将车停放在有阴凉的地方，且不要在车内放置食品或其他可燃物；最后郑重提醒，千万不要将孩子遗忘在车内哦！车车衷心的祝福您生活和工作开心快乐，关注车车微信号“checheapp”，客服专线4000150999，车车竭诚为您服务dwz.cn/22rJRI ', '初始化数据，未设置操作人', now(), now(), NULL);
INSERT INTO `sms_template`(name, zucp_code, yxt_code, disable, content, comment, create_time, update_time, operator)
VALUES ('车船税活动', 'PENDING_017', null, '0', '车船税减免券已放入您的账户，9月来车车买车险，报价立减车船税，最高立减4400元，点击立即报价 t.cn/RLDsybM', '初始化数据，未设置操作人', now(), now(), NULL);
INSERT INTO `sms_template`(name, zucp_code, yxt_code, disable, content, comment, create_time, update_time, operator)
VALUES ('上广深200元优惠券', 'PENDING_018', null, '0', '200元车险代金券已放入您的账户，购买人保、平安、太平洋大牌车险85折起立减200元，点击查看报价 t.cn/RLDsLMY', '初始化数据，未设置操作人', now(), now(), NULL);
INSERT INTO `sms_template`(name, zucp_code, yxt_code, disable, content, comment, create_time, update_time, operator)
VALUES ('支付成功', 'PENDING_023', null, '0', '尊敬的车车用户您好，您的订单已支付成功，车车客服会尽快与您联系，核对您的信息。如有疑问，请随时拨打车车客服电话4000150999。感谢您对车车的支持。', '初始化数据，未设置操作人', now(), now(), NULL);
INSERT INTO `sms_template`(name, zucp_code, yxt_code, disable, content, comment, create_time, update_time, operator)
VALUES ('订单取消', 'PENDING_024', null, '0', '尊敬的车车用户您好，您的订单已成功取消，如有疑问，请随时拨打车车客服电话4000150999。感谢您对车车的支持。', '初始化数据，未设置操作人', now(), now(), NULL);
INSERT INTO `sms_template`(name, zucp_code, yxt_code, disable, content, comment, create_time, update_time, operator)
VALUES ('人工报价', 'PENDING_021', null, '0', '尊敬的车车用户您好，车车为您报价：您选择的${InsuranceCompany.Name}，${CustomerQuoteDetail}最终价格以出单时保单价格为准。如需详询请致电车车24小时客服专线4000150999，或登陆dwz.cn/22rJRI 自行查询配比保险价格。', '初始化数据，未设置操作人', now(), now(), NULL);
INSERT INTO `sms_template`(name, zucp_code, yxt_code, disable, content, comment, create_time, update_time, operator)
VALUES ('人工提交订单', 'PENDING_022', null, '0', '尊敬的车车用户您好，车车客服已为您生成订单，请点击dwz.cn/27T8Rb ，查看并支付。如需详询请致电4000150999。感谢您对车车的支持。', '初始化数据，未设置操作人', now(), now(), NULL);
INSERT INTO `sms_template`(name, zucp_code, yxt_code, disable, content, comment, create_time, update_time, operator)
VALUES ('双11活动', 'PENDING_019', null, '0', '车车车险双十一“买车险赢免单”活动1500元红包已存入您的${Mobile}账户，立即使用赢免单dwz.cn/22rJRI', '初始化数据，未设置操作人', now(), now(), NULL);
INSERT INTO `sms_template`(name, zucp_code, yxt_code, disable, content, comment, create_time, update_time, operator)
VALUES ('双11活动审核通过发', 'PENDING_020', null, '0', '尊敬的用户，您参加车车车险双十一“预约送红包”活动审核通过，50元微信红包将发到您的微信，请注意查收。双十一购车险，千万红包还能免单，戳我参与：t.cn/RUf2bN6', '初始化数据，未设置操作人', now(), now(), NULL);
