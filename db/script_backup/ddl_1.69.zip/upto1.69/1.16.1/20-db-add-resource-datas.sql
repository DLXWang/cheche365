﻿-- 短信中心资源
INSERT INTO `resource` VALUES ('19', '短信中心', '1', '1', '2');
INSERT INTO `resource` VALUES ('20', '短信模板管理', '19', '1', '3');
INSERT INTO `resource` VALUES ('21', '筛选用户功能管理', '19', '1', '3');
INSERT INTO `resource` VALUES ('22', '条件触发短信', '19', '1', '3');
INSERT INTO `resource` VALUES ('23', '条件触发短信日志', '19', '1', '3');
INSERT INTO `resource` VALUES ('24', '主动发送短信', '19', '1', '3');
-- 红包审核资源
INSERT INTO `resource` VALUES ('25', '红包发送审核', '1', '1', '2');
INSERT INTO `resource` VALUES ('26', '红包发送审核', '25', '1', '3');