﻿-- 短信中心资源权限：短信模板管理
INSERT INTO `permission_resource` VALUES ('55', '66', '20');
INSERT INTO `permission_resource` VALUES ('56', '67', '20');
INSERT INTO `permission_resource` VALUES ('57', '68', '20');
INSERT INTO `permission_resource` VALUES ('58', '69', '20');
-- 短信中心资源权限：筛选用户功能管理
INSERT INTO `permission_resource` VALUES ('59', '70', '21');
INSERT INTO `permission_resource` VALUES ('60', '71', '21');
INSERT INTO `permission_resource` VALUES ('61', '72', '21');
INSERT INTO `permission_resource` VALUES ('62', '73', '21');
INSERT INTO `permission_resource` VALUES ('63', '74', '21');
-- 短信中心资源权限：条件触发短信
INSERT INTO `permission_resource` VALUES ('64', '75', '22');
INSERT INTO `permission_resource` VALUES ('65', '76', '22');
INSERT INTO `permission_resource` VALUES ('66', '77', '22');
INSERT INTO `permission_resource` VALUES ('67', '78', '22');
-- 短信中心资源权限：条件触发短信日志
INSERT INTO `permission_resource` VALUES ('68', '79', '23');
-- 短信中心资源权限：主动发送短信
INSERT INTO `permission_resource` VALUES ('69', '80', '24');
INSERT INTO `permission_resource` VALUES ('70', '81', '24');
INSERT INTO `permission_resource` VALUES ('71', '82', '24');
INSERT INTO `permission_resource` VALUES ('72', '83', '24');
INSERT INTO `permission_resource` VALUES ('73', '84', '24');
-- 红包审核资源权限
INSERT INTO `permission_resource` VALUES ('74', '85', '26');