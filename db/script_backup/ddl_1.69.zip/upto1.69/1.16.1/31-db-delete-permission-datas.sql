-- 删除调试筛选用户功能权限资源表
DELETE FROM `permission_resource` WHERE `permission` = 74;
-- 删除调试筛选用户功能角色权限
DELETE FROM `role_permission` WHERE `permission` = 74;
-- 删除调试筛选用户功能权限
DELETE FROM `permission` WHERE `id` = 74;
