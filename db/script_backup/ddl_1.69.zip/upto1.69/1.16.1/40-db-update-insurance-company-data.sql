update insurance_company set type = 2 where id = 20000;
