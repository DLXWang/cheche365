-- 出单中心权限
INSERT INTO `permission` VALUES ('86', '出单中心/订单管理/线下订单', '查看线下订单页', '2', '1', 'or0101');
INSERT INTO `permission` VALUES ('87', '出单中心/订单管理/线上订单', '查看线上订单页', '2', '1', 'or0102');
INSERT INTO `permission` VALUES ('88', '出单中心/订单管理/订单查询', '查看订单查询页', '2', '1', 'or0103');
INSERT INTO `permission` VALUES ('89', '出单中心/订单管理/分配订单', '查看分配订单页', '2', '1', 'or0104');
INSERT INTO `permission` VALUES ('90', '出单中心/订单管理/保单录入', '查看保单录入页', '2', '1', 'or0105');
INSERT INTO `permission` VALUES ('91', '出单中心/客户管理/客户预约', '查看客户预约页', '2', '1', 'or0201');
INSERT INTO `permission` VALUES ('92', '出单中心/代理人管理/新增代理人', '查看新增代理人页', '2', '1', 'or0301');
INSERT INTO `permission` VALUES ('93', '出单中心/代理人管理/代理人列表', '查看代理人列表页', '2', '1', 'or0302');
INSERT INTO `permission` VALUES ('94', '出单中心/用户管理/新增用户', '查看新增用户页', '2', '1', 'or0401');
INSERT INTO `permission` VALUES ('95', '出单中心/用户管理/用户列表', '查看用户列表页', '2', '1', 'or0402');
INSERT INTO `permission` VALUES ('96', '出单中心/用户管理/配置用户组', '查看配置用户组页', '2', '1', 'or0403');
INSERT INTO `permission` VALUES ('97', '出单中心/用户管理/用户组列表', '查看用户组列表页', '2', '1', 'or0404');
INSERT INTO `permission` VALUES ('98', '出单中心/车辆报价/拍照信息', '查看拍照信息页', '2', '1', 'or0501');
INSERT INTO `permission` VALUES ('99', '出单中心/车辆报价/电话信息', '查看电话信息页', '2', '1', 'or0502');
