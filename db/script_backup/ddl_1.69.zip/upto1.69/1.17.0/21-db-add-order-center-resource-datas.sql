-- 出单中心资源
INSERT INTO `resource` VALUES ('27', '出单中心', null, '1', '1');
-- 订单管理
INSERT INTO `resource` VALUES ('28', '订单管理', '27', '1', '2');
INSERT INTO `resource` VALUES ('29', '线下订单', '28', '1', '3');
INSERT INTO `resource` VALUES ('30', '线上订单', '28', '1', '3');
INSERT INTO `resource` VALUES ('31', '订单查询', '28', '1', '3');
INSERT INTO `resource` VALUES ('32', '分配订单', '28', '1', '3');
INSERT INTO `resource` VALUES ('33', '保单录入', '28', '1', '3');
-- 客户管理
INSERT INTO `resource` VALUES ('34', '客户管理', '27', '1', '2');
INSERT INTO `resource` VALUES ('35', '客户预约', '34', '1', '3');
-- 代理人管理
INSERT INTO `resource` VALUES ('36', '代理人管理', '27', '1', '2');
INSERT INTO `resource` VALUES ('37', '新增代理人', '36', '1', '3');
INSERT INTO `resource` VALUES ('38', '代理人列表', '36', '1', '3');
-- 用户管理
INSERT INTO `resource` VALUES ('39', '用户管理', '27', '1', '2');
INSERT INTO `resource` VALUES ('40', '新增用户', '39', '1', '3');
INSERT INTO `resource` VALUES ('41', '用户列表', '39', '1', '3');
INSERT INTO `resource` VALUES ('42', '配置用户组', '39', '1', '3');
INSERT INTO `resource` VALUES ('43', '用户组列表', '39', '1', '3');
-- 车辆报价
INSERT INTO `resource` VALUES ('44', '车辆报价', '27', '1', '2');
INSERT INTO `resource` VALUES ('45', '拍照信息', '44', '1', '3');
INSERT INTO `resource` VALUES ('46', '电话信息', '44', '1', '3');
