-- 出单中心资源权限
INSERT INTO `permission_resource` VALUES ('75', '10', '27');
INSERT INTO `permission_resource` VALUES ('76', '86', '29');
INSERT INTO `permission_resource` VALUES ('77', '87', '30');
INSERT INTO `permission_resource` VALUES ('78', '88', '31');
INSERT INTO `permission_resource` VALUES ('79', '89', '32');
INSERT INTO `permission_resource` VALUES ('80', '90', '33');
INSERT INTO `permission_resource` VALUES ('81', '91', '35');
INSERT INTO `permission_resource` VALUES ('82', '92', '37');
INSERT INTO `permission_resource` VALUES ('83', '93', '38');
INSERT INTO `permission_resource` VALUES ('84', '94', '40');
INSERT INTO `permission_resource` VALUES ('85', '95', '41');
INSERT INTO `permission_resource` VALUES ('86', '96', '42');
INSERT INTO `permission_resource` VALUES ('87', '97', '43');
INSERT INTO `permission_resource` VALUES ('88', '98', '45');
INSERT INTO `permission_resource` VALUES ('89', '99', '46');
