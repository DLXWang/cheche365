-- 更新出单中心原有角色名称
update `role` set `name`='出单中心客服', disable=0 where id=1;
update `role` set `name`='出单中心内勤', disable=0 where id=2;
update `role` set `name`='出单中心管理员', disable=0 where id=3;
update `role` set `name`='出单中心CPS', disable=0 where id=4;
update `role` set `name`='出单中心外勤', disable=0 where id=5;
update `role` set `name`='出单中心修改状态', disable=0 where id=6;
update `role` set `name`='出单中心录单员', disable=0 where id=7;

-- 给出单中心原有角色添加权限
-- 出单中心管理员
insert into role_permission(role, permission) values(3, 10);
insert into role_permission(role, permission) values(3, 86);
insert into role_permission(role, permission) values(3, 87);
insert into role_permission(role, permission) values(3, 88);
insert into role_permission(role, permission) values(3, 89);
insert into role_permission(role, permission) values(3, 90);
insert into role_permission(role, permission) values(3, 91);
insert into role_permission(role, permission) values(3, 92);
insert into role_permission(role, permission) values(3, 93);
insert into role_permission(role, permission) values(3, 94);
insert into role_permission(role, permission) values(3, 95);
insert into role_permission(role, permission) values(3, 96);
insert into role_permission(role, permission) values(3, 97);
insert into role_permission(role, permission) values(3, 98);
insert into role_permission(role, permission) values(3, 99);
-- 出单中心客服
insert into role_permission(role, permission) values(1, 10);
insert into role_permission(role, permission) values(1, 86);
insert into role_permission(role, permission) values(1, 87);
insert into role_permission(role, permission) values(1, 88);
insert into role_permission(role, permission) values(1, 91);
insert into role_permission(role, permission) values(1, 98);
insert into role_permission(role, permission) values(1, 99);
-- 出单中心内勤
insert into role_permission(role, permission) values(2, 10);
insert into role_permission(role, permission) values(2, 86);
insert into role_permission(role, permission) values(2, 87);
insert into role_permission(role, permission) values(2, 88);
insert into role_permission(role, permission) values(2, 90);
insert into role_permission(role, permission) values(2, 91);
insert into role_permission(role, permission) values(2, 98);
insert into role_permission(role, permission) values(2, 99);
-- 出单中心外勤
insert into role_permission(role, permission) values(5, 10);
insert into role_permission(role, permission) values(5, 86);
insert into role_permission(role, permission) values(5, 87);
insert into role_permission(role, permission) values(5, 88);
insert into role_permission(role, permission) values(5, 91);
-- 出单中心录单员
insert into role_permission(role, permission) values(7, 10);
insert into role_permission(role, permission) values(7, 88);
insert into role_permission(role, permission) values(7, 90);
