ALTER TABLE `gift`  CHANGE COLUMN `description` `description` VARCHAR(2000) NULL DEFAULT NULL ;
