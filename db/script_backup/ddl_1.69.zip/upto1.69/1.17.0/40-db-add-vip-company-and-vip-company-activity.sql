INSERT INTO vip_company(id,code,name,create_time,update_time) VALUES(22, 'lenovo', '联想',now(),now());


INSERT INTO vip_company_activity(id,code,name,company,insurance_url,error_url,begin_date,end_date,rule_class,unsupport_company,payment_channel_channel) VALUES
(22,'lenovo_1','联想-活动1',22,'lenovo.html','','2015-11-10','2016-11-10','com.cheche365.cheche.core.service.factory.VipActivityHandler',NULL,'1,3,4,6');


INSERT INTO vip_company(id,code,name,create_time,update_time) VALUES(23, 'lianjia', '链家',now(),now());


INSERT INTO vip_company_activity(id,code,name,company,insurance_url,error_url,begin_date,end_date,rule_class,unsupport_company,payment_channel_channel) VALUES
(23,'lianjia_1','链家-活动1',23,'lianjia.html','','2015-11-10','2016-11-10','com.cheche365.cheche.core.service.factory.VipActivityHandler',NULL,'1,3,4,6');


INSERT INTO vip_company(id,code,name,create_time,update_time) VALUES(24, 'baidu', '百度',now(),now());


INSERT INTO vip_company_activity(id,code,name,company,insurance_url,error_url,begin_date,end_date,rule_class,unsupport_company,payment_channel_channel) VALUES
(24,'baidu_1','百度-活动1',24,'baidu.html','','2015-11-10','2016-11-10','com.cheche365.cheche.core.service.factory.VipActivityHandler',NULL,'1,3,4,6');


INSERT INTO vip_company(id,code,name,create_time,update_time) VALUES(25, '58', '58同城',now(),now());


INSERT INTO vip_company_activity(id,code,name,company,insurance_url,error_url,begin_date,end_date,rule_class,unsupport_company,payment_channel_channel) VALUES
(25,'58_1','58同城-活动1',25,'58.html','','2015-11-10','2016-11-10','com.cheche365.cheche.core.service.factory.VipActivityHandler',NULL,'1,3,4,6');


INSERT INTO vip_company(id,code,name,create_time,update_time) VALUES(26, 'ganji', '赶集',now(),now());


INSERT INTO vip_company_activity(id,code,name,company,insurance_url,error_url,begin_date,end_date,rule_class,unsupport_company,payment_channel_channel) VALUES
(26,'ganji_1','赶集-活动1',26,'ganji.html','','2015-11-10','2016-11-10','com.cheche365.cheche.core.service.factory.VipActivityHandler',NULL,'1,3,4,6');


INSERT INTO vip_company(id,code,name,create_time,update_time) VALUES(27, '91jinrong', '91金融',now(),now());


INSERT INTO vip_company_activity(id,code,name,company,insurance_url,error_url,begin_date,end_date,rule_class,unsupport_company,payment_channel_channel) VALUES
(27,'91jinrong_1','91金融-活动1',27,'91jinrong.html','','2015-11-10','2016-11-10','com.cheche365.cheche.core.service.factory.VipActivityHandler',NULL,'1,3,4,6');


INSERT INTO vip_company(id,code,name,create_time,update_time) VALUES(28, 'ruijie', '锐捷网络',now(),now());


INSERT INTO vip_company_activity(id,code,name,company,insurance_url,error_url,begin_date,end_date,rule_class,unsupport_company,payment_channel_channel) VALUES
(28,'ruijie_1','锐捷网络-活动1',28,'ruijie.html','','2015-11-10','2016-11-10','com.cheche365.cheche.core.service.factory.VipActivityHandler',NULL,'1,3,4,6');


INSERT INTO vip_company(id,code,name,create_time,update_time) VALUES(29, 'jsj', '金色世纪',now(),now());


INSERT INTO vip_company_activity(id,code,name,company,insurance_url,error_url,begin_date,end_date,rule_class,unsupport_company,payment_channel_channel) VALUES
(29,'jsj_1','金色世纪-活动1',29,'jsj.html','','2015-11-10','2016-11-10','com.cheche365.cheche.core.service.factory.VipActivityHandler',NULL,'1,3,4,6');


INSERT INTO vip_company(id,code,name,create_time,update_time) VALUES(30, 'iqiyi', '爱奇艺',now(),now());


INSERT INTO vip_company_activity(id,code,name,company,insurance_url,error_url,begin_date,end_date,rule_class,unsupport_company,payment_channel_channel) VALUES
(30,'iqiyi_1','爱奇艺-活动1',30,'iqiyi.html','','2015-11-10','2016-11-10','com.cheche365.cheche.core.service.factory.VipActivityHandler',NULL,'1,3,4,6');


INSERT INTO vip_company(id,code,name,create_time,update_time) VALUES(31, 'xdf', '新东方',now(),now());


INSERT INTO vip_company_activity(id,code,name,company,insurance_url,error_url,begin_date,end_date,rule_class,unsupport_company,payment_channel_channel) VALUES
(31,'xdf_1','新东方-活动1',31,'xdf.html','','2015-11-10','2016-11-10','com.cheche365.cheche.core.service.factory.VipActivityHandler',NULL,'1,3,4,6');


INSERT INTO vip_company(id,code,name,create_time,update_time) VALUES(32, 'tencent', '腾讯',now(),now());


INSERT INTO vip_company_activity(id,code,name,company,insurance_url,error_url,begin_date,end_date,rule_class,unsupport_company,payment_channel_channel) VALUES
(32,'tencent_1','腾讯-活动1',32,'tencent.html','','2015-11-10','2016-11-10','com.cheche365.cheche.core.service.factory.VipActivityHandler',NULL,'1,3,4,6');


INSERT INTO vip_company(id,code,name,create_time,update_time) VALUES(33, 'lecai', '百度彩票',now(),now());


INSERT INTO vip_company_activity(id,code,name,company,insurance_url,error_url,begin_date,end_date,rule_class,unsupport_company,payment_channel_channel) VALUES
(33,'lecai_1','百度彩票-活动1',33,'lecai.html','','2015-11-10','2016-11-10','com.cheche365.cheche.core.service.factory.VipActivityHandler',NULL,'1,3,4,6');


INSERT INTO vip_company(id,code,name,create_time,update_time) VALUES(34, 'cmcm', '猎豹移动',now(),now());


INSERT INTO vip_company_activity(id,code,name,company,insurance_url,error_url,begin_date,end_date,rule_class,unsupport_company,payment_channel_channel) VALUES
(34,'cmcm_1','猎豹移动-活动1',34,'cmcm.html','','2015-11-10','2016-11-10','com.cheche365.cheche.core.service.factory.VipActivityHandler',NULL,'1,3,4,6');


INSERT INTO vip_company(id,code,name,create_time,update_time) VALUES(35, 'jd', '京东',now(),now());


INSERT INTO vip_company_activity(id,code,name,company,insurance_url,error_url,begin_date,end_date,rule_class,unsupport_company,payment_channel_channel) VALUES
(35,'jd_1','京东-活动1',35,'jd.html','','2015-11-10','2016-11-10','com.cheche365.cheche.core.service.factory.VipActivityHandler',NULL,'1,3,4,6');



INSERT INTO vip_company(id,code,name,create_time,update_time) VALUES(36, 'meituan', '美团',now(),now());


INSERT INTO vip_company_activity(id,code,name,company,insurance_url,error_url,begin_date,end_date,rule_class,unsupport_company,payment_channel_channel) VALUES
(36,'meituan_1','美团-活动1',36,'meituan.html','','2015-11-10','2016-11-10','com.cheche365.cheche.core.service.factory.VipActivityHandler',NULL,'1,3,4,6');


INSERT INTO vip_company(id,code,name,create_time,update_time) VALUES(37, 'sohu', '搜狐',now(),now());


INSERT INTO vip_company_activity(id,code,name,company,insurance_url,error_url,begin_date,end_date,rule_class,unsupport_company,payment_channel_channel) VALUES
(37,'sohu_1','搜狐-活动1',37,'sohu.html','','2015-11-10','2016-11-10','com.cheche365.cheche.core.service.factory.VipActivityHandler',NULL,'1,3,4,6');

INSERT INTO vip_company(id,code,name,create_time,update_time) VALUES(38, 'chalco', '中国铝业',now(),now());


INSERT INTO vip_company_activity(id,code,name,company,insurance_url,error_url,begin_date,end_date,rule_class,unsupport_company,payment_channel_channel) VALUES
(38,'chalco_1','中国铝业-活动1',38,'chalco.html','','2015-11-10','2016-11-10','com.cheche365.cheche.core.service.factory.VipActivityHandler',NULL,'1,3,4,6');
