ALTER TABLE schedule_condition ADD COLUMN marketing bigint(20) DEFAULT NULL;
ALTER TABLE schedule_condition ADD FOREIGN KEY (marketing) REFERENCES marketing(id) ON DELETE RESTRICT ON UPDATE RESTRICT;

update schedule_condition set marketing = 8 where id = 7;
update schedule_condition set marketing = 9 where id = 8;
update schedule_condition set marketing = 10 where id = 9;
