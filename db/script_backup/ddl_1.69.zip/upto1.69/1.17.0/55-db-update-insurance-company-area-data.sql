-- 国寿财不支持天津
delete from insurance_company_area where insurance_company_id = 40000 and area_id = 120000;
