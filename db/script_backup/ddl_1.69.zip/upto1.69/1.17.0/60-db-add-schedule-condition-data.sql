INSERT INTO schedule_condition(id, name, marketing) VALUES(10, '2015年双十一红包活动', 15);
