-- 阳光不支持深圳
delete from insurance_company_area where insurance_company_id = 15000 and area_id = 440300;
