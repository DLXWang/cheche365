ALTER TABLE `marketing` CHANGE COLUMN `describle` `description` VARCHAR(2000) NULL DEFAULT NULL ;
