UPDATE `gift_code_exchange_way`
SET `name`= '自媒体会场全国通用兑换券'
WHERE id = '13';

UPDATE gift set reason = '自媒体会场全国通用兑换券'
WHERE reason = '300元全国通用兑换券';
