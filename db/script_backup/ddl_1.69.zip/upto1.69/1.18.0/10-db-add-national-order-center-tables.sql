-- ---------------------------------------------------------
-- Table structure for order_process_type 订单类型表
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS `order_process_type` (
  `id`          BIGINT(20)     NOT NULL     AUTO_INCREMENT  COMMENT '主键',
  `name`      	VARCHAR(45)    DEFAULT NULL                 COMMENT '类型名称',
  `description` VARCHAR(200)   DEFAULT NULL                 COMMENT '描述',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ---------------------------------------------------------
-- Table structure for order_process_area 订单处理城市表
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS `order_process_area` (
    `id` 					bigint(20) 		NOT NULL        AUTO_INCREMENT		COMMENT '主键',
    `area`					bigint(20) 		DEFAULT NULL	                    COMMENT '城市',
    `order_process_type`	bigint(20) 		DEFAULT NULL	                    COMMENT '订单处理类型',
    PRIMARY KEY (`id`),
    KEY `FK_ORDER_PROCESS_AREA_REF_AREA` (`area`),
    KEY `FK_ORDER_PROCESS_AREA_REF_TYPE` (`order_process_type`),
    CONSTRAINT `FK_ORDER_PROCESS_AREA_REF_AREA` FOREIGN KEY (`area`) REFERENCES `area` (`id`),
    CONSTRAINT `FK_ORDER_PROCESS_AREA_REF_TYPE` FOREIGN KEY (`order_process_type`) REFERENCES `order_process_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ---------------------------------------------------------
-- Table structure for order_process_history 订单处理历史表
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS `order_process_history` (
    `id` 					bigint(20) 		NOT NULL        AUTO_INCREMENT		COMMENT '主键',
    `purchase_order`		bigint(20) 		DEFAULT NULL	                    COMMENT '订单',
    `original_status`		bigint(20) 		DEFAULT NULL	                    COMMENT '原出单状态，关联合作出单状态表或独立出单状态表',
    `current_status`		bigint(20) 		DEFAULT NULL	                    COMMENT '新出单状态，关联合作出单状态表或独立出单状态表',
    `order_process_type`	bigint(20) 		DEFAULT NULL	                    COMMENT '订单处理类型',
    `comment`  				varchar(2000) 	DEFAULT NULL	                    COMMENT '备注',
    `create_time` 			datetime 		DEFAULT NULL	                    COMMENT '创建时间',
    `operator` 				bigint(20) 		DEFAULT NULL	                    COMMENT '操作人',
    PRIMARY KEY (`id`),
    KEY `FK_ORDER_PROCESS_HISTORY_REF_PURCHASE_ORDER` (`purchase_order`),
    KEY `FK_ORDER_PROCESS_HISTORY_REF_TYPE` (`order_process_type`),
    KEY `FK_ORDER_PROCESS_HISTORY_REF_OPERATOR` (`operator`),
    CONSTRAINT `FK_ORDER_PROCESS_HISTORY_REF_PURCHASE_ORDER` FOREIGN KEY (`purchase_order`) REFERENCES `purchase_order` (`id`),
    CONSTRAINT `FK_ORDER_PROCESS_HISTORY_REF_TYPE` FOREIGN KEY (`order_process_type`) REFERENCES `order_process_type` (`id`),
    CONSTRAINT `FK_ORDER_PROCESS_HISTORY_REF_OPERATOR` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ---------------------------------------------------------
-- Table structure for area_contact_info 车车地区联系信息表
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS `area_contact_info` (
    `id` 			bigint(20) 		NOT NULL        AUTO_INCREMENT		COMMENT '主键',
    `area`			bigint(20) 		DEFAULT NULL	                    COMMENT '城市',
    `name`  		varchar(20) 	DEFAULT NULL	                    COMMENT '负责人姓名',
    `mobile`  		varchar(20) 	DEFAULT NULL	                    COMMENT '负责人手机号',
    `email`  		varchar(45) 	DEFAULT NULL	                    COMMENT '负责人邮箱',
    `qq`  			varchar(20) 	DEFAULT NULL	                    COMMENT '负责人QQ',
    `province`  	bigint(20) 		DEFAULT NULL	                    COMMENT '省份',
    `city`  		bigint(20) 		DEFAULT NULL	                    COMMENT '城市',
    `district`  	bigint(20) 		DEFAULT NULL	                    COMMENT '区县',
    `street`  		varchar(100) 	DEFAULT NULL	                    COMMENT '街道',
    `comment`  		varchar(200) 	DEFAULT NULL	                    COMMENT '备注',
    `create_time` 	datetime 		DEFAULT NULL	                    COMMENT '创建时间',
    `update_time` 	datetime 		DEFAULT NULL	                    COMMENT '修改时间',
    `operator` 		bigint(20) 		DEFAULT NULL	                    COMMENT '操作人',
    PRIMARY KEY (`id`),
    KEY `FK_AREA_CONTACT_INFO_REF_AREA` (`area`),
    KEY `FK_AREA_CONTACT_INFO_REF_PROVINCE` (`province`),
    KEY `FK_AREA_CONTACT_INFO_REF_CITY` (`city`),
    KEY `FK_AREA_CONTACT_INFO_REF_DISTRICT` (`district`),
    KEY `FK_AREA_CONTACT_INFO_REF_OPERATOR` (`operator`),
    CONSTRAINT `FK_AREA_CONTACT_INFO_REF_AREA` FOREIGN KEY (`area`) REFERENCES `area` (`id`),
    CONSTRAINT `FK_AREA_CONTACT_INFO_REF_PROVINCE` FOREIGN KEY (`province`) REFERENCES `area` (`id`),
    CONSTRAINT `FK_AREA_CONTACT_INFO_REF_CITY` FOREIGN KEY (`city`) REFERENCES `area` (`id`),
    CONSTRAINT `FK_AREA_CONTACT_INFO_REF_DISTRICT` FOREIGN KEY (`district`) REFERENCES `area` (`id`),
    CONSTRAINT `FK_AREA_CONTACT_INFO_REF_OPERATOR` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ---------------------------------------------------------
-- Table structure for institution 出单机构表
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS `institution` (
    `id` 				bigint(20) 		NOT NULL        AUTO_INCREMENT		COMMENT '主键',
    `name`  			varchar(20) 	DEFAULT NULL	                    COMMENT '出单机构名称',
    `comment`  			varchar(200) 	DEFAULT NULL	                    COMMENT '备注',
    `contact_name` 		varchar(20) 	DEFAULT NULL	                    COMMENT '机构联系人姓名',
    `contact_mobile`  	varchar(20) 	DEFAULT NULL	                    COMMENT '机构联系人手机号',
    `contact_email`  	varchar(45) 	DEFAULT NULL	                    COMMENT '机构联系人邮箱',
    `contact_qq`  		varchar(20) 	DEFAULT NULL	                    COMMENT '机构联系人QQ',
    `cheche_name`  		varchar(20) 	DEFAULT NULL	                    COMMENT '车车责任人姓名',
    `cheche_mobile`  	varchar(20) 	DEFAULT NULL	                    COMMENT '车车责任人手机号',
    `cheche_email`  	varchar(45) 	DEFAULT NULL	                    COMMENT '车车责任人邮箱',
    `cheche_qq`  		varchar(20) 	DEFAULT NULL	                    COMMENT '车车责任人QQ',
    `create_time` 		datetime 		DEFAULT NULL	                    COMMENT '创建时间',
    `update_time` 		datetime 		DEFAULT NULL	                    COMMENT '修改时间',
    `operator` 			bigint(20) 		DEFAULT NULL	                    COMMENT '操作人',
    PRIMARY KEY (`id`),
    KEY `FK_INSTITUTION_REF_OPERATOR` (`operator`),
    CONSTRAINT `FK_INSTITUTION_REF_OPERATOR` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ---------------------------------------------------------
-- Table structure for institution_bank_account 出单机构银行账户表
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS `institution_bank_account` (
    `id` 				bigint(20) 		NOT NULL        AUTO_INCREMENT		COMMENT '主键',
    `institution`  		bigint(20) 		DEFAULT NULL	                    COMMENT '出单机构',
    `bank`  			varchar(45) 	DEFAULT NULL	                    COMMENT '开户行',
    `account_name` 		varchar(45) 	DEFAULT NULL	                    COMMENT '开户名',
    `account_no`  		varchar(45) 	DEFAULT NULL	                    COMMENT '帐号',
    `create_time` 		datetime 		DEFAULT NULL	                    COMMENT '创建时间',
    `update_time` 		datetime 		DEFAULT NULL	                    COMMENT '修改时间',
    `operator` 			bigint(20) 		DEFAULT NULL	                    COMMENT '操作人',
    PRIMARY KEY (`id`),
    KEY `FK_INSTITUTION_BANK_ACCOUNT_REF_INSTITUTION` (`institution`),
    KEY `FK_INSTITUTION_BANK_ACCOUNT_REF_OPERATOR` (`operator`),
    CONSTRAINT `FK_INSTITUTION_BANK_ACCOUNT_REF_INSTITUTION` FOREIGN KEY (`institution`) REFERENCES `institution` (`id`),
    CONSTRAINT `FK_INSTITUTION_BANK_ACCOUNT_REF_OPERATOR` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ---------------------------------------------------------
-- Table structure for institution_rebate 出单机构佣金表
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS `institution_rebate` (
    `id` 						bigint(20) 		NOT NULL        AUTO_INCREMENT		COMMENT '主键',
    `institution`  				bigint(20) 		DEFAULT NULL	                    COMMENT '出单机构',
    `area`  					bigint(20) 		DEFAULT NULL	                    COMMENT '城市',
    `insurance_company` 		bigint(20) 		DEFAULT NULL	                    COMMENT '保险公司',
    `commercial_rebate`  		Decimal(18,2) 	DEFAULT NULL	                    COMMENT '商业险佣金',
    `compulsory_rebate`  		Decimal(18,2) 	DEFAULT NULL	                    COMMENT '交强险佣金',
    `create_time` 				datetime 		DEFAULT NULL	                    COMMENT '创建时间',
    `update_time` 				datetime 		DEFAULT NULL	                    COMMENT '修改时间',
    `operator` 					bigint(20) 		DEFAULT NULL	                    COMMENT '操作人',
    PRIMARY KEY (`id`),
    KEY `FK_INSTITUTION_REBATE_REF_INSTITUTION` (`institution`),
    KEY `FK_INSTITUTION_REBATE_REF_AREA` (`area`),
    KEY `FK_INSTITUTION_REBATE_REF_INSURANCE_COMPANY` (`insurance_company`),
    KEY `FK_INSTITUTION_REBATE_REF_OPERATOR` (`operator`),
    CONSTRAINT `FK_INSTITUTION_REBATE_REF_INSTITUTION` FOREIGN KEY (`institution`) REFERENCES `institution` (`id`),
    CONSTRAINT `FK_INSTITUTION_REBATE_REF_AREA` FOREIGN KEY (`area`) REFERENCES `area` (`id`),
    CONSTRAINT `FK_INSTITUTION_REBATE_REF_INSURANCE_COMPANY` FOREIGN KEY (`insurance_company`) REFERENCES `insurance_company` (`id`),
    CONSTRAINT `FK_INSTITUTION_REBATE_REF_OPERATOR` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ---------------------------------------------------------
-- Table structure for order_cooperation_status 合作出单状态表
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS `order_cooperation_status` (
  `id`          BIGINT(20)     NOT NULL     AUTO_INCREMENT  COMMENT '主键',
  `status`      VARCHAR(45)    DEFAULT NULL                 COMMENT '状态',
  `description` VARCHAR(200)   DEFAULT NULL                 COMMENT '描述',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ---------------------------------------------------------
-- Table structure for order_cooperation_info 合作出单信息表
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS `order_cooperation_info` (
    `id` 						bigint(20) 		NOT NULL        AUTO_INCREMENT		COMMENT '主键',
    `purchase_order`  			bigint(20) 		DEFAULT NULL	                    COMMENT '订单',
    `area`  					bigint(20) 		DEFAULT NULL	                    COMMENT '城市',
    `insurance_company` 		bigint(20) 		DEFAULT NULL	                    COMMENT '保险公司',
    `area_contact_info`  		bigint(20) 		DEFAULT NULL	                    COMMENT '车车分站',
    `institution`  				bigint(20) 		DEFAULT NULL	                    COMMENT '出单机构',
    `appoint_time`  			datetime 		DEFAULT NULL	                    COMMENT '指定出单机构时间',
    `status`  					bigint(20) 		DEFAULT NULL	                    COMMENT '合作出单状态',
    `reason`  					varchar(45) 	DEFAULT NULL	                    COMMENT '订单异常原因',
    `rebate_status`  			tinyint(1) 		DEFAULT NULL	                    COMMENT '确认佣金到账状态',
    `audit_status`  			tinyint(1) 		DEFAULT NULL	                    COMMENT '审核状态',
    `income_status`  			tinyint(1) 		DEFAULT NULL	                    COMMENT '收益状态',
    `match_status`  			tinyint(1) 		DEFAULT NULL	                    COMMENT '险种保额匹配状态',
    `create_time` 				datetime 		DEFAULT NULL	                    COMMENT '创建时间',
    `update_time` 				datetime 		DEFAULT NULL	                    COMMENT '修改时间',
    `operator` 					bigint(20) 		DEFAULT NULL	                    COMMENT '最后操作人',
    `assigner` 					bigint(20) 		DEFAULT NULL	                    COMMENT '指定操作人',
    PRIMARY KEY (`id`),
    KEY `FK_ORDER_COOPERATION_INFO_REF_PURCHASE_ORDER` (`purchase_order`),
    KEY `FK_ORDER_COOPERATION_INFO_REF_AREA` (`area`),
    KEY `FK_ORDER_COOPERATION_INFO_REF_INSURANCE_COMPANY` (`insurance_company`),
    KEY `FK_ORDER_COOPERATION_INFO_REF_AREA_CONTACT_INFO` (`area_contact_info`),
    KEY `FK_ORDER_COOPERATION_INFO_REF_INSTITUTION` (`institution`),
    KEY `FK_ORDER_COOPERATION_INFO_REF_STATUS` (`status`),
    KEY `FK_ORDER_COOPERATION_INFO_REF_OPERATOR` (`operator`),
    KEY `FK_ORDER_COOPERATION_INFO_REF_ASSIGNER` (`assigner`),
    CONSTRAINT `FK_ORDER_COOPERATION_INFO_REF_PURCHASE_ORDER` FOREIGN KEY (`purchase_order`) REFERENCES `purchase_order` (`id`),
    CONSTRAINT `FK_ORDER_COOPERATION_INFO_REF_AREA` FOREIGN KEY (`area`) REFERENCES `area` (`id`),
    CONSTRAINT `FK_ORDER_COOPERATION_INFO_REF_INSURANCE_COMPANY` FOREIGN KEY (`insurance_company`) REFERENCES `insurance_company` (`id`),
    CONSTRAINT `FK_ORDER_COOPERATION_INFO_REF_AREA_CONTACT_INFO` FOREIGN KEY (`area_contact_info`) REFERENCES `area_contact_info` (`id`),
    CONSTRAINT `FK_ORDER_COOPERATION_INFO_REF_INSTITUTION` FOREIGN KEY (`institution`) REFERENCES `institution` (`id`),
    CONSTRAINT `FK_ORDER_COOPERATION_INFO_REF_STATUS` FOREIGN KEY (`status`) REFERENCES `order_cooperation_status` (`id`),
    CONSTRAINT `FK_ORDER_COOPERATION_INFO_REF_OPERATOR` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`),
    CONSTRAINT `FK_ORDER_COOPERATION_INFO_REF_ASSIGNER` FOREIGN KEY (`assigner`) REFERENCES `internal_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ---------------------------------------------------------
-- Table structure for delivery_info 快递信息表
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS `delivery_info` (
    `id` 				bigint(20) 		NOT NULL        AUTO_INCREMENT		COMMENT '主键',
    `purchase_order`  	bigint(20) 		DEFAULT NULL	                    COMMENT '订单',
    `express_company`  	varchar(45)		DEFAULT NULL	                    COMMENT '快递公司',
    `tracking_no`  		varchar(50) 	DEFAULT NULL	                    COMMENT '快递单号',
    `delivery_man`  	varchar(20) 	DEFAULT NULL	                    COMMENT '送货员',
    `mobile`  			varchar(20) 	DEFAULT NULL	                    COMMENT '送货员手机号',
    `delivery_time` 	datetime 		DEFAULT NULL	                    COMMENT '送货时间',
    `create_time` 		datetime 		DEFAULT NULL	                    COMMENT '创建时间',
    `update_time` 		datetime 		DEFAULT NULL	                    COMMENT '修改时间',
    `operator` 			bigint(20) 		DEFAULT NULL	                    COMMENT '操作人',
    PRIMARY KEY (`id`),
    KEY `FK_DELIVERY_INFO_REF_PURCHASE_ORDER` (`purchase_order`),
    KEY `FK_DELIVERY_INFO_REF_OPERATOR` (`operator`),
    CONSTRAINT `FK_DELIVERY_INFO_REF_PURCHASE_ORDER` FOREIGN KEY (`purchase_order`) REFERENCES `purchase_order` (`id`),
    CONSTRAINT `FK_DELIVERY_INFO_REF_OPERATOR` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ---------------------------------------------------------
-- Table structure for institution_quote_record 出单机构报价表
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS `institution_quote_record` (
    `id` 						bigint(20) 		NOT NULL        AUTO_INCREMENT		COMMENT '主键',
    `purchase_order`  			bigint(20) 		DEFAULT NULL	                    COMMENT '订单',
    `insurance_company` 		bigint(20) 		DEFAULT NULL	                    COMMENT '保险公司',
    `insurance_package`  		bigint(20) 		DEFAULT NULL	                    COMMENT '报价套餐',
    `institution`  				bigint(20) 		DEFAULT NULL	                    COMMENT '出单机构',
    `commercial_policy_no`  	varchar(45) 	DEFAULT NULL	                    COMMENT '商业险保单号',
    `compulsory_policy_no`  	varchar(45) 	DEFAULT NULL	                    COMMENT '交强险保单号',
    `commercial_premium`  		decimal(18,2) 	DEFAULT NULL	                    COMMENT '商业险保费',
    `compulsory_premium`  		decimal(18,2) 	DEFAULT NULL	                    COMMENT '交强险保费',
    `auto_tax`  				decimal(18,2) 	DEFAULT NULL	                    COMMENT '车船税',
    `third_party_amount`  		decimal(18,2) 	DEFAULT NULL	                    COMMENT '三者险保额',
    `third_party_premium`  		decimal(18,2) 	DEFAULT NULL	                    COMMENT '三者险保费',
    `theft_amount`  			decimal(18,2) 	DEFAULT NULL	                    COMMENT '盗抢险保额',
    `theft_premium`  			decimal(18,2) 	DEFAULT NULL	                    COMMENT '盗抢险保费',
    `damage_amount`  			decimal(18,2) 	DEFAULT NULL	                    COMMENT '车损险保额',
    `damage_premium`  			decimal(18,2) 	DEFAULT NULL	                    COMMENT '车损险保费',
    `driver_amount`  			decimal(18,2) 	DEFAULT NULL	                    COMMENT '司机险保额',
    `driver_premium`  			decimal(18,2) 	DEFAULT NULL	                    COMMENT '司机险保费',
    `passenger_amount`  		decimal(18,2) 	DEFAULT NULL	                    COMMENT '乘客险保额',
    `passenger_premium`  		decimal(18,2) 	DEFAULT NULL	                    COMMENT '乘客险保费',
    `passenger_count`  			tinyint(3) 		DEFAULT NULL	                    COMMENT '乘客数量',
    `engine_premium`  			decimal(18,2) 	DEFAULT NULL	                    COMMENT '发动机险保费',
    `glass_premium`  			decimal(18,2) 	DEFAULT NULL	                    COMMENT '玻璃险保费',
    `scratch_amount`  			decimal(18,2) 	DEFAULT NULL	                    COMMENT '划痕险保额',
    `scratch_premium`  			decimal(18,2) 	DEFAULT NULL	                    COMMENT '划痕险保费',
    `spontaneous_loss_amount`  	decimal(18,2) 	DEFAULT NULL	                    COMMENT '自燃险保额',
    `spontaneous_loss_premium`  decimal(18,2) 	DEFAULT NULL	                    COMMENT '自燃险保费',
    `third_party_iop`  			decimal(18,2) 	DEFAULT NULL	                    COMMENT '三者险不计免赔',
    `theft_iop`  				decimal(18,2) 	DEFAULT NULL	                    COMMENT '盗抢险不计免赔',
    `damage_iop`  				decimal(18,2) 	DEFAULT NULL	                    COMMENT '车损险不计免赔',
    `driver_iop`  				decimal(18,2) 	DEFAULT NULL	                    COMMENT '司机险不计免赔',
    `passenger_iop`  			decimal(18,2) 	DEFAULT NULL	                    COMMENT '乘客险不计免赔',
    `engine_iop`  				decimal(18,2) 	DEFAULT NULL	                    COMMENT '发动机险不计免赔',
    `scratch_iop`  				decimal(18,2) 	DEFAULT NULL	                    COMMENT '划痕险不计免赔',
    `create_time` 				datetime 		DEFAULT NULL	                    COMMENT '创建时间',
    `update_time` 				datetime 		DEFAULT NULL	                    COMMENT '修改时间',
    `operator` 					bigint(20) 		DEFAULT NULL	                    COMMENT '操作人',
    PRIMARY KEY (`id`),
    KEY `FK_INSTITUTION_QUOTE_RECORD_REF_PURCHASE_ORDER` (`purchase_order`),
    KEY `FK_INSTITUTION_QUOTE_RECORD_REF_INSURANCE_COMPANY` (`insurance_company`),
    KEY `FK_INSTITUTION_QUOTE_RECORD_REF_INSURANCE_PACKAGE` (`insurance_package`),
    KEY `FK_INSTITUTION_QUOTE_RECORD_REF_INSTITUTION` (`institution`),
    KEY `FK_INSTITUTION_QUOTE_RECORD_REF_OPERATOR` (`operator`),
    CONSTRAINT `FK_INSTITUTION_QUOTE_RECORD_REF_PURCHASE_ORDER` FOREIGN KEY (`purchase_order`) REFERENCES `purchase_order` (`id`),
    CONSTRAINT `FK_INSTITUTION_QUOTE_RECORD_REF_INSURANCE_COMPANY` FOREIGN KEY (`insurance_company`) REFERENCES `insurance_company` (`id`),
    CONSTRAINT `FK_INSTITUTION_QUOTE_RECORD_REF_INSURANCE_PACKAGE` FOREIGN KEY (`insurance_package`) REFERENCES `insurance_package` (`id`),
    CONSTRAINT `FK_INSTITUTION_QUOTE_RECORD_REF_INSTITUTION` FOREIGN KEY (`institution`) REFERENCES `institution` (`id`),
    CONSTRAINT `FK_INSTITUTION_QUOTE_RECORD_REF_OPERATOR` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ---------------------------------------------------------
-- purchase_order 订单表 添加快递信息字段
-- ---------------------------------------------------------
ALTER TABLE purchase_order ADD COLUMN delivery_info bigint(20)	DEFAULT NULL	COMMENT '快递信息';
ALTER TABLE purchase_order ADD CONSTRAINT `FK_PURCHASE_ORDER_REF_DELIVERY_INFO` FOREIGN KEY (delivery_info) REFERENCES delivery_info(id) ON DELETE RESTRICT ON UPDATE RESTRICT;

-- ---------------------------------------------------------
-- insurance 商业险保单表 添加出单机构字段
-- ---------------------------------------------------------
ALTER TABLE insurance ADD COLUMN institution bigint(20)	DEFAULT NULL	COMMENT '出单机构';
ALTER TABLE insurance ADD CONSTRAINT `FK_INSURANCE_REF_INSTITUTION` FOREIGN KEY (institution) REFERENCES institution(id) ON DELETE RESTRICT ON UPDATE RESTRICT;

-- ---------------------------------------------------------
-- compulsory_insurance 交强险保单表 添加出单机构字段
-- ---------------------------------------------------------
ALTER TABLE compulsory_insurance ADD COLUMN institution bigint(20)	DEFAULT NULL	COMMENT '出单机构';
ALTER TABLE compulsory_insurance ADD CONSTRAINT `FK_COMPULSORY_INSURANCE_REF_INSTITUTION` FOREIGN KEY (institution) REFERENCES institution(id) ON DELETE RESTRICT ON UPDATE RESTRICT;
