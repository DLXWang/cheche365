INSERT INTO schedule_condition(id, name, marketing) VALUES(11, '2015年双十二红包活动', 16);
