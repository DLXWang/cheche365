INSERT INTO message_variable(id, code, name, type, placeholder, length, parameter, model_class, model_method)
VALUES(28, '${GiftAmount}', '红包金额', 'number', '请输入红包金额', 18, 'giftAmount', null, null);
