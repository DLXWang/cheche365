-- 订单下单类型表
insert into order_process_type(id, name, description) values (1, '独立下单', '独立下单');
insert into order_process_type(id, name, description) values (2, '合作下单', '合作下单');
