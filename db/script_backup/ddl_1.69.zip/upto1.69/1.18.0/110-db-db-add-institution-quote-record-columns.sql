ALTER TABLE institution_quote_record DROP FOREIGN KEY FK_INSTITUTION_QUOTE_RECORD_REF_INSURANCE_COMPANY;
ALTER TABLE institution_quote_record DROP COLUMN insurance_company;

ALTER TABLE institution_quote_record DROP FOREIGN KEY FK_INSTITUTION_QUOTE_RECORD_REF_INSTITUTION_REBATE;
ALTER TABLE institution_quote_record DROP COLUMN institution_rebate;

ALTER TABLE institution_quote_record ADD COLUMN institution bigint(20) DEFAULT NULL COMMENT '出单机构' AFTER `insurance_package`;
ALTER TABLE institution_quote_record ADD CONSTRAINT FK_INSTITUTION_QUOTE_RECORD_REF_INSTITUTION FOREIGN KEY (institution) REFERENCES institution(id) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE institution_quote_record ADD COLUMN commercial_rebate DECIMAL(18,2) DEFAULT NULL COMMENT '商业险佣金' AFTER `institution`;
ALTER TABLE institution_quote_record ADD COLUMN compulsory_rebate DECIMAL(18,2) DEFAULT NULL COMMENT '交强险佣金' AFTER `commercial_rebate`;
