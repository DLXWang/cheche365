UPDATE `marketing` SET `end_date`='2015-12-12 23:59:59', `failure_date_class_param`='2016-02-29 23:59:59' WHERE `id`='16';
