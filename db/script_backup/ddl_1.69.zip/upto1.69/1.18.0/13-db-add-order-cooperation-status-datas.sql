-- 合作出单状态
insert into order_cooperation_status(id, status, description) values (1, '订单新建', '订单新建');
insert into order_cooperation_status(id, status, description) values (2, '已报价待审核', '已报价待审核');
insert into order_cooperation_status(id, status, description) values (3, '通过审核待结款', '通过审核待结款');
insert into order_cooperation_status(id, status, description) values (4, '结款完成待出单', '结款完成待出单');
insert into order_cooperation_status(id, status, description) values (5, '已出单', '已出单');
insert into order_cooperation_status(id, status, description) values (6, '订单完成', '订单完成');
insert into order_cooperation_status(id, status, description) values (7, '订单异常', '订单异常');
insert into order_cooperation_status(id, status, description) values (8, '订单退款', '订单退款');
