-- 将商务活动编号和落地页统一改为小写
update business_activity set code = lower(code), landing_page = lower(landing_page);
