-- ---------------------------------------------------------
-- Table structure for purchase_order_refund 订单退款表
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS `purchase_order_refund` (
    `id` 					bigint(20) 		NOT NULL        AUTO_INCREMENT		COMMENT '主键',
    `purchase_order`		bigint(20) 		DEFAULT NULL	                    COMMENT '订单',
    `user_check`		    tinyint(1) 		DEFAULT 1	                        COMMENT '是否车车退款给用户',
    `cheche_check`		    tinyint(1) 		DEFAULT NULL	                    COMMENT '是否出单机构退款给车车',
    `rebate_check`  	    tinyint(1) 		DEFAULT NULL	                    COMMENT '是否退佣金给出单机构',
    `user_status`		    tinyint(1) 		DEFAULT NULL	                    COMMENT '退款给用户状态，0-未退款，1-已退款',
    `cheche_status`		    tinyint(1) 		DEFAULT NULL	                    COMMENT '退款给车车状态，0-未退款，1-已退款',
    `create_time` 			datetime 		DEFAULT NULL	                    COMMENT '创建时间',
    `update_time` 			datetime 		DEFAULT NULL	                    COMMENT '修改时间',
    `operator` 				bigint(20) 		DEFAULT NULL	                    COMMENT '操作人',
    PRIMARY KEY (`id`),
    KEY `FK_PURCHASE_ORDER_REFUND_REF_PURCHASE_ORDER` (`purchase_order`),
    KEY `FK_PURCHASE_ORDER_REFUND_REF_OPERATOR` (`operator`),
    CONSTRAINT `FK_PURCHASE_ORDER_REFUND_REF_PURCHASE_ORDER` FOREIGN KEY (`purchase_order`) REFERENCES `purchase_order` (`id`),
    CONSTRAINT `FK_PURCHASE_ORDER_REFUND_REF_OPERATOR` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
