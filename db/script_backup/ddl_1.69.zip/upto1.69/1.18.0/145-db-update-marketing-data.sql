UPDATE `marketing` SET
gift_class="com.cheche365.cheche.core.service.market.JsonParamConvertor"
WHERE `id`='16';
