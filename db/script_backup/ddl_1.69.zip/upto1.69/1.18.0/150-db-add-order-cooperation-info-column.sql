ALTER TABLE order_cooperation_info ADD COLUMN quote_status tinyint(1) DEFAULT NULL COMMENT '报价状态' AFTER `match_status`;
