
-- 开通11个城市
UPDATE area SET short_code = '冀A',active = 1 WHERE id = '130100';
UPDATE area SET short_code = '蒙A',active = 1 WHERE id = '150100';
UPDATE area SET short_code = '鲁A',active = 1 WHERE id = '370100';
UPDATE area SET short_code = '琼A',active = 1 WHERE id = '460100';
UPDATE area SET short_code = '云A',active = 1 WHERE id = '530100';
UPDATE area SET short_code = '陕A',active = 1 WHERE id = '610100';
UPDATE area SET short_code = '青A',active = 1 WHERE id = '630100';
UPDATE area SET short_code = '宁A',active = 1 WHERE id = '640100';
UPDATE area SET short_code = '黑A',active = 1 WHERE id = '230100';
UPDATE area SET short_code = '闽A',active = 1 WHERE id = '350100';
UPDATE area SET short_code = '苏A',active = 1 WHERE id = '320100';

-- 人保财险
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 130100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 150100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 370100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 460100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 530100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 610100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 630100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 640100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 230100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 350100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 320100);

-- 平安保险
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 130100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 150100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 370100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 460100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 530100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 610100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 630100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 640100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 230100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 350100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 320100);

-- 太平洋保险
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 130100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 150100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 370100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 460100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 530100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 610100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 630100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 640100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 230100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 350100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 320100);

-- 再开通11个城市
UPDATE area SET short_code = '晋A',active = 1 WHERE id = '140100';
UPDATE area SET short_code = '辽A',active = 1 WHERE id = '210100';
UPDATE area SET short_code = '吉A',active = 1 WHERE id = '220100';
UPDATE area SET short_code = '皖A',active = 1 WHERE id = '340100';
UPDATE area SET short_code = '赣A',active = 1 WHERE id = '360100';
UPDATE area SET short_code = '湘A',active = 1 WHERE id = '430100';
UPDATE area SET short_code = '桂A',active = 1 WHERE id = '450100';
UPDATE area SET short_code = '贵A',active = 1 WHERE id = '520100';
UPDATE area SET short_code = '藏A',active = 1 WHERE id = '540100';
UPDATE area SET short_code = '甘A',active = 1 WHERE id = '620100';
UPDATE area SET short_code = '新A',active = 1 WHERE id = '650100';


-- 人保财险
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 140100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 210100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 220100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 340100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 360100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 430100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 450100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 520100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 540100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 620100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (10000, 650100);

-- 平安保险
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 140100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 210100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 220100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 340100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 360100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 430100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 450100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 520100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 540100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 620100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (20000, 650100);

-- 太平洋保险
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 140100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 210100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 220100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 340100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 360100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 430100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 450100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 520100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 540100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 620100);
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (25000, 650100);

