UPDATE `marketing` SET `failure_date_class`='com.cheche365.cheche.marketing.service.FixedDate' WHERE `id`='15';
UPDATE `marketing` SET `amount_class`='com.cheche365.cheche.marketing.service.FixedAmount' WHERE `id`='15';

