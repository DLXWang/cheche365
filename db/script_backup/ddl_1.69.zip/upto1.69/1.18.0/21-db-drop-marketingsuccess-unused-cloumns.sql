ALTER TABLE `marketing_success`
DROP COLUMN `used_count`,
DROP COLUMN `max_use_count`;
