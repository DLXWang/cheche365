-- ---------------------------------------------------------
-- Table structure for tel_marketing_center_source 电销数据来源表
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS `tel_marketing_center_source` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(200) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB CHARSET=utf8;

-- ---------------------------------------------------------
-- Table structure for tel_marketing_center_source 电销处理状态表
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS `tel_marketing_center_status` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(200) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB CHARSET=utf8;
-- ---------------------------------------------------------
-- Table structure for tel_marketing_center 电销表
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS `tel_marketing_center` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `user` bigint(20) DEFAULT NULL COMMENT '用户ID',
  `mobile` varchar(50) NOT NULL COMMENT '用户电话',
  `user_name` varchar(45) DEFAULT NULL COMMENT '用户名',
  `processed_number` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '处理次数',
  `status` bigint(20) DEFAULT NULL COMMENT '状态|标记',
  `priority` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '优先级',
  `operator` bigint(20) DEFAULT NULL COMMENT '操作人|指派人',
  `expire_time` datetime DEFAULT NULL COMMENT '到期时间',
  `trigger_time` datetime DEFAULT NULL COMMENT '触发时间',
  `source` bigint(20) DEFAULT NULL COMMENT '来源',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `display` tinyint(1) DEFAULT NULL COMMENT '是否显示 1显示 0不显示',
  PRIMARY KEY (`id`),
  KEY `FK_TEL_MARKETING_CENTER_REF_USER` (`user`) USING BTREE,
  KEY `FK_TEL_MARKETING_CENTER_REF_SOURCE` (`source`) USING BTREE,
  KEY `FK_TEL_MARKETING_CENTER_REF_STATUS` (`status`) USING BTREE,
  KEY `FK_TEL_MARKETING_CENTER_REF_OPERATOR` (`operator`) USING BTREE,
  CONSTRAINT `FK_TEL_MARKETING_CENTER_REF_OPERATOR` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`),
  CONSTRAINT `FK_TEL_MARKETING_CENTER_REF_SOURCE` FOREIGN KEY (`source`) REFERENCES `tel_marketing_center_source` (`id`),
  CONSTRAINT `FK_TEL_MARKETING_CENTER_REF_STATUS` FOREIGN KEY (`status`) REFERENCES `tel_marketing_center_status` (`id`),
  CONSTRAINT `FK_TEL_MARKETING_CENTER_REF_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`)
) ENGINE=InnoDB CHARSET=utf8;

-- ---------------------------------------------------------
-- Table structure for tel_marketing_center_history 电销历史记录表
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS `tel_marketing_center_history` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `tel_marketing_center` bigint(20) DEFAULT NULL COMMENT '电话营销中心数据',
  `operator` bigint(20) DEFAULT NULL COMMENT '操作人',
  `comment` varchar(200) DEFAULT NULL COMMENT '备注',
  `deal_result` varchar(45) DEFAULT NULL COMMENT '处理结果',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `FK_TEL_MARKETING_CENTER_HISTORY_REF_TEL_MARKETING_CENTER` (`tel_marketing_center`),
  KEY `FK_TEL_MARKETING_CENTER_HISTORY_REF_OPERATOR` (`operator`),
  CONSTRAINT `FK_TEL_MARKETING_CENTER_HISTORY_REF_OPERATOR` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`),
  CONSTRAINT `FK_TEL_MARKETING_CENTER_HISTORY_REF_TEL_MARKETING_CENTER` FOREIGN KEY (`tel_marketing_center`) REFERENCES `tel_marketing_center` (`id`)
) ENGINE=InnoDB CHARSET=utf8;