-- 添加电销数据来源记录
INSERT INTO `tel_marketing_center_source` (`id`, `description`, `name`) VALUES ('10', '主动预约', '主动预约');
INSERT INTO `tel_marketing_center_source` (`id`, `description`, `name`) VALUES ('20', '地推', '地推收集');
INSERT INTO `tel_marketing_center_source` (`id`, `description`, `name`) VALUES ('30', '各种活动', '活动');
INSERT INTO `tel_marketing_center_source` (`id`, `description`, `name`) VALUES ('40', '注册但是无购买记录', '无购买记录用户');
INSERT INTO `tel_marketing_center_source` (`id`, `description`, `name`) VALUES ('50', '合作方提供', '合作方提供');
INSERT INTO `tel_marketing_center_source` (`id`, `description`, `name`) VALUES ('60', '拍照报价', '拍照报价用户');
INSERT INTO `tel_marketing_center_source` (`id`, `description`, `name`) VALUES ('70', '未支付订单用户', '有订单未支付用户');
INSERT INTO `tel_marketing_center_source` (`id`, `description`, `name`) VALUES ('80', '已购买用户', '已购买用户');

-- 添加电销处理状态记录
INSERT INTO `tel_marketing_center_status` (`id`, `description`, `name`) VALUES ('1', '未处理', '未处理');
INSERT INTO `tel_marketing_center_status` (`id`, `description`, `name`) VALUES ('10', '之前已在车车成单', '已成单');
INSERT INTO `tel_marketing_center_status` (`id`, `description`, `name`) VALUES ('20', '已报价', '已报价');
INSERT INTO `tel_marketing_center_status` (`id`, `description`, `name`) VALUES ('30', '已告知购买流程', '已告知');
INSERT INTO `tel_marketing_center_status` (`id`, `description`, `name`) VALUES ('40', '到期联系', '到期联系');
INSERT INTO `tel_marketing_center_status` (`id`, `description`, `name`) VALUES ('50', '非开通城市', '非开通城市');
INSERT INTO `tel_marketing_center_status` (`id`, `description`, `name`) VALUES ('60', '成单', '成单');
INSERT INTO `tel_marketing_center_status` (`id`, `description`, `name`) VALUES ('70', '拒绝', '拒绝');
INSERT INTO `tel_marketing_center_status` (`id`, `description`, `name`) VALUES ('80', '非车主', '非车主');
INSERT INTO `tel_marketing_center_status` (`id`, `description`, `name`) VALUES ('90', '无法接通', '无法接通');
INSERT INTO `tel_marketing_center_status` (`id`, `description`, `name`) VALUES ('91', '挂断', '挂断');
INSERT INTO `tel_marketing_center_status` (`id`, `description`, `name`) VALUES ('92', '其他', '其他');