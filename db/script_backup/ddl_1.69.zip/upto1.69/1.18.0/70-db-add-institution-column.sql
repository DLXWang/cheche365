ALTER TABLE institution ADD COLUMN enable tinyint(1) DEFAULT NULL COMMENT '启用禁用标记';
