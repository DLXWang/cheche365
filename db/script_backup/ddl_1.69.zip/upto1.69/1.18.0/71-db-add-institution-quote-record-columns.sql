ALTER TABLE institution_quote_record DROP FOREIGN KEY FK_INSTITUTION_QUOTE_RECORD_REF_INSTITUTION;
ALTER TABLE institution_quote_record DROP COLUMN institution;
ALTER TABLE institution_quote_record ADD COLUMN institution_rebate bigint(20) DEFAULT NULL COMMENT '出单机构佣金' AFTER `insurance_package`;
ALTER TABLE institution_quote_record ADD CONSTRAINT FK_INSTITUTION_QUOTE_RECORD_REF_INSTITUTION_REBATE FOREIGN KEY (institution_rebate) REFERENCES institution_rebate(id) ON DELETE RESTRICT ON UPDATE RESTRICT;
