-- 添加用户类型枚举
INSERT INTO identity_type VALUES ('4', '回乡证', '回乡证');
INSERT INTO identity_type VALUES ('5', '临时身份证', '临时身份证');
INSERT INTO identity_type VALUES ('6', '户口簿', '户口簿');
INSERT INTO identity_type VALUES ('7', '警官证', '警官证');
INSERT INTO identity_type VALUES ('8', '台胞证', '台胞证');
INSERT INTO identity_type VALUES ('9', '营业执照', '营业执照');
INSERT INTO identity_type VALUES ('10', '其它证件', '其它证件');
