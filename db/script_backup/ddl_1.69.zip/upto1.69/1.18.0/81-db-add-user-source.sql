-- 添加用户来源
INSERT INTO `user_source` VALUES ('2', '微信关注', '微信关注');
INSERT INTO `user_source` VALUES ('3', '支付宝钱包', '支付宝钱包');
