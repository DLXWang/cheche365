-- 添加alipay_support保险公司是否支持支付宝
ALTER TABLE insurance_company ADD COLUMN alipay_support TINYINT(1) DEFAULT 0 COMMENT '添加是否支持支付宝';
UPDATE insurance_company SET `alipay_support` = 1 WHERE `code` IN ('PICC', 'CPIC', 'PINGAN');
