-- add alipay_support column
ALTER TABLE gift ADD COLUMN alipay_support TINYINT(1) DEFAULT 0 COMMENT '是否是支付宝可使用的红包';
