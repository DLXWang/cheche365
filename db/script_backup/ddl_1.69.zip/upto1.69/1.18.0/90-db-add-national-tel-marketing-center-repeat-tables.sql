CREATE TABLE IF NOT EXISTS `tel_marketing_center_repeat` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `user` bigint(20) DEFAULT NULL COMMENT '用户ID',
  `mobile` varchar(50) NOT NULL COMMENT '用户电话',
  `user_name` varchar(45) DEFAULT NULL COMMENT '用户名',
  `source` bigint(20) DEFAULT NULL COMMENT '来源',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `FK_TEL_MARKETING_CENTER_REPEAT_REF_USER` (`user`) USING BTREE,
  KEY `FK_TEL_MARKETING_CENTER_REPEAT_REF_SOURCE` (`source`) USING BTREE,
  CONSTRAINT `FK_TEL_MARKETING_CENTER_REPEAT_REF_SOURCE` FOREIGN KEY (`source`) REFERENCES `tel_marketing_center_source` (`id`),
  CONSTRAINT `FK_TEL_MARKETING_CENTER_REPEAT_REF_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`)
) ENGINE=InnoDB CHARSET=utf8;
