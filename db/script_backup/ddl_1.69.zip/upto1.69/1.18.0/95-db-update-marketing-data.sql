update marketing set amount_class = 'com.cheche365.cheche.marketing.service.FixedAmount'
where amount_class = 'com.cheche365.cheche.rest.service.marketing.FixedAmount';

update marketing set amount_class = 'com.cheche365.cheche.marketing.service.ResPackageAmount'
where amount_class = 'com.cheche365.cheche.rest.service.marketing.ResPackageAmount';

update marketing set failure_date_class = 'com.cheche365.cheche.marketing.service.FixedDate'
where failure_date_class = 'com.cheche365.cheche.rest.service.marketing.FixedDate';
