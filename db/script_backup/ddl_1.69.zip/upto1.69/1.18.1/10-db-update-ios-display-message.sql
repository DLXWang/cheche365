-- update double one banner and activity image
UPDATE `ios_display_message` SET `icon_url` = '20151123/activity/doubleone.jpg' WHERE `name` = '双11，车车车险与滴滴代驾联合为您送福！';