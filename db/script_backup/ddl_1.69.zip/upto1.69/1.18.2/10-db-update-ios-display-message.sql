-- add double twelve banner and activity
INSERT INTO `ios_display_message` VALUES (41, '/marketing/m/201511002/index_IOSAPP.action', '双12，无兄弟不免单！', '双12，无兄弟不免单！', '20151123/activity/doubletwelve.jpg', NULL, 1, 15, '2015-11-24', '2015-12-31', 1, '20151212');
INSERT INTO `ios_display_message` VALUES (42, '/marketing/m/201511002/index_IOSAPP.action', '双12，无兄弟不免单！', '双12，无兄弟不免单！', '20151123/activity/doubletwelve.jpg', NULL, 3, 15, '2015-11-24', '2015-12-31', 1, '20151212');

-- update middle AD image
UPDATE `ios_display_message` SET `url` = '/marketing/m/201511002/index.html', `icon_url` = '20151123/promotion/bj-l1.jpg' WHERE id = 9;
UPDATE `ios_display_message` SET `url` = '/marketing/m/201511001/index.html', `icon_url` = '20151123/promotion/bj-r1.jpg' WHERE id = 10;
UPDATE `ios_display_message` SET `url` = '/marketing/m/201511001/index.html', `icon_url` = '20151123/promotion/bj-r2.jpg' WHERE id = 11;
