INSERT INTO marketing (id, name, code, begin_date, end_date, marketing_type)
VALUES (17, '2015年感恩节/双十二营销活动_WEB渠道统计', '201511002', '2015-11-23 00:00:00', '2015-12-12 23:59:59', 'web');
