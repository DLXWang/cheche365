UPDATE `sms_template`
SET content = '尊敬的车车用户，您参加车车车险“无兄弟不免单”活动，目前获得${GiftAmount}元车险代金劵（无使用门槛）继续邀请兄弟获得代金劵升级，关注“车车”微信公众号，了解您的最新活动进展，立即购买（t.cn/RU1nqiI）垂询：4000-150-999'
WHERE zucp_code = 'PENDING_025';
