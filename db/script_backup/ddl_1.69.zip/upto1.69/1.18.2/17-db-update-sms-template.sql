UPDATE `sms_template`
SET content = '【车车科技】恭喜您获得${GiftAmount}元无使用限制车险代金劵，马上去微信吆喝兄弟助力更可获得代金劵翻倍！关注“车车”微信公众号参与“无兄弟不免单”活动，或立即购买车险 dwz.cn/22rJRI ，垂询：4000-150-999回T退订'
WHERE zucp_code = 'PENDING_025';
