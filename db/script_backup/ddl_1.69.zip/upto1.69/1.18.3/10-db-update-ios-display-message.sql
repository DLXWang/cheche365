-- change double 12 start and end date
UPDATE `ios_display_message` SET `start_date` = '2015-11-25', `end_date` = '2015-12-12' WHERE `name` = '双12，无兄弟不免单！';