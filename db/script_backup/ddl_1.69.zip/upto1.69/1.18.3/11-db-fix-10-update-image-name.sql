-- update middle AD image
UPDATE `ios_display_message` SET `url` = '/marketing/m/201511002/index.html', `icon_url` = '20151123/promotion/bj-l10.jpg' WHERE id = 9;
UPDATE `ios_display_message` SET `url` = '/marketing/m/201511001/index.html', `icon_url` = '20151123/promotion/bj-r10.jpg' WHERE id = 10;
UPDATE `ios_display_message` SET `url` = '/marketing/m/201511001/index.html', `icon_url` = '20151123/promotion/bj-r20.jpg' WHERE id = 11;
