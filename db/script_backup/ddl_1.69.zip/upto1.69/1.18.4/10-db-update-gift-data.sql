update gift g
set g.usage_rule_param = '[{"key":"com.cheche365.cheche.core.service.giftUsageRule.AreaCondition","values":["110000","120000","310000","320500","330100","410100","420100","440100","440300","500000","510100"]},{"key":"com.cheche365.cheche.core.service.giftUsageRule.ProjectCondition","values":["1"]}]'
where  exists (select * from marketing_success m where m.marketing_id =16 and g.source = m.id )
and g.usage_rule_param is not null;
