-- update use double 12
UPDATE `ios_display_message` SET `url` = '/marketing/m/201511002/index.html', `icon_url` = '20151130/promotion/bj-r1.jpg' WHERE `id` = 10;
UPDATE `ios_display_message` SET `url` = '/marketing/m/201511002/index.html', `icon_url` = '20151130/promotion/bj-r2.jpg' WHERE `id` = 11;
