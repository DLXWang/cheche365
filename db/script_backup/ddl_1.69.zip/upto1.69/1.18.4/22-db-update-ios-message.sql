UPDATE `ios_display_message` SET `name` = '双12，无兄弟不免单！' , `title` = '双12，无兄弟不免单！' WHERE id IN (9, 10 ,11);
