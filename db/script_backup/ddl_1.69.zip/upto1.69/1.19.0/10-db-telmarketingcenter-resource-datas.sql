-- 电话管理资源
INSERT INTO `resource` VALUES ('47', '电话管理', '27', '1', '2');
INSERT INTO `resource` VALUES ('48', '意向客户', '47', '1', '3');
INSERT INTO `resource` VALUES ('49', '工作查看', '47', '1', '3');
