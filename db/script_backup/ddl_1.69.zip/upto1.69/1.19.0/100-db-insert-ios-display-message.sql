-- add yi da bo red packet banner and activity
INSERT INTO `ios_display_message` VALUES (43, '/marketing/m/201512001/index.html', '一大波红包来袭！', '一大波红包来袭！', '20151202/activity/lotsofgift.jpg', NULL, 1, 16, '2015-12-01', '2015-12-31', 1, '20151201');
INSERT INTO `ios_display_message` VALUES (44, '/marketing/m/201512001/index.html', '一大波红包来袭！', '一大波红包来袭！', '20151202/activity/lotsofgift.jpg', NULL, 3, 16, '2015-12-01', '2015-12-31', 1, '20151201');

-- update middle ADs
UPDATE `ios_display_message` SET `url` = '/marketing/m/201512001/index.html', `icon_url` = '20151202/promotion/bj-r1.jpg', `name` = '一大波红包来袭！', title = '一大波红包来袭！' WHERE id = 10;
UPDATE `ios_display_message` SET `url` = '/marketing/m/201512001/index.html', `icon_url` = '20151202/promotion/bj-r2.jpg', `name` = '一大波红包来袭！', title = '一大波红包来袭！' WHERE id = 11;
