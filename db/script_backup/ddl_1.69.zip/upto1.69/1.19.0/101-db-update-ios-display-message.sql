-- update fanchuansai banner
update ios_display_message set icon_url = '20151202/banner/ab_fc.jpg' where id = 8;
