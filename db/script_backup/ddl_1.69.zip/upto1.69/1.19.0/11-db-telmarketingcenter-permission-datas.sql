-- 电话管理权限：意向客户
INSERT INTO `permission` VALUES ('100', '电销中心/电话管理/意向客户', '查看意向客户页', '2', '1', 'or0601');
INSERT INTO `permission` VALUES ('101', '电销中心/电话管理/意向客户/编辑', '编辑意向客户', '2', '1', 'or060101');
INSERT INTO `permission` VALUES ('102', '电销中心/电话管理/意向客户/搜索', '意向客户搜索信息', '2', '1', 'or060102');
INSERT INTO `permission` VALUES ('103', '电销中心/电话管理/意向客户/搜索/编辑', '意向客户编辑搜索信息', '2', '1', 'or060103');

-- 电话管理权限：工作查看
INSERT INTO `permission` VALUES ('104', '电销中心/电话管理/工作查看', '查看工作查看页', '2', '1', 'or0602');
INSERT INTO `permission` VALUES ('105', '电销中心/电话管理/工作查看/呼出记录', '查看呼出记录', '2', '1', 'or060201');
INSERT INTO `permission` VALUES ('106', '电销中心/电话管理/工作查看/呼出记录/指定人筛选', '呼出记录指定人筛选', '2', '1', 'or060202');
INSERT INTO `permission` VALUES ('107', '电销中心/电话管理/工作查看/短信数量', '查看短信数量', '2', '1', 'or060203');
INSERT INTO `permission` VALUES ('108', '电销中心/电话管理/工作查看/短信数量/指定人筛选', '短信数量指定人筛选', '2', '1', 'or060204');
INSERT INTO `permission` VALUES ('109', '电销中心/电话管理/工作查看/报价记录', '查看报价记录', '2', '1', 'or060205');
INSERT INTO `permission` VALUES ('110', '电销中心/电话管理/工作查看/报价记录/指定人筛选', '报价记录指定人筛选', '2', '1', 'or060206');
INSERT INTO `permission` VALUES ('111', '电销中心/电话管理/工作查看/成单记录', '查看报价记录', '2', '1', 'or060207');
INSERT INTO `permission` VALUES ('112', '电销中心/电话管理/工作查看/成单记录/指定人筛选', '成单记录指定人筛选', '2', '1', 'or060208');
INSERT INTO `permission` VALUES ('113', '电销中心/电话管理/工作查看/整体情况', '查看整体情况', '2', '1', 'or060209');
INSERT INTO `permission` VALUES ('114', '电销中心/电话管理/工作查看/搜索', '工作查看搜索信息', '2', '1', 'or060210');
INSERT INTO `permission` VALUES ('115', '电销中心/电话管理/工作查看/搜索/编辑', '工作查看编辑搜索信息', '2', '1', 'or060211');
