-- 电话管理权限资源：意向客户
INSERT INTO permission_resource VALUES (90,100,48);
INSERT INTO permission_resource VALUES (91,101,48);
INSERT INTO permission_resource VALUES (92,102,48);
INSERT INTO permission_resource VALUES (93,103,48);

-- 电话管理权限资源：工作查看
INSERT INTO permission_resource VALUES (94,104,49);
INSERT INTO permission_resource VALUES (95,105,49);
INSERT INTO permission_resource VALUES (96,106,49);
INSERT INTO permission_resource VALUES (97,107,49);
INSERT INTO permission_resource VALUES (98,108,49);
INSERT INTO permission_resource VALUES (99,109,49);
INSERT INTO permission_resource VALUES (100,110,49);
INSERT INTO permission_resource VALUES (101,111,49);
INSERT INTO permission_resource VALUES (102,112,49);
INSERT INTO permission_resource VALUES (103,113,49);
INSERT INTO permission_resource VALUES (104,114,49);
INSERT INTO permission_resource VALUES (105,115,49);
