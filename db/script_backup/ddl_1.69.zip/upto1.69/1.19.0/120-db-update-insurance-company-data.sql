update insurance_company set website_url = 'http://e.cic.cn/' where id=45000;
