-- 电话管理角色：电话主管，电话专员
INSERT INTO role(description,NAME,TYPE,DISABLE) VALUES('电话主管','电话主管',2,0);
INSERT INTO role(description,NAME,TYPE,DISABLE) VALUES('电话专员','电话专员',2,0);
