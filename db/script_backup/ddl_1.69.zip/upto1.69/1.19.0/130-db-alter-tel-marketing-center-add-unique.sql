-- 修改description字段长度为2000
ALTER TABLE tel_marketing_center_source MODIFY description VARCHAR(2000);

-- 修改description字段长度为2000
ALTER TABLE tel_marketing_center_status MODIFY description VARCHAR(2000);

-- 修改索引名称为tel_marketing_center_history_ibfk_1
ALTER TABLE tel_marketing_center_history DROP FOREIGN KEY `FK_TEL_MARKETING_CENTER_HISTORY_REF_OPERATOR`;
ALTER TABLE tel_marketing_center_history ADD CONSTRAINT `tel_marketing_center_history_ibfk_1` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`);

-- 修改索引名称为tel_marketing_center_history_ibfk_2
ALTER TABLE tel_marketing_center_history DROP FOREIGN KEY `FK_TEL_MARKETING_CENTER_HISTORY_REF_TEL_MARKETING_CENTER`;
ALTER TABLE tel_marketing_center_history ADD CONSTRAINT `tel_marketing_center_history_ibfk_2` FOREIGN KEY (`tel_marketing_center`) REFERENCES `tel_marketing_center` (`id`);

-- 修改字段name值
UPDATE tel_marketing_center_status tmc SET tmc.name = '之前已在车车成单' WHERE tmc.id = 10;

-- 修改字段name和description值
UPDATE tel_marketing_center_source tmc SET tmc.name = '预约联系',tmc.description = '预约联系' WHERE tmc.id = 40;

-- 电销中心用户ID唯一索引
ALTER TABLE `tel_marketing_center`
DROP INDEX `FK_TEL_MARKETING_CENTER_REF_USER` ,
ADD UNIQUE INDEX `FK_TEL_MARKETING_CENTER_REF_USER` (`user`) USING BTREE ;
