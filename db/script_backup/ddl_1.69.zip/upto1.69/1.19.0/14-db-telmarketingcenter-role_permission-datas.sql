-- 电话管理角色：电话主管登录权限
insert into role_permission(permission, role)
SELECT 10, id FROM role WHERE NAME = '电话主管';

-- 电话管理角色：电话主管用户权限
insert into role_permission(permission, role) 
SELECT 94, id FROM role WHERE NAME = '电话主管';
insert into role_permission(permission, role) 
SELECT 95, id FROM role WHERE NAME = '电话主管';

-- 电话管理角色：电话主管电销权限
insert into role_permission(permission, role) 
SELECT 100, id FROM role WHERE NAME = '电话主管';
insert into role_permission(permission, role) 
SELECT 101, id FROM role WHERE NAME = '电话主管';
insert into role_permission(permission, role) 
SELECT 102, id FROM role WHERE NAME = '电话主管';
insert into role_permission(permission, role) 
SELECT 103, id FROM role WHERE NAME = '电话主管';
insert into role_permission(permission, role) 
SELECT 104, id FROM role WHERE NAME = '电话主管';
insert into role_permission(permission, role) 
SELECT 105, id FROM role WHERE NAME = '电话主管';
insert into role_permission(permission, role) 
SELECT 106, id FROM role WHERE NAME = '电话主管';
insert into role_permission(permission, role) 
SELECT 107, id FROM role WHERE NAME = '电话主管';
insert into role_permission(permission, role) 
SELECT 108, id FROM role WHERE NAME = '电话主管';
insert into role_permission(permission, role) 
SELECT 109, id FROM role WHERE NAME = '电话主管';
insert into role_permission(permission, role) 
SELECT 110, id FROM role WHERE NAME = '电话主管';
insert into role_permission(permission, role) 
SELECT 111, id FROM role WHERE NAME = '电话主管';
insert into role_permission(permission, role) 
SELECT 112, id FROM role WHERE NAME = '电话主管';
insert into role_permission(permission, role) 
SELECT 113, id FROM role WHERE NAME = '电话主管';
insert into role_permission(permission, role)
SELECT 114, id FROM role WHERE NAME = '电话主管';
insert into role_permission(permission, role)
SELECT 115, id FROM role WHERE NAME = '电话主管';

-- 电话管理角色：电话专员登录权限
insert into role_permission(permission, role)
SELECT 10, id FROM role WHERE NAME = '电话专员';

-- 电话管理角色：电话专员报价权限
insert into role_permission(permission, role) 
SELECT 98, id FROM role WHERE NAME = '电话专员';
insert into role_permission(permission, role) 
SELECT 99, id FROM role WHERE NAME = '电话专员';

-- 电话管理角色：电话专员电销权限
insert into role_permission(permission, role) 
SELECT 100, id FROM role WHERE NAME = '电话专员';
insert into role_permission(permission, role) 
SELECT 101, id FROM role WHERE NAME = '电话专员';
insert into role_permission(permission, role) 
SELECT 102, id FROM role WHERE NAME = '电话专员';
insert into role_permission(permission, role) 
SELECT 104, id FROM role WHERE NAME = '电话专员';
insert into role_permission(permission, role) 
SELECT 105, id FROM role WHERE NAME = '电话专员';
insert into role_permission(permission, role) 
SELECT 107, id FROM role WHERE NAME = '电话专员';
insert into role_permission(permission, role) 
SELECT 109, id FROM role WHERE NAME = '电话专员';
insert into role_permission(permission, role) 
SELECT 111, id FROM role WHERE NAME = '电话专员';
insert into role_permission(permission, role)
SELECT 114, id FROM role WHERE NAME = '电话专员';


-- 电话管理角色：系统管理员添加电销权限
insert into role_permission(permission, role) value(100,8);
insert into role_permission(permission, role) value(101,8);
insert into role_permission(permission, role) value(102,8);
insert into role_permission(permission, role) value(103,8);
insert into role_permission(permission, role) value(104,8);
insert into role_permission(permission, role) value(105,8);
insert into role_permission(permission, role) value(106,8);
insert into role_permission(permission, role) value(107,8);
insert into role_permission(permission, role) value(108,8);
insert into role_permission(permission, role) value(109,8);
insert into role_permission(permission, role) value(110,8);
insert into role_permission(permission, role) value(111,8);
insert into role_permission(permission, role) value(112,8);
insert into role_permission(permission, role) value(113,8);
insert into role_permission(permission, role) value(114,8);
insert into role_permission(permission, role) value(115,8);
