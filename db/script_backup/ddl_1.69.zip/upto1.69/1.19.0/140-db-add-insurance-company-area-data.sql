update insurance_company set type = 1 where id = 45000;

INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (45000, 110000); -- 北京市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (45000, 310000); -- 上海市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (45000, 440100); -- 广州市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (45000, 440300); -- 深圳市

INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (45000, 120000); -- 天津市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (45000, 320500); -- 苏州市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (45000, 330100); -- 杭州市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (45000, 410100); -- 郑州市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (45000, 420100); -- 武汉市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (45000, 500000); -- 重庆市
INSERT INTO `insurance_company_area`(`insurance_company_id`, `area_id`) VALUES (45000, 510100); -- 成都市
