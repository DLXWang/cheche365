-- 修改字段name和description值
UPDATE tel_marketing_center_source tmc SET tmc.name = '无购买记录用户',tmc.description = '无购买记录用户' WHERE tmc.id = 40;