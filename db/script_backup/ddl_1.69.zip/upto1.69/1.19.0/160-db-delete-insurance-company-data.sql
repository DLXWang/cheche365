-- 关闭中华联合11个城市
update insurance_company set type = 3 where id = 45000;

delete from `insurance_company_area`
where `insurance_company_id` = 45000
and `area_id` in (110000,310000,440100,440300,120000,320500,330100,410100,420100,500000,510100);

-- 关闭 国寿财剩余的除西宁（630100）/ 银川（640100）/拉萨（540100）外的19个城市
delete from `insurance_company_area`
where `insurance_company_id` = 40000
and `area_id` in (130100, 150100, 370100, 460100, 530100,
610100, 230100, 350100, 320100, 140100,
210100, 220100, 340100, 360100, 430100,
450100, 520100, 620100, 650100);
