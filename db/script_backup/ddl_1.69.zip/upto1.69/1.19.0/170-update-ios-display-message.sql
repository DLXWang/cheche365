UPDATE `ios_display_message` SET `icon_url`='20151202/activity/lotsofgift01.jpg' WHERE `id`='43';
UPDATE `ios_display_message` SET `icon_url`='20151202/activity/lotsofgift01.jpg' WHERE `id`='44';
