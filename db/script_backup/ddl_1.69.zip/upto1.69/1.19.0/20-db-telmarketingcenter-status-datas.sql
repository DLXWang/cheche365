-- 电销中心状态名修改
update tel_marketing_center_status ts set ts.name = '之前已在车车成单' where ts.id = 10;
update tel_marketing_center_status ts set ts.name = '预约联系' where ts.id = 40;