ALTER TABLE qrcode_channel ADD COLUMN department VARCHAR(20) DEFAULT NULL comment '所属部门' AFTER rebate;
