INSERT INTO `permission` VALUES ('116', '出单中心/订单管理/订单查询/导出查询结果', '导出查询结果', '2', '1', 'or010301');
INSERT INTO `permission_resource` VALUES ('106', '116', '31');
