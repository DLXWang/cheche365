-- 保险公司官网链接
ALTER TABLE `insurance_company` ADD COLUMN `website_url` VARCHAR(100) DEFAULT '';

update insurance_company set website_url = 'http://www.epicc.com.cn/' where id=10000;
update insurance_company set website_url = 'http://chexian.sinosig.com/' where id=15000;
update insurance_company set website_url = 'http://insurance.pingan.com/list/chexian/index.shtml?source=index_NEW' where id=20000;
update insurance_company set website_url = 'http://www.ecpic.com.cn/' where id=25000;
update insurance_company set website_url = 'http://www.chinalife-p.com.cn/' where id=40000;
