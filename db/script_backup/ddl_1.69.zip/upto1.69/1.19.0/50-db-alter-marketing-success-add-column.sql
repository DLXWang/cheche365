ALTER TABLE `marketing_success` ADD COLUMN `synced` TINYINT(1) NULL DEFAULT 0 COMMENT '记录是否已同步到gift表' AFTER `area`;
