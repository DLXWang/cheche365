ALTER TABLE `marketing_success` ADD INDEX `mobile_synced` (`synced` ASC, `mobile` ASC);
