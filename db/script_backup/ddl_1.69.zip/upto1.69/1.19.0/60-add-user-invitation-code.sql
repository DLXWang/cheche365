
CREATE TABLE `user_invitation_code` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '记录用户的邀请码',
  `user` bigint(20) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `code` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_u_user_invitation_code_code` (`code`) USING BTREE,
  KEY `FK_USER_INVITATION_CODE_REF_USER` (`user`),
  CONSTRAINT `FK_USER_INVITATION_CODE_REF_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
