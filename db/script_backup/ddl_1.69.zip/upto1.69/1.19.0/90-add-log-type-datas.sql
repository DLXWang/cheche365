INSERT INTO `log_type` (`name`, `description`) SELECT '商业险套餐变更', '商业险套餐变更' FROM DUAL WHERE NOT EXISTS(SELECT name FROM log_type WHERE name = '商业险套餐变更');
INSERT INTO `log_type` (`name`, `description`) SELECT '交强险套餐变更', '交强险套餐变更' FROM DUAL WHERE NOT EXISTS(SELECT name FROM log_type WHERE name = '交强险套餐变更');
INSERT INTO `log_type` (`name`, `description`) SELECT '出单状态变更', '出单状态变更' FROM DUAL WHERE NOT EXISTS(SELECT name FROM log_type WHERE name = '出单状态变更');
INSERT INTO `log_type` (`name`, `description`) SELECT '出单时间', '订单出单完成时间' FROM DUAL WHERE NOT EXISTS(SELECT name FROM log_type WHERE name = '出单时间');
update log_type set name = '删除内部用户', description = '删除内部用户' where id = 10;
