INSERT INTO marketing (id, name, code, begin_date, end_date, marketing_type)
VALUES (19, '2015一大波红包来袭_WEB渠道统计', '201512001', '2015-12-01 00:00:00', '2016-03-31 23:59:59', 'web');
