-- ----------------------------
-- Table structure for auto_shop_service_item
-- 4s店服务项
-- ----------------------------
CREATE TABLE if not exists `auto_shop_service_item` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `auto_shop` bigint(20) NOT NULL,
  `name` varchar(100) COLLATE utf8_bin NOT NULL,
  `img_url` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `disable` tinyint(1) default 0,
  `service_kind` tinyint(1) DEFAULT '1' COMMENT '1:基本服务.2:特色服务',
  `comments` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `FK_AUTO_SHOP_SERVICE_ITEM_REF_AUTO_SHOP` FOREIGN KEY (`auto_shop`) REFERENCES `auto_shop` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Table structure for auto_shop_brand
-- 4s店品牌表
-- ----------------------------
CREATE TABLE IF NOT EXISTS `auto_shop_brand` (
    `auto_shop` bigint(20) NOT NULL,
    `autohome_brand` bigint(20) NOT NULL,
    PRIMARY KEY (`auto_shop`,`autohome_brand`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Table structure for auto_shop_temporary
-- 4s店临时表存储相关信息
-- ----------------------------
CREATE TABLE IF NOT EXISTS `auto_shop_temporary` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `brand_name` varchar(100) COLLATE utf8_bin NOT NULL,
  `insurance_company` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
