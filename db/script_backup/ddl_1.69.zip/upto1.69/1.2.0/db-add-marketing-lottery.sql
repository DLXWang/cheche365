-- ----------------------------
-- Table structure for `marketing_lottery`
-- ----------------------------
CREATE TABLE IF NOT EXISTS `marketing_lottery` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `marketing_id` bigint(20) NOT NULL, 
  `user_id` bigint(20) default NULL, 
  `mobile` varchar(11) default NULL, 
  `resource_table_name` varchar(100) not NULL,
  `resource_id` bigint(20) not NULL,
  `create_time` datetime NOT NULL,
  `used` tinyint(1) default 0,
  `lottery_time` datetime default NULL,
  `gift_name` varchar(100) DEFAULT NULL,
  `gift_quantity` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;