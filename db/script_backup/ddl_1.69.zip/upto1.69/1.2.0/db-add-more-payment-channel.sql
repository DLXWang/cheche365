INSERT INTO payment_channel VALUES (10, '大客户活动现金减免', '大客户活动现金减免');
