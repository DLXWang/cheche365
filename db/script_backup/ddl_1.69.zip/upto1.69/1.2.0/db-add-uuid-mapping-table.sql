CREATE TABLE `uuid_mapping` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `uuid` VARCHAR(45) NOT NULL,
  `session_id` VARCHAR(45) NOT NULL,
  `logged` TINYINT(1) NOT NULL,
  PRIMARY KEY (`id`))
DEFAULT CHARACTER SET = utf8
COLLATE = utf8_bin
COMMENT = '维护app的uuid和系统session mapping，保证app session不过期';
