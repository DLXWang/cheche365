-- ----------------------------
-- Table structure for vip_company
-- ----------------------------
CREATE TABLE IF NOT EXISTS `vip_company` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `code` varchar(45) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  `comment` varchar(2000) DEFAULT NULL,
  `operator` bigint(20) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_VIP_COMPANY_REF_INTERNAL_USER` (`operator`),
  CONSTRAINT `FK_VIP_COMPANY_REF_INTERNAL_USER` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `vip_company_activity` (
    `id` bigint(20) NOT NULL AUTO_INCREMENT,
    `code` varchar(20) DEFAULT NULL,
    `name` varchar(100) DEFAULT NULL,
    `company` bigint(20) NOT NULL,
    `insurance_url` varchar(100) NOT NULL,
    `error_url` varchar(100) default NULL,
    `begin_date` datetime DEFAULT NULL,
    `end_date` datetime DEFAULT NULL,
    `description` varchar(200) default NULL,
    `discount` decimal(18,6) DEFAULT NULL,
    `rule_class` varchar(100) NOT NULL,
    PRIMARY KEY (`id`),
    KEY `FK_VIP_COMPANY_ACTIVITY_REF_COMPANY` (`company`),
    CONSTRAINT `FK_VIP_COMPANY_ACTIVITY_REF_COMPANY` FOREIGN KEY (`company`) REFERENCES `vip_company` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

