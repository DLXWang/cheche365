ALTER TABLE auto_shop_address ADD COLUMN address_detail VARCHAR(400) DEFAULT NULL;
