ALTER TABLE auto_shop_picture ADD COLUMN original_name VARCHAR(300) DEFAULT NULL;
ALTER TABLE auto_shop_picture MODIFY COLUMN auto_shop bigint NULL;
