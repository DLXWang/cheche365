ALTER TABLE `gift` ADD COLUMN `quantity` tinyint(3) DEFAULT NULL;
