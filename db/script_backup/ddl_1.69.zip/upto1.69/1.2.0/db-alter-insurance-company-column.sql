ALTER TABLE insurance_company ADD COLUMN `disable` tinyint(1) default 0;
create index idx_u_insurance_company_disable on insurance_company(disable);
