ALTER TABLE `purchase_order` ADD COLUMN `company_activity` bigint(20) DEFAULT NULL;
