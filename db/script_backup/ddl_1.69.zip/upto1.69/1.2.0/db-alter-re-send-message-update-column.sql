ALTER TABLE re_send_message modify COLUMN param mediumtext DEFAULT NULL;
