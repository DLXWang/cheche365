ALTER TABLE `uuidmapping`
ADD COLUMN `update_date` DATETIME NOT NULL AFTER `logged`,
ADD COLUMN `login_date` DATETIME NULL AFTER `update_date`,
ADD COLUMN `logout_date` DATETIME NULL AFTER `login_date`,
ADD COLUMN `user` BIGINT(20) NOT NULL AFTER `session_id`;

ALTER TABLE `uuidmapping`
CHANGE COLUMN `user` `user` BIGINT(20) NULL ,
ADD INDEX `FK_UUID_MAPPING_REF_USER_idx` (`user` ASC);
ALTER TABLE `uuidmapping`
ADD CONSTRAINT `FK_UUID_MAPPING_REF_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`)
