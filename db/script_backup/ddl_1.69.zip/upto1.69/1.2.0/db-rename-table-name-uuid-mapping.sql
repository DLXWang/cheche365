ALTER TABLE `uuid_mapping`
RENAME TO  `uuidmapping` ;





