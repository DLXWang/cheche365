UPDATE `insurance_company` SET `logo`='picc.png' WHERE `id`='10000';
UPDATE `insurance_company` SET `logo`='sinosig.png' WHERE `id`='15000';
UPDATE `insurance_company` SET `logo`='pingan.png' WHERE `id`='20000';
UPDATE `insurance_company` SET `logo`='cpic.png' WHERE `id`='25000';
