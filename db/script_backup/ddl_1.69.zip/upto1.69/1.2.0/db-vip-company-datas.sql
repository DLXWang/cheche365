﻿INSERT INTO vip_company(id,code,name,create_time,update_time) VALUES(1, 'ultrapower', '北京神州泰岳软件股份有限公司',now(),now());
