DELETE FROM vehicle_license WHERE engine_no = '' OR vin_no = '';
