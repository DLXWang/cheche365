#整理系统垃圾数据 之前营销活动的gift_type是1 应该改成2 该bug之影响前两次活动 对618活动无影响 此bug修复的svn版本为3562

update gift set source_type=2 where reason = "营销活动赠送代金券"
