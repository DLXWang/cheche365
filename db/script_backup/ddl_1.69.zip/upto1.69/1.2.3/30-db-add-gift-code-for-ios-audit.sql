INSERT INTO `gift` (`gift_amount`, `gift_type`, `gift_code`) VALUES ('100', '4', 'IOS123456');
