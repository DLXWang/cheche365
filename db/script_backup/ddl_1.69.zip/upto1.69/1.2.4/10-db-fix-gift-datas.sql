﻿/*客户出单未支付,解除优惠券绑定用
select * from payment t where t.`user` = (select t.applicant from purchase_order t where t.order_no = 'I20150623000039') and t.amount=618;--查询优惠券使用情况
*/
update gift a set a.status=1 where a.applicant = (select t.applicant from purchase_order t where t.order_no = 'I20150623000039')
and a.gift_amount=618;