﻿/*取消订单,并且解除优惠券绑定。总共3条update语句，需要手动执行
select * from payment t where t.`user` = (select t.applicant from purchase_order t where t.order_no = 'I20150624000002') and t.amount=418;--查询优惠券使用情况
*/
update purchase_order p set p.`status` = 6,p.update_time = now() where p.order_no = 'I20150624000002'; 
update order_operation_info o set o.current_status = 12,o.update_time = now() where o.purchase_order = (select q.id from purchase_order q where q.order_no = 'I20150624000002');
update gift a set a.status=1 where a.applicant = (select t.applicant from purchase_order t where t.order_no = 'I20150624000002') and a.gift_amount=418;