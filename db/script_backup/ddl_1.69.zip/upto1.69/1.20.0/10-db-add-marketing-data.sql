insert into `marketing` (`id`, `name`, `code`, `begin_date`, `end_date`, `failure_date_class_param`, `channel`, `amount_class_param`,
`amount_class`, `failure_date_class`, `description`,
`full_limit_param`, `gift_class`, `marketing_type`)
values(20,'2015广播活动','201512002','2015-12-11 00:00:00','2016-01-11 23:59:59','2016-01-11 23:59:59',NULL,'0',
'com.cheche365.cheche.marketing.service.FixedAmount','com.cheche365.cheche.marketing.service.FixedDate','2015广播活动',
NULL,'com.cheche365.cheche.core.service.market.RandomAmountRealGiftConvertor','m');

INSERT INTO marketing (id, name, code, begin_date, end_date, marketing_type)
VALUES (21, '2015广播活动_WEB渠道统计', '201512002', '2015-12-11 00:00:00', '2016-01-11 23:59:59', 'web');
