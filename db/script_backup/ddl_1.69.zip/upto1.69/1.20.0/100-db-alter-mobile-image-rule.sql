-- 重新设计图片映射规则表
-- ----------------------------
-- Table structure for mobile_device_pic_rule
-- ----------------------------
DROP TABLE IF EXISTS `mobile_device_pic_rule`;
CREATE TABLE `mobile_device_pic_rule` (
    `id` BIGINT(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
    `message_type` VARCHAR(200) NOT NULL COMMENT '图片显示类别',
    `client` VARCHAR(200) NOT NULL COMMENT '客户端类型',
    `version` VARCHAR(200) NOT NULL COMMENT '是否默认（每个类别应该有一个默认）',
    `screen_size` VARCHAR(500) NOT NULL COMMENT '屏幕尺寸',
    `image_suffix` VARCHAR(200) NOT NULL COMMENT '对应图片名字后缀',
    `description` VARCHAR(400) DEFAULT NULL,
    `order` INT(6) NOT NULL DEFAULT '0',
    PRIMARY KEY (`id`)
) ENGINE=INNODB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of mobile_device_pic_rule
-- ----------------------------
INSERT INTO `mobile_device_pic_rule` VALUES ('1', '(10|12)', 'ios', '-1.3', '(320_480|320_568)', 'ios_640_298', NULL, '1');
INSERT INTO `mobile_device_pic_rule` VALUES ('2', '(10|12)', 'ios', '-1.3', '(375_667)', 'ios_750_350', NULL, '2');
INSERT INTO `mobile_device_pic_rule` VALUES ('3', '(10|12)', 'ios', '-1.3', '*', 'ios_828_386', NULL, '3');
INSERT INTO `mobile_device_pic_rule` VALUES ('4', '(10|12)', 'ios', '1.3-', '(320_480|320_568|375_667)', 'ios_750_220', NULL, '4');
INSERT INTO `mobile_device_pic_rule` VALUES ('5', '(10|12)', 'ios', '1.3-', '*', 'ios_1125_330', NULL, '5');
INSERT INTO `mobile_device_pic_rule` VALUES ('6', '(10|12)', '*', '*', '*', '828_386', NULL, '99');
INSERT INTO `mobile_device_pic_rule` VALUES ('7', '11', '*', '*', '*', '', NULL, '100');
INSERT INTO `mobile_device_pic_rule` VALUES ('8', '(131|132|133)', 'ios', '*', '(320_480|320_568)', '640_170', NULL, '200');
INSERT INTO `mobile_device_pic_rule` VALUES ('9', '(131|132|133)', 'ios', '*', '(375_667)', '750_200', NULL, '201');
INSERT INTO `mobile_device_pic_rule` VALUES ('10', '(131|132|133)', '*', '*', '*', '828_220', NULL, '299');
INSERT INTO `mobile_device_pic_rule` VALUES ('11', '14', '*', '*', '(320_480|320_568|375_667)', '192_66', NULL, '300');
INSERT INTO `mobile_device_pic_rule` VALUES ('12', '14', '*', '*', '*', '288_99', NULL, '399');
