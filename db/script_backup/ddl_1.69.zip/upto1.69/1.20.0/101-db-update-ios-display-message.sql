-- IOS middle AD
UPDATE `ios_display_message` SET `url` = '/marketing/m/201512002/index.html', NAME = '年底大促双重壕礼，100%中奖！', `title` = '年底大促双重壕礼，100%中奖！', `icon_url` = '20151209/promotion/r1.jpg' WHERE `id` = 10;
UPDATE `ios_display_message` SET `url` = '/marketing/m/201512001/index.html', NAME = '一大波红包来袭！', `title` = '一大波红包来袭！', `icon_url` = '20151209/promotion/r2.jpg' WHERE `id` = 11;
