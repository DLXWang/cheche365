-- drop some column
ALTER TABLE `alipay_user_info` DROP COLUMN `nick_name`;
ALTER TABLE `alipay_user_info` DROP COLUMN `sex`;
ALTER TABLE `alipay_user_info` DROP COLUMN `language`;
ALTER TABLE `alipay_user_info` DROP COLUMN `city`;
ALTER TABLE `alipay_user_info` DROP COLUMN `head_img_url`;
ALTER TABLE `alipay_user_info` DROP COLUMN `qrcode`;
ALTER TABLE `alipay_user_info` DROP COLUMN `qrcode_channel`;
ALTER TABLE `alipay_user_info` DROP COLUMN `union_id`;
ALTER TABLE `alipay_user_info` DROP COLUMN `province`;
ALTER TABLE `alipay_user_info` DROP COLUMN `country`;

-- add some column
ALTER TABLE `alipay_user_info` ADD COLUMN `create_time` DATE DEFAULT NULL COMMENT '创建时间';

ALTER TABLE `alipay_user_info` ADD COLUMN `user_type_value` VARCHAR(6) DEFAULT NULL COMMENT '用户类型（1/2）。1代表公司账户；2代表个人账户';
ALTER TABLE `alipay_user_info` ADD COLUMN `user_status` VARCHAR(6) DEFAULT NULL COMMENT '用户状态。Q代表快速注册用户;T代表已认证用户;B代表被冻结账户;W代表已注册，未激活的账户;';
ALTER TABLE `alipay_user_info` ADD COLUMN `firm_name` VARCHAR(200) DEFAULT NULL COMMENT '公司名称（用户类型是公司类型时，才有此字段）';
ALTER TABLE `alipay_user_info` ADD COLUMN `real_name` VARCHAR(200) DEFAULT NULL COMMENT '用户的真实姓名';
ALTER TABLE `alipay_user_info` ADD COLUMN `avatar` VARCHAR(200) DEFAULT NULL COMMENT '用户头像';
ALTER TABLE `alipay_user_info` ADD COLUMN `cert_no` VARCHAR(100) DEFAULT NULL COMMENT '证件号码';
ALTER TABLE `alipay_user_info` ADD COLUMN `gender` VARCHAR(6) DEFAULT NULL COMMENT '性别（F：女性；M：男性）';
ALTER TABLE `alipay_user_info` ADD COLUMN `phone` VARCHAR(50) DEFAULT NULL COMMENT '电话号码';
ALTER TABLE `alipay_user_info` ADD COLUMN `mobile` VARCHAR(50) DEFAULT NULL COMMENT '手机号码';
ALTER TABLE `alipay_user_info` ADD COLUMN `is_certified` VARCHAR(6) DEFAULT NULL COMMENT '是否通过实名认证。T是通过；F是没有实名认证';
ALTER TABLE `alipay_user_info` ADD COLUMN `is_student_certified` VARCHAR(6) DEFAULT NULL COMMENT '是否是学生。T表示是学生；F表示不是学生';
ALTER TABLE `alipay_user_info` ADD COLUMN `is_bank_auth` VARCHAR(6) DEFAULT NULL COMMENT 'T为是银行卡认证，F为非银行卡认证';
ALTER TABLE `alipay_user_info` ADD COLUMN `is_id_auth` VARCHAR(6) DEFAULT NULL COMMENT 'T为是身份证认证，F为非身份证认证';
ALTER TABLE `alipay_user_info` ADD COLUMN `is_mobile_auth` VARCHAR(6) DEFAULT NULL COMMENT 'T为是手机认证，F为非手机认证';
ALTER TABLE `alipay_user_info` ADD COLUMN `is_licence_auth` VARCHAR(6) DEFAULT NULL COMMENT 'T为通过营业执照认证，F为没有通过';
ALTER TABLE `alipay_user_info` ADD COLUMN `cert_type_value` VARCHAR(6) DEFAULT NULL COMMENT '0：身份证；1：护照；2：军官证；3：士兵证；4：回乡证；5：临时身份证；6：户口簿；7：警官证；8：台胞证；9：营业执照；10：其它证件';
ALTER TABLE `alipay_user_info` ADD COLUMN `province` VARCHAR(50) DEFAULT NULL COMMENT '省份名称';
ALTER TABLE `alipay_user_info` ADD COLUMN `city` VARCHAR(50) DEFAULT NULL COMMENT '市名称';
ALTER TABLE `alipay_user_info` ADD COLUMN `area` VARCHAR(50) DEFAULT NULL COMMENT '区县名称';
ALTER TABLE `alipay_user_info` ADD COLUMN `address` VARCHAR(500) DEFAULT NULL COMMENT '详细地址';
ALTER TABLE `alipay_user_info` ADD COLUMN `zip` VARCHAR(50) DEFAULT NULL COMMENT '邮政编码';
ALTER TABLE `alipay_user_info` ADD COLUMN `address_code` VARCHAR(6) DEFAULT NULL COMMENT '区域编码，暂时不返回值';
