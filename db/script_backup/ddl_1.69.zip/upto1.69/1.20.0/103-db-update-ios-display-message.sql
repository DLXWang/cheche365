UPDATE `ios_display_message` SET `icon_url` = '20151123/promotion/bj-l1.jpg' WHERE `id` = 9;
