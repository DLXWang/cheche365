-- update pingan logo
UPDATE `insurance_company` SET `logo` = 'pingan.png' WHERE `id` = 20000;
