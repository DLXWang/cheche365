-- 中间广告左1修改成冬日关怀
UPDATE `ios_display_message` SET `url` = '/marketing/m/201512003/index.html', `name` = '车车车险冬日关怀，免费送保养！', `title` = '车车车险冬日关怀，免费送保养！', `icon_url` = '20151209/promotion/l1.jpg' WHERE id = 9;
-- 双12下架
UPDATE `ios_display_message` SET `enable` = 0 WHERE `name` = '双12，无兄弟不免单！';
