-- 打开平安
UPDATE `insurance_company` SET `type` = 1 WHERE id = 20000;
