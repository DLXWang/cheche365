insert into `schedule_condition` (`id`, `name`, `marketing`) values('13','2015广播活动','20');
