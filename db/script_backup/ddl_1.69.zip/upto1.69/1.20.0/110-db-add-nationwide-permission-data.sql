-- 全国出单中心 订单总控台权限
INSERT INTO `permission` VALUES ('117', '出单中心/全国出单中心/订单管理/订单总控台', '查看订单总控台', '2', '1', 'or070101');
INSERT INTO `permission` VALUES ('118', '出单中心/全国出单中心/订单管理/订单总控台/操作', '操作', '2', '1', 'or07010101');

INSERT INTO `resource` VALUES ('50', '全国出单中心', '27', '1', '2');
INSERT INTO `resource` VALUES ('51', '订单管理-订单总控台', '50', '1', '3');

INSERT INTO `permission_resource` VALUES ('107', '117', '51');
INSERT INTO `permission_resource` VALUES ('108', '118', '51');
