INSERT INTO `gift_type` (`id`, `name`, `description`, `use_type`, `category`, `category_name`)
VALUES (21, '加油卡', '加油卡&下单可抽奖', 2, 4, "礼包");
