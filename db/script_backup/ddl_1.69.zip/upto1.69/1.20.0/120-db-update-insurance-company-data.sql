-- 人保
UPDATE insurance_company SET rank = 1 WHERE id = 10000;
-- 阳光
UPDATE insurance_company SET rank = 2 WHERE id = 15000;
-- 平安
UPDATE insurance_company SET rank = 99 WHERE id = 20000;
-- 太平洋
UPDATE insurance_company SET rank = 3 WHERE id = 25000;
-- 中国太平
UPDATE insurance_company SET rank = 4 WHERE id = 30000;
-- 安邦
UPDATE insurance_company SET rank = 5 WHERE id = 35000;
-- 国寿
UPDATE insurance_company SET rank = 6 WHERE id = 40000;
-- 中华联合
UPDATE insurance_company SET rank = 7 WHERE id = 45000;
