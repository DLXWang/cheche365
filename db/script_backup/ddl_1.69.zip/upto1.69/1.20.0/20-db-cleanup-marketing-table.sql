ALTER TABLE `marketing`
DROP COLUMN `failure_date_class`,
DROP COLUMN `amount_class`,
CHANGE COLUMN `description` `description` VARCHAR(2000) NULL DEFAULT NULL AFTER `marketing_type`,
CHANGE COLUMN `failure_date_class_param` `gift_expire_date` VARCHAR(100) NULL DEFAULT NULL COMMENT '优惠券过期日期' ,
CHANGE COLUMN `amount_class_param` `amount` VARCHAR(100) NULL DEFAULT NULL COMMENT '营销活动赠送代金券金额，可包含多个，用分号分割' ,
CHANGE COLUMN `full_limit_param` `full_limit` VARCHAR(500) NULL DEFAULT NULL COMMENT '优惠券使用的满减条件，如订单满1000才能使用' ;
