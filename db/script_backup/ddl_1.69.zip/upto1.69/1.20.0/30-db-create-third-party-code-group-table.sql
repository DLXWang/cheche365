CREATE TABLE `third_party_code_group` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `code` VARCHAR(50) NOT NULL,
  `name` VARCHAR(45) NOT NULL,
  `description` VARCHAR(2000) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_third_party_code_group_code` (`code`)
  ) ENGINE=INNODB DEFAULT CHARSET=utf8;
