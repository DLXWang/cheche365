 CREATE TABLE `third_party_code` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `code` VARCHAR(50) NOT NULL,
  `name` VARCHAR(50) NOT NULL,
  `user` BIGINT(20) NULL,
  `create_time` DATETIME NULL,
  `update_time` DATETIME NULL,
  `occupied` TINYINT(1) NULL DEFAULT 0 COMMENT '是否已领用',
  `code_group` BIGINT(20) NULL,
  `description` VARCHAR(2000) NULL,
  PRIMARY KEY (`id`),
  INDEX `FK_THIRD_PARTY_CODE_REF_USER_idx` (`user` ASC),
  INDEX `FK_THIRD_PARTY_CODE_REF_GROUP_idx` (`code_group` ASC),
  CONSTRAINT `FK_THIRD_PARTY_CODE_REF_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`),
  CONSTRAINT `FK_THIRD_PARTY_CODE_REF_GROUP` FOREIGN KEY (`code_group`) REFERENCES `third_party_code_group` (`id`))
  ENGINE=InnoDB DEFAULT CHARSET=utf8;
