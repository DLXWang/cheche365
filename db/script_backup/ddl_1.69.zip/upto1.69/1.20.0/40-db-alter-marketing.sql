ALTER TABLE `marketing`
ADD COLUMN `quote_support`  tinyint(1) DEFAULT 1 COMMENT '是否支持报价时领取优惠券 1 支持 0 不支持' AFTER `marketing_type`,
ADD COLUMN `short_name`  varchar(20) NULL COMMENT '优惠活动简称' AFTER `quote_support`;
