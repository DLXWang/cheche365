create index idx_uuid_clienttype on uuidmapping (uuid,client_type);
