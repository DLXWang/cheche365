create index idx_active on area (active);
