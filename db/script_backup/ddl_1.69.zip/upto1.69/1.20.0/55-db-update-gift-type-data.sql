update `gift_type`
set `description` = '满千送百元加油卡&下单可抽奖'
where `id` = 21;

