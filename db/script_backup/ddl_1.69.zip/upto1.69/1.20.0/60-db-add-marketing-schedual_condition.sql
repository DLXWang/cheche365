-- marketing 表
insert into `marketing` (`id`, `name`, `code`, `begin_date`, `end_date`, `gift_expire_date`, `channel`, `amount`, `gift_class`, `full_limit`, `marketing_type`, `description`, `quote_support`, `short_name`) values('22','2015车车冬日关怀','201512003','2015-12-01 00:00:00','2015-12-31 23:59:59','2015-12-31 23:59:59',NULL,NULL,NULL,NULL,'m','车车冬日关怀','1',NULL);
-- schedule_condition表
insert into `schedule_condition` (`id`, `name`, `marketing`) values('14','2015车车冬日关怀','22');
-- sms_template 表
insert into `sms_template` (`id`, `name`, `zucp_code`, `yxt_code`, `disable`, `content`, `comment`, `create_time`, `update_time`, `operator`) values('38','2015车车冬日关怀','PENDING_027',NULL,'0','尊敬的车车用户，“车车冬日关怀”送您免费“${CodeType}”一次，兑换码为：${Code}。请于2015.12.31日前登陆E保养，选择“${CodeType}”项目使用。上车车买车险，省钱省心。点击获取车险报价：t.cn/RUFRGMH',NULL,'2015-12-07 16:46:49',NULL,NULL);
-- schedule_message 表
insert into `schedule_message` (`id`, `sms_template`, `schedule_condition`, `disable`, `comment`, `create_time`, `update_time`, `operator`) values('16','38','14','0',NULL,'2015-12-07 17:07:41',NULL,NULL);
-- message_variable表
insert into `message_variable` (`id`, `code`, `name`, `type`, `placeholder`, `length`, `parameter`, `model_class`, `model_method`) values('29','${CodeType}','兑换码类型','varchar','请输入兑换码类型','100','codeType',NULL,NULL);
insert into `message_variable` (`id`, `code`, `name`, `type`, `placeholder`, `length`, `parameter`, `model_class`, `model_method`) values('30','${Code}','兑换码','varchar','请输入兑换码','100','code',NULL,NULL);
