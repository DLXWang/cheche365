ALTER TABLE `third_party_code` ADD UNIQUE(`code`);
