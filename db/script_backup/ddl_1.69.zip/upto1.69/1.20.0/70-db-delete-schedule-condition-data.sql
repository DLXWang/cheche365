-- 广播活动领取以及抽奖均不需要触发短信
delete from `schedule_condition`
where `id` = '13';
