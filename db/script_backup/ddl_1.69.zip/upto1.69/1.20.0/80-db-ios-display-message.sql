INSERT INTO `ios_display_message` VALUES (45, '/marketing/m/201512002/index.html', '年底大促双重壕礼，100%中奖！', '年底大促双重壕礼，100%中奖！', '20151209/activity/nddc.jpg', NULL, 1, 17, '2015-12-11', '2016-01-11', 1, '201512002');
INSERT INTO `ios_display_message` VALUES (46, '/marketing/m/201512002/index.html', '年底大促双重壕礼，100%中奖！', '年底大促双重壕礼，100%中奖！', '20151209/activity/nddc.jpg', NULL, 3, 17, '2015-12-11', '2016-01-11', 1, '201512002');

INSERT INTO `ios_display_message` VALUES (47, '/marketing/m/201512003/index.html', '车车车险冬日关怀，免费送保养！', '车车车险冬日关怀，免费送保养！', '20151209/activity/ebc.jpg', NULL, 1, 18, '2015-12-10', '2015-12-31', 1, '201512003');
INSERT INTO `ios_display_message` VALUES (48, '/marketing/m/201512003/index.html', '车车车险冬日关怀，免费送保养！', '车车车险冬日关怀，免费送保养！', '20151209/activity/ebc.jpg', NULL, 3, 18, '2015-12-10', '2015-12-31', 1, '201512003');
