INSERT INTO `gift_code_exchange_way` (`id`, `name`, `exchange_class`, `common_exchange`, `amount`, `operator`, `create_time`, `update_time`, `description`,`effective_date` ,`expire_date` ,`amount_param` ,`full_limit_param`)
VALUES ('16', '新春礼品卡第一批', 'com.cheche365.cheche.core.service.giftcode.JsonParamCodeExchange', '0', '300.00', null, NOW(), null, '每个优惠码兑换一张300元优惠券', '2015-12-15', '2016-12-14', '300.00', null);

INSERT INTO `gift_code_exchange_way` (`id`, `name`, `exchange_class`, `common_exchange`, `amount`, `operator`, `create_time`, `update_time`, `description`,`effective_date` ,`expire_date` ,`amount_param` ,`full_limit_param`)
VALUES ('17', '新春礼品卡第二批', 'com.cheche365.cheche.core.service.giftcode.JsonParamCodeExchange', '0', '300.00', null, NOW(), null, '每个优惠码兑换一张300元优惠券', '2015-12-15', '2016-12-14', '300.00', null);

INSERT INTO `gift_code_exchange_way` (`id`, `name`, `exchange_class`, `common_exchange`, `amount`, `operator`, `create_time`, `update_time`, `description`,`effective_date` ,`expire_date` ,`amount_param` ,`full_limit_param`)
VALUES ('18', 'vip企业专享卡', 'com.cheche365.cheche.core.service.giftcode.JsonParamCodeExchange', '0', '300.00', null, NOW(), null, '每个优惠码兑换一张300元优惠券', '2015-12-15', '2016-12-31', '300.00', null);

INSERT INTO `gift_code_exchange_way` (`id`, `name`, `exchange_class`, `common_exchange`, `amount`, `operator`, `create_time`, `update_time`, `description`,`effective_date` ,`expire_date` ,`amount_param` ,`full_limit_param`)
VALUES ('19', '百度宝宝知道会员专享卡', 'com.cheche365.cheche.core.service.giftcode.JsonParamCodeExchange', '0', '300.00', null, NOW(), null, '每个优惠码兑换一张300元优惠券', '2015-12-15', '2016-12-31', '300.00', null);

INSERT INTO `gift_code_exchange_way` (`id`, `name`, `exchange_class`, `common_exchange`, `amount`, `operator`, `create_time`, `update_time`, `description`,`effective_date` ,`expire_date` ,`amount_param` ,`full_limit_param`)
VALUES ('20', '金色世纪会员特供卡', 'com.cheche365.cheche.core.service.giftcode.JsonParamCodeExchange', '0', '300.00', null, NOW(), null, '每个优惠码兑换一张300元优惠券', '2015-12-15', '2016-12-31', '300.00', null);

INSERT INTO `gift_code_exchange_way` (`id`, `name`, `exchange_class`, `common_exchange`, `amount`, `operator`, `create_time`, `update_time`, `description`,`effective_date` ,`expire_date` ,`amount_param` ,`full_limit_param`)
VALUES ('21', '车车双蛋兑换码第一批', 'com.cheche365.cheche.core.service.giftcode.JsonParamCodeExchange', '0', null, null, NOW(), null, '每个优惠码兑换15张200,300,400...1600元元优惠券,满千减百再多优惠一百', '2015-12-10', '2016-02-29',
 '200;300;400;500;600;700;800;900;1000;1100;1200;1300;1400;1500;1600', '200_1000;300_2000;400_3000;500_4000;600_5000;700_6000;800_7000;900_8000;1000_9000;1100_10000;1200_11000;1300_12000;1400_13000;1500_14000;1600_15000');

INSERT INTO `gift_code_exchange_way` (`id`, `name`, `exchange_class`, `common_exchange`, `amount`, `operator`, `create_time`, `update_time`, `description`,`effective_date` ,`expire_date` ,`amount_param` ,`full_limit_param`)
VALUES ('22', '车车双蛋兑换码第二批', 'com.cheche365.cheche.core.service.giftcode.JsonParamCodeExchange', '0', null, null, NOW(), null, '每个优惠码兑换15张200,300,400...1600元元优惠券,满千减百再多优惠一百', '2015-12-10', '2016-02-29',
 '200;300;400;500;600;700;800;900;1000;1100;1200;1300;1400;1500;1600', '200_1000;300_2000;400_3000;500_4000;600_5000;700_6000;800_7000;900_8000;1000_9000;1100_10000;1200_11000;1300_12000;1400_13000;1500_14000;1600_15000');

INSERT INTO `gift_code_exchange_way` (`id`, `name`, `exchange_class`, `common_exchange`, `amount`, `operator`, `create_time`, `update_time`, `description`,`effective_date` ,`expire_date` ,`amount_param` ,`full_limit_param`)
VALUES ('23', '车车双蛋兑换码第三批', 'com.cheche365.cheche.core.service.giftcode.JsonParamCodeExchange', '0', null, null, NOW(), null, '每个优惠码兑换15张200,300,400...1600元元优惠券,满千减百再多优惠一百', '2015-12-10', '2016-02-29',
 '200;300;400;500;600;700;800;900;1000;1100;1200;1300;1400;1500;1600', '200_1000;300_2000;400_3000;500_4000;600_5000;700_6000;800_7000;900_8000;1000_9000;1100_10000;1200_11000;1300_12000;1400_13000;1500_14000;1600_15000');
