update `gift_type`
set `description` = '满千送百元壕礼&下单可抽奖'
where `id` = 21;
