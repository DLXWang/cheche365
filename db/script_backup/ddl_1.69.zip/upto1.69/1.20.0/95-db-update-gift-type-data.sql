update `gift_type`
set `name` = '壕礼'
where `id` = 21;
