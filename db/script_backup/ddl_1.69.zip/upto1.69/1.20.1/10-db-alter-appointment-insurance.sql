ALTER TABLE `appointment_insurance` ADD COLUMN source_channel BIGINT(20) DEFAULT NULL ;
ALTER TABLE `appointment_insurance` ADD CONSTRAINT `FK_APPOINTMENT_INSURANCE_REF_CHANNEL_IDX` FOREIGN KEY (`source_channel`) REFERENCES `channel` (`id`);
