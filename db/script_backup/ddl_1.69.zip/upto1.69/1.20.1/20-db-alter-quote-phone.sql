UPDATE user_img ui SET ui.source_channel = 9;

UPDATE appointment_insurance ai SET ai.source_channel = 9;