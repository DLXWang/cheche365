insert into `schedule_condition` (`id`, `name`, `marketing`) values('15','提交订单', null);
insert into `schedule_condition` (`id`, `name`, `marketing`) values('16','支付宝请求验证码', null);
insert into `schedule_condition` (`id`, `name`, `marketing`) values('17','支付宝提交订单', null);
insert into `schedule_condition` (`id`, `name`, `marketing`) values('18','支付宝支付成功', null);
insert into `schedule_condition` (`id`, `name`, `marketing`) values('19','支付宝订单取消', null);
insert into `schedule_condition` (`id`, `name`, `marketing`) values('20','支付宝下单送礼活动', null);
