INSERT INTO message_variable(id, code, name, type, placeholder, length, parameter, model_class, model_method)
VALUES(31, '${Amount}', '金额', 'number', '请输入金额值', 18, 'amount', null, null);
