insert into gift_type (id,name,description)values(22,'移动电源','移动电源');
insert into gift_type (id,name,description)values(23,'移动硬盘','移动硬盘');
