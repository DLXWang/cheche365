update gift_type
set use_type=3, category=6, category_name = '实物礼品'
where id = 22 or id = 23;

