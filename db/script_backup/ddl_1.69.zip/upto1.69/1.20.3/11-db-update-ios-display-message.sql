-- 修正上一个脚本 修改IOS中间广告图片
UPDATE `ios_display_message` SET `icon_url` = '20151209/promotion/l10.jpg' WHERE `id` = 9;
UPDATE `ios_display_message` SET `icon_url` = '20151209/promotion/r10.jpg' WHERE `id` = 10;
UPDATE `ios_display_message` SET `icon_url` = '20151209/promotion/r20.jpg' WHERE `id` = 11;

-- 修正上一个脚本 修改E保养和抽奖图片
UPDATE `ios_display_message` SET `icon_url` = '20151209/activity/emaintain.jpg' WHERE `name` = '车车车险冬日关怀，免费送保养！' AND `message_type` IN (1, 3);
UPDATE `ios_display_message` SET `icon_url` = '20151209/activity/lottery.jpg' WHERE `name` = '年底大促双重壕礼，100%中奖！' AND `message_type` IN (1, 3);
