-- 修改支付宝相关模板电话号码
update sms_template
set content = REPLACE(content, '4000150999', '400-072-1056')
where content is not null and zucp_code in ('PENDING_034','PENDING_035','PENDING_036','PENDING_037','PENDING_038');

update sms_template
set content = REPLACE(content, '4000-150-999', '400-072-1056')
where content is not null and zucp_code in ('PENDING_034','PENDING_035','PENDING_036','PENDING_037','PENDING_038');
