CREATE TABLE `marketing_area` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `marketing_id` bigint(20) NOT NULL COMMENT '活动编号',
  `area_id` bigint(20) NOT NULL COMMENT '地区编号',
  PRIMARY KEY (`id`),
  CONSTRAINT `marketing_area_ibfk_1` FOREIGN KEY (`marketing_id`) REFERENCES `marketing` (`id`),
  CONSTRAINT `marketing_area_ibfk_2` FOREIGN KEY (`area_id`) REFERENCES `area` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
