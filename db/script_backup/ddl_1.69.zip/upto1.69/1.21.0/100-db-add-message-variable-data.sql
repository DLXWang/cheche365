INSERT INTO message_variable(id, code, name, type, placeholder, length, parameter, model_class, model_method)
VALUES(32, '${MPaymentLink}', 'M站支付链接', 'varchar', '请输入M站支付链接', 100, 'mpl', null, null);
