update sms_template
set content = '尊敬的车车用户您好，车车客服已为您生成订单，请点击${MPaymentLink} 查看并支付，订单的有效期为8小时。如需详询请致电4000150999。感谢您对车车的支持'
where content is not null and zucp_code = 'PENDING_022';
