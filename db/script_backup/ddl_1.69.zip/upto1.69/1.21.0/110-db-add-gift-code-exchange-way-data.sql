INSERT INTO `gift_code_exchange_way` (`id`, `name`, `exchange_class`, `common_exchange`, `amount`, `operator`, `create_time`, `update_time`, `description`,`effective_date` ,`expire_date` ,`amount_param` ,`full_limit_param`)
VALUES ('25', '爱聚苏宁公益活动兑换码', 'com.cheche365.cheche.core.service.giftcode.JsonParamCodeExchange', '0', '300.00', null, NOW(), null, '每个优惠码兑换一张300元优惠券', '2015-12-23', '2016-05-01', '300.00', null);

INSERT INTO `gift_code_exchange_way` (`id`, `name`, `exchange_class`, `common_exchange`, `amount`, `operator`, `create_time`, `update_time`, `description`,`effective_date` ,`expire_date` ,`amount_param` ,`full_limit_param`)
VALUES ('26', 'WeMedia圣诞元旦活动兑换码', 'com.cheche365.cheche.core.service.giftcode.JsonParamCodeExchange', '0', '200.00', null, NOW(), null, '每个优惠码兑换一张200元优惠券', '2015-12-25', '2016-12-31', '200.00', null);
