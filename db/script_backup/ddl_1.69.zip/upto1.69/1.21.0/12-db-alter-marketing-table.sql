ALTER TABLE `marketing`
MODIFY COLUMN `short_name`  varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '优惠活动简称' AFTER `quote_support`;
