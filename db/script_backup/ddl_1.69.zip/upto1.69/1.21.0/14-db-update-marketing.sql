update `marketing` set quote_support = 0 , short_name = '中秋节活动' where id =  11 ;
update `marketing` set quote_support = 0  WHERE  marketing_type = 'web';
