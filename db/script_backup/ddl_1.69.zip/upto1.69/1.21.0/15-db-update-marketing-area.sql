DELETE from marketing_area WHERE marketing_id in(12,13,14,19,21);
