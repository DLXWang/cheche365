ALTER TABLE `quote_record` ADD COLUMN `changed_car` tinyint(1) DEFAULT 0 COMMENT '是否留牌换车';
