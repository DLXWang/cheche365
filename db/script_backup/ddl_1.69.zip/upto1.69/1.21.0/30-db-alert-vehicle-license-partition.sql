/* 添加id和code为主键 */
alter table vehicle_license change id id  bigint(20);
alter table vehicle_license drop primary key;
alter table vehicle_license add column code  bigint(20)  default 0;
alter table vehicle_license change id id bigint(20)  auto_increment ,add primary key (id,code);
drop index idx_vehicle_license_licenseno on vehicle_license ;
create index idx_no_code_owner  on vehicle_license  (license_plate_no, owner,code);


/* 创建触发器 */
drop trigger if exists vehicle_insert_trigger;
create trigger vehicle_insert_trigger
before
insert on vehicle_license
for each row begin
set new.code =
  (select id
   from
     (select t1.short_code ,
             t2.id
      from
        (select min(id) newid ,
                        short_code
         from area
         where length(short_code)>0
           and active = 1
         group by short_code
         order by newid) as t1
      left outer join
        (select *
         from area
         where type=1
           or type=2) as t2 on substr(convert(t1.newid,char),1,2)=substr(convert(t2.id,char),1,2)
      order by t2.id) as tab2
   where tab2.short_code = substr(new.license_plate_no,1,1)
     or tab2.short_code = substr(new.license_plate_no,1,2)); 
end;



/* code列更新为相应的省id */
update vehicle_license t1 ,
  ( select shortcode.newid,
           shortcode.city_code ,
           vl.*
   from vehicle_license vl
   inner join
     ( select min(id) newid ,
                      short_code ,
                      city_code
      from area
      where length(short_code)>0
        and active = 1
        and type=2
      group by short_code
      order by newid) as shortcode on substr(vl.license_plate_no,1,1)= shortcode.short_code ) as t2
set t1.code=t2.newid
where t1.id=t2.id;


update vehicle_license t1 ,
  ( select t2.id cid,
                 t1.*
   from
     ( select shortcode.newid,
              vl.*
      from vehicle_license vl
      inner join
        ( select min(id) newid ,
                         short_code
         from area
         where length(short_code)>0
           and active = 1
         group by short_code
         order by newid) as shortcode on substr(vl.license_plate_no,1,2)= shortcode.short_code ) as t1
   left outer join
     ( select *
      from area
      where type=1) as t2 on substr(convert(t1.newid,char),1,2)=substr(convert(t2.id,char),1,2) ) as t2
set t1.code=t2.cid
where t1.id=t2.id;




/* 创建分区 */
alter table vehicle_license
partition by list(code) (
    partition p0 values in (110000),
    partition p1 values in (120000),
    partition p2 values in (130000),
    partition p3 values in (140000),
    partition p4 values in (150000),
    partition p5 values in (210000),
    partition p6 values in (220000),
    partition p7 values in (230000),
    partition p8 values in (310000),
    partition p9 values in (320000),
    partition p10 values in (330000),
    partition p11 values in (340000),
    partition p12 values in (350000),
    partition p13 values in (360000),
    partition p14 values in (370000),
    partition p15 values in (410000),
    partition p16 values in (420000),
    partition p17 values in (430000),
    partition p18 values in (440000),
    partition p19 values in (450000),
    partition p20 values in (460000),
    partition p21 values in (500000),
    partition p22 values in (510000),
    partition p23 values in (520000),
    partition p24 values in (530000),
    partition p25 values in (540000),
    partition p26 values in (610000),
    partition p27 values in (620000),
    partition p28 values in (630000),
    partition p29 values in (640000),
    partition p30 values in (650000),
	partition other values in (0)
);


