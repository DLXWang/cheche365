alter table quote_record add column iop_total decimal(18,2) default 0.0;
update quote_record set iop_total = (ifnull(damage_iop, 0) + ifnull(driver_iop,0) + ifnull(passenger_iop,0) + ifnull(third_party_iop,0) + ifnull(theft_iop,0) + ifnull(scratch_iop,0) + ifnull(engine_iop,0));
