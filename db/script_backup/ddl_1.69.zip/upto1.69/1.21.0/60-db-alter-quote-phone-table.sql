-- 电话报价添加source_channel字段
ALTER TABLE quote_phone ADD COLUMN `source_channel` bigint(20);

-- 修改电话报价表source_channel默认值
UPDATE quote_phone qp SET qp.source_channel = 9;

-- 电话报价表添加source_channel索引
ALTER TABLE quote_phone ADD INDEX `FK_QUOTE_PHONE_REF_CHANNEL_IDX`(`source_channel`) USING BTREE;

-- 电话标价表添加source_channel外键
ALTER TABLE quote_phone ADD CONSTRAINT `FK_QUOTE_PHONE_REF_CHANNEL_IDX` FOREIGN KEY (`source_channel`) REFERENCES `channel` (`id`); 
