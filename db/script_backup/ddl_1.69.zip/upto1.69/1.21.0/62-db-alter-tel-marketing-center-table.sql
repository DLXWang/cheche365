-- 为电销表电话添加索引
ALTER TABLE tel_marketing_center ADD INDEX `INDEX_TEL_MARKETING_CENTER_REF_MOBILE` (`mobile`) USING BTREE;

-- 电销中心数据来源添加支付宝来源数据
INSERT INTO `tel_marketing_center_source` (`id`, `description`, `name`) VALUES ('90', '支付宝主动预约', '支付宝主动预约');
INSERT INTO `tel_marketing_center_source` (`id`, `description`, `name`) VALUES ('91', '支付宝未支付订单用户', '支付宝未支付订单用户');
