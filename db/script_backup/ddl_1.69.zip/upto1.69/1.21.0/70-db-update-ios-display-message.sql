UPDATE `ios_display_message` SET `url` = '/marketing/m/201512002/index.html', `icon_url` = '20151209/promotion/l11.jpg', `name` = '年底大促双重壕礼，100%中奖！', `title` = '年底大促双重壕礼，100%中奖！' WHERE id = 9;
