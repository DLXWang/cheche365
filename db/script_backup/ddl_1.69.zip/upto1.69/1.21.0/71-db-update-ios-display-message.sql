-- 下架冬日关怀
UPDATE `ios_display_message` SET `enable` = 0 WHERE `message_type` IN (1, 3) AND `name` = '车车车险冬日关怀，免费送保养！';
