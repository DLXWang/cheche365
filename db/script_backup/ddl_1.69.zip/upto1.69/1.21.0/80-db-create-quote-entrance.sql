CREATE TABLE `quote_entrance` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `entrance` VARCHAR(100) DEFAULT NULL COMMENT '拍照报价入口',
  `description` VARCHAR(2000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IDX_U_QUOTE_ENTRANCE_RF_ENTRANCE` (`entrance`)
) ENGINE=INNODB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `quote_entrance` (`id`, `entrance`, `description`) VALUES('1','quote','报价');
INSERT INTO `quote_entrance` (`id`, `entrance`, `description`) VALUES('2','appointment','预约');
