ALTER TABLE `user_img` ADD COLUMN `quote_entrance` BIGINT(20) NULL COMMENT '拍照报价入口';
ALTER TABLE `user_img` ADD CONSTRAINT `FK_USER_IMG_REF_QUOTE_ENTRANCE` FOREIGN KEY (`quote_entrance`) REFERENCES `quote_entrance`(`id`);
UPDATE `user_img` SET `quote_entrance` = 1;
