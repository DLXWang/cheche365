INSERT INTO source_type(id, name, description) VALUES(4, '兑换码', '兑换码');

-- 将gift_code列数据合并至source(新增兑换码来源 source_type=4)
update gift
set source_type = 4, source=gift_code
where gift_code is not null;
