INSERT INTO `channel` VALUES ('12', '出单中心支付宝通道', 'ORDER_CENTER_ALIPAY');
