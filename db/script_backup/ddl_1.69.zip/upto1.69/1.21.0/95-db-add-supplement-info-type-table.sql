CREATE TABLE IF NOT EXISTS `supplement_info_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(2000) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO supplement_info_type VALUES(1, '日期选择器', '日期选择器');
INSERT INTO supplement_info_type VALUES(2, '单选列表', '单选列表');
INSERT INTO supplement_info_type VALUES(3, '文本域', '文本域');
