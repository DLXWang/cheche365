CREATE TABLE IF NOT EXISTS `quote_supplement_info` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `auto` BIGINT(20) NOT NULL,
  `quote_record` BIGINT(20) NOT NULL,
  `supplement_info_type` BIGINT(20) NOT NULL,
  `field_path` VARCHAR(200) NULL,
  `field_type` VARCHAR(50) NULL,
  `field_label` VARCHAR(200) NULL,
  `validation_type` VARCHAR(200) NULL,
  `value` VARCHAR(200) NULL,
  `create_time` DATETIME NULL,
  `update_time` DATETIME NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `FK_SUPPLEMENT_INFO_REF_AUTO` FOREIGN KEY (`auto`) REFERENCES `auto` (`id`),
  CONSTRAINT `FK_SUPPLEMENT_INFO_REF_QUOTE_RECORD` FOREIGN KEY (`quote_record`) REFERENCES `quote_record` (`id`),
  CONSTRAINT `FK_SUPPLEMENT_INFO_REF_SUPPLEMENT_INFO_TYPE` FOREIGN KEY (`supplement_info_type`) REFERENCES `supplement_info_type` (`id`)
  )ENGINE=InnoDB DEFAULT CHARSET=utf8;
