ALTER TABLE `marketing_area`
ADD UNIQUE INDEX `marketing_unique_index` (`marketing_id`, `area_id`) ;
