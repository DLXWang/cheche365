-- 修改电话报价表source_channel默认值
UPDATE quote_phone qp SET qp.source_channel = 11 where qp.source_channel not in (11,12);
