UPDATE `purchase_order` SET type=1;
