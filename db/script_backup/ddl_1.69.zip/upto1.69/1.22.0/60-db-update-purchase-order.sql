ALTER TABLE `purchase_order` DROP COLUMN `audit`;
