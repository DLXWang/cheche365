-- WechatUserInfo
create index idx_w_user_qrcode on wechat_user_info(qrcode);
create index idx_w_user_qrcode_channel on wechat_user_info(qrcode_channel);
