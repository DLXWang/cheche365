-- 删除扫描数等于0和关注数小于等于0的数据
delete from qrcode_statistics where scan_count = 0 and subscribe_count <= 0;
-- -----------------------------------------------------------------------------------------------------------
-- 相同名称的二维码渠道标记为禁用
update qrcode_channel qc1
left join (
select distinct qs.qrcode_channel from qrcode_statistics qs
union
select distinct qrcode_channel from wechat_user_info where qrcode_channel is not null
) tmp1
on qc1.id = tmp1.qrcode_channel, qrcode_channel qc2
set qc1.DISABLE = 1, qc1.comment = CONCAT(qc1.comment, ',disable the same name channel'), qc1.update_time = now()
where tmp1.qrcode_channel is null
and qc1.id > qc2.id
and qc1.name = qc2.name
and qc1.disable = 0 and qc2.disable = 0
and qc1.wechat_qrcode = qc2.wechat_qrcode;
-- -----------------------------------------------------------------------------------------------------------
-- 将二维码相同的复用二维码渠道置为禁用
update qrcode_channel
set disable = 1,
comment = CONCAT(comment, ', set disable is true for the reuse qrcode channel'),
update_time = now()
where id in (
1003, 1002, 1001, 1000, 999, 998, 997, 996, 995, 994,
993, 992, 991, 990, 989, 988, 987, 986, 985, 984,
983, 982, 981, 980, 979, 978, 977, 976, 975, 974,
973, 972, 971, 970, 969, 968, 967, 966, 965, 964,
963, 962, 961, 960, 959, 958,
1723, 1152, 1151, 1150, 1149, 1148, 1147, 1146, 1145, 1144,
1143, 1142, 1141, 1140, 1139, 1138, 1137, 1136
);
-- -----------------------------------------------------------------------------------------------------------
-- 恢复复用二维码渠道统计数据
update qrcode_statistics set qrcode_channel = 2086 where qrcode_channel = 1003;
update qrcode_statistics set qrcode_channel = 2087 where qrcode_channel = 1002;
update qrcode_statistics set qrcode_channel = 2088 where qrcode_channel = 1001;
update qrcode_statistics set qrcode_channel = 2089 where qrcode_channel = 1000;
update qrcode_statistics set qrcode_channel = 2090 where qrcode_channel = 999;
update qrcode_statistics set qrcode_channel = 2091 where qrcode_channel = 998;
update qrcode_statistics set qrcode_channel = 2092 where qrcode_channel = 997;
update qrcode_statistics set qrcode_channel = 2093 where qrcode_channel = 996;
update qrcode_statistics set qrcode_channel = 2094 where qrcode_channel = 995;
update qrcode_statistics set qrcode_channel = 2095 where qrcode_channel = 994;
update qrcode_statistics set qrcode_channel = 2096 where qrcode_channel = 993;
update qrcode_statistics set qrcode_channel = 2097 where qrcode_channel = 992;
update qrcode_statistics set qrcode_channel = 2098 where qrcode_channel = 991;
update qrcode_statistics set qrcode_channel = 2099 where qrcode_channel = 990;
update qrcode_statistics set qrcode_channel = 2100 where qrcode_channel = 989;
update qrcode_statistics set qrcode_channel = 2101 where qrcode_channel = 988;
update qrcode_statistics set qrcode_channel = 2102 where qrcode_channel = 987;
update qrcode_statistics set qrcode_channel = 2103 where qrcode_channel = 986;
update qrcode_statistics set qrcode_channel = 2104 where qrcode_channel = 985;
update qrcode_statistics set qrcode_channel = 2105 where qrcode_channel = 984;
update qrcode_statistics set qrcode_channel = 2106 where qrcode_channel = 983;
update qrcode_statistics set qrcode_channel = 2107 where qrcode_channel = 982;
update qrcode_statistics set qrcode_channel = 2108 where qrcode_channel = 981;
update qrcode_statistics set qrcode_channel = 2109 where qrcode_channel = 980;
update qrcode_statistics set qrcode_channel = 2110 where qrcode_channel = 979;
update qrcode_statistics set qrcode_channel = 2111 where qrcode_channel = 978;
update qrcode_statistics set qrcode_channel = 2112 where qrcode_channel = 977;
update qrcode_statistics set qrcode_channel = 2113 where qrcode_channel = 976;
update qrcode_statistics set qrcode_channel = 2114 where qrcode_channel = 975;
update qrcode_statistics set qrcode_channel = 2115 where qrcode_channel = 974;
update qrcode_statistics set qrcode_channel = 2116 where qrcode_channel = 973;
update qrcode_statistics set qrcode_channel = 2117 where qrcode_channel = 972;
update qrcode_statistics set qrcode_channel = 2118 where qrcode_channel = 971;
update qrcode_statistics set qrcode_channel = 2119 where qrcode_channel = 970;
update qrcode_statistics set qrcode_channel = 2120 where qrcode_channel = 969;
update qrcode_statistics set qrcode_channel = 2121 where qrcode_channel = 968;
update qrcode_statistics set qrcode_channel = 2122 where qrcode_channel = 967;
update qrcode_statistics set qrcode_channel = 2123 where qrcode_channel = 966;
update qrcode_statistics set qrcode_channel = 2124 where qrcode_channel = 965;
update qrcode_statistics set qrcode_channel = 2125 where qrcode_channel = 964;
update qrcode_statistics set qrcode_channel = 2126 where qrcode_channel = 963;
update qrcode_statistics set qrcode_channel = 2127 where qrcode_channel = 962;
update qrcode_statistics set qrcode_channel = 2128 where qrcode_channel = 961;
update qrcode_statistics set qrcode_channel = 2129 where qrcode_channel = 960;
update qrcode_statistics set qrcode_channel = 2130 where qrcode_channel = 959;
update qrcode_statistics set qrcode_channel = 2131 where qrcode_channel = 958;

-- 恢复复用二维码渠道统计数据，设置微信用户渠道号
update wechat_user_info set qrcode_channel = 2086 where qrcode_channel = 1003;
update wechat_user_info set qrcode_channel = 2087 where qrcode_channel = 1002;
update wechat_user_info set qrcode_channel = 2088 where qrcode_channel = 1001;
update wechat_user_info set qrcode_channel = 2089 where qrcode_channel = 1000;
update wechat_user_info set qrcode_channel = 2090 where qrcode_channel = 999;
update wechat_user_info set qrcode_channel = 2091 where qrcode_channel = 998;
update wechat_user_info set qrcode_channel = 2092 where qrcode_channel = 997;
update wechat_user_info set qrcode_channel = 2093 where qrcode_channel = 996;
update wechat_user_info set qrcode_channel = 2094 where qrcode_channel = 995;
update wechat_user_info set qrcode_channel = 2095 where qrcode_channel = 994;
update wechat_user_info set qrcode_channel = 2096 where qrcode_channel = 993;
update wechat_user_info set qrcode_channel = 2097 where qrcode_channel = 992;
update wechat_user_info set qrcode_channel = 2098 where qrcode_channel = 991;
update wechat_user_info set qrcode_channel = 2099 where qrcode_channel = 990;
update wechat_user_info set qrcode_channel = 2100 where qrcode_channel = 989;
update wechat_user_info set qrcode_channel = 2101 where qrcode_channel = 988;
update wechat_user_info set qrcode_channel = 2102 where qrcode_channel = 987;
update wechat_user_info set qrcode_channel = 2103 where qrcode_channel = 986;
update wechat_user_info set qrcode_channel = 2104 where qrcode_channel = 985;
update wechat_user_info set qrcode_channel = 2105 where qrcode_channel = 984;
update wechat_user_info set qrcode_channel = 2106 where qrcode_channel = 983;
update wechat_user_info set qrcode_channel = 2107 where qrcode_channel = 982;
update wechat_user_info set qrcode_channel = 2108 where qrcode_channel = 981;
update wechat_user_info set qrcode_channel = 2109 where qrcode_channel = 980;
update wechat_user_info set qrcode_channel = 2110 where qrcode_channel = 979;
update wechat_user_info set qrcode_channel = 2111 where qrcode_channel = 978;
update wechat_user_info set qrcode_channel = 2112 where qrcode_channel = 977;
update wechat_user_info set qrcode_channel = 2113 where qrcode_channel = 976;
update wechat_user_info set qrcode_channel = 2114 where qrcode_channel = 975;
update wechat_user_info set qrcode_channel = 2115 where qrcode_channel = 974;
update wechat_user_info set qrcode_channel = 2116 where qrcode_channel = 973;
update wechat_user_info set qrcode_channel = 2117 where qrcode_channel = 972;
update wechat_user_info set qrcode_channel = 2118 where qrcode_channel = 971;
update wechat_user_info set qrcode_channel = 2119 where qrcode_channel = 970;
update wechat_user_info set qrcode_channel = 2120 where qrcode_channel = 969;
update wechat_user_info set qrcode_channel = 2121 where qrcode_channel = 968;
update wechat_user_info set qrcode_channel = 2122 where qrcode_channel = 967;
update wechat_user_info set qrcode_channel = 2123 where qrcode_channel = 966;
update wechat_user_info set qrcode_channel = 2124 where qrcode_channel = 965;
update wechat_user_info set qrcode_channel = 2125 where qrcode_channel = 964;
update wechat_user_info set qrcode_channel = 2126 where qrcode_channel = 963;
update wechat_user_info set qrcode_channel = 2127 where qrcode_channel = 962;
update wechat_user_info set qrcode_channel = 2128 where qrcode_channel = 961;
update wechat_user_info set qrcode_channel = 2129 where qrcode_channel = 960;
update wechat_user_info set qrcode_channel = 2130 where qrcode_channel = 959;
update wechat_user_info set qrcode_channel = 2131 where qrcode_channel = 958;
-- -------------------------------------------------------------------------------------------------------------
-- 修改微信用户的二维码渠道id
update wechat_user_info wu,
(select id, scene_id from wechat_qrcode where scene_id > 10000) wq,
(select id, wechat_qrcode from qrcode_channel where disable = 0) qc
set wu.qrcode_channel = qc.id
where wu.qrcode_channel > 10000 and wu.unsubscribed = 0
and wu.qrcode = wq.id
and wu.qrcode_channel = wq.scene_id
and wq.id = qc.wechat_qrcode;
-- -----------------------------------------------------------------------------------------------------------
-- 删除相同渠道和日期的统计数据
delete qs1
from qrcode_statistics qs1,
(
select *
from qrcode_statistics
group by qrcode_channel, statistics_time, scan_count, subscribe_count
having count(*) > 1
) qs2
where qs1.id <> qs2.id
and qs1.qrcode_channel = qs2.qrcode_channel
and qs1.statistics_time = qs2.statistics_time
and qs1.scan_count = qs2.scan_count
and qs1.subscribe_count = qs2.subscribe_count;

delete qs1
from qrcode_statistics qs1,
(
select max(id) as id, qrcode_channel, statistics_time, subscribe_count
from qrcode_statistics
group by qrcode_channel, statistics_time, subscribe_count
having count(*) > 1
) qs2
where qs1.id <> qs2.id
and qs1.qrcode_channel = qs2.qrcode_channel
and qs1.statistics_time = qs2.statistics_time
and qs1.subscribe_count = qs2.subscribe_count;

delete qs1
from qrcode_statistics qs1,
(
select min(id) as id, qrcode_channel, statistics_time, scan_count
from qrcode_statistics
group by qrcode_channel, statistics_time, scan_count
having count(*) > 1
) qs2
where qs1.id <> qs2.id
and qs1.qrcode_channel = qs2.qrcode_channel
and qs1.statistics_time = qs2.statistics_time
and qs1.scan_count = qs2.scan_count;

delete qs1
from qrcode_statistics qs1, qrcode_statistics qs2
where qs1.id <> qs2.id
and qs1.qrcode_channel = qs2.qrcode_channel
and qs1.statistics_time = qs2.statistics_time
and qs1.scan_count = 3 * qs2.scan_count
and qs1.subscribe_count = 3 * qs2.subscribe_count;

delete qs1
from qrcode_statistics qs1,
(
select min(id) as id, qrcode_channel, statistics_time
from qrcode_statistics
group by qrcode_channel, statistics_time
having count(*) > 1
) qs2
where qs1.id <> qs2.id
and qs1.qrcode_channel = qs2.qrcode_channel
and qs1.statistics_time = qs2.statistics_time;
-- -----------------------------------------------------------------------------------------------------------
-- 修改部分二维码渠道统计数大于微信用户数
-- 737 统计数为1，用户数为0
delete from qrcode_statistics where id = 22 and qrcode_channel = 737;
-- 785 统计数为1，用户数为0
update qrcode_statistics set subscribe_count = 0 where id = 1627 and qrcode_channel = 785;
-- 940 统计数为1，用户数为0
delete from qrcode_statistics where id = 75 and qrcode_channel = 940;
-- 2074 统计数为1，用户数为0
delete from qrcode_statistics where id = 12165 and qrcode_channel = 2074;
-- 758 统计数为1，用户数为0
delete from qrcode_statistics where id = 160408 and qrcode_channel = 758;
-- 931 统计数为1，用户数为0
delete from qrcode_statistics where id = 61 and qrcode_channel = 931;
-- 789 统计数为1，用户数为0
delete from qrcode_statistics where id = 598 and qrcode_channel = 789;
-- 2064 统计数为1，用户数为0
update qrcode_statistics set subscribe_count = 0 where id = 2410 and qrcode_channel = 2064;
-- 729 统计数为1，用户数为0
delete from qrcode_statistics where id = 1222 and qrcode_channel = 729;
-- 731 统计数为2，用户数为1
delete from qrcode_statistics where id = 13 and qrcode_channel = 731;
-- 724 统计数为3，用户数为2
update qrcode_statistics set subscribe_count = 1 where id = 14035 and qrcode_channel = 724;
-- 736 统计数为3，用户数为0
delete from qrcode_statistics where id = 17 and qrcode_channel = 736;
delete from qrcode_statistics where id = 19 and qrcode_channel = 736;
-- 741 统计数为3，用户数为1
update qrcode_statistics set subscribe_count = 0 where id = 32 and qrcode_channel = 741;
-- 763 统计数为3，用户数为0
delete from qrcode_statistics where id = 473 and qrcode_channel = 763;
delete from qrcode_statistics where id = 474 and qrcode_channel = 763;
-- 806 统计数为3，用户数为2
update qrcode_statistics set subscribe_count = 1, statistics_time = '2015-08-16 07:00:00' where id = 1710 and qrcode_channel = 806;
update qrcode_statistics set subscribe_count = 1, statistics_time = '2015-08-20 11:00:00' where id = 93602 and qrcode_channel = 806;
-- 732 统计数为3，用户数为2
update qrcode_statistics set subscribe_count = 1 where id = 49372 and qrcode_channel = 732;
-- 751 统计数为3，用户数为2
update qrcode_statistics set subscribe_count = 1 where id = 14380 and qrcode_channel = 751;
-- 775 统计数为3，用户数为0
delete from qrcode_statistics where id = 545 and qrcode_channel = 775;
delete from qrcode_statistics where id = 12756 and qrcode_channel = 775;
-- 937 统计数为3，用户数为2
update qrcode_statistics set subscribe_count = 1 where id = 730 and qrcode_channel = 937;
-- 2075 统计数为4，用户数为1(1970-01-01 08:00:00)
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2075, '1970-01-01 08:00:00', 0, 1);
delete from qrcode_statistics where id = 24062 and qrcode_channel = 2075;
update qrcode_statistics set subscribe_count = 0 where id = 39657 and qrcode_channel = 2075;
-- 2127 统计数为4，用户数为2
delete from qrcode_statistics where id = 323392 and qrcode_channel = 2127;
update qrcode_statistics set subscribe_count = 1 where id = 6620 and qrcode_channel = 2127;
-- 727 统计数为6，用户数为3
delete from qrcode_statistics where id = 76983 and qrcode_channel = 727;
update qrcode_statistics set subscribe_count = 1 where id = 176 and qrcode_channel = 727;
-- 932 统计数为6，用户数为3
update qrcode_statistics set subscribe_count = 1 where id = 63 and qrcode_channel = 932;
update qrcode_statistics set subscribe_count = 1 where id = 670 and qrcode_channel = 932;
update qrcode_statistics set subscribe_count = 1 where id = 1784 and qrcode_channel = 932;
-- 2106 统计数为6，用户数为5
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2106, '2015-10-30 11:00:00', 0, 1);
delete from qrcode_statistics where id = 323561 and qrcode_channel = 2106;
update qrcode_statistics set subscribe_count = 1 where id = 323769 and qrcode_channel = 2106;
-- 2098 统计数为8，用户数为7
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2098, '2015-10-23 12:00:00', 0, 1);
delete from qrcode_statistics where id = 323467 and qrcode_channel = 2098;
delete from qrcode_statistics where id = 323899 and qrcode_channel = 2098;
-- 2112 统计数为11，用户数为10
delete from qrcode_statistics where id = 5063 and qrcode_channel = 2112;
-- 110 统计数为12，用户数为11
delete from qrcode_statistics where id = 324158 and qrcode_channel = 110;
-- 2118 统计数为14，用户数为8
delete from qrcode_statistics where id = 82 and qrcode_channel = 2118;
update qrcode_statistics set subscribe_count = 1 where id = 83 and qrcode_channel = 2118;
update qrcode_statistics set subscribe_count = 2 where id = 84 and qrcode_channel = 2118;
update qrcode_statistics set subscribe_count = 2 where id = 880 and qrcode_channel = 2118;
-- 2109 统计数为15，用户数为14
delete from qrcode_statistics where id = 911 and qrcode_channel = 2109;
delete from qrcode_statistics where id = 287263 and qrcode_channel = 2109;
update qrcode_statistics set subscribe_count = 1, statistics_time = '2015-10-30 18:00:00' where id = 287565 and qrcode_channel = 2109;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2109, '2015-11-12 09:00:00', 0, 1);
-- 2097 统计数为19，用户数为18
update qrcode_statistics set subscribe_count = 1 where id = 323469 and qrcode_channel = 2097;
-- 2090 统计数为20，用户数为18
update qrcode_statistics set subscribe_count = 1 where id = 89 and qrcode_channel = 2090;
update qrcode_statistics set subscribe_count = 1 where id = 287146 and qrcode_channel = 2090;
update qrcode_statistics set subscribe_count = 2 where id = 287217 and qrcode_channel = 2090;
update qrcode_statistics set subscribe_count = 4 where id = 323310 and qrcode_channel = 2090;
-- 788 统计数为20，用户数为8
update qrcode_statistics set subscribe_count = 1 where id = 1632 and qrcode_channel = 788;
delete from qrcode_statistics where id = 3077 and qrcode_channel = 788;
update qrcode_statistics set subscribe_count = 1 where id = 4581 and qrcode_channel = 788;
update qrcode_statistics set subscribe_count = 1 where id = 4583 and qrcode_channel = 788;
update qrcode_statistics set subscribe_count = 1 where id = 7796 and qrcode_channel = 788;
delete from qrcode_statistics where id = 7799 and qrcode_channel = 788;
update qrcode_statistics set subscribe_count = 1 where id = 12827 and qrcode_channel = 788;
update qrcode_statistics set subscribe_count = 1 where id = 12828 and qrcode_channel = 788;
delete from qrcode_statistics where id = 36084 and qrcode_channel = 788;
-- 764 统计数为1，用户数为0
delete from qrcode_statistics where id = 57 and qrcode_channel = 764;
-- 2137 统计数为1，用户数为0
delete from qrcode_statistics where id = 323495 and qrcode_channel = 2137;
-- 728 统计数为2，用户数为1
delete from qrcode_statistics where id = 5653 and qrcode_channel = 728;
delete from qrcode_statistics where id = 325483 and qrcode_channel = 728;
-- 705 统计数为2，用户数为1
delete from qrcode_statistics where id = 39993 and qrcode_channel = 705;
-- 728 统计数为2，用户数为1
delete from qrcode_statistics where id = 325483 and qrcode_channel = 728;
-- 2113 统计数为3，用户数为1
update qrcode_statistics set subscribe_count = 0 where id = 323987 and qrcode_channel = 2113;
update qrcode_statistics set statistics_time = '2015-10-31 11:00:00' where id = 324676 and qrcode_channel = 2113;
delete from qrcode_statistics where id = 325564 and qrcode_channel = 2113;
-- 2094 统计数为4，用户数为3
update qrcode_statistics set subscribe_count = 0 where id = 324151 and qrcode_channel = 2094;
-- 2098 统计数为7，用户数为6
delete from qrcode_statistics where id = 323885 and qrcode_channel = 2098;
-- 2153	统计数为8，用户数为5
delete from qrcode_statistics where id = 325295 and qrcode_channel = 2153;
update qrcode_statistics set subscribe_count = 3 where id = 325301 and qrcode_channel = 2153;
-- 2163	统计数为8，用户数为5
delete from qrcode_statistics where id = 324436 and qrcode_channel = 2163;
update qrcode_statistics set subscribe_count = 0 where id = 324671 and qrcode_channel = 2163;
update qrcode_statistics set subscribe_count = 0 where id = 325340 and qrcode_channel = 2163;
-- 2171	统计数为9，用户数为5
update qrcode_statistics set subscribe_count = 3 where id = 324531 and qrcode_channel = 2171;
-- 2100	统计数为10，用户数为7
delete from qrcode_statistics where id = 323805 and qrcode_channel = 2100;
update qrcode_statistics set subscribe_count = 3 where id = 323970 and qrcode_channel = 2100;
delete from qrcode_statistics where id = 323982 and qrcode_channel = 2100;
-- 2105	统计数为14，用户数为12
delete from qrcode_statistics where id = 326470 and qrcode_channel = 2105;
update qrcode_statistics set subscribe_count = 2 where id = 326471 and qrcode_channel = 2105;
-- 2107	统计数为14，用户数为13
delete from qrcode_statistics where id = 323651 and qrcode_channel = 2107;
-- 110	统计数为15，用户数为13
delete from qrcode_statistics where id = 324866 and qrcode_channel = 110;
delete from qrcode_statistics where id = 325166 and qrcode_channel = 110;
-- 2109	统计数为15，用户数为14
delete from qrcode_statistics where id = 323318 and qrcode_channel = 2109;
-- 2102	统计数为16，用户数为15
update qrcode_statistics set subscribe_count = 4 where id = 323902 and qrcode_channel = 2102;
-- 2226	统计数为16，用户数为15
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2226, '1970-01-01 08:00:00', 0, 4);
update qrcode_statistics set subscribe_count = 0 where id = 325751 and qrcode_channel = 2226;
update qrcode_statistics set subscribe_count = 1 where id = 325807 and qrcode_channel = 2226;
delete from qrcode_statistics where id = 325815 and qrcode_channel = 2226;
update qrcode_statistics set subscribe_count = 0 where id = 325870 and qrcode_channel = 2226;
delete from qrcode_statistics where id = 326197 and qrcode_channel = 2226;
-- 2125	统计数为17，用户数为15
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2125, '2015-10-22 19:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 1 where id = 323874 and qrcode_channel = 2125;
update qrcode_statistics set subscribe_count = 2 where id = 323903 and qrcode_channel = 2125;
update qrcode_statistics set subscribe_count = 1 where id = 324694 and qrcode_channel = 2125;
-- 2230	统计数为17，用户数为15
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2230, '1970-01-01 08:00:00', 0, 1);
delete from qrcode_statistics where id = 325554 and qrcode_channel = 2230;
update qrcode_statistics set subscribe_count = 3 where id = 325570 and qrcode_channel = 2230;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2230, '2015-12-04 16:00:00', 0, 1);
delete from qrcode_statistics where id = 325778 and qrcode_channel = 2230;
-- 2087	统计数为18，用户数为16
update qrcode_statistics set subscribe_count = 1 where id = 326486 and qrcode_channel = 2087;
update qrcode_statistics set subscribe_count = 1 where id = 325300 and qrcode_channel = 2087;
-- 2090	统计数为18，用户数为17
update qrcode_statistics set subscribe_count = 3 where id = 287365 and qrcode_channel = 2090;
-- 2097	统计数为18，用户数为16
update qrcode_statistics set subscribe_count = 1 where id = 323526 and qrcode_channel = 2097;
update qrcode_statistics set subscribe_count = 1 where id = 323806 and qrcode_channel = 2097;
-- 2162	统计数为21，用户数为19
update qrcode_statistics set subscribe_count = 2 where id = 324679 and qrcode_channel = 2162;
delete from qrcode_statistics where id = 324682 and qrcode_channel = 2162;
-- 933	统计数为22，用户数为11
update qrcode_statistics set subscribe_count = 1 where id = 1802 and qrcode_channel = 933;
update qrcode_statistics set subscribe_count = 1 where id = 4779 and qrcode_channel = 933;
update qrcode_statistics set subscribe_count = 1 where id = 6368 and qrcode_channel = 933;
update qrcode_statistics set subscribe_count = 1 where id = 11293 and qrcode_channel = 933;
delete from qrcode_statistics where id = 13040 and qrcode_channel = 933;
update qrcode_statistics set subscribe_count = 2 where id = 16843 and qrcode_channel = 933;
update qrcode_statistics set subscribe_count = 1 where id = 18864 and qrcode_channel = 933;
-- 2091	统计数为23，用户数为20
update qrcode_statistics set subscribe_count = 5 where id = 323320 and qrcode_channel = 2091;
update qrcode_statistics set subscribe_count = 1 where id = 323328 and qrcode_channel = 2091;
delete from qrcode_statistics where id = 323417 and qrcode_channel = 2091;
-- 2164	统计数为23，用户数为21
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2164, '1970-01-01 08:00:00', 0, 2);
update qrcode_statistics set subscribe_count = 2 where id = 324404 and qrcode_channel = 2164;
delete from qrcode_statistics where id = 324653 and qrcode_channel = 2164;
delete from qrcode_statistics where id = 325716 and qrcode_channel = 2164;
delete from qrcode_statistics where id = 325855 and qrcode_channel = 2164;
-- 2103	统计数为24，用户数为22
update qrcode_statistics set subscribe_count = 2 where id = 326474 and qrcode_channel = 2103;
update qrcode_statistics set subscribe_count = 1 where id = 323535 and qrcode_channel = 2103;
-- 2123	统计数为26，用户数为23
delete from qrcode_statistics where id = 323847 and qrcode_channel = 2123;
delete from qrcode_statistics where id = 323945 and qrcode_channel = 2123;
delete from qrcode_statistics where id = 324534 and qrcode_channel = 2123;
-- 2177	统计数为26，用户数为24
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2177, '1970-01-01 08:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2177, '2015-11-04 16:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 3 where id = 326076 and qrcode_channel = 2177;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2177, '2015-12-11 00:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 2 where id = 326090 and qrcode_channel = 2177;
update qrcode_statistics set subscribe_count = 6 where id = 326095 and qrcode_channel = 2177;
delete from qrcode_statistics where id = 326104 and qrcode_channel = 2177;
-- 2096	统计数为27，用户数为24
update qrcode_statistics set subscribe_count = 6 where id = 323463 and qrcode_channel = 2096;
delete from qrcode_statistics where id = 323737 and qrcode_channel = 2096;
-- 2209	统计数为31，用户数为29
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2209, '1970-01-01 08:00:00', 0, 1);
delete from qrcode_statistics where id = 325106 and qrcode_channel = 2209;
delete from qrcode_statistics where id = 325184 and qrcode_channel = 2209;
delete from qrcode_statistics where id = 326313 and qrcode_channel = 2209;
-- 2095	统计数为32，用户数为23
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2095, '2015-11-04 10:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 4 where id = 323485 and qrcode_channel = 2095;
update qrcode_statistics set subscribe_count = 1 where id = 323458 and qrcode_channel = 2095;
delete from qrcode_statistics where id = 323475 and qrcode_channel = 2095;
update qrcode_statistics set subscribe_count = 5 where id = 323591 and qrcode_channel = 2095;
update qrcode_statistics set subscribe_count = 2 where id = 323596 and qrcode_channel = 2095;
update qrcode_statistics set subscribe_count = 4 where id = 323605 and qrcode_channel = 2095;
update qrcode_statistics set subscribe_count = 1 where id = 323612 and qrcode_channel = 2095;
update qrcode_statistics set subscribe_count = 1 where id = 323630 and qrcode_channel = 2095;
delete from qrcode_statistics where id = 323799 and qrcode_channel = 2095;
update qrcode_statistics set subscribe_count = 0 where id = 323801 and qrcode_channel = 2095;
-- 2231	统计数为32，用户数为31
delete from qrcode_statistics where id = 325853 and qrcode_channel = 2231;
-- 938	统计数为35，用户数为13
delete from qrcode_statistics where id = 1862 and qrcode_channel = 938;
update qrcode_statistics set subscribe_count = 2 where id = 3332 and qrcode_channel = 938;
delete from qrcode_statistics where id = 3350 and qrcode_channel = 938;
update qrcode_statistics set subscribe_count = 1 where id = 4862 and qrcode_channel = 938;
update qrcode_statistics set subscribe_count = 1 where id = 6430 and qrcode_channel = 938;
update qrcode_statistics set subscribe_count = 1 where id = 6444 and qrcode_channel = 938;
update qrcode_statistics set subscribe_count = 1 where id = 14934 and qrcode_channel = 938;
update qrcode_statistics set subscribe_count = 1 where id = 18952 and qrcode_channel = 938;
update qrcode_statistics set subscribe_count = 1 where id = 34198 and qrcode_channel = 938;
delete from qrcode_statistics where id = 38732 and qrcode_channel = 938;
update qrcode_statistics set subscribe_count = 1 where id = 38736 and qrcode_channel = 938;
update qrcode_statistics set subscribe_count = 1 where id = 41041 and qrcode_channel = 938;
delete from qrcode_statistics where id = 64490 and qrcode_channel = 938;
update qrcode_statistics set subscribe_count = 1 where id = 77884 and qrcode_channel = 938;
-- 2088	统计数为38，用户数为32
update qrcode_statistics set subscribe_count = 2 where id = 323325 and qrcode_channel = 2088;
update qrcode_statistics set subscribe_count = 3 where id = 323332 and qrcode_channel = 2088;
update qrcode_statistics set subscribe_count = 1 where id = 324968 and qrcode_channel = 2088;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2088, '2015-11-26 12:00:00', 0, 1);
delete from qrcode_statistics where id = 325285 and qrcode_channel = 2088;
delete from qrcode_statistics where id = 325287 and qrcode_channel = 2088;
delete from qrcode_statistics where id = 325302 and qrcode_channel = 2088;
-- 2124	统计数为39，用户数为34
update qrcode_statistics set subscribe_count = 3 where id = 326114 and qrcode_channel = 2124;
update qrcode_statistics set subscribe_count = 7 where id = 326416 and qrcode_channel = 2124;
update qrcode_statistics set subscribe_count = 5 where id = 326422 and qrcode_channel = 2124;
update qrcode_statistics set statistics_time = '2015-12-15 13:00:00' where id = 326431 and qrcode_channel = 2124;
-- 2122	统计数为41，用户数为33
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2122, '1970-01-01 08:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2122, '2015-10-30 07:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2122, '2015-10-30 17:00:00', 0, 1);
delete from qrcode_statistics where id = 323396 and qrcode_channel = 2122;
delete from qrcode_statistics where id = 323408 and qrcode_channel = 2122;
delete from qrcode_statistics where id = 323455 and qrcode_channel = 2122;
update qrcode_statistics set subscribe_count = 2 where id = 324012 and qrcode_channel = 2122;
update qrcode_statistics set subscribe_count = 4 where id = 324023 and qrcode_channel = 2122;
delete from qrcode_statistics where id = 324126 and qrcode_channel = 2122;
delete from qrcode_statistics where id = 324552 and qrcode_channel = 2122;
delete from qrcode_statistics where id = 324698 and qrcode_channel = 2122;
delete from qrcode_statistics where id = 324967 and qrcode_channel = 2122;
-- 2110	统计数为44，用户数为38 截止到2015-12-06
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2110, '1970-01-01 08:00:00', 0, 1);
delete from qrcode_statistics where id = 323900 and qrcode_channel = 2110;
update qrcode_statistics set subscribe_count = 2 where id = 324287 and qrcode_channel = 2110;
update qrcode_statistics set subscribe_count = 2 where id = 324700 and qrcode_channel = 2110;
delete from qrcode_statistics where id = 324766 and qrcode_channel = 2110;
update qrcode_statistics set subscribe_count = 3 where id = 325729 and qrcode_channel = 2110;
-- 2133	统计数为47，用户数为37 截止到2015-11-29
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2133, '1970-01-01 08:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2133, '2015-10-10 16:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 1 where id = 323090 and qrcode_channel = 2133;
delete from qrcode_statistics where id = 323093 and qrcode_channel = 2133;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2133, '2015-11-06 14:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 0 where id = 323099 and qrcode_channel = 2133;
update qrcode_statistics set subscribe_count = 0 where id = 323098 and qrcode_channel = 2133;
update qrcode_statistics set subscribe_count = 0 where id = 323752 and qrcode_channel = 2133;
update qrcode_statistics set subscribe_count = 1 where id = 323754 and qrcode_channel = 2133;
delete from qrcode_statistics where id = 323819 and qrcode_channel = 2133;
delete from qrcode_statistics where id = 323908 and qrcode_channel = 2133;
update qrcode_statistics set subscribe_count = 0 where id = 324004 and qrcode_channel = 2133;
delete from qrcode_statistics where id = 324143 and qrcode_channel = 2133;
delete from qrcode_statistics where id = 324274 and qrcode_channel = 2133;
update qrcode_statistics set subscribe_count = 1 where id = 324306 and qrcode_channel = 2133;
-- 2214	统计数为50，用户数为48 截止到2015-12-14
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2214, '1970-01-01 08:00:00', 0, 6);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2214, '2015-11-28 19:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2214, '2015-12-01 18:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 1 where id = 325461 and qrcode_channel = 2214;
update qrcode_statistics set subscribe_count = 0 where id = 325475 and qrcode_channel = 2214;
update qrcode_statistics set subscribe_count = 0 where id = 325542 and qrcode_channel = 2214;
update qrcode_statistics set subscribe_count = 7 where id = 325553 and qrcode_channel = 2214;
update qrcode_statistics set subscribe_count = 7 where id = 325568 and qrcode_channel = 2214;
delete from qrcode_statistics where id = 326204 and qrcode_channel = 2214;
update qrcode_statistics set subscribe_count = 5 where id = 326308 and qrcode_channel = 2214;
-- 2104	统计数为73，用户数为65 截止到2015-12-14
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2104, '1970-01-01 08:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2104, '2015-11-09 15:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 1 where id = 323697 and qrcode_channel = 2104;
delete from qrcode_statistics where id = 323844 and qrcode_channel = 2104;
update qrcode_statistics set subscribe_count = 6 where id = 324341 and qrcode_channel = 2104;
update qrcode_statistics set subscribe_count = 4 where id = 324370 and qrcode_channel = 2104;
update qrcode_statistics set subscribe_count = 0 where id = 324398 and qrcode_channel = 2104;
delete from qrcode_statistics where id = 324578 and qrcode_channel = 2104;
delete from qrcode_statistics where id = 325279 and qrcode_channel = 2104;
update qrcode_statistics set subscribe_count = 1 where id = 325367 and qrcode_channel = 2104;
delete from qrcode_statistics where id = 325499 and qrcode_channel = 2104;
delete from qrcode_statistics where id = 325529 and qrcode_channel = 2104;
delete from qrcode_statistics where id = 325722 and qrcode_channel = 2104;
update qrcode_statistics set statistics_time = '2015-12-10 17:00:00' where id = 325894 and qrcode_channel = 2104;
-- 105	统计数为93，用户数为65 截止到2015-12-02
update qrcode_statistics set subscribe_count = 3 where id = 156577 and qrcode_channel = 105;
update qrcode_statistics set subscribe_count = 1 where id = 156578 and qrcode_channel = 105;
delete from qrcode_statistics where id = 156579 and qrcode_channel = 105;
update qrcode_statistics set subscribe_count = 2 where id = 156580 and qrcode_channel = 105;
update qrcode_statistics set subscribe_count = 1 where id = 156581 and qrcode_channel = 105;
update qrcode_statistics set subscribe_count = 2 where id = 156582 and qrcode_channel = 105;
update qrcode_statistics set subscribe_count = 2 where id = 159425 and qrcode_channel = 105;
update qrcode_statistics set subscribe_count = 2 where id = 159426 and qrcode_channel = 105;
update qrcode_statistics set subscribe_count = 3 where id = 159427 and qrcode_channel = 105;
update qrcode_statistics set subscribe_count = 2 where id = 159428 and qrcode_channel = 105;
delete from qrcode_statistics where id = 159429 and qrcode_channel = 105;
update qrcode_statistics set subscribe_count = 1 where id = 159432 and qrcode_channel = 105;
update qrcode_statistics set subscribe_count = 1 where id = 162287 and qrcode_channel = 105;
update qrcode_statistics set subscribe_count = 1 where id = 162288 and qrcode_channel = 105;
update qrcode_statistics set subscribe_count = 2 where id = 162290 and qrcode_channel = 105;
update qrcode_statistics set subscribe_count = 1 where id = 162291 and qrcode_channel = 105;
update qrcode_statistics set subscribe_count = 2 where id = 162292 and qrcode_channel = 105;
update qrcode_statistics set subscribe_count = 2 where id = 162293 and qrcode_channel = 105;
delete from qrcode_statistics where id = 162294 and qrcode_channel = 105;
update qrcode_statistics set subscribe_count = 2 where id = 165189 and qrcode_channel = 105;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (105, '2015-10-27 09:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (105, '2015-10-27 10:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (105, '2015-10-27 12:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (105, '2015-10-27 14:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (105, '2015-10-27 16:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (105, '2015-10-27 17:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (105, '2015-10-28 10:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (105, '2015-10-28 11:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (105, '2015-10-28 12:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (105, '2015-10-28 14:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (105, '2015-10-29 12:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (105, '2015-10-29 13:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (105, '2015-10-30 10:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (105, '2015-10-30 12:00:00', 0, 1);
delete from qrcode_statistics where id = 324457 and qrcode_channel = 105;
delete from qrcode_statistics where id = 325217 and qrcode_channel = 105;
delete from qrcode_statistics where id = 325238 and qrcode_channel = 105;
-- 2154	统计数为94，用户数为84 截止到2015-12-14
update qrcode_statistics set subscribe_count = 9 where id = 326219 and qrcode_channel = 2154;
update qrcode_statistics set subscribe_count = 10 where id = 326214 and qrcode_channel = 2154;
update qrcode_statistics set subscribe_count = 10 where id = 326221 and qrcode_channel = 2154;
update qrcode_statistics set subscribe_count = 7 where id = 326220 and qrcode_channel = 2154;
update qrcode_statistics set subscribe_count = 7 where id = 326215 and qrcode_channel = 2154;
update qrcode_statistics set subscribe_count = 21 where id = 326223 and qrcode_channel = 2154;
update qrcode_statistics set subscribe_count = 9 where id = 326217 and qrcode_channel = 2154;
update qrcode_statistics set subscribe_count = 9 where id = 326224 and qrcode_channel = 2154;
-- 2126	统计数为97，用户数为87 截止到2015-12-07
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2126, '1970-01-01 08:00:00', 0, 5);
update qrcode_statistics set subscribe_count = 4 where id = 324039 and qrcode_channel = 2126;
update qrcode_statistics set subscribe_count = 2 where id = 324073 and qrcode_channel = 2126;
update qrcode_statistics set subscribe_count = 1 where id = 324076 and qrcode_channel = 2126;
update qrcode_statistics set statistics_time = '2015-11-13 16:00:00' where id = 324101 and qrcode_channel = 2126;
update qrcode_statistics set statistics_time = '2015-11-13 17:00:00' where id = 324110 and qrcode_channel = 2126;
delete from qrcode_statistics where id = 324138 and qrcode_channel = 2126;
update qrcode_statistics set subscribe_count = 1 where id = 324170 and qrcode_channel = 2126;
update qrcode_statistics set subscribe_count = 1 where id = 324182 and qrcode_channel = 2126;
delete from qrcode_statistics where id = 324195 and qrcode_channel = 2126;
update qrcode_statistics set subscribe_count = 2 where id = 324208 and qrcode_channel = 2126;
delete from qrcode_statistics where id = 324320 and qrcode_channel = 2126;
delete from qrcode_statistics where id = 324353 and qrcode_channel = 2126;
delete from qrcode_statistics where id = 324364 and qrcode_channel = 2126;
update qrcode_statistics set subscribe_count = 1 where id = 324368 and qrcode_channel = 2126;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2126, '2015-11-18 12:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 1 where id = 324604 and qrcode_channel = 2126;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2126, '2015-11-20 16:00:00', 0, 1);
delete from qrcode_statistics where id = 324747 and qrcode_channel = 2126;
delete from qrcode_statistics where id = 324902 and qrcode_channel = 2126;
-- 2129	统计数为98，用户数为89 截止到2015-12-15
delete from qrcode_statistics where id = 323161 and qrcode_channel = 2129;
update qrcode_statistics set subscribe_count = 2 where id = 323159 and qrcode_channel = 2129;
update qrcode_statistics set statistics_time = '2015-11-05 15:00:00', subscribe_count = 1 where id = 323189 and qrcode_channel = 2129;
update qrcode_statistics set subscribe_count = 1 where id = 323581 and qrcode_channel = 2129;
update qrcode_statistics set subscribe_count = 0 where id = 323646 and qrcode_channel = 2129;
delete from qrcode_statistics where id = 323738 and qrcode_channel = 2129;
delete from qrcode_statistics where id = 323741 and qrcode_channel = 2129;
delete from qrcode_statistics where id = 323755 and qrcode_channel = 2129;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2129, '2015-11-11 16:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 2 where id = 324022 and qrcode_channel = 2129;
update qrcode_statistics set subscribe_count = 2 where id = 324107 and qrcode_channel = 2129;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2129, '2015-12-04 15:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 1 where id = 324558 and qrcode_channel = 2129;
-- 2139	统计数为106，用户数为99 截止到2015-12-11
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2139, '1970-01-01 08:00:00', 0, 9);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2139, '2015-10-30 11:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2139, '2015-11-01 04:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2139, '2015-11-20 19:00:00', 0, 2);
update qrcode_statistics set subscribe_count = 1 where id = 325121 and qrcode_channel = 2139;
update qrcode_statistics set subscribe_count = 0 where id = 325371 and qrcode_channel = 2139;
delete from qrcode_statistics where id = 325401 and qrcode_channel = 2139;
delete from qrcode_statistics where id = 325481 and qrcode_channel = 2139;
delete from qrcode_statistics where id = 325494 and qrcode_channel = 2139;
delete from qrcode_statistics where id = 325519 and qrcode_channel = 2139;
delete from qrcode_statistics where id = 325531 and qrcode_channel = 2139;
delete from qrcode_statistics where id = 325556 and qrcode_channel = 2139;
delete from qrcode_statistics where id = 325718 and qrcode_channel = 2139;
delete from qrcode_statistics where id = 325946 and qrcode_channel = 2139;
delete from qrcode_statistics where id = 325948 and qrcode_channel = 2139;
delete from qrcode_statistics where id = 326021 and qrcode_channel = 2139;
update qrcode_statistics set subscribe_count = 5 where id = 326063 and qrcode_channel = 2139;
delete from qrcode_statistics where id = 326108 and qrcode_channel = 2139;
-- 2130	统计数为112，用户数为96 截止到2015-12-15
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2130, '2015-08-18 21:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 0 where id = 323335 and qrcode_channel = 2130;
delete from qrcode_statistics where id = 323376 and qrcode_channel = 2130;
update qrcode_statistics set subscribe_count = 2 where id = 323356 and qrcode_channel = 2130;
delete from qrcode_statistics where id = 323383 and qrcode_channel = 2130;
update qrcode_statistics set subscribe_count = 3 where id = 323387 and qrcode_channel = 2130;
update qrcode_statistics set subscribe_count = 2 where id = 323385 and qrcode_channel = 2130;
update qrcode_statistics set subscribe_count = 0 where id = 323377 and qrcode_channel = 2130;
update qrcode_statistics set subscribe_count = 1 where id = 323380 and qrcode_channel = 2130;
update qrcode_statistics set subscribe_count = 2 where id = 323404 and qrcode_channel = 2130;
delete from qrcode_statistics where id = 323393 and qrcode_channel = 2130;
update qrcode_statistics set subscribe_count = 2 where id = 323510 and qrcode_channel = 2130;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2130, '2015-11-08 12:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 5 where id = 323574 and qrcode_channel = 2130;
update qrcode_statistics set subscribe_count = 4 where id = 323701 and qrcode_channel = 2130;
delete from qrcode_statistics where id = 323716 and qrcode_channel = 2130;
delete from qrcode_statistics where id = 323761 and qrcode_channel = 2130;
delete from qrcode_statistics where id = 323873 and qrcode_channel = 2130;
update qrcode_statistics set subscribe_count = 1 where id = 323911 and qrcode_channel = 2130;
delete from qrcode_statistics where id = 325131 and qrcode_channel = 2130;
-- 117	统计数为144，用户数为77 截止到2015-12-15
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (117, '1970-01-01 08:00:00', 0, 2);
update qrcode_statistics set subscribe_count = 1 where id = 37532 and qrcode_channel = 117;
delete from qrcode_statistics where id = 37533 and qrcode_channel = 117;
update qrcode_statistics set subscribe_count = 1 where id = 37536 and qrcode_channel = 117;
delete from qrcode_statistics where id = 44487 and qrcode_channel = 117;
delete from qrcode_statistics where id = 44488 and qrcode_channel = 117;
update qrcode_statistics set subscribe_count = 1 where id = 44492 and qrcode_channel = 117;
update qrcode_statistics set subscribe_count = 1 where id = 44493 and qrcode_channel = 117;
update qrcode_statistics set subscribe_count = 1 where id = 47374 and qrcode_channel = 117;
update qrcode_statistics set subscribe_count = 1 where id = 47443 and qrcode_channel = 117;
update qrcode_statistics set subscribe_count = 1 where id = 47444 and qrcode_channel = 117;
update qrcode_statistics set subscribe_count = 1 where id = 47462 and qrcode_channel = 117;
delete from qrcode_statistics where id = 47463 and qrcode_channel = 117;
update qrcode_statistics set subscribe_count = 1 where id = 47464 and qrcode_channel = 117;
update qrcode_statistics set subscribe_count = 1 where id = 47466 and qrcode_channel = 117;
update qrcode_statistics set subscribe_count = 1 where id = 47467 and qrcode_channel = 117;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (117, '2015-09-15 16:00:00', 0, 2);
update qrcode_statistics set subscribe_count = 4 where id = 47469 and qrcode_channel = 117;
update qrcode_statistics set subscribe_count = 1 where id = 47484 and qrcode_channel = 117;
delete from qrcode_statistics where id = 47485 and qrcode_channel = 117;
update qrcode_statistics set subscribe_count = 1 where id = 47486 and qrcode_channel = 117;
update qrcode_statistics set subscribe_count = 1 where id = 47487 and qrcode_channel = 117;
update qrcode_statistics set subscribe_count = 1 where id = 47490 and qrcode_channel = 117;
delete from qrcode_statistics where id = 58268 and qrcode_channel = 117;
delete from qrcode_statistics where id = 58285 and qrcode_channel = 117;
delete from qrcode_statistics where id = 58286 and qrcode_channel = 117;
update qrcode_statistics set subscribe_count = 1 where id = 58287 and qrcode_channel = 117;
update qrcode_statistics set subscribe_count = 1 where id = 60756 and qrcode_channel = 117;
update qrcode_statistics set subscribe_count = 1 where id = 60758 and qrcode_channel = 117;
update qrcode_statistics set subscribe_count = 1 where id = 60760 and qrcode_channel = 117;
delete from qrcode_statistics where id = 60761 and qrcode_channel = 117;
delete from qrcode_statistics where id = 63217 and qrcode_channel = 117;
delete from qrcode_statistics where id = 63218 and qrcode_channel = 117;
update qrcode_statistics set subscribe_count = 1 where id = 63234 and qrcode_channel = 117;
update qrcode_statistics set subscribe_count = 1 where id = 63238 and qrcode_channel = 117;
update qrcode_statistics set subscribe_count = 1 where id = 65935 and qrcode_channel = 117;
update qrcode_statistics set subscribe_count = 1 where id = 65938 and qrcode_channel = 117;
update qrcode_statistics set subscribe_count = 1 where id = 65940 and qrcode_channel = 117;
update qrcode_statistics set subscribe_count = 1 where id = 71531 and qrcode_channel = 117;
update qrcode_statistics set subscribe_count = 1 where id = 74106 and qrcode_channel = 117;
update qrcode_statistics set subscribe_count = 1 where id = 81919 and qrcode_channel = 117;
update qrcode_statistics set subscribe_count = 1 where id = 84573 and qrcode_channel = 117;
delete from qrcode_statistics where id = 100758 and qrcode_channel = 117;
update qrcode_statistics set subscribe_count = 1 where id = 117080 and qrcode_channel = 117;
delete from qrcode_statistics where id = 325315 and qrcode_channel = 117;
-- 2131	统计数为153，用户数为132 截止到2015-12-15
delete from qrcode_statistics where id = 837 and qrcode_channel = 2131;
delete from qrcode_statistics where id = 856 and qrcode_channel = 2131;
update qrcode_statistics set subscribe_count = 1 where id = 9836 and qrcode_channel = 2131;
update qrcode_statistics set subscribe_count = 1 where id = 17070 and qrcode_channel = 2131;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2131, '2015-09-12 09:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2131, '2015-10-14 19:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 1 where id = 323352 and qrcode_channel = 2131;
update qrcode_statistics set subscribe_count = 1 where id = 323394 and qrcode_channel = 2131;
delete from qrcode_statistics where id = 323389 and qrcode_channel = 2131;
update qrcode_statistics set statistics_time = '2015-11-08 12:00:00' where id = 323539 and qrcode_channel = 2131;
update qrcode_statistics set statistics_time = '2015-11-08 13:00:00' where id = 323547 and qrcode_channel = 2131;
update qrcode_statistics set subscribe_count = 8 where id = 323683 and qrcode_channel = 2131;
update qrcode_statistics set subscribe_count = 7 where id = 323688 and qrcode_channel = 2131;
update qrcode_statistics set subscribe_count = 3 where id = 323696 and qrcode_channel = 2131;
update qrcode_statistics set subscribe_count = 1 where id = 323706 and qrcode_channel = 2131;
update qrcode_statistics set subscribe_count = 1 where id = 323719 and qrcode_channel = 2131;
update qrcode_statistics set subscribe_count = 1 where id = 323781 and qrcode_channel = 2131;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2131, '2015-11-11 09:00:00', 0, 1);
delete from qrcode_statistics where id = 323975 and qrcode_channel = 2131;
update qrcode_statistics set subscribe_count = 2 where id = 323991 and qrcode_channel = 2131;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2131, '2015-11-12 14:00:00', 0, 1);
delete from qrcode_statistics where id = 324131 and qrcode_channel = 2131;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2131, '2015-11-21 15:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 4 where id = 325146 and qrcode_channel = 2131;
delete from qrcode_statistics where id = 324069 and qrcode_channel = 2131;
-- 2212	统计数为154，用户数为130 截止到2015-12-06
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2212, '2015-07-16 21:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 1 where id = 324845 and qrcode_channel = 2212;
update qrcode_statistics set subscribe_count = 2 where id = 324903 and qrcode_channel = 2212;
delete from qrcode_statistics where id = 324912 and qrcode_channel = 2212;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2212, '2015-11-25 15:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 0 where id = 324937 and qrcode_channel = 2212;
update qrcode_statistics set subscribe_count = 22 where id = 325685 and qrcode_channel = 2212;
update qrcode_statistics set subscribe_count = 14 where id = 325688 and qrcode_channel = 2212;
update qrcode_statistics set subscribe_count = 8 where id = 325705 and qrcode_channel = 2212;
update qrcode_statistics set subscribe_count = 9 where id = 325711 and qrcode_channel = 2212;
update qrcode_statistics set subscribe_count = 6 where id = 325715 and qrcode_channel = 2212;
update qrcode_statistics set subscribe_count = 3 where id = 325772 and qrcode_channel = 2212;
update qrcode_statistics set subscribe_count = 7 where id = 325779 and qrcode_channel = 2212;
-- 111	统计数为182，用户数为174 截止到2015-12-03
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (111, '2015-03-24 18:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (111, '2015-04-27 14:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 2 where id = 162421 and qrcode_channel = 111;
update qrcode_statistics set subscribe_count = 2 where id = 162422 and qrcode_channel = 111;
update qrcode_statistics set subscribe_count = 1 where id = 326561 and qrcode_channel = 111;
update qrcode_statistics set subscribe_count = 6 where id = 326563 and qrcode_channel = 111;
update qrcode_statistics set subscribe_count = 1 where id = 326566 and qrcode_channel = 111;
update qrcode_statistics set subscribe_count = 6 where id = 326580 and qrcode_channel = 111;
delete from qrcode_statistics where id = 324027 and qrcode_channel = 111;
delete from qrcode_statistics where id = 324191 and qrcode_channel = 111;
delete from qrcode_statistics where id = 324253 and qrcode_channel = 111;
delete from qrcode_statistics where id = 325081 and qrcode_channel = 111;
-- 116	统计数为215，用户数为206 截止到2015-12-15
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (116, '1970-01-01 08:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (116, '2015-09-16 08:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 4 where id = 159702 and qrcode_channel = 116;
update qrcode_statistics set subscribe_count = 2 where id = 159703 and qrcode_channel = 116;
update qrcode_statistics set subscribe_count = 2 where id = 162564 and qrcode_channel = 116;
update qrcode_statistics set subscribe_count = 3 where id = 326524 and qrcode_channel = 116;
update qrcode_statistics set subscribe_count = 1 where id = 326535 and qrcode_channel = 116;
update qrcode_statistics set subscribe_count = 2 where id = 326545 and qrcode_channel = 116;
update qrcode_statistics set subscribe_count = 1 where id = 326546 and qrcode_channel = 116;
delete from qrcode_statistics where id = 325399 and qrcode_channel = 116;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (116, '2015-12-02 14:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 8 where id = 325687 and qrcode_channel = 116;
update qrcode_statistics set subscribe_count = 6 where id = 325695 and qrcode_channel = 116;
delete from qrcode_statistics where id = 326043 and qrcode_channel = 116;
delete from qrcode_statistics where id = 320019 and qrcode_channel = 116;
-- 115	统计数为375，用户数为189 截止到2015-11-30
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (115, '1970-01-01 08:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 1 where id = 35222 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 1 where id = 37483 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 1 where id = 39770 and qrcode_channel = 115;
update qrcode_statistics set statistics_time = '2015-09-08 17:00:00', subscribe_count = 1 where id = 37482 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 2 where id = 39788 and qrcode_channel = 115;
delete from qrcode_statistics where id = 39789 and qrcode_channel = 115;
delete from qrcode_statistics where id = 39791 and qrcode_channel = 115;
delete from qrcode_statistics where id = 39793 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 1 where id = 44443 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 1 where id = 47130 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 1 where id = 47131 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 1 where id = 47146 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 5 where id = 47147 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 3 where id = 47148 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 5 where id = 47149 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 3 where id = 47150 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 1 where id = 47151 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 3 where id = 47152 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 4 where id = 47153 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 1 where id = 47154 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 3 where id = 47155 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 1 where id = 47156 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 1 where id = 47170 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 1 where id = 47172 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 4 where id = 47173 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 1 where id = 47175 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 2 where id = 47176 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 3 where id = 47177 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 2 where id = 47178 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 5 where id = 47179 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 5 where id = 47180 and qrcode_channel = 115;
delete from qrcode_statistics where id = 47197 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 1 where id = 47200 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 2 where id = 47201 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 1 where id = 47202 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 2 where id = 47203 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 2 where id = 47204 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 1 where id = 47223 and qrcode_channel = 115;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (115, '2015-09-15 17:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 1 where id = 47242 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 3 where id = 47243 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 3 where id = 47244 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 2 where id = 47245 and qrcode_channel = 115;
update qrcode_statistics set statistics_time = '2015-09-16 15:00:00', subscribe_count = 1 where id = 47246 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 2 where id = 58218 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 2 where id = 58234 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 1 where id = 58235 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 1 where id = 58237 and qrcode_channel = 115;
delete from qrcode_statistics where id = 58240 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 1 where id = 60691 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 1 where id = 60707 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 2 where id = 60708 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 1 where id = 60709 and qrcode_channel = 115;
delete from qrcode_statistics where id = 60710 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 2 where id = 60711 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 1 where id = 60712 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 1 where id = 60713 and qrcode_channel = 115;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (115, '2015-09-18 16:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 2 where id = 63168 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 3 where id = 63184 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 3 where id = 63186 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 2 where id = 63188 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 1 where id = 63189 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 1 where id = 74056 and qrcode_channel = 115;
delete from qrcode_statistics where id = 74057 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 2 where id = 74060 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 3 where id = 76613 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 1 where id = 76614 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 1 where id = 76630 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 1 where id = 76631 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 2 where id = 76633 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 1 where id = 76635 and qrcode_channel = 115;
delete from qrcode_statistics where id = 79206 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 1 where id = 122673 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 1 where id = 125498 and qrcode_channel = 115;
delete from qrcode_statistics where id = 125499 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 1 where id = 156826 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 2 where id = 156827 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 1 where id = 156829 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 1 where id = 162538 and qrcode_channel = 115;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (115, '2015-10-27 09:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (115, '2015-10-27 10:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (115, '2015-10-27 12:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (115, '2015-10-27 14:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (115, '2015-10-27 15:00:00', 0, 5);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (115, '2015-10-27 16:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (115, '2015-10-27 17:00:00', 0, 4);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (115, '2015-10-28 09:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (115, '2015-10-28 11:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (115, '2015-10-28 12:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (115, '2015-10-28 14:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (115, '2015-10-28 15:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (115, '2015-10-28 16:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (115, '2015-10-29 10:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (115, '2015-10-29 15:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (115, '2015-10-30 10:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (115, '2015-10-30 12:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (115, '2015-10-30 13:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (115, '2015-10-30 15:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (115, '2015-10-30 17:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 1 where id = 288411 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 1 where id = 288827 and qrcode_channel = 115;
delete from qrcode_statistics where id = 319975 and qrcode_channel = 115;
delete from qrcode_statistics where id = 289899 and qrcode_channel = 115;
update qrcode_statistics set subscribe_count = 1 where id = 324081 and qrcode_channel = 115;
delete from qrcode_statistics where id = 324235 and qrcode_channel = 115;
delete from qrcode_statistics where id = 324337 and qrcode_channel = 115;
-- 106	统计数为415，用户数为291 截止到2015-12-12
update qrcode_statistics set subscribe_count = 1 where id = 128105 and qrcode_channel = 106;
delete from qrcode_statistics where id = 128106 and qrcode_channel = 106;
update qrcode_statistics set subscribe_count = 1 where id = 128107 and qrcode_channel = 106;
update qrcode_statistics set subscribe_count = 1 where id = 130935 and qrcode_channel = 106;
update qrcode_statistics set subscribe_count = 2 where id = 130951 and qrcode_channel = 106;
update qrcode_statistics set subscribe_count = 3 where id = 130952 and qrcode_channel = 106;
update qrcode_statistics set subscribe_count = 1 where id = 130955 and qrcode_channel = 106;
update qrcode_statistics set subscribe_count = 2 where id = 156600 and qrcode_channel = 106;
update qrcode_statistics set subscribe_count = 9 where id = 156601 and qrcode_channel = 106;
update qrcode_statistics set subscribe_count = 4 where id = 156602 and qrcode_channel = 106;
update qrcode_statistics set subscribe_count = 2 where id = 156603 and qrcode_channel = 106;
update qrcode_statistics set subscribe_count = 5 where id = 156604 and qrcode_channel = 106;
update qrcode_statistics set subscribe_count = 5 where id = 156605 and qrcode_channel = 106;
update qrcode_statistics set subscribe_count = 7 where id = 156606 and qrcode_channel = 106;
update qrcode_statistics set subscribe_count = 7 where id = 156607 and qrcode_channel = 106;
update qrcode_statistics set subscribe_count = 4 where id = 159434 and qrcode_channel = 106;
update qrcode_statistics set subscribe_count = 5 where id = 159435 and qrcode_channel = 106;
update qrcode_statistics set subscribe_count = 1 where id = 159436 and qrcode_channel = 106;
update qrcode_statistics set subscribe_count = 1 where id = 159437 and qrcode_channel = 106;
update qrcode_statistics set subscribe_count = 4 where id = 159450 and qrcode_channel = 106;
update qrcode_statistics set subscribe_count = 7 where id = 159451 and qrcode_channel = 106;
update qrcode_statistics set subscribe_count = 5 where id = 159452 and qrcode_channel = 106;
update qrcode_statistics set subscribe_count = 9 where id = 159453 and qrcode_channel = 106;
update qrcode_statistics set subscribe_count = 4 where id = 159454 and qrcode_channel = 106;
update qrcode_statistics set subscribe_count = 4 where id = 159455 and qrcode_channel = 106;
update qrcode_statistics set subscribe_count = 4 where id = 159456 and qrcode_channel = 106;
update qrcode_statistics set subscribe_count = 2 where id = 159457 and qrcode_channel = 106;
update qrcode_statistics set subscribe_count = 2 where id = 162296 and qrcode_channel = 106;
update qrcode_statistics set subscribe_count = 3 where id = 162297 and qrcode_channel = 106;
update qrcode_statistics set subscribe_count = 1 where id = 162312 and qrcode_channel = 106;
update qrcode_statistics set subscribe_count = 2 where id = 162313 and qrcode_channel = 106;
update qrcode_statistics set subscribe_count = 3 where id = 162314 and qrcode_channel = 106;
update qrcode_statistics set subscribe_count = 2 where id = 162315 and qrcode_channel = 106;
update qrcode_statistics set subscribe_count = 1 where id = 162316 and qrcode_channel = 106;
update qrcode_statistics set subscribe_count = 3 where id = 162317 and qrcode_channel = 106;
update qrcode_statistics set subscribe_count = 4 where id = 162318 and qrcode_channel = 106;
update qrcode_statistics set subscribe_count = 2 where id = 162319 and qrcode_channel = 106;
update qrcode_statistics set subscribe_count = 3 where id = 165219 and qrcode_channel = 106;
update qrcode_statistics set subscribe_count = 3 where id = 169466 and qrcode_channel = 106;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (106, '2015-10-27 08:00:00', 0, 6);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (106, '2015-10-27 09:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (106, '2015-10-27 10:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (106, '2015-10-27 11:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (106, '2015-10-27 12:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (106, '2015-10-27 13:00:00', 0, 5);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (106, '2015-10-27 14:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (106, '2015-10-27 15:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (106, '2015-10-27 16:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (106, '2015-10-27 17:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (106, '2015-10-28 07:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (106, '2015-10-28 08:00:00', 0, 4);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (106, '2015-10-28 09:00:00', 0, 4);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (106, '2015-10-28 10:00:00', 0, 4);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (106, '2015-10-28 11:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (106, '2015-10-28 12:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (106, '2015-10-28 13:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (106, '2015-10-28 14:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (106, '2015-10-28 15:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (106, '2015-10-28 17:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (106, '2015-10-29 08:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (106, '2015-10-29 09:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (106, '2015-10-29 10:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (106, '2015-10-29 12:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (106, '2015-10-29 13:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (106, '2015-10-29 14:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (106, '2015-10-29 15:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (106, '2015-10-29 17:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (106, '2015-10-29 18:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (106, '2015-10-29 19:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (106, '2015-10-30 08:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (106, '2015-10-30 09:00:00', 0, 4);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (106, '2015-10-30 10:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (106, '2015-10-30 12:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (106, '2015-10-30 13:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (106, '2015-10-30 14:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (106, '2015-10-30 16:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (106, '2015-10-30 17:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 6 where id = 287131 and qrcode_channel = 106;
update qrcode_statistics set subscribe_count = 5 where id = 287317 and qrcode_channel = 106;
update qrcode_statistics set subscribe_count = 1 where id = 287958 and qrcode_channel = 106;
delete from qrcode_statistics where id = 319847 and qrcode_channel = 106;
update qrcode_statistics set subscribe_count = 1 where id = 319893 and qrcode_channel = 106;
update qrcode_statistics set subscribe_count = 3 where id = 319882 and qrcode_channel = 106;
update qrcode_statistics set subscribe_count = 5 where id = 319877 and qrcode_channel = 106;
update qrcode_statistics set subscribe_count = 3 where id = 319864 and qrcode_channel = 106;
update qrcode_statistics set subscribe_count = 2 where id = 319902 and qrcode_channel = 106;
update qrcode_statistics set subscribe_count = 2 where id = 319889 and qrcode_channel = 106;
update qrcode_statistics set subscribe_count = 1 where id = 319908 and qrcode_channel = 106;
delete from qrcode_statistics where id = 319956 and qrcode_channel = 106;
delete from qrcode_statistics where id = 319939 and qrcode_channel = 106;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (106, '2015-11-11 13:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 1 where id = 325314 and qrcode_channel = 106;
update qrcode_statistics set subscribe_count = 1 where id = 325424 and qrcode_channel = 106;
update qrcode_statistics set statistics_time = '2015-12-09 16:00:00', subscribe_count = 1 where id = 325944 and qrcode_channel = 106;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (106, '2015-12-12 16:00:00', 0, 1);
-- 107	统计数为440，用户数为269 截止到2015-12-12
update qrcode_statistics set subscribe_count = 1 where id = 122475 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 1 where id = 122477 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 2 where id = 125281 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 1 where id = 125299 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 1 where id = 125300 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 1 where id = 128110 and qrcode_channel = 107;
delete from qrcode_statistics where id = 128109 and qrcode_channel = 107;
delete from qrcode_statistics where id = 128111 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 1 where id = 128125 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 1 where id = 128129 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 2 where id = 128130 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 3 where id = 128131 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 4 where id = 128132 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 1 where id = 130960 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 2 where id = 130961 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 2 where id = 130962 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 3 where id = 130976 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 2 where id = 130977 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 3 where id = 130978 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 5 where id = 130980 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 4 where id = 130981 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 1 where id = 130982 and qrcode_channel = 107;
delete from qrcode_statistics where id = 139526 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 1 where id = 139527 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 2 where id = 139528 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 4 where id = 139529 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 5 where id = 139531 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 2 where id = 139532 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 2 where id = 142376 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 1 where id = 142377 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 2 where id = 142378 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 3 where id = 142381 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 2 where id = 142382 and qrcode_channel = 107;
delete from qrcode_statistics where id = 145232 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 4 where id = 148059 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 5 where id = 148060 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 3 where id = 148061 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 1 where id = 148062 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 1 where id = 148076 and qrcode_channel = 107;
delete from qrcode_statistics where id = 148077 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 2 where id = 148078 and qrcode_channel = 107;
delete from qrcode_statistics where id = 150909 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 2 where id = 150910 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 3 where id = 156626 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 2 where id = 156627 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 6 where id = 156628 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 1 where id = 156629 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 1 where id = 156630 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 3 where id = 156631 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 2 where id = 156632 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 1 where id = 159476 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 7 where id = 159477 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 3 where id = 159478 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 2 where id = 159479 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 3 where id = 159480 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 1 where id = 162338 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 1 where id = 162339 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 6 where id = 162340 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 3 where id = 162341 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 4 where id = 162342 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 2 where id = 162343 and qrcode_channel = 107;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (107, '2015-10-27 09:00:00', 0, 4);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (107, '2015-10-27 10:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (107, '2015-10-27 11:00:00', 0, 5);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (107, '2015-10-27 12:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (107, '2015-10-27 13:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (107, '2015-10-27 14:00:00', 0, 4);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (107, '2015-10-28 09:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (107, '2015-10-28 10:00:00', 0, 4);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (107, '2015-10-28 11:00:00', 0, 5);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (107, '2015-10-28 12:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (107, '2015-10-28 13:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (107, '2015-10-29 09:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (107, '2015-10-29 10:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (107, '2015-10-29 11:00:00', 0, 4);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (107, '2015-10-29 12:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (107, '2015-10-29 13:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (107, '2015-10-29 14:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (107, '2015-10-29 15:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (107, '2015-10-29 16:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (107, '2015-10-29 17:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (107, '2015-10-30 09:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (107, '2015-10-30 10:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (107, '2015-10-30 11:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (107, '2015-10-30 12:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (107, '2015-10-30 13:00:00', 0, 4);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (107, '2015-10-30 15:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (107, '2015-10-30 16:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (107, '2015-10-30 17:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 3 where id = 288314 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 5 where id = 287199 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 3 where id = 287567 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 2 where id = 288480 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 1 where id = 319862 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 4 where id = 319874 and qrcode_channel = 107;
delete from qrcode_statistics where id = 324018 and qrcode_channel = 107;
delete from qrcode_statistics where id = 324155 and qrcode_channel = 107;
delete from qrcode_statistics where id = 324300 and qrcode_channel = 107;
delete from qrcode_statistics where id = 324331 and qrcode_channel = 107;
delete from qrcode_statistics where id = 324446 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 1 where id = 324874 and qrcode_channel = 107;
delete from qrcode_statistics where id = 325245 and qrcode_channel = 107;
update qrcode_statistics set subscribe_count = 2 where id = 325251 and qrcode_channel = 107;
-- 108	统计数为466，用户数为327 截止到2015-12-15
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (108, '1970-01-01 08:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 1 where id = 325251 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 2 where id = 122498 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 4 where id = 122499 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 2 where id = 122501 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 1 where id = 122502 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 2 where id = 122503 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 3 where id = 125323 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 1 where id = 125324 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 1 where id = 125325 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 3 where id = 125326 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 1 where id = 125327 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 2 where id = 125328 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 3 where id = 128134 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 1 where id = 128135 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 2 where id = 128151 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 6 where id = 128152 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 4 where id = 128153 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 3 where id = 128154 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 7 where id = 128155 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 3 where id = 128156 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 1 where id = 131001 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 1 where id = 131003 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 0 where id = 131004 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 6 where id = 131005 and qrcode_channel = 108;
delete from qrcode_statistics where id = 131006 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 2 where id = 131007 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 2 where id = 133850 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 1 where id = 133851 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 5 where id = 133852 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 4 where id = 133853 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 1 where id = 133854 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 1 where id = 133855 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 1 where id = 133856 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 1 where id = 133857 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 2 where id = 136684 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 5 where id = 136685 and qrcode_channel = 108;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (108, '2015-10-16 09:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 1 where id = 136706 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 1 where id = 156652 and qrcode_channel = 108;
delete from qrcode_statistics where id = 156653 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 5 where id = 156654 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 4 where id = 156655 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 3 where id = 156656 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 1 where id = 156657 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 5 where id = 159484 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 3 where id = 159485 and qrcode_channel = 108;
delete from qrcode_statistics where id = 159487 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 2 where id = 159499 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 6 where id = 159501 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 3 where id = 159502 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 4 where id = 159503 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 8 where id = 159504 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 1 where id = 159505 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 3 where id = 159506 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 2 where id = 159507 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 3 where id = 162347 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 1 where id = 162362 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 3 where id = 162363 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 1 where id = 162364 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 1 where id = 162365 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 1 where id = 162366 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 1 where id = 162367 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 2 where id = 162368 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 2 where id = 162369 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 1 where id = 165246 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 2 where id = 165247 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 1 where id = 165248 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 1 where id = 165249 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 1 where id = 165266 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 2 where id = 165268 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 3 where id = 165269 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 3 where id = 169518 and qrcode_channel = 108;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (108, '2015-10-26 17:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (108, '2015-10-27 08:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (108, '2015-10-27 09:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (108, '2015-10-27 10:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (108, '2015-10-27 12:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (108, '2015-10-27 13:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (108, '2015-10-27 15:00:00', 0, 4);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (108, '2015-10-27 16:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (108, '2015-10-27 17:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (108, '2015-10-28 08:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (108, '2015-10-28 09:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (108, '2015-10-28 10:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (108, '2015-10-28 11:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (108, '2015-10-28 12:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (108, '2015-10-28 13:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (108, '2015-10-28 14:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (108, '2015-10-28 15:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (108, '2015-10-28 16:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (108, '2015-10-28 17:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (108, '2015-10-28 20:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (108, '2015-10-29 08:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (108, '2015-10-29 09:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (108, '2015-10-29 10:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (108, '2015-10-29 11:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (108, '2015-10-29 12:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (108, '2015-10-29 13:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (108, '2015-10-29 14:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (108, '2015-10-29 15:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (108, '2015-10-29 16:00:00', 0, 4);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (108, '2015-10-29 17:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (108, '2015-10-30 07:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (108, '2015-10-30 08:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (108, '2015-10-30 09:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (108, '2015-10-30 10:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (108, '2015-10-30 11:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (108, '2015-10-30 12:00:00', 0, 6);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (108, '2015-10-30 13:00:00', 0, 4);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (108, '2015-10-30 14:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (108, '2015-10-30 15:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (108, '2015-10-30 16:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (108, '2015-10-30 18:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 4 where id = 287166 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 3 where id = 287361 and qrcode_channel = 108;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (108, '2015-10-31 14:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 2 where id = 288861 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 1 where id = 319849 and qrcode_channel = 108;
delete from qrcode_statistics where id = 319906 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 2 where id = 319860 and qrcode_channel = 108;
update qrcode_statistics set subscribe_count = 1 where id = 324161 and qrcode_channel = 108;
delete from qrcode_statistics where id = 324246 and qrcode_channel = 108;
delete from qrcode_statistics where id = 325073 and qrcode_channel = 108;
delete from qrcode_statistics where id = 325278 and qrcode_channel = 108;
delete from qrcode_statistics where id = 325449 and qrcode_channel = 108;
-- 120	统计数为602，用户数为359 截止到2015-12-09
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (120, '2015-08-20 17:00:00', 0, 1);
delete from qrcode_statistics where id = 35344 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 4 where id = 35345 and qrcode_channel = 120;
delete from qrcode_statistics where id = 35346 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 2 where id = 35347 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 2 where id = 35348 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 35350 and qrcode_channel = 120;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (120, '2015-09-08 09:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 2 where id = 37607 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 2 where id = 37608 and qrcode_channel = 120;
delete from qrcode_statistics where id = 37609 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 37611 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 2 where id = 44563 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 44566 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 44568 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 47736 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 2 where id = 47756 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 47805 and qrcode_channel = 120;
delete from qrcode_statistics where id = 47823 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 2 where id = 47826 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 47827 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 47829 and qrcode_channel = 120;
delete from qrcode_statistics where id = 47830 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 58343 and qrcode_channel = 120;
delete from qrcode_statistics where id = 58344 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 58365 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 60816 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 60817 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 4 where id = 60832 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 3 where id = 60833 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 5 where id = 60834 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 3 where id = 60835 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 2 where id = 60836 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 5 where id = 60838 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 63308 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 2 where id = 63310 and qrcode_channel = 120;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (120, '2015-09-18 18:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 4 where id = 63334 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 3 where id = 63335 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 3 where id = 63336 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 3 where id = 63337 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 63339 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 4 where id = 63340 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 5 where id = 65992 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 65993 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 65994 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 3 where id = 66007 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 66008 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 6 where id = 66009 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 3 where id = 66010 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 66011 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 2 where id = 66012 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 66013 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 2 where id = 66014 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 66015 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 2 where id = 68842 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 66015 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 2 where id = 68842 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 3 where id = 68843 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 2 where id = 68844 and qrcode_channel = 120;
delete from qrcode_statistics where id = 74180 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 2 where id = 74181 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 2 where id = 74182 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 74183 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 74184 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 2 where id = 74185 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 74186 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 2 where id = 76739 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 3 where id = 76755 and qrcode_channel = 120;
delete from qrcode_statistics where id = 76756 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 76758 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 76759 and qrcode_channel = 120;
delete from qrcode_statistics where id = 76761 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 79329 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 79330 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 4 where id = 79331 and qrcode_channel = 120;
delete from qrcode_statistics where id = 79333 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 2 where id = 79334 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 81972 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 81973 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 81988 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 81989 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 81990 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 3 where id = 81991 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 81992 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 2 where id = 81993 and qrcode_channel = 120;
delete from qrcode_statistics where id = 81994 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 84648 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 84664 and qrcode_channel = 120;
delete from qrcode_statistics where id = 84665 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 84668 and qrcode_channel = 120;
delete from qrcode_statistics where id = 84669 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 84670 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 2 where id = 90043 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 90045 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1, statistics_time = '2015-09-29 17:00:00' where id = 90046 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 3 where id = 92743 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 92745 and qrcode_channel = 120;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (120, '2015-10-09 08:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 2 where id = 117154 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 2 where id = 117159 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 3 where id = 117160 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 119970 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 119971 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 145549 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 145550 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 145554 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 145556 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 145557 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 148404 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 154104 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 159784 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 159800 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 7 where id = 159801 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 4 where id = 159802 and qrcode_channel = 120;
delete from qrcode_statistics where id = 159803 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 159804 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 3 where id = 159805 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 4 where id = 159806 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 3 where id = 159807 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 162647 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 2 where id = 162662 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 3 where id = 162663 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 162667 and qrcode_channel = 120;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (120, '2015-10-27 09:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (120, '2015-10-27 10:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (120, '2015-10-27 11:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (120, '2015-10-29 12:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (120, '2015-10-30 09:00:00', 0, 6);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (120, '2015-10-30 10:00:00', 0, 6);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (120, '2015-10-30 11:00:00', 0, 4);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (120, '2015-10-30 12:00:00', 0, 5);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (120, '2015-10-30 13:00:00', 0, 6);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (120, '2015-10-30 14:00:00', 0, 7);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (120, '2015-10-30 15:00:00', 0, 7);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (120, '2015-10-30 16:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (120, '2015-10-30 17:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 5 where id = 287115 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 5 where id = 287562 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 9 where id = 287566 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 4 where id = 287332 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 6 where id = 288770 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 5 where id = 319984 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 4 where id = 289915 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 1 where id = 324247 and qrcode_channel = 120;
update qrcode_statistics set statistics_time = '2015-11-18 19:00:00' where id = 324545 and qrcode_channel = 120;
update qrcode_statistics set subscribe_count = 0 where id = 325161 and qrcode_channel = 120;
delete from qrcode_statistics where id = 325389 and qrcode_channel = 120;
-- 112	统计数为1114，用户数为622 截止到2015-12-10
update qrcode_statistics set subscribe_count = 1 where id = 119773 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 2 where id = 119774 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 1 where id = 119775 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 0 where id = 119776 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 1 where id = 119777 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 1 where id = 122596 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 5 where id = 122597 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 7 where id = 122598 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 3 where id = 122599 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 3 where id = 122600 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 6 where id = 122601 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 5 where id = 122602 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 10 where id = 122603 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 13 where id = 125405 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 9 where id = 125406 and qrcode_channel = 112;
delete from qrcode_statistics where id = 125407 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 5 where id = 125421 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 5 where id = 125422 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 3 where id = 125423 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 1 where id = 125424 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 6 where id = 125425 and qrcode_channel = 112;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (112, '2015-10-12 13:00:00', 0, 2);
update qrcode_statistics set subscribe_count = 3 where id = 125427 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 7 where id = 125428 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 3 where id = 128234 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 5 where id = 128235 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 6 where id = 128251 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 2 where id = 128252 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 5 where id = 128253 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 3 where id = 128254 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 6 where id = 128255 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 4 where id = 128256 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 3 where id = 128257 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 4 where id = 131084 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 2 where id = 131085 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 1, statistics_time = '2015-10-14 09:00:00' where id = 131100 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 5 where id = 131102 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 6 where id = 131103 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 2 where id = 131104 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 3 where id = 131106 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 6 where id = 131107 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 3 where id = 133935 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 2 where id = 133936 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 1 where id = 136800 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 5 where id = 136801 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 4 where id = 136802 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 2 where id = 136803 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 2 where id = 136804 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 7 where id = 136806 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 2 where id = 136807 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 1 where id = 139651 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 5 where id = 139652 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 5 where id = 139653 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 4 where id = 139654 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 3 where id = 139655 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 3 where id = 139656 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 6 where id = 139657 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 5 where id = 142484 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 3 where id = 142499 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 4 where id = 142500 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 7 where id = 142501 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 4 where id = 142502 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 4 where id = 142503 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 6 where id = 142504 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 7 where id = 142505 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 3 where id = 142506 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 8 where id = 142507 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 8 where id = 145334 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 4 where id = 145335 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 6 where id = 145350 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 3 where id = 145351 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 3 where id = 145352 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 1 where id = 145353 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 2 where id = 145354 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 1 where id = 145355 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 4 where id = 145356 and qrcode_channel = 112;
delete from qrcode_statistics where id = 145357 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 1 where id = 148184 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 4 where id = 148185 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 1 where id = 148186 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 5 where id = 156750 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 2 where id = 156751 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 5 where id = 156752 and qrcode_channel = 112;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (112, '2015-10-23 11:00:00', 0, 5);
update qrcode_statistics set subscribe_count = 2 where id = 156754 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 1 where id = 156755 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 2 where id = 156756 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 4 where id = 156757 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 3 where id = 159585 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 4 where id = 159600 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 8 where id = 159601 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 5 where id = 159603 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 2 where id = 159604 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 3 where id = 159605 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 3 where id = 159606 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 5 where id = 159607 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 3 where id = 162446 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 4 where id = 162462 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 5 where id = 162463 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 3 where id = 162464 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 4 where id = 162465 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 2 where id = 162466 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 2 where id = 162469 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 2 where id = 165347 and qrcode_channel = 112;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (112, '2015-10-27 09:00:00', 0, 4);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (112, '2015-10-27 10:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (112, '2015-10-27 11:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (112, '2015-10-27 12:00:00', 0, 6);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (112, '2015-10-27 13:00:00', 0, 4);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (112, '2015-10-27 14:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (112, '2015-10-27 15:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (112, '2015-10-27 16:00:00', 0, 4);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (112, '2015-10-27 17:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (112, '2015-10-28 08:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (112, '2015-10-28 09:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (112, '2015-10-28 10:00:00', 0, 5);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (112, '2015-10-28 11:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (112, '2015-10-28 12:00:00', 0, 5);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (112, '2015-10-28 13:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (112, '2015-10-28 14:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (112, '2015-10-28 15:00:00', 0, 5);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (112, '2015-10-28 16:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (112, '2015-10-28 17:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (112, '2015-10-29 08:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (112, '2015-10-29 10:00:00', 0, 6);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (112, '2015-10-29 12:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (112, '2015-10-29 13:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (112, '2015-10-29 14:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (112, '2015-10-30 08:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (112, '2015-10-30 09:00:00', 0, 5);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (112, '2015-10-30 10:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (112, '2015-10-30 11:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (112, '2015-10-30 12:00:00', 0, 4);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (112, '2015-10-30 13:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (112, '2015-10-30 14:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (112, '2015-10-30 15:00:00', 0, 2);
update qrcode_statistics set subscribe_count = 3 where id = 319850 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 3 where id = 319895 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 5 where id = 319912 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 3 where id = 319855 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 6 where id = 319869 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 2 where id = 319886 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 2 where id = 319866 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 3 where id = 319878 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 2 where id = 319894 and qrcode_channel = 112;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (112, '2015-11-11 09:00:00', 0, 1);
delete from qrcode_statistics where id = 324250 and qrcode_channel = 112;
delete from qrcode_statistics where id = 324354 and qrcode_channel = 112;
delete from qrcode_statistics where id = 324393 and qrcode_channel = 112;
delete from qrcode_statistics where id = 324418 and qrcode_channel = 112;
delete from qrcode_statistics where id = 324483 and qrcode_channel = 112;
delete from qrcode_statistics where id = 324687 and qrcode_channel = 112;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (112, '2015-11-24 12:00:00', 0, 1);
delete from qrcode_statistics where id = 325088 and qrcode_channel = 112;
update qrcode_statistics set subscribe_count = 2 where id = 325134 and qrcode_channel = 112;
delete from qrcode_statistics where id = 325181 and qrcode_channel = 112;
delete from qrcode_statistics where id = 325836 and qrcode_channel = 112;
-- 114	统计数为1312，用户数为647 截止到2015-12-02
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (114, '1970-01-01 08:00:00', 0, 3);
delete from qrcode_statistics where id = 37439 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 3 where id = 37440 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 37455 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 37456 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 37457 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 37459 and qrcode_channel = 114;
delete from qrcode_statistics where id = 37458 and qrcode_channel = 114;
delete from qrcode_statistics where id = 39746 and qrcode_channel = 114;
delete from qrcode_statistics where id = 39747 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 44413 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 44414 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 44415 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 44418 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 2 where id = 47026 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 3 where id = 47027 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 3 where id = 47028 and qrcode_channel = 114;
delete from qrcode_statistics where id = 47029 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 47031 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 47032 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 47033 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 47035 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 2 where id = 47034 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 47049 and qrcode_channel = 114;
delete from qrcode_statistics where id = 47050 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 3 where id = 47051 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 47052 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 3 where id = 47053 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 47054 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 47055 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 47056 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 47057 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 47058 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 47082 and qrcode_channel = 114;
delete from qrcode_statistics where id = 47083 and qrcode_channel = 114;
delete from qrcode_statistics where id = 47097 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 47098 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 47099 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 47100 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 47101 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 47102 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 2 where id = 47105 and qrcode_channel = 114;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (114, '2015-09-15 17:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 4 where id = 47121 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 3 where id = 47122 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 2 where id = 47123 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 4 where id = 47124 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 7 where id = 47125 and qrcode_channel = 114;
delete from qrcode_statistics where id = 47126 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 2 where id = 47127 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 2 where id = 47128 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 58193 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 3 where id = 58194 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 58196 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 58197 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 3 where id = 58207 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 5 where id = 58208 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 5 where id = 58209 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 5 where id = 58210 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 3 where id = 58213 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 2 where id = 58214 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 3 where id = 58215 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 2 where id = 60665 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 2 where id = 60666 and qrcode_channel = 114;
delete from qrcode_statistics where id = 60667 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 4 where id = 60680 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 12 where id = 60681 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 10 where id = 60682 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 4 where id = 60683 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 3 where id = 60684 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 5 where id = 60685 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 3 where id = 60686 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 4 where id = 60687 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 2 where id = 60688 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 9 where id = 63142 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 2 where id = 63143 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 63144 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 2 where id = 63157 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 8 where id = 63158 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 6 where id = 63159 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 4 where id = 63160 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 3 where id = 63161 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 3 where id = 63162 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 5 where id = 63163 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 6 where id = 63164 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 5 where id = 63165 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 4 where id = 65817 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 2 where id = 71454 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 71455 and qrcode_channel = 114;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (114, '2015-09-22 11:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 1 where id = 74028 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 2 where id = 74029 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 5 where id = 74030 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 2 where id = 74031 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 3 where id = 74032 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 2 where id = 74033 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 5 where id = 74035 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 4 where id = 74036 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 2 where id = 76588 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 5 where id = 76589 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 76606 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 76607 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 2 where id = 76609 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 2 where id = 76610 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 76611 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 0 where id = 79164 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 79178 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 79179 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 79180 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 2 where id = 79181 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 2 where id = 79182 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 2 where id = 79183 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 79184 and qrcode_channel = 114;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (114, '2015-09-25 14:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 3 where id = 79186 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 81822 and qrcode_channel = 114;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (114, '2015-09-25 17:00:00', 0, 3);
update qrcode_statistics set subscribe_count = 4 where id = 81838 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 81839 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 3 where id = 81841 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 81842 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 2 where id = 81843 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 2 where id = 81844 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 2 where id = 84498 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 2 where id = 84513 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 84514 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 2 where id = 84515 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 2 where id = 84516 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 3 where id = 84517 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 84518 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 84519 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 84520 and qrcode_channel = 114;
delete from qrcode_statistics where id = 87176 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 95292 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 5 where id = 95293 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 3 where id = 95294 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 95295 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 95296 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 95298 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 95299 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 3 where id = 117004 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 117007 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 2 where id = 117008 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 117009 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 117010 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 2 where id = 119805 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 3 where id = 119806 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 3 where id = 119821 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 119822 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 2 where id = 119823 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 119824 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 119825 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 4 where id = 119827 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 3 where id = 119828 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 3 where id = 122646 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 5 where id = 122647 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 2 where id = 122648 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 2 where id = 122650 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 2 where id = 122651 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 122652 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 5 where id = 122653 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 3 where id = 125455 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 5 where id = 125456 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 2 where id = 125457 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 2 where id = 125470 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 3 where id = 125471 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 125472 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 2 where id = 125473 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 2 where id = 125477 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 125478 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 2 where id = 128285 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 2 where id = 128301 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 3 where id = 128302 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 4 where id = 128303 and qrcode_channel = 114;
delete from qrcode_statistics where id = 128304 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 131152 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 131155 and qrcode_channel = 114;
delete from qrcode_statistics where id = 133985 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 134005 and qrcode_channel = 114;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (114, '2015-10-15 08:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 3 where id = 156801 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 6 where id = 156802 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 156803 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 3 where id = 156805 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 3 where id = 156806 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 3 where id = 156807 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 2 where id = 159650 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 4 where id = 159651 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 7 where id = 159652 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 11 where id = 159653 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 5 where id = 159654 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 6 where id = 159655 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 4 where id = 159656 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 2 where id = 159657 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 162497 and qrcode_channel = 114;
delete from qrcode_statistics where id = 162513 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 6 where id = 162514 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 3 where id = 162515 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 3 where id = 162516 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 4 where id = 162517 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 2 where id = 162518 and qrcode_channel = 114;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (114, '2015-10-25 16:00:00', 0, 1);
delete from qrcode_statistics where id = 170110 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 0 where id = 170111 and qrcode_channel = 114;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (114, '2015-10-27 09:00:00', 0, 5);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (114, '2015-10-27 10:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (114, '2015-10-27 11:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (114, '2015-10-27 12:00:00', 0, 6);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (114, '2015-10-27 13:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (114, '2015-10-27 14:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (114, '2015-10-28 09:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (114, '2015-10-28 10:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (114, '2015-10-28 11:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (114, '2015-10-28 12:00:00', 0, 6);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (114, '2015-10-28 13:00:00', 0, 4);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (114, '2015-10-28 14:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (114, '2015-10-28 15:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (114, '2015-10-28 17:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (114, '2015-10-29 09:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (114, '2015-10-29 10:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (114, '2015-10-29 11:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (114, '2015-10-29 12:00:00', 0, 4);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (114, '2015-10-29 13:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (114, '2015-10-29 14:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (114, '2015-10-29 15:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (114, '2015-10-29 16:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (114, '2015-10-29 17:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (114, '2015-10-30 08:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (114, '2015-10-30 09:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (114, '2015-10-30 10:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (114, '2015-10-30 11:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (114, '2015-10-30 12:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (114, '2015-10-30 13:00:00', 0, 6);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (114, '2015-10-30 14:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (114, '2015-10-30 15:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (114, '2015-10-30 16:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (114, '2015-10-30 17:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 4 where id = 287152 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 6 where id = 288859 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 6 where id = 287363 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 6 where id = 288836 and qrcode_channel = 114;
delete from qrcode_statistics where id = 288545 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 0 where id = 320018 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 320003 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 1 where id = 320024 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 4 where id = 319993 and qrcode_channel = 114;
update qrcode_statistics set subscribe_count = 3 where id = 320028 and qrcode_channel = 114;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (114, '2015-11-01 14:00:00', 0, 1);
delete from qrcode_statistics where id = 324244 and qrcode_channel = 114;
delete from qrcode_statistics where id = 324283 and qrcode_channel = 114;
delete from qrcode_statistics where id = 325329 and qrcode_channel = 114;
delete from qrcode_statistics where id = 325361 and qrcode_channel = 114;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (114, '2015-12-02 13:00:00', 0, 1);
delete from qrcode_statistics where id = 325489 and qrcode_channel = 114;
-- 113	统计数为1666，用户数为847 截止到2015-12-15
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (113, '1970-01-01 08:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 1 where id = 37437 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 44388 and qrcode_channel = 113;
delete from qrcode_statistics where id = 44390 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 44391 and qrcode_channel = 113;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (113, '2015-09-11 14:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 2 where id = 44393 and qrcode_channel = 113;
delete from qrcode_statistics where id = 46888 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 46889 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 46907 and qrcode_channel = 113;
delete from qrcode_statistics where id = 46912 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 46913 and qrcode_channel = 113;
delete from qrcode_statistics where id = 46928 and qrcode_channel = 113;
delete from qrcode_statistics where id = 46933 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 2 where id = 46934 and qrcode_channel = 113;
delete from qrcode_statistics where id = 46935 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 46936 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 46937 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 46938 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 46955 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 46956 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 46957 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 46958 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 46960 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 3 where id = 46961 and qrcode_channel = 113;
delete from qrcode_statistics where id = 46962 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 46976 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 46978 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 3 where id = 46979 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 4 where id = 46980 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 46981 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 3 where id = 46982 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 46983 and qrcode_channel = 113;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (113, '2015-09-15 16:00:00', 0, 3);
update qrcode_statistics set subscribe_count = 1 where id = 46985 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 4 where id = 47000 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 47002 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 4 where id = 47003 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 7 where id = 47004 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 4 where id = 47005 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 4 where id = 47006 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 5 where id = 47007 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 58167 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 4 where id = 58168 and qrcode_channel = 113;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (113, '2015-09-16 18:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 1 where id = 58182 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 2 where id = 58183 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 2 where id = 58184 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 3 where id = 58186 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 6 where id = 58187 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 58188 and qrcode_channel = 113;
delete from qrcode_statistics where id = 60640 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 5 where id = 60641 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 60655 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 6 where id = 60656 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 5 where id = 60657 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 2 where id = 60658 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 7 where id = 60659 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 3 where id = 60660 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 5 where id = 60661 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 9 where id = 60662 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 60663 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 4 where id = 63117 and qrcode_channel = 113;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (113, '2015-09-18 17:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 1 where id = 63119 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 3 where id = 63134 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 4 where id = 63135 and qrcode_channel = 113;
delete from qrcode_statistics where id = 63136 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 3 where id = 63137 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 63138 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 63139 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 2 where id = 63140 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 65793 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 2 where id = 74005 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 2 where id = 74006 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 74007 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 4 where id = 74008 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 74009 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 2 where id = 74010 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 74011 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 4 where id = 76563 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 2 where id = 76564 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 76565 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 3 where id = 76580 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 12 where id = 76583 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 3 where id = 76584 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 2 where id = 81813 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 4 where id = 81814 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 2 where id = 81815 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 81816 and qrcode_channel = 113;
delete from qrcode_statistics where id = 81817 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 81819 and qrcode_channel = 113;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (113, '2015-09-26 15:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 1 where id = 84473 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 84489 and qrcode_channel = 113;
delete from qrcode_statistics where id = 84490 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 84491 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 5 where id = 116978 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 7 where id = 116979 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 3 where id = 116980 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 2 where id = 116981 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 4 where id = 116982 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 3 where id = 116983 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 4 where id = 116984 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 5 where id = 116985 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 3 where id = 119780 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 2 where id = 119781 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 2 where id = 119782 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 2 where id = 119798 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 2 where id = 119799 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 2 where id = 119801 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 119803 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 2 where id = 122605 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 2 where id = 122606 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 4 where id = 122622 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 2 where id = 122623 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 122624 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 122628 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 5 where id = 125430 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 5 where id = 125431 and qrcode_channel = 113;
delete from qrcode_statistics where id = 125432 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 4 where id = 125446 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 6 where id = 125447 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 4 where id = 125448 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 7 where id = 125449 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 2 where id = 125450 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 125451 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 8 where id = 125452 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 9 where id = 125453 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 7 where id = 128259 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 3 where id = 128260 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 5 where id = 128276 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 4 where id = 128277 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 4 where id = 128278 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 3 where id = 128279 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 3 where id = 128280 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 5 where id = 128281 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 6 where id = 128282 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 6 where id = 131110 and qrcode_channel = 113;
delete from qrcode_statistics where id = 131111 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 131125 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 6 where id = 131126 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 3 where id = 131127 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 6 where id = 131128 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 7 where id = 131129 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 131131 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 4 where id = 131132 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 2 where id = 133959 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 133960 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 4 where id = 136825 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 2 where id = 136826 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 4 where id = 136827 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 4 where id = 136828 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 3 where id = 136829 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 3 where id = 136830 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 2 where id = 136831 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 2 where id = 136832 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 2 where id = 139660 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 3 where id = 139676 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 6 where id = 139677 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 3 where id = 139678 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 2 where id = 139679 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 3 where id = 139680 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 3 where id = 139681 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 5 where id = 139682 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 6 where id = 142509 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 4 where id = 142510 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 142511 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 142524 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 3 where id = 142525 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 8 where id = 142526 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 4 where id = 142527 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 5 where id = 142528 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 5 where id = 142529 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 5 where id = 142530 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 7 where id = 142531 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 6 where id = 142532 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 5 where id = 145360 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 145361 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 4 where id = 145375 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 5 where id = 145376 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 4 where id = 145377 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 4 where id = 145378 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 4 where id = 145379 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 3 where id = 145380 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 2 where id = 145381 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 4 where id = 145382 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 5 where id = 148209 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 2 where id = 148210 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 148229 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 156760 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 3 where id = 156775 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 2 where id = 156776 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 2 where id = 156777 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 4 where id = 156778 and qrcode_channel = 113;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (113, '2015-10-23 12:00:00', 0, 2);
update qrcode_statistics set subscribe_count = 3 where id = 156780 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 4 where id = 156781 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 4 where id = 156782 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 4 where id = 159609 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 3 where id = 159610 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 4 where id = 159625 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 4 where id = 159626 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 4 where id = 159627 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 3 where id = 159628 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 159629 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 3 where id = 159630 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 159631 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 159632 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 5 where id = 162471 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 3 where id = 162472 and qrcode_channel = 113;
delete from qrcode_statistics where id = 162487 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 6 where id = 162488 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 3 where id = 162489 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 162490 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 162491 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 3 where id = 162492 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 2 where id = 162493 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 3 where id = 162494 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 3 where id = 165371 and qrcode_channel = 113;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (113, '2015-10-27 08:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (113, '2015-10-27 09:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (113, '2015-10-27 10:00:00', 0, 5);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (113, '2015-10-27 11:00:00', 0, 4);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (113, '2015-10-27 12:00:00', 0, 5);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (113, '2015-10-27 13:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (113, '2015-10-27 14:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (113, '2015-10-27 15:00:00', 0, 5);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (113, '2015-10-27 16:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (113, '2015-10-27 17:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (113, '2015-10-28 08:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (113, '2015-10-28 09:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (113, '2015-10-28 10:00:00', 0, 5);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (113, '2015-10-28 11:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (113, '2015-10-28 12:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (113, '2015-10-28 13:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (113, '2015-10-28 14:00:00', 0, 5);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (113, '2015-10-28 15:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (113, '2015-10-28 16:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (113, '2015-10-29 09:00:00', 0, 5);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (113, '2015-10-29 10:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (113, '2015-10-29 11:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (113, '2015-10-29 12:00:00', 0, 7);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (113, '2015-10-29 13:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (113, '2015-10-30 08:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (113, '2015-10-30 10:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (113, '2015-10-30 12:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (113, '2015-10-30 14:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (113, '2015-10-30 15:00:00', 0, 5);
update qrcode_statistics set subscribe_count = 5 where id = 319905 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 6 where id = 319891 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 2 where id = 319861 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 3 where id = 319896 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 2 where id = 319904 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 3 where id = 319854 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 319897 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 2 where id = 319907 and qrcode_channel = 113;
delete from qrcode_statistics where id = 319963 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 0 where id = 323572 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 0 where id = 323670 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 323997 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 2 where id = 324007 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 324066 and qrcode_channel = 113;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (113, '2015-11-13 12:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (113, '2015-11-15 09:00:00', 0, 1);
delete from qrcode_statistics where id = 324270 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 1 where id = 324324 and qrcode_channel = 113;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (113, '2015-11-24 11:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 1 where id = 325503 and qrcode_channel = 113;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (113, '2015-12-07 11:00:00', 0, 1);
delete from qrcode_statistics where id = 325881 and qrcode_channel = 113;
update qrcode_statistics set subscribe_count = 2 where id = 326409 and qrcode_channel = 113;
-- 121	统计数为1897，用户数为830 截止到2015-11-29
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (121, '1970-01-01 08:00:00', 0, 4);
update qrcode_statistics set subscribe_count = 1 where id = 35370 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 1 where id = 37630 and qrcode_channel = 121;
delete from qrcode_statistics where id = 37631 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 1 where id = 37632 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 2 where id = 37633 and qrcode_channel = 121;
delete from qrcode_statistics where id = 37634 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 1 where id = 37635 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 1, statistics_time= '2015-09-08 18:00:00' where id = 37636 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 1 where id = 39941 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 2 where id = 47926 and qrcode_channel = 121;
delete from qrcode_statistics where id = 47927 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 1 where id = 47928 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 6 where id = 47944 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 2 where id = 47945 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 3 where id = 47946 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 4 where id = 47947 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 3 where id = 47948 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 2 where id = 47949 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 1 where id = 47950 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 2 where id = 47951 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 3 where id = 47952 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 3 where id = 47953 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 7 where id = 47967 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 4 where id = 47968 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 5 where id = 47968 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 8 where id = 47970 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 5 where id = 47971 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 6 where id = 47972 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 3 where id = 47973 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 4 where id = 47974 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 4 where id = 47975 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 4 where id = 58367 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 4 where id = 58368 and qrcode_channel = 121;
delete from qrcode_statistics where id = 58372 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 1 where id = 58382 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 6 where id = 58383 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 6 where id = 58384 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 5 where id = 58385 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 4 where id = 58386 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 2 where id = 58387 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 3 where id = 58388 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 1 where id = 58389 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 2 where id = 58390 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 5 where id = 60841 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 1 where id = 60855 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 3 where id = 60856 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 5 where id = 60857 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 2 where id = 60858 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 6 where id = 60859 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 3 where id = 60860 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 7 where id = 60861 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 6 where id = 60862 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 8 where id = 60863 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 8 where id = 63342 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 4 where id = 63343 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 4 where id = 63344 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 1 where id = 63357 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 6 where id = 63358 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 9 where id = 63359 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 7 where id = 63360 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 6 where id = 63361 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 11 where id = 63362 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 7 where id = 63363 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 2 where id = 63364 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 6 where id = 63365 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 4 where id = 66018 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 1 where id = 66019 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 1 where id = 66033 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 5 where id = 66034 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 6 where id = 66035 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 9 where id = 66036 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 4 where id = 66037 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 3 where id = 66038 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 8 where id = 66039 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 5 where id = 66040 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 4 where id = 68867 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 1 where id = 68868 and qrcode_channel = 121;
delete from qrcode_statistics where id = 71613 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 1 where id = 74203 and qrcode_channel = 121;
delete from qrcode_statistics where id = 74204 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 4 where id = 74205 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 5 where id = 74206 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 2 where id = 74207 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 3 where id = 74208 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 3 where id = 74209 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 5 where id = 74210 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 6 where id = 74211 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 2 where id = 76763 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 5 where id = 76764 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 1 where id = 76765 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 1 where id = 76779 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 1 where id = 76780 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 1 where id = 76781 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 1 where id = 76785 and qrcode_channel = 121;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (121, '2015-09-25 08:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 5 where id = 79355 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 3 where id = 79356 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 3 where id = 79357 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 4 where id = 79359 and qrcode_channel = 121;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (121, '2015-09-25 14:00:00', 0, 2);
update qrcode_statistics set subscribe_count = 5 where id = 81997 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 6 where id = 81998 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 1 where id = 81999 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 1 where id = 82013 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 7 where id = 82014 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 3 where id = 82015 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 6 where id = 82016 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 2 where id = 82017 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 3 where id = 82018 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 3 where id = 82019 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 6 where id = 82020 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 7 where id = 84672 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 5 where id = 84673 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 1, statistics_time = '2015-09-26 20:00:00' where id = 84674 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 2 where id = 84688 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 4 where id = 84689 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 6 where id = 84690 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 4 where id = 84691 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 3 where id = 84692 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 4 where id = 84693 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 3 where id = 84694 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 1, statistics_time = '2015-09-29 10:00:00' where id = 90068 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 1 where id = 90072 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 3 where id = 90073 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 2 where id = 92751 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 1 where id = 92752 and qrcode_channel = 121;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (121, '2015-09-29 18:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 1 where id = 95453 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 2 where id = 117179 and qrcode_channel = 121;
delete from qrcode_statistics where id = 117180 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 2 where id = 117181 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 1 where id = 117182 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 1 where id = 117183 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 3 where id = 117184 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 5 where id = 119981 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 1 where id = 119982 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 1 where id = 119996 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 6 where id = 119997 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 5 where id = 119998 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 1 where id = 119999 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 2 where id = 120000 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 1 where id = 120001 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 3 where id = 120002 and qrcode_channel = 121;
delete from qrcode_statistics where id = 120003 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 3 where id = 122805 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 6 where id = 122822 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 3 where id = 122823 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 1 where id = 122824 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 3 where id = 122825 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 2 where id = 122826 and qrcode_channel = 121;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (121, '2015-10-11 14:00:00', 0, 3);
update qrcode_statistics set subscribe_count = 2 where id = 122828 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 3 where id = 125631 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 2 where id = 125647 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 2 where id = 125648 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 3 where id = 125649 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 1 where id = 125650 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 2 where id = 125651 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 3 where id = 125652 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 4 where id = 125653 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 6 where id = 128460 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 7 where id = 128476 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 2 where id = 128477 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 1 where id = 128478 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 3 where id = 128479 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 4 where id = 128480 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 3 where id = 128481 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 4 where id = 128482 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 5 where id = 131309 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 3 where id = 131310 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 4 where id = 131326 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 2 where id = 131327 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 3 where id = 131328 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 1 where id = 131329 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 4 where id = 131330 and qrcode_channel = 121;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (121, '2015-10-14 14:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 2 where id = 134160 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 2 where id = 134176 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 1 where id = 134177 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 1 where id = 134178 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 6 where id = 134179 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 2 where id = 134180 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 1 where id = 134181 and qrcode_channel = 121;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (121, '2015-10-15 15:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 2 where id = 137009 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 4 where id = 137026 and qrcode_channel = 121;
delete from qrcode_statistics where id = 137027 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 2 where id = 137028 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 4 where id = 137029 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 5 where id = 137030 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 3 where id = 137031 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 4 where id = 137032 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 1 where id = 139859 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 2 where id = 142725 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 3 where id = 142726 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 5 where id = 142727 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 4 where id = 142728 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 7 where id = 142729 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 4 where id = 142730 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 4 where id = 142731 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 3 where id = 142732 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 3 where id = 145560 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 3 where id = 145576 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 4 where id = 145577 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 2 where id = 145578 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 1 where id = 145579 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 5 where id = 145580 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 2 where id = 145581 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 2 where id = 145582 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 5 where id = 148409 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 3 where id = 148410 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 2 where id = 156977 and qrcode_channel = 121;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (121, '2015-10-23 11:00:00', 0, 3);
update qrcode_statistics set subscribe_count = 1 where id = 156980 and qrcode_channel = 121;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (121, '2015-10-23 14:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 2 where id = 156982 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 5 where id = 159809 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 4 where id = 159810 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 4 where id = 159826 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 7 where id = 159827 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 3 where id = 159828 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 2 where id = 159829 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 2 where id = 159830 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 2 where id = 159831 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 2 where id = 159832 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 2 where id = 162672 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 1 where id = 162688 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 6 where id = 162689 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 2 where id = 162690 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 3 where id = 162691 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 4 where id = 162692 and qrcode_channel = 121;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (121, '2015-10-27 15:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (121, '2015-10-27 16:00:00', 0, 4);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (121, '2015-10-27 17:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (121, '2015-10-28 08:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (121, '2015-10-29 11:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (121, '2015-10-29 13:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (121, '2015-10-29 14:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (121, '2015-10-29 15:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (121, '2015-10-29 16:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (121, '2015-10-30 08:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (121, '2015-10-30 09:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (121, '2015-10-30 10:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (121, '2015-10-30 12:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (121, '2015-10-30 13:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (121, '2015-10-30 14:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (121, '2015-10-30 15:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 1 where id = 288363 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 1 where id = 288289 and qrcode_channel = 121;
delete from qrcode_statistics where id = 319980 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 1 where id = 319973 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 0 where id = 323704 and qrcode_channel = 121;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (121, '2015-11-14 14:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 1 where id = 324167 and qrcode_channel = 121;
update qrcode_statistics set subscribe_count = 1, statistics_time = '2015-11-15 18:00:00' where id = 324186 and qrcode_channel = 121;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (121, '2015-11-16 14:00:00', 0, 1);
delete from qrcode_statistics where id = 325128 and qrcode_channel = 121;
delete from qrcode_statistics where id = 325226 and qrcode_channel = 121;
-- 119	统计数为2341，用户数为1155 截止到2015-12-02
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (119, '2015-08-19 15:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 1 where id = 35319 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 35320 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 35321 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 35324 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 35325 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 37564 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 37565 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 4 where id = 37580 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 37581 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 37582 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 37583 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 0 where id = 37587 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 39875 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 39879 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 39886 and qrcode_channel = 119;
delete from qrcode_statistics where id = 39887 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 39888 and qrcode_channel = 119;
delete from qrcode_statistics where id = 39891 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 4 where id = 44536 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 4 where id = 44537 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 44538 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 44539 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 44541 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 44542 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 44543 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 47615 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 47630 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 47631 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 47632 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 47633 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 47634 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 47636 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 47637 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 47638 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 4 where id = 47639 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 47640 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 47653 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 47654 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 47655 and qrcode_channel = 119;
delete from qrcode_statistics where id = 47656 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 47657 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 47658 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 47659 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 47660 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 47661 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 4 where id = 47662 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 47663 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 47677 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 47680 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 47681 and qrcode_channel = 119;
delete from qrcode_statistics where id = 47682 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 47684 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 47685 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 47686 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 47687 and qrcode_channel = 119;
delete from qrcode_statistics where id = 47688 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 47702 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 47703 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 47704 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 47705 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 47706 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 47708 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 47709 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 47710 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 47725 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 47726 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 47727 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 47728 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 47729 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 47730 and qrcode_channel = 119;
delete from qrcode_statistics where id = 47731 and qrcode_channel = 119; -- 2
update qrcode_statistics set subscribe_count = 1 where id = 47733 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 58317 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 58318 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 58319 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 58333 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 4 where id = 58334 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 58335 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 58336 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 5 where id = 58338 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 58339 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 4 where id = 58340 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 6 where id = 60790 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 8 where id = 60791 and qrcode_channel = 119;
delete from qrcode_statistics where id = 60792 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 11 where id = 60806 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 10 where id = 60807 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 6 where id = 60808 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 10 where id = 60809 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 10 where id = 60810 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 5 where id = 60811 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 10 where id = 60812 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 12 where id = 60813 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 12 where id = 63267 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 10 where id = 63268 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 63269 and qrcode_channel = 119;
delete from qrcode_statistics where id = 63272 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 14 where id = 63282 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 12 where id = 63283 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 11 where id = 63284 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 14 where id = 63285 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 63286 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 63287 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 7 where id = 63288 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 7 where id = 63289 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 8 where id = 63290 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 10 where id = 65967 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 65968 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 65982 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 65983 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 5 where id = 65984 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 10 where id = 65985 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 4 where id = 65986 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 6 where id = 65987 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 8 where id = 65988 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 7 where id = 65989 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 65990 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 74153 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 5 where id = 74154 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 4 where id = 74155 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 4 where id = 74156 and qrcode_channel = 119;
delete from qrcode_statistics where id = 74157 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 74158 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 74159 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 5 where id = 74160 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 74161 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 76713 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 76714 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 76728 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 76729 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 76732 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 76733 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 76734 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 76735 and qrcode_channel = 119;
delete from qrcode_statistics where id = 76736 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 79288 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 79289 and qrcode_channel = 119;
delete from qrcode_statistics where id = 79303 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 5 where id = 79304 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 5 where id = 79305 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 79306 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 79307 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 79308 and qrcode_channel = 119;
delete from qrcode_statistics where id = 79309 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 79310 and qrcode_channel = 119;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (119, '2015-09-25 15:00:00', 0, 2);
update qrcode_statistics set subscribe_count = 4 where id = 81947 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 81948 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 4 where id = 81963 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 5 where id = 81964 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 6 where id = 81965 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 81967 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 81968 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 5 where id = 81969 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 4 where id = 81970 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 5 where id = 84622 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 84623 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 84637 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 84638 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 5 where id = 84639 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 84640 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 84641 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 84643 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 84644 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 84645 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 87302 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1, statistics_time = '2015-09-28 09:00:00' where id = 87317 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 90019 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 90020 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 92715 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 92716 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 4 where id = 92717 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 5 where id = 92719 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 92720 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 111676 and qrcode_channel = 119;
delete from qrcode_statistics where id = 111678 and qrcode_channel = 119;
delete from qrcode_statistics where id = 117131 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 117133 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 4 where id = 117134 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 117135 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 119930 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 119931 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 119945 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 119946 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 119947 and qrcode_channel = 119;
delete from qrcode_statistics where id = 119948 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 4 where id = 119949 and qrcode_channel = 119;
delete from qrcode_statistics where id = 119950 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 119952 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 4 where id = 119953 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 6 where id = 122755 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 122770 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 5 where id = 122771 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 4 where id = 122772 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 4 where id = 122773 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 122774 and qrcode_channel = 119;
delete from qrcode_statistics where id = 122775 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 122776 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 122777 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 11 where id = 122778 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 125581 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 125594 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 125595 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 125596 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 125597 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 5 where id = 125599 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 125601 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 5 where id = 125602 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 5 where id = 125603 and qrcode_channel = 119;
delete from qrcode_statistics where id = 128424 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 128425 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 128426 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 128427 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 128428 and qrcode_channel = 119;
delete from qrcode_statistics where id = 128429 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 4 where id = 128431 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 128432 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 5 where id = 131259 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 4 where id = 131260 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 131276 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 131277 and qrcode_channel = 119;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (119, '2015-10-14 11:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 2 where id = 131280 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 131281 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 134110 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 134125 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 134127 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 134128 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 134129 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 134130 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 134131 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 136959 and qrcode_channel = 119;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (119, '2015-10-15 17:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 2 where id = 136975 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 136976 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 136977 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 136979 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 136980 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 5 where id = 136981 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 136982 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 139809 and qrcode_channel = 119;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (119, '2015-10-16 17:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 3 where id = 139825 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 5 where id = 139826 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 4 where id = 139827 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 139828 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 5 where id = 139829 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 8 where id = 139830 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 139831 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 5 where id = 139832 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 4 where id = 142659 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 142660 and qrcode_channel = 119;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (119, '2015-10-17 18:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 4 where id = 142675 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 4 where id = 142676 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 4 where id = 142677 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 142678 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 142679 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 142680 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 142681 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 7 where id = 142682 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 5 where id = 145509 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 145510 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 145526 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 145530 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 145531 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 148360 and qrcode_channel = 119;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (119, '2015-10-20 13:00:00', 0, 1);
delete from qrcode_statistics where id = 154063 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 154082 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 1 where id = 156910 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 156925 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 156926 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 10 where id = 156927 and qrcode_channel = 119;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (119, '2015-10-23 11:00:00', 0, 2);
update qrcode_statistics set subscribe_count = 4 where id = 156930 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 156931 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 7 where id = 156932 and qrcode_channel = 119;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (119, '2015-10-24 07:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 5 where id = 159775 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 4 where id = 159776 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 159777 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 4 where id = 159778 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 6 where id = 159780 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 8 where id = 159781 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 6 where id = 159782 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 4 where id = 162621 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 5 where id = 162622 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 162622 and qrcode_channel = 119;
delete from qrcode_statistics where id = 162637 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 162638 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 162639 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 162640 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 162643 and qrcode_channel = 119;
delete from qrcode_statistics where id = 162644 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 165541 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 4 where id = 165542 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 165543 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 8 where id = 165544 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 8 where id = 170315 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 170316 and qrcode_channel = 119;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (119, '2015-10-27 08:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (119, '2015-10-27 09:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (119, '2015-10-27 10:00:00', 0, 8);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (119, '2015-10-27 11:00:00', 0, 5);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (119, '2015-10-27 12:00:00', 0, 8);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (119, '2015-10-27 13:00:00', 0, 5);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (119, '2015-10-27 14:00:00', 0, 7);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (119, '2015-10-27 15:00:00', 0, 7);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (119, '2015-10-27 16:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (119, '2015-10-27 17:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (119, '2015-10-28 08:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (119, '2015-10-28 09:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (119, '2015-10-28 10:00:00', 0, 4);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (119, '2015-10-28 11:00:00', 0, 4);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (119, '2015-10-28 12:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (119, '2015-10-28 13:00:00', 0, 5);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (119, '2015-10-28 14:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (119, '2015-10-28 15:00:00', 0, 4);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (119, '2015-10-28 16:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (119, '2015-10-28 17:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (119, '2015-10-29 09:00:00', 0, 4);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (119, '2015-10-29 10:00:00', 0, 6);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (119, '2015-10-29 11:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (119, '2015-10-29 12:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (119, '2015-10-29 13:00:00', 0, 5);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (119, '2015-10-29 14:00:00', 0, 5);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (119, '2015-10-29 15:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (119, '2015-10-29 16:00:00', 0, 4);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (119, '2015-10-29 17:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (119, '2015-10-30 09:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (119, '2015-10-30 11:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (119, '2015-10-30 12:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (119, '2015-10-30 13:00:00', 0, 2);
delete from qrcode_statistics where id = 287109 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 11 where id = 287145 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 8 where id = 287322 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 2 where id = 287322 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 4 where id = 288284 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 7 where id = 288504 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 319974 and qrcode_channel = 119;
delete from qrcode_statistics where id = 320023 and qrcode_channel = 119;
update qrcode_statistics set subscribe_count = 3 where id = 320001 and qrcode_channel = 119;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (119, '2015-11-01 14:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 0 where id = 323926 and qrcode_channel = 119;
delete from qrcode_statistics where id = 324157 and qrcode_channel = 119;
delete from qrcode_statistics where id = 324600 and qrcode_channel = 119;
delete from qrcode_statistics where id = 324817 and qrcode_channel = 119;
-- 118	统计数为2891，用户数为1411 截止到2015-12-10
update qrcode_statistics set subscribe_count = 1 where id = 35296 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 35297 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 35299 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 35300 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 37540 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 2 where id = 44512 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 44513 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 3 where id = 44514 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 2 where id = 44515 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 44516 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 2 where id = 44517 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 2 where id = 44518 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 47493 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 47495 and qrcode_channel = 118;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-09-11 21:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 1 where id = 47510 and qrcode_channel = 118;
delete from qrcode_statistics where id = 47511 and qrcode_channel = 118;
delete from qrcode_statistics where id = 47515 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 3 where id = 47516 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 2 where id = 47517 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 3 where id = 47518 and qrcode_channel = 118;
delete from qrcode_statistics where id = 47519 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 3 where id = 47534 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 47536 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 47537 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 2 where id = 47538 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 2 where id = 47541 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 47542 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 47562 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 47583 and qrcode_channel = 118;
delete from qrcode_statistics where id = 47585 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 47586 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 2 where id = 47587 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 47588 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 0 where id = 47589 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 3 where id = 47590 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 47604 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 5 where id = 47605 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 9 where id = 47606 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 6 where id = 47607 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 8 where id = 47608 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 5 where id = 47609 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 8 where id = 47610 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 9 where id = 47611 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 3 where id = 47612 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 5 where id = 58293 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 58308 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 6 where id = 58309 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 6 where id = 58310 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 3 where id = 58311 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 4 where id = 58312 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 6 where id = 58313 and qrcode_channel = 118;
delete from qrcode_statistics where id = 58314 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 58315 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 4 where id = 60766 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 60767 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 2 where id = 60781 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 60782 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 6 where id = 60783 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 7 where id = 60784 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 3 where id = 60785 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 3 where id = 60786 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 3 where id = 60787 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 6 where id = 60788 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 4 where id = 63242 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 3 where id = 63243 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 2 where id = 63244 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 4 where id = 63259 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 6 where id = 63260 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 3 where id = 63261 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 2 where id = 63262 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 3 where id = 63263 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 7 where id = 63264 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 9 where id = 63265 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 2 where id = 65942 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 6 where id = 65943 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 2 where id = 65944 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 65945 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 4 where id = 65958 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 3 where id = 65959 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 7 where id = 65960 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 4 where id = 65961 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 4 where id = 65962 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 6 where id = 65963 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 4 where id = 65964 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 4 where id = 65965 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 3 where id = 68793 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 68794 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 68807 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 68808 and qrcode_channel = 118;
delete from qrcode_statistics where id = 68809 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 68811 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 68812 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 2 where id = 68813 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 3 where id = 71539 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 71554 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 2 where id = 71558 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 0 where id = 71560 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 74128 and qrcode_channel = 118;
delete from qrcode_statistics where id = 74129 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 10 where id = 74130 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 4 where id = 74131 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 6 where id = 65963 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 6 where id = 74132 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 10 where id = 74133 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 4 where id = 74134 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 4 where id = 74135 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 4 where id = 74136 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 4 where id = 76689 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 3 where id = 76690 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 3 where id = 76705 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 3 where id = 76706 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 2 where id = 76708 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 4 where id = 76709 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 5 where id = 76710 and qrcode_channel = 118;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-09-24 15:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-09-24 17:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 1 where id = 79278 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 2 where id = 79279 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 7 where id = 79280 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 6 where id = 79281 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 3 where id = 79282 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 10 where id = 79284 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 4 where id = 79285 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 6 where id = 79286 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 7 where id = 81922 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 11 where id = 81923 and qrcode_channel = 118;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-09-25 18:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 2 where id = 81938 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 4 where id = 81939 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 10 where id = 81940 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 16 where id = 81941 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 2 where id = 81942 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 7 where id = 81943 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 6 where id = 81944 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 8 where id = 81945 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 4 where id = 84597 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 2 where id = 84598 and qrcode_channel = 118;
delete from qrcode_statistics where id = 84599 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 84613 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 2 where id = 84614 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 8 where id = 84615 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 4 where id = 84616 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 3 where id = 84617 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 6 where id = 84618 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 3 where id = 84619 and qrcode_channel = 118;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-09-27 15:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 1 where id = 89997 and qrcode_channel = 118;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-01 11:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 1 where id = 98093 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 117103 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 2 where id = 117104 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 117105 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 3 where id = 117108 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 3 where id = 117109 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 3 where id = 117110 and qrcode_channel = 118;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-09 16:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 2 where id = 119906 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 3 where id = 119921 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 2 where id = 119922 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 2 where id = 119923 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 8 where id = 119924 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 2 where id = 119925 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 2 where id = 119926 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 4 where id = 119927 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 119928 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 122746 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 2 where id = 125574 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 3 where id = 125575 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 2 where id = 125576 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 125577 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 6 where id = 125578 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 11 where id = 128384 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 9 where id = 128385 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 128386 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 10 where id = 128401 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 10 where id = 128402 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 6 where id = 128403 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 5 where id = 128404 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 5 where id = 128405 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 7 where id = 128406 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 7 where id = 128407 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 10 where id = 131234 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 7 where id = 131235 and qrcode_channel = 118;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-13 18:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 1 where id = 131248 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 2 where id = 131249 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 4 where id = 131250 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 5 where id = 131251 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 7 where id = 131252 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 7 where id = 131253 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 4 where id = 131254 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 5 where id = 131255 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 3 where id = 131256 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 6 where id = 131257 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 2 where id = 134084 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 3 where id = 134085 and qrcode_channel = 118;
delete from qrcode_statistics where id = 134087 and qrcode_channel = 118;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-14 20:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 1 where id = 134099 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 5 where id = 134100 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 4 where id = 134101 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 8 where id = 134102 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 7 where id = 134103 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 5 where id = 134104 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 5 where id = 134105 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 3 where id = 134106 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 2 where id = 134107 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 6 where id = 136935 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 136938 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 4 where id = 136950 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 4 where id = 136951 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 5 where id = 136952 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 9 where id = 136953 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 3 where id = 136954 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 3 where id = 136955 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 6 where id = 136956 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 6 where id = 136957 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 4 where id = 139784 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 5 where id = 139785 and qrcode_channel = 118;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-16 18:00:00', 0, 4);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-16 19:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 2 where id = 139799 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 5 where id = 139800 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 7 where id = 139801 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 8 where id = 139802 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 9 where id = 139803 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 14 where id = 139804 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 7 where id = 139805 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 5 where id = 139806 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 5 where id = 139807 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 12 where id = 142634 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 8 where id = 142635 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 2 where id = 142636 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 7 where id = 142651 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 9 where id = 142652 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 8 where id = 142653 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 10 where id = 142654 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 5 where id = 142655 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 6 where id = 142656 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 7 where id = 142657 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 9 where id = 145484 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 7 where id = 145485 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 4 where id = 145499 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 5 where id = 145500 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 3 where id = 145501 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 6 where id = 145502 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 5 where id = 145503 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 6 where id = 145504 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 6 where id = 145505 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 4 where id = 145506 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 4 where id = 145507 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 148334 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 7 where id = 148335 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 148350 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 3 where id = 148352 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 4 where id = 148353 and qrcode_channel = 118;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-20 12:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-20 13:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 1 where id = 148356 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 2 where id = 151185 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 151206 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 2 where id = 154035 and qrcode_channel = 118;
delete from qrcode_statistics where id = 154036 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 2 where id = 154037 and qrcode_channel = 118;
delete from qrcode_statistics where id = 154052 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 154053 and qrcode_channel = 118;
delete from qrcode_statistics where id = 154055 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 3 where id = 154056 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 4 where id = 154057 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 3 where id = 156885 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 156887 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 156888 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 156898 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 2 where id = 156899 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 2 where id = 156900 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 5 where id = 156901 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 7 where id = 156902 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 4 where id = 156903 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 6 where id = 156904 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 8 where id = 156905 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 5 where id = 156906 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 5 where id = 156907 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 6 where id = 159734 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 6 where id = 159735 and qrcode_channel = 118;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-23 19:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 1 where id = 159738 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 4 where id = 159749 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 5 where id = 159750 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 5 where id = 159751 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 3 where id = 159752 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 2 where id = 159753 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 4 where id = 159754 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 2 where id = 159755 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 5 where id = 159756 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 6 where id = 159757 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 5 where id = 162596 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 7 where id = 162597 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 162598 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 162611 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 3 where id = 162612 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 3 where id = 162613 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 4 where id = 162614 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 162615 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 3 where id = 162617 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 2 where id = 162618 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 2 where id = 162619 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 165497 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 165514 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 165515 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 165519 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 170291 and qrcode_channel = 118;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-27 08:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-27 10:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-27 11:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-27 12:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-27 13:00:00', 0, 4);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-27 14:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-27 15:00:00', 0, 4);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-27 16:00:00', 0, 6);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-27 17:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-27 18:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-28 07:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-28 08:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-28 09:00:00', 0, 5);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-28 10:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-28 11:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-28 12:00:00', 0, 4);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-28 13:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-28 14:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-28 15:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-28 16:00:00', 0, 5);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-28 18:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-29 07:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-29 08:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-29 09:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-29 10:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-29 12:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-29 13:00:00', 0, 4);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-29 15:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-29 16:00:00', 0, 4);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-29 19:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-30 07:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-30 08:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-30 10:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-30 11:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-30 12:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-30 13:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-30 15:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-30 16:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-30 17:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-30 18:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 1 where id = 287212 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 1 where id = 287597 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 2 where id = 287989 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 2 where id = 288863 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 3 where id = 288794 and qrcode_channel = 118;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-10-31 17:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 3 where id = 320012 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 6 where id = 320008 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 3 where id = 320017 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 6 where id = 320009 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 4 where id = 319989 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 4 where id = 319998 and qrcode_channel = 118;
update qrcode_statistics set subscribe_count = 5 where id = 320004 and qrcode_channel = 118;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-11-01 18:00:00', 0, 1);
delete from qrcode_statistics where id = 320039 and qrcode_channel = 118;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (118, '2015-11-18 17:00:00', 0, 1);
delete from qrcode_statistics where id = 325575 and qrcode_channel = 118;
-- 944	统计数为64，用户数为24 截止到2015-09-13
-- 1029	统计数为151，用户数为143 截止到2015-09-20
-- 2085	统计数为151，用户数为53 截止到2015-09-18
-- 109	统计数为267，用户数为176 截止到2015-11-01
-- 692	统计数为308，用户数为146 截止到2015-10-29
-- 1018	统计数为589，用户数为467 截止到2015-08-19
-- 2081	统计数为1236，用户数为617 截止到2015-10-06
-- 2082	统计数为1342，用户数为786 截止到2015-10-06
-- 2078	统计数为1442，用户数为976 截止到2015-09-22
-- 2080	统计数为2070，用户数为1034 截止到2015-09-21
-- 2086	统计数为2219，用户数为705 截止到2015-09-28
-- 1006	统计数为2433，用户数为1826 截止到2015-09-13
-- 2079	统计数为2491，用户数为1276 截止到2015-09-21
-- 2077	统计数为2550，用户数为1274 截止到2015-09-21
-- 2083	统计数为2554，用户数为1350 截止到2015-10-06
-- 2084	统计数为3882，用户数为1954 截止到2015-10-10
-- 1009	统计数为5050，用户数为3889 截止到2015-10-12
-- 1010	统计数为6972，用户数为5099 截止到2015-10-12
-- 1033	统计数为9871，用户数为4789 截止到2015-10-29
-- 3	统计数为10905，用户数为5475 截止到2015-10-29
-- -----------------------------------------------------------------------------------------------------------
-- 修改部分二维码渠道统计数小于微信用户数
-- 1005 统计数为476，用户数为799 截止到 2015-09-11
-- 1015 统计数为564，用户数为1740 截止到 2015-08-19
-- 1016 统计数为565，用户数为1320 截止到 2015-08-19
-- 1017 统计数为557，用户数为1397 截止到 2015-08-19
-- 1011 统计数为2345，用户数为2471 截止到 2015-10-12
-- 1013 统计数为2460，用户数为3828 截止到 2015-09-23
-- 1030 统计数为2874，用户数为3319 截止到 2015-10-12
-- 1012 统计数为7829，用户数为8489 截止到 2015-10-07
-- 2075 统计数为0，用户数为1   关注时间：1970-01-01 08:00:00
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2075, '1970-01-01 08:00:00', 0, 1);
-- 2105 统计数为7，用户数为12
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2105, '2015-10-30 12:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2105, '2015-10-30 13:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2105, '2015-10-30 14:00:00', 0, 1);
-- 2103 统计数为17，用户数为20
delete from qrcode_statistics where qrcode_channel = 2103 and id = 36757;
delete from qrcode_statistics where qrcode_channel = 2103 and id = 323766;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2103, '2015-10-30 13:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2103, '2015-10-30 14:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2103, '2015-10-30 16:00:00', 0, 1);
-- 2102 统计数为14，用户数为16
update qrcode_statistics set subscribe_count = 5 where id = 323902 and qrcode_channel = 2102;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2102, '2015-10-30 11:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2102, '2015-10-30 12:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2102, '2015-10-30 13:00:00', 0, 1);
-- 2092 统计数为7，用户数为12
update qrcode_statistics set subscribe_count = 2, statistics_time = '2015-10-30 13:00:00' where id = 287697 and qrcode_channel = 2092;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2092, '2015-10-30 14:00:00', 0, 4);
-- 2088 统计数为19，用户数为29
update qrcode_statistics set subscribe_count = 2, statistics_time = '2015-10-27 08:00:00' where id = 161365 and qrcode_channel = 2088;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2088, '2015-10-28 08:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2088, '2015-10-28 09:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2088, '2015-10-28 10:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2088, '2015-10-28 11:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2088, '2015-10-28 12:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2088, '2015-10-28 13:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 1, statistics_time = '2015-10-30 16:00:00' where id = 323317 and qrcode_channel = 2088;
update qrcode_statistics set subscribe_count = 3, statistics_time = '2015-10-28 14:00:00' where id = 323325 and qrcode_channel = 2088;
update qrcode_statistics set subscribe_count = 4 where id = 323332 and qrcode_channel = 2088;
update qrcode_statistics set subscribe_count = 3 where id = 323327 and qrcode_channel = 2088;
delete from qrcode_statistics where id = 323321 and qrcode_channel = 2088;
delete from qrcode_statistics where id = 323315 and qrcode_channel = 2088;
delete from qrcode_statistics where id = 323602 and qrcode_channel = 2088;
-- 2087 统计数为2，用户数为15
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2087, '2015-10-28 10:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2087, '2015-10-28 11:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2087, '2015-10-28 12:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2087, '2015-10-28 13:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2087, '2015-10-28 15:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2087, '2015-10-28 16:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (2087, '2015-10-30 00:00:00', 0, 1);
-- 1029 统计数为7，用户数为151
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (1029, '2015-07-16 11:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (1029, '2015-07-23 19:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (1029, '2015-07-23 23:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (1029, '2015-07-24 09:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (1029, '2015-07-24 14:00:00', 0, 4);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (1029, '2015-07-24 18:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (1029, '2015-07-24 19:00:00', 0, 5);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (1029, '2015-07-24 22:00:00', 0, 4);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (1029, '2015-07-25 08:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (1029, '2015-07-25 12:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (1029, '2015-07-25 14:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (1029, '2015-07-25 15:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (1029, '2015-07-25 16:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (1029, '2015-07-25 18:00:00', 0, 26);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (1029, '2015-07-25 19:00:00', 0, 32);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (1029, '2015-07-25 20:00:00', 0, 50);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (1029, '2015-07-25 21:00:00', 0, 4);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (1029, '2015-07-26 10:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (1029, '2015-07-26 11:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (1029, '2015-07-28 16:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (1029, '2015-08-01 15:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (1029, '2015-08-02 13:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (1029, '2015-08-02 15:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (1029, '2015-08-05 13:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (1029, '2015-08-10 19:00:00', 0, 1);
delete from qrcode_statistics where id = 17502 and qrcode_channel = 1029;
update qrcode_statistics set subscribe_count = 1 where id = 28163 and qrcode_channel = 1029;
update qrcode_statistics set subscribe_count = 1 where id = 60146 and qrcode_channel = 1029;
update qrcode_statistics set subscribe_count = 1 where id = 70793 and qrcode_channel = 1029;
-- 116 统计数为173，用户数为177
update qrcode_statistics set subscribe_count = 1 where id = 44467 and qrcode_channel = 116;
delete from qrcode_statistics where id = 44468 and qrcode_channel = 116;
update qrcode_statistics set subscribe_count = 1 where id = 47269 and qrcode_channel = 116;
delete from qrcode_statistics where id = 47270 and qrcode_channel = 116;
update qrcode_statistics set subscribe_count = 3 where id = 47271 and qrcode_channel = 116;
update qrcode_statistics set subscribe_count = 1 where id = 47272 and qrcode_channel = 116;
update qrcode_statistics set subscribe_count = 1 where id = 47273 and qrcode_channel = 116;
update qrcode_statistics set subscribe_count = 1 where id = 47275 and qrcode_channel = 116;
delete from qrcode_statistics where id = 47294 and qrcode_channel = 116;
delete from qrcode_statistics where id = 47352 and qrcode_channel = 116;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (116, '2015-10-10 11:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (116, '2015-10-17 14:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 2 where id = 159700 and qrcode_channel = 116;
update qrcode_statistics set subscribe_count = 5 where id = 159701 and qrcode_channel = 116;
update qrcode_statistics set subscribe_count = 5 where id = 159702 and qrcode_channel = 116;
update qrcode_statistics set subscribe_count = 3 where id = 159703 and qrcode_channel = 116;
update qrcode_statistics set subscribe_count = 4 where id = 159704 and qrcode_channel = 116;
update qrcode_statistics set subscribe_count = 2 where id = 159705 and qrcode_channel = 116;
update qrcode_statistics set subscribe_count = 3 where id = 159706 and qrcode_channel = 116;
update qrcode_statistics set subscribe_count = 2 where id = 159707 and qrcode_channel = 116;
update qrcode_statistics set subscribe_count = 1 where id = 162562 and qrcode_channel = 116;
update qrcode_statistics set subscribe_count = 1 where id = 162563 and qrcode_channel = 116;
update qrcode_statistics set subscribe_count = 3 where id = 162564 and qrcode_channel = 116;
update qrcode_statistics set subscribe_count = 3 where id = 162565 and qrcode_channel = 116;
update qrcode_statistics set subscribe_count = 3 where id = 162566 and qrcode_channel = 116;
update qrcode_statistics set subscribe_count = 1 where id = 162567 and qrcode_channel = 116;
delete from qrcode_statistics where id = 162568 and qrcode_channel = 116;
update qrcode_statistics set subscribe_count = 1 where id = 162569 and qrcode_channel = 116;
update qrcode_statistics set subscribe_count = 1 where id = 165447 and qrcode_channel = 116;
update qrcode_statistics set subscribe_count = 1 where id = 165448 and qrcode_channel = 116;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (116, '2015-10-27 09:00:00', 0, 6);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (116, '2015-10-27 10:00:00', 0, 6);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (116, '2015-10-27 11:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (116, '2015-10-27 14:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (116, '2015-10-27 15:00:00', 0, 4);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (116, '2015-10-27 16:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (116, '2015-10-27 17:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (116, '2015-10-28 08:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (116, '2015-10-28 11:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (116, '2015-10-28 12:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (116, '2015-10-28 14:00:00', 0, 4);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (116, '2015-10-28 15:00:00', 0, 6);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (116, '2015-10-28 16:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (116, '2015-10-28 17:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (116, '2015-10-29 07:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (116, '2015-10-29 10:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (116, '2015-10-29 13:00:00', 0, 5);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (116, '2015-10-29 14:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (116, '2015-10-29 15:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (116, '2015-10-29 16:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (116, '2015-10-29 17:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (116, '2015-10-30 10:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (116, '2015-10-30 12:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (116, '2015-10-30 13:00:00', 0, 5);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (116, '2015-10-30 14:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (116, '2015-10-30 15:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (116, '2015-10-30 17:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (116, '2015-10-30 18:00:00', 0, 1);
update qrcode_statistics set subscribe_count = 1 where id = 287157 and qrcode_channel = 116;
update qrcode_statistics set subscribe_count = 1 where id = 287313 and qrcode_channel = 116;
update qrcode_statistics set subscribe_count = 5 where id = 289134 and qrcode_channel = 116;
update qrcode_statistics set subscribe_count = 2 where id = 288218 and qrcode_channel = 116;
update qrcode_statistics set subscribe_count = 2 where id = 288845 and qrcode_channel = 116;
update qrcode_statistics set subscribe_count = 0 where id = 320010 and qrcode_channel = 116;
delete from qrcode_statistics where id = 320029 and qrcode_channel = 116;
update qrcode_statistics set subscribe_count = 4 where id = 319985 and qrcode_channel = 116;
delete from qrcode_statistics where id = 319987 and qrcode_channel = 116;
update qrcode_statistics set subscribe_count = 1 where id = 324040 and qrcode_channel = 116;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (116, '2015-11-15 16:00:00', 0, 1);
-- 813
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (813, '2015-08-14 18:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (813, '2015-08-15 07:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (813, '2015-08-15 12:00:00', 0, 2);
update qrcode_statistics set subscribe_count = 1, statistics_time = '2015-08-16 10:00:00' where id = 131790 and qrcode_channel = 813;
-- 782
delete from qrcode_statistics where qrcode_channel = 782 and id = 36051;
-- 111
update qrcode_statistics set subscribe_count = 0 where id = 116934 and qrcode_channel = 111;
update qrcode_statistics set subscribe_count = 1 where id = 156716 and qrcode_channel = 111;
update qrcode_statistics set subscribe_count = 3 where id = 159576 and qrcode_channel = 111;
update qrcode_statistics set subscribe_count = 3 where id = 159577 and qrcode_channel = 111;
update qrcode_statistics set subscribe_count = 4 where id = 159578 and qrcode_channel = 111;
update qrcode_statistics set subscribe_count = 1 where id = 159580 and qrcode_channel = 111;
update qrcode_statistics set subscribe_count = 3 where id = 159581 and qrcode_channel = 111;
update qrcode_statistics set subscribe_count = 4 where id = 159582 and qrcode_channel = 111;
update qrcode_statistics set subscribe_count = 3 where id = 162422 and qrcode_channel = 111;
update qrcode_statistics set subscribe_count = 3 where id = 319881 and qrcode_channel = 111;
update qrcode_statistics set subscribe_count = 4 where id = 319883 and qrcode_channel = 111;
update qrcode_statistics set subscribe_count = 1 where id = 319900 and qrcode_channel = 111;
update qrcode_statistics set subscribe_count = 4 where id = 319852 and qrcode_channel = 111;
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (111, '2015-10-27 08:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (111, '2015-10-27 09:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (111, '2015-10-27 10:00:00', 0, 7);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (111, '2015-10-27 11:00:00', 0, 9);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (111, '2015-10-27 12:00:00', 0, 4);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (111, '2015-10-27 13:00:00', 0, 4);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (111, '2015-10-27 14:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (111, '2015-10-27 15:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (111, '2015-10-27 16:00:00', 0, 4);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (111, '2015-10-27 17:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (111, '2015-10-28 09:00:00', 0, 4);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (111, '2015-10-28 10:00:00', 0, 7);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (111, '2015-10-28 11:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (111, '2015-10-28 12:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (111, '2015-10-28 13:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (111, '2015-10-28 14:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (111, '2015-10-28 15:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (111, '2015-10-28 16:00:00', 0, 4);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (111, '2015-10-29 09:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (111, '2015-10-29 10:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (111, '2015-10-29 11:00:00', 0, 2);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (111, '2015-10-29 12:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (111, '2015-10-29 13:00:00', 0, 4);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (111, '2015-10-29 14:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (111, '2015-10-29 15:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (111, '2015-10-30 08:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (111, '2015-10-30 09:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (111, '2015-10-30 10:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (111, '2015-10-30 11:00:00', 0, 7);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (111, '2015-10-30 12:00:00', 0, 1);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (111, '2015-10-30 13:00:00', 0, 3);
insert into qrcode_statistics (qrcode_channel, statistics_time, scan_count, subscribe_count)
values (111, '2015-10-30 14:00:00', 0, 4);
-- -----------------------------------------------------------------------------------------------------------
-- 修改部分二维码渠道统计数为负数，渠道ID为728, 729, 737, 764, 785, 789, 821, 931, 940, 1008, 1014, 1019, 1020, 1022, 1024, 1025, 1026, 1028, 2064, 2074
update qrcode_statistics set subscribe_count = -2 where id = 140085 and qrcode_channel = 728;
update qrcode_statistics set subscribe_count = -1 where id = 4134 and qrcode_channel = 729;
update qrcode_statistics set subscribe_count = -1 where id = 23 and qrcode_channel = 737;
update qrcode_statistics set subscribe_count = -1 where id = 502 and qrcode_channel = 764;
update qrcode_statistics set subscribe_count = -1 where id = 24994 and qrcode_channel = 785;
update qrcode_statistics set subscribe_count = -1 where id = 25045 and qrcode_channel = 789;
update qrcode_statistics set subscribe_count = -1 where id = 3226 and qrcode_channel = 931;
update qrcode_statistics set subscribe_count = -1 where id = 143888 and qrcode_channel = 940;
update qrcode_statistics set subscribe_count = -1 where id = 12000 and qrcode_channel = 2064;
update qrcode_statistics set subscribe_count = -1 where id = 127749 and qrcode_channel = 2074;
delete from qrcode_statistics where id = 323339 and qrcode_channel = 821;
delete from qrcode_statistics where id = 323470 and qrcode_channel = 1008;
delete from qrcode_statistics where qrcode_channel = 1014;
delete from qrcode_statistics where qrcode_channel = 1019;
delete from qrcode_statistics where qrcode_channel = 1020;
delete from qrcode_statistics where qrcode_channel = 1022;
delete from qrcode_statistics where qrcode_channel = 1024;
delete from qrcode_statistics where qrcode_channel = 1025;
delete from qrcode_statistics where qrcode_channel = 1026;
delete from qrcode_statistics where qrcode_channel = 1028;
-- -----------------------------------------------------------------------------------------------------------
-- 修改编号长度不为10的渠道编号
update qrcode_channel set code = CONCAT(left(code, 2), '0', right(code, 7)) where length(code) = 9;
-- -----------------------------------------------------------------------------------------------------------
-- 未整理二维码渠道添加备注
update qrcode_channel qc set comment = CONCAT(qc.comment, ',该渠道数据未整理'), qc.update_time = now()
where qc.id in (944,1029,2085,109,692,1018,2081,2082,2078,2080,2086,1006,2079,2077,2083,2084,1009,1010,1033,3,1005,1015,1016,1017,1011,1013,1030,1012);
