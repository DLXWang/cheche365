-- 将gift_code列数据合并至source(新增兑换码来源 source_type=4)
update gift
set source_type = 4, source=gift_code
where gift_code is not null and source_type is null and source is null;

-- 将gift_code列去掉
ALTER TABLE `gift` DROP FOREIGN KEY  `FK_GIFT_REF_GIFT_CODE`;
ALTER TABLE `gift` DROP COLUMN `gift_code`;
