update `marketing`
set `end_date` =  '2016-01-10 23:59:59'
where id = 18 or id = 19;
