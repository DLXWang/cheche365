update `marketing`
set channel = null
where channel is not null;

 INSERT INTO `marketing` (`id`, `name`, `code`, `begin_date`, `end_date`, `gift_expire_date`,
 `channel`, `amount`,
 `gift_class`,
 `full_limit`,
 `marketing_type`, `quote_support`,`short_name`, `description`) VALUES
 (24, '支付宝满额减活动', '201512006', '2015-12-29 00:00:00', '2016-01-10 23:59:59', '2016-06-30 23:59:59',
  '10', '50;100;150;200;250;300;350;400;450;500;550;600;650;700;750;800;850;900;950;1000',
  'com.cheche365.cheche.core.service.market.JsonParamConvertor',
  '50_1000;100_2000;150_3000;200_4000;250_5000;300_6000;350_7000;400_8000;450_9000;500_10000;550_11000;600_12000;650_13000;700_14000;750_15000;800_16000;850_17000;900_18000;950_19000;1000_20000',
  'm', '0', '支付宝满额减活动', '支付宝满额减活动');
