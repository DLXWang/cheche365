ALTER TABLE quote_record ADD COLUMN channel bigint(20) default null;
ALTER TABLE `quote_record` ADD CONSTRAINT `FK_QUOTE_RECORD_REF_CHANNEL` FOREIGN KEY (`channel`) REFERENCES `channel` (`id`);
