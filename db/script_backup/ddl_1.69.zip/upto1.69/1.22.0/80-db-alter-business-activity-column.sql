alter table business_activity modify column email varchar(200) DEFAULT NULL;
