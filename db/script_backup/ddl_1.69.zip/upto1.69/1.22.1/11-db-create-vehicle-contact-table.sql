INSERT INTO `tel_marketing_center_source` (`id`, `description`, `name`) VALUES ('41', '人工导入', '人工导入');

CREATE TABLE IF NOT EXISTS `vehicle_contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mobile` varchar(50) DEFAULT NULL,
  `vehicle_license` int(11) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_VEHICLE_CONTACT_REF_VEHICLE_LICENSE` (`vehicle_license`),
  KEY `IDX_VEHICLE_CONTACT_MOBILE` (`mobile`),
  KEY `IDX_VEHICLE_CONTACT_CREATE_TIME` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

ALTER TABLE vehicle_license ADD COLUMN identity varchar(45) default null;
