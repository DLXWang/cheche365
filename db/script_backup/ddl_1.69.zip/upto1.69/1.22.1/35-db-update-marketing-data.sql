update marketing set channel = '10;12' where code = '201512006';
