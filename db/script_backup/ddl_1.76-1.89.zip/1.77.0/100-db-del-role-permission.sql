delete from role_permission where role is null;
