UPDATE user u
SET u.bound = 1, u.register_channel = 11, u.source_type = 6, u.name = '董旭威', u.gender = 1
WHERE u.id = 343504;

UPDATE address a
SET a.name = '董旭威', a.applicant = 343504, a.update_time = '2017-10-17 00:00:00'
WHERE a.name LIKE '%线下数据导入默认地址%';




