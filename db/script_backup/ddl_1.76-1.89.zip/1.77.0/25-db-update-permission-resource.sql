DELETE from permission_resource where id in (171,172);
delete from role_permission where permission in (185,186);
DELETE from permission where id in (185,186);
DELETE from resource where id in (101,102);


INSERT INTO `permission` (`id`, `description`, `name`, `type`, `permission_type`, `code`, `level`) VALUES ('185', '电销中心/电话管理/意向客户/呼叫', '天润呼叫', '2', '1', 'or060104', '0');
INSERT INTO `permission_resource` (`id`, `permission`, `resource`) VALUES ('171', '185', '48');


INSERT INTO `permission` (`id`, `description`, `name`, `type`, `permission_type`, `code`, `level`) VALUES ('186', '电销中心/电话管理/电话客服管理', '电话客服管理', '2', '1', 'or0606', '0');
INSERT INTO `resource` (`id`, `name`, `parent`, `resource_type`, `level`) VALUES ('101', '电话客服管理', '47', '1', '3');
INSERT INTO `permission_resource` (`id`, `permission`, `resource`) VALUES ('172', '186', '101');


INSERT INTO permission (id, description, name, type, permission_type, code, level) VALUES (187, '出单中心/礼物订单管理/保单导入', '保单导入', 2, 1, 'or0804', 0);
INSERT INTO resource (id, name, parent, resource_type, level) VALUES (102, '礼物订单管理-保单导入', 64, 1, 3);
INSERT INTO permission_resource (id, permission, resource) VALUES (173, 187, 102);
