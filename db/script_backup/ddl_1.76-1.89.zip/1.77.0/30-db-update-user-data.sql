UPDATE `user` SET gender = (2-SUBSTRING(identity,17,1)%2) WHERE LENGTH(identity) = 18;
UPDATE `user` SET gender = (2-SUBSTRING(identity,15,1)%2) WHERE LENGTH(identity) = 15;
