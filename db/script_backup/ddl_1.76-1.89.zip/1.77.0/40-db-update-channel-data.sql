UPDATE channel SET tag=3073 WHERE id=3;
UPDATE channel SET tag=1057 WHERE id=4;
UPDATE channel SET tag=1057 WHERE id=6;
UPDATE channel SET tag=1025 WHERE id=8;
UPDATE channel SET tag=1 WHERE id=21;
UPDATE channel SET tag=2049 WHERE id=39;
