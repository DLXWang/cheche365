UPDATE channel SET tag=1025 WHERE id=21;
UPDATE channel SET tag=3073 WHERE id=39;
