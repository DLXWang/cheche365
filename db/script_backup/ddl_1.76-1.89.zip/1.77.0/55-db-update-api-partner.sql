UPDATE `api_partner` SET `description`='飞凡' WHERE `id`='40';
UPDATE `channel` SET `description`='飞凡' WHERE `id`='97';
UPDATE `channel` SET `description`='飞凡-出单中心' WHERE `id`='98';
