INSERT INTO `api_partner_properties` (`partner`, `key`, `value`) VALUES ('39', 'sync.enable.buffering', 'TRUE');
