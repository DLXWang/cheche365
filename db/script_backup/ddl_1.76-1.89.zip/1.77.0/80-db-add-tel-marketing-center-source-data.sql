INSERT INTO `tel_marketing_center_source` (`id`, `description`, `name`, `enable`, `type`) VALUES ('169', '双11活动_官网', 'MARKETING_201711001', '1', '2');
