update sys_version set channel = 6 where channel = 4 AND version = '2.1.2';
