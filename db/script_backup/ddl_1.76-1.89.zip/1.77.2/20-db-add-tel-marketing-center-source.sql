INSERT INTO `tel_marketing_center_source` (`id`, `description`, `name`, `enable`, `type`) VALUES ('170', '双11活动_车主无忧', 'MARKETING_201711002', '1', '2');
INSERT INTO `tel_marketing_center_source` (`id`, `description`, `name`, `enable`, `type`) VALUES ('171', '双11活动_快钱', 'MARKETING_201711003', '1', '2');
INSERT INTO `tel_marketing_center_source` (`id`, `description`, `name`, `enable`, `type`) VALUES ('172', '双11活动_途虎', 'MARKETING_201711004', '1', '2');
INSERT INTO `tel_marketing_center_source` (`id`, `description`, `name`, `enable`, `type`) VALUES ('173', '双11活动_PC', 'MARKETING_201711005', '1', '2');
