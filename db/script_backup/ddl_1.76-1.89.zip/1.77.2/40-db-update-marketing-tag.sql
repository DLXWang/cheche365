UPDATE marketing SET tag=6 WHERE id=101;
