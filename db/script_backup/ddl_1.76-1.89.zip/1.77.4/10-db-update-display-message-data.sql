UPDATE display_message SET title='官网首页背景图', url = null, icon_url = 'banner/top-banner6.jpg', version = 28 WHERE id = 11;
