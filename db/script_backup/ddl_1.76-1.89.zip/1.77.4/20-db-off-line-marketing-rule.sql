update marketing_rule set status =3 where insurance_company=10000  and status =2 and channel in (3,4,6,8,21,39,48);
