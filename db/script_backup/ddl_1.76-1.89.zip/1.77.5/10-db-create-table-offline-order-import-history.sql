CREATE TABLE `offline_order_import_history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `start_time` datetime DEFAULT NULL COMMENT '开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '结束时间',
  `operator` bigint(20) DEFAULT NULL COMMENT '操作人',
  `create_time` datetime DEFAULT NULL COMMENT '上传时间',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  `file_path` varchar(150)  DEFAULT NULL COMMENT '上传文件路径',
  `success_path` varchar(150) DEFAULT NULL COMMENT '成功文件路径',
  `failed_path` varchar(150) DEFAULT NULL COMMENT '失败文件路径',
  `status` tinyint(1) NOT NULL COMMENT '状态',
  `comment` varchar(200) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`),
  KEY `FK_OFFLINE_ORDER_IMPORT_HISTORY_REF_INTERNAL_USER` (`operator`) USING BTREE,
  CONSTRAINT `OFFLINE_ORDER_IMPORT_HISTORY_IBFK_2` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;
