INSERT INTO payment_channel (id, name, customer_pay, description) VALUES (19, 'offlinepay', 1, '线下支付');
