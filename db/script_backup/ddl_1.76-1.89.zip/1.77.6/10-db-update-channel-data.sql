update channel set tag = tag -512 where id =15;
