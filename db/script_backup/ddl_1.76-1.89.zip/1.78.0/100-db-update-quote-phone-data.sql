UPDATE quote_phone SET identity_type = 1 WHERE identity_type IS NULL;
UPDATE quote_phone SET insured_id_type = 1 WHERE insured_id_type IS NULL;
UPDATE quote_photo SET identity_type = 1 WHERE identity_type IS NULL;
UPDATE quote_photo SET insured_id_type = 1 WHERE insured_id_type IS NULL;
