INSERT INTO log_type (`name`, `description`) VALUES ('免费领取意外险', '免费领取意外险活动');
