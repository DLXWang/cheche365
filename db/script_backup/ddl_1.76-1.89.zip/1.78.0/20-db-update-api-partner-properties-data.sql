UPDATE `api_partner_properties` SET `value`='http://test.tnhdfwh.rxdai.com/cccx-callback/api/v1/order/save' WHERE `partner` = '39' AND `key` = 'sync.order.url';
