ALTER TABLE `compulsory_insurance` ADD COLUMN `stamp`  varchar(200) NULL ;

