ALTER TABLE `quote_supplement_info`
CHANGE COLUMN `value` `value` TEXT NULL DEFAULT NULL;

