ALTER TABLE `insurance`
ADD COLUMN `applicant_identity_type`  bigint NULL DEFAULT 1 AFTER `applicant_id_no`,
ADD COLUMN `insured_identity_type`  bigint NULL DEFAULT 1 AFTER `insured_id_no`;

ALTER TABLE `insurance` ADD CONSTRAINT `FK_INSURANCE_APPLICANT_REF_IDENTITY_TYPE` FOREIGN KEY (`applicant_identity_type`) REFERENCES `identity_type` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `insurance` ADD CONSTRAINT `FK_INSURANCE_INSURED_REF_IDENTITY_TYPE` FOREIGN KEY (`insured_identity_type`) REFERENCES `identity_type` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


ALTER TABLE `compulsory_insurance`
ADD COLUMN `applicant_identity_type`  bigint NULL DEFAULT 1 AFTER `applicant_id_no`,
ADD COLUMN `insured_identity_type`  bigint NULL DEFAULT 1 AFTER `insured_id_no`;

ALTER TABLE `compulsory_insurance` ADD CONSTRAINT `FK_COMPULSORY_INSURANCE_APPLICANT_REF_IDENTITY_TYPE` FOREIGN KEY (`applicant_identity_type`) REFERENCES `identity_type` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `compulsory_insurance` ADD CONSTRAINT `FK_COMPULSORY_INSURANCE_INSURED_REF_IDENTITY_TYPE` FOREIGN KEY (`insured_identity_type`) REFERENCES `identity_type` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

