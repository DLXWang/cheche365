INSERT INTO `identity_type` (`id`, `description`, `name`) VALUES ('11', '组织机构代码', '组织机构代码');
INSERT INTO `identity_type` (`id`, `description`, `name`) VALUES ('12', '工商注册号码', '工商注册号码');
INSERT INTO `identity_type` (`id`, `description`, `name`) VALUES ('13', '统一社会信用代码', '统一社会信用代码');
