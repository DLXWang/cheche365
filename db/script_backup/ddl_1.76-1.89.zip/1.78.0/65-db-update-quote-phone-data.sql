ALTER TABLE `quote_phone`
ADD COLUMN `identity_type`  bigint NULL AFTER `owner`,
ADD COLUMN `insured_id_type`  bigint NULL AFTER `insured_name`;
ALTER TABLE `quote_phone` ADD CONSTRAINT `fk_quote_phone_identity_type_ref_identity_type` FOREIGN KEY (`identity_type`) REFERENCES `identity_type` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE `quote_phone` ADD CONSTRAINT `fk_quote_phone_insured_id_type_ref_identity_type` FOREIGN KEY (`insured_id_type`) REFERENCES `identity_type` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `quote_photo`
ADD COLUMN `identity_type`  bigint NULL AFTER `owner`,
ADD COLUMN `insured_id_type`  bigint NULL AFTER `insured_name`;
ALTER TABLE `quote_photo` ADD CONSTRAINT `fk_quote_photo_identity_type_ref_identity_type` FOREIGN KEY (`identity_type`) REFERENCES `identity_type` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;
ALTER TABLE `quote_photo` ADD CONSTRAINT `fk_quote_photo_insured_id_type_ref_identity_type` FOREIGN KEY (`insured_id_type`) REFERENCES `identity_type` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;
