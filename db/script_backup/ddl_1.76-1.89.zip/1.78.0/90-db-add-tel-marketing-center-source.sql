INSERT INTO `tel_marketing_center_source` (`id`, `description`, `name`, `enable`, `type`) VALUES ('175', '太平洋返现', 'MARKETING_201711006', '1', '2');
