update marketing set begin_date='2017-11-22 00:00:00' where id ='102';
