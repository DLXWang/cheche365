INSERT INTO `auto_vehicle_license_service_item` (`service_name`, `priority`, `disable`) VALUES ('bihu', '1', '0');
