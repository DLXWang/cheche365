INSERT INTO `log_type` (`name`, `description`) VALUES ('BIHU', '壁虎');
