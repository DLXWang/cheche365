DELETE FROM `api_partner_properties` WHERE `partner` = '39' AND `key` = 'sync.enable.buffering';
INSERT INTO `api_partner_properties` (`partner`, `key`, `value`) VALUES ('39', 'sync.enable.buffering', 'TRUE');

INSERT INTO `api_partner_properties` (`partner`, `key`, `value`) VALUES ('39', 'production.sync.sign.method', 'HMAC-SHA1');
INSERT INTO `api_partner_properties` (`partner`, `key`, `value`) VALUES ('39', 'production.sync.app.id', 'a0e1605f');
INSERT INTO `api_partner_properties` (`partner`, `key`, `value`) VALUES ('39', 'production.sync.app.secret', '143b-42ad-a523-f6a43ab7905b');
INSERT INTO `api_partner_properties` (`partner`, `key`, `value`) VALUES ('39', 'production.sync.order.url', 'http://pre-tnhdfwh.touna.cn/cheche/api/v1/order/save');
INSERT INTO `api_partner_properties` (`partner`, `key`, `value`) VALUES ('39', 'production.sync.enable.buffering', 'TRUE');
