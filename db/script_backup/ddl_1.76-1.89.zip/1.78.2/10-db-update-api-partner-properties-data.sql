UPDATE `api_partner_properties` SET `value`='http://daibafwh.touna.cn/cheche/api/v1/order/save' WHERE `partner` = '39' AND `key` = 'production.sync.order.url';
