INSERT INTO `sys_version` (`channel`, `version`, `update_advice`, `reason`) VALUES
('4', '2.1.6', 'required', '有新版本上线啦！优化程序稳定性，更新icon和引导页,快去更新最新版本吧。');
