UPDATE `marketing` SET `name`='SEM111', `short_name`='SEM111' WHERE `code`='201712011';
UPDATE `marketing` SET `name`='SEM222', `short_name`='SEM222' WHERE `code`='201712012';
UPDATE `marketing` SET `name`='SEM333', `short_name`='SEM333' WHERE `code`='201712013';
UPDATE `marketing` SET `name`='SEM444', `short_name`='SEM444' WHERE `code`='201712014';
UPDATE `marketing` SET `name`='SEM555', `short_name`='SEM555' WHERE `code`='201712015';
UPDATE `marketing` SET `name`='SEM666', `short_name`='SEM666' WHERE `code`='201712016';
UPDATE `marketing` SET `name`='SEM777', `short_name`='SEM777' WHERE `code`='201712017';
UPDATE `marketing` SET `name`='SEM888', `short_name`='SEM888' WHERE `code`='201712018';
