update channel set tag = tag -1536 where id =84;
