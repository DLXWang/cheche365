update message_type set type ='HOME_COMPANY',description='首页保险公司列表',name='首页保险公司列表' where id ='18';
DELETE from message_type where id in ('19','20');
INSERT INTO `message_type` (`id`, `type`, `description`, `name`) VALUES ('19', 'HOME_TOP_IMAGE', '首页背景图新版', '首页背景图新版');
