INSERT INTO `api_partner` (`id`, `code`, `app_id`, `app_secret`, `tag`, `description`) VALUES ('41', 'cx580', '', '', '132', '车行易');
INSERT INTO `channel` (`id`, `name`, `tag`, `parent`, `api_partner`, `icon`, `description`) VALUES ('99', 'PARTNER_CX580', '2', '99', '41', 'cx580.png', '车行易');
INSERT INTO `channel` (`id`, `name`, `tag`, `parent`, `api_partner`, `icon`, `description`) VALUES ('100', 'ORDER_CENTER_CX580', NULL, '99', '41', 'cx580.png', '车行易-出单中心');
