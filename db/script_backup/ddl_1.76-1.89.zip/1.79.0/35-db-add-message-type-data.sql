INSERT INTO `message_type` (`id`, `type`, `description`, `name`) VALUES ('28', 'TK_DISCOUNT', '淘客打折产品', '淘客打折产品');
