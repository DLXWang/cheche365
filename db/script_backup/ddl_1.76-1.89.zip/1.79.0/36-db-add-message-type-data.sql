INSERT INTO `message_type` (`id`, `type`, `description`, `name`) VALUES ('29', 'HOME_BOTTOM', 'm站底部监管备案', 'm站底部监管备案');
