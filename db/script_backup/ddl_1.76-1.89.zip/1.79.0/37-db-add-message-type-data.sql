INSERT INTO `message_type` (`id`, `type`, `description`, `name`) VALUES ('30', 'CO_NEW', '新版合作运营', '新版合作运营');
