INSERT INTO `api_partner` (`id`, `code`, `app_id`, `app_secret`, `tag`, `description`) VALUES ('42', 'sinopaypal', '', '', '196', '钱喵');
INSERT INTO `channel` (`id`, `name`, `tag`, `parent`, `api_partner`, `icon`, `description`) VALUES ('104', 'PARTNER_SINOPAYPAL', '2', '104', '42', 'sinopaypal.png', '钱喵');
INSERT INTO `channel` (`id`, `name`, `tag`, `parent`, `api_partner`, `icon`, `description`) VALUES ('105', 'ORDER_CENTER_SINOPAYPAL', NULL, '104', '42', 'sinopaypal.png', '钱喵-出单中心');
INSERT INTO `api_partner_properties` (`partner`, `key`, `value`) VALUES ('42', 'sync.sign.method', 'HMAC-SHA1');
INSERT INTO `api_partner_properties` (`partner`, `key`, `value`) VALUES ('42', 'sync.app.id', '5c9de2ed');
INSERT INTO `api_partner_properties` (`partner`, `key`, `value`) VALUES ('42', 'sync.app.secret', '7a3f-4eed-811a-0e6d3cf8713c');
INSERT INTO `api_partner_properties` (`partner`, `key`, `value`) VALUES ('42', 'sync.order.url', '');
