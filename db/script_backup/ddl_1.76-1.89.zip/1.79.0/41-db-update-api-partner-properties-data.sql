UPDATE `api_partner_properties` SET `value`='http://qmtest.sinopaypal.com.cn/carSteward/cheche/callback' WHERE `partner` = '42' AND `key` = 'sync.order.url';
