INSERT INTO `payment_channel` (`id`, `name`, `customer_pay`, `description`) VALUES (20, 'za', 1, '众安');

INSERT INTO `log_type` (`id`, `name`, `description`) VALUES (55, '众安支付同步通知', '众安支付同步通知');
