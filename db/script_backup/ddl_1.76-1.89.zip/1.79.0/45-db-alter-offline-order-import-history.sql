alter table offline_order_import_history add (file_name varchar(100) COMMENT '上传文件名称');
alter table offline_order_import_history add (type tinyint(1) COMMENT '文件来源');
alter table offline_order_import_history add (area BIGINT(20) COMMENT '地区');
alter table offline_order_import_history add (description varchar(150) COMMENT '描述');
alter table offline_order_import_history add constraint FK_OFFLINE_ORDER_IMPORT_HISTORY_REF_AREA foreign key (area) references area (id);
alter table offline_order_import_history add index FK_OFFLINE_ORDER_IMPORT_HISTORY_REF_AREA_INDEX (area);

update offline_order_import_history set type = 1 where type is NULL ;