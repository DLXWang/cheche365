INSERT INTO `message_type` (`id`, `type`, `description`, `name`) VALUES ('31', 'HOME_MARKETING', '首页活动', '首页活动');
