ALTER TABLE `vehicle_license`
ADD COLUMN `seats`  int(11) DEFAULT NULL,
ADD COLUMN `new_price`  decimal(18,2) DEFAULT NULL,
ADD COLUMN `license_color_code`  int(11) DEFAULT NULL,
ADD COLUMN `is_public`  int(11) DEFAULT  NULL,
ADD COLUMN `data_source`  int(11) NULL default NULL;

CREATE TABLE `vehicle_data_source` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `code` varchar(45) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO vehicle_data_source (name,code,priority) VALUES ("壁虎","BIHU",1);
INSERT INTO vehicle_data_source (name,code,priority) VALUES ("车车","CHECHE",2);
