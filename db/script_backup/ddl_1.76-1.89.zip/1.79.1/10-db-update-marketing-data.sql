update marketing set end_date = "2017-12-17 00:00:00" where code in ('201710001','201710002','201710003','201710004');
