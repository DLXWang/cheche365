update insurance_purchase_order_rebate set up_commercial_rebate=0 where up_commercial_rebate is null;
update insurance_purchase_order_rebate set up_compulsory_rebate=0 where up_compulsory_rebate is null;
