INSERT INTO `api_partner` (`id`, `code`, `app_id`, `app_secret`, `tag`, `description`) VALUES ('43', 'dongchedi', '', '', '196', '懂车帝');
INSERT INTO `channel` (`id`, `name`, `tag`, `parent`, `api_partner`, `icon`, `description`) VALUES ('106', 'PARTNER_DONGCHEDI', '2', '106', '43', 'dongchedi.png', '懂车帝');
INSERT INTO `channel` (`id`, `name`, `tag`, `parent`, `api_partner`, `icon`, `description`) VALUES ('107', 'ORDER_CENTER_DONGCHEDI', NULL, '106', '43', 'dongchedi.png', '懂车帝-出单中心');
INSERT INTO `api_partner_properties` (`partner`, `key`, `value`) VALUES ('43', 'sync.sign.method', 'HMAC-SHA1');
INSERT INTO `api_partner_properties` (`partner`, `key`, `value`) VALUES ('43', 'sync.app.id', 'bcc102ef');
INSERT INTO `api_partner_properties` (`partner`, `key`, `value`) VALUES ('43', 'sync.app.secret', 'd631-4aa9-a7b1-a44817665771');
INSERT INTO `api_partner_properties` (`partner`, `key`, `value`) VALUES ('43', 'sync.order.url', '');
