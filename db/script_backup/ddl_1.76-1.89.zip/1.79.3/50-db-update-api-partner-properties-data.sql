UPDATE `api_partner_properties` SET `value`='http://i.snssdk.com/motor/car_show/v1/post_insurance' WHERE `partner` = '43' AND `key` = 'sync.order.url';
