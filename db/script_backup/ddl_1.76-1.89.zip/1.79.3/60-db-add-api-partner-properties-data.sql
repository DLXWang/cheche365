INSERT INTO `api_partner_properties` (`partner`, `key`, `value`) VALUES ('43', 'production.sync.sign.method', 'HMAC-SHA1');
INSERT INTO `api_partner_properties` (`partner`, `key`, `value`) VALUES ('43', 'production.sync.app.id', 'bcc102ef');
INSERT INTO `api_partner_properties` (`partner`, `key`, `value`) VALUES ('43', 'production.sync.app.secret', 'd631-4aa9-a7b1-a44817665771');
INSERT INTO `api_partner_properties` (`partner`, `key`, `value`) VALUES ('43', 'production.sync.order.url', 'http://i.snssdk.com/motor/car_show/v1/post_insurance');
