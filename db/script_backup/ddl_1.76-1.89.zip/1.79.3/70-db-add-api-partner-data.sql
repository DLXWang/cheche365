INSERT INTO `api_partner` (`id`, `code`, `app_id`, `app_secret`, `tag`, `description`) VALUES ('44', 'che300', '', '', '2', '车300');
INSERT INTO `channel` (`id`, `name`, `tag`, `parent`, `api_partner`, `icon`, `description`) VALUES ('108', 'PARTNER_CHE300', '2', '108', '44', 'che300.png', '车300');
INSERT INTO `channel` (`id`, `name`, `tag`, `parent`, `api_partner`, `icon`, `description`) VALUES ('109', 'ORDER_CENTER_CHE300', NULL, '108', '44', 'che300.png', '车300-出单中心');
