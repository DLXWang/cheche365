ALTER TABLE `insurance_company` ADD COLUMN `tag` BIGINT(20) DEFAULT NULL AFTER `mobile`;

UPDATE insurance_company set tag = 1+2 where id in (10500,20500,45000);
UPDATE insurance_company set tag = 1+2+1024 where id in (40000,15000);
UPDATE insurance_company set tag = 1+2+16+1024+8192+16384+32768 where id in (65000);
UPDATE insurance_company set tag = 1+2+4+1024 where id in (10000,25000);
UPDATE insurance_company set tag = 1+2+4+8+1024 where id in (20000);
UPDATE insurance_company set tag = 1 where id in (55000);
UPDATE insurance_company set tag = 2 where id in (30000,35000,60000);
UPDATE insurance_company set tag = 8+1024 where id in (50000);

UPDATE insurance_company set tag = 512 where id in ('125000','99999999',
'99999998','99999997','160000','155000','150000','145000','140000',
'135000','130000','120000','115000','110000','105000','100000');
UPDATE insurance_company set tag = 512+1024 where id in (
'70000','95000','90000','85000','80000','75000');
