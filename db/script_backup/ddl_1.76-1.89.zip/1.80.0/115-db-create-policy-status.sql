CREATE TABLE IF NOT EXISTS `policy_status` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(2000) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;


INSERT INTO `policy_status` (`id`, `description`, `status`) VALUES
(1, '出单失败', '出单失败')
;

ALTER TABLE `purchase_order`
	ADD COLUMN `sub_status` BIGINT(20) NULL DEFAULT NULL AFTER `status`,
	ADD CONSTRAINT `FK_PURCHASE_ORDER_REF_POLICY_STATUS` FOREIGN KEY (`sub_status`) REFERENCES `policy_status` (`id`);






