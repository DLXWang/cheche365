INSERT INTO `api_partner_properties` (`partner`, `key`, `value`) VALUES ('42', 'production.sync.sign.method', 'HMAC-SHA1');
INSERT INTO `api_partner_properties` (`partner`, `key`, `value`) VALUES ('42', 'production.sync.app.id', '5c9de2ed');
INSERT INTO `api_partner_properties` (`partner`, `key`, `value`) VALUES ('42', 'production.sync.app.secret', 'f360-4b0e-8a11-5ca722504130');
INSERT INTO `api_partner_properties` (`partner`, `key`, `value`) VALUES ('42', 'production.sync.order.url', 'http://chesuixing.sinopaypal.com.cn/carSteward/cheche/callback');
