ALTER TABLE `payment`
ADD COLUMN `itp_no` VARCHAR(100) NULL DEFAULT NULL AFTER `thirdparty_payment_no`;


