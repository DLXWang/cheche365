UPDATE insurance_company set logo = "zhongan2.png" where id = 50000;
