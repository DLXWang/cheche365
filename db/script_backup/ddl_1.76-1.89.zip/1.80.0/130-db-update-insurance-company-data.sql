UPDATE insurance_company set tag = tag + 3 where id in (50000);

UPDATE insurance_company set tag = tag + 32 + 64 + 128 where id = 10000;
UPDATE insurance_company set tag = tag + 32 + 128 where id = 65000;
UPDATE insurance_company set tag = tag + 32 + 128 where id = 50000;
