ALTER  TABLE policy_status RENAME TO order_sub_status;

ALTER TABLE `purchase_order`
	DROP FOREIGN KEY `FK_PURCHASE_ORDER_REF_POLICY_STATUS`;


ALTER TABLE `purchase_order`
	ADD CONSTRAINT `FK_PURCHASE_ORDER_REF_ORDER_SUB_STATUS` FOREIGN KEY (`sub_status`) REFERENCES `order_sub_status` (`id`);

ALTER TABLE `order_sub_status`
CHANGE COLUMN `status` `name` VARCHAR(45) NULL DEFAULT NULL AFTER `id`;

update order_sub_status set name='承保失败',description='承保失败'
