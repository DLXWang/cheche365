UPDATE insurance_company set tag = tag - 32 where id = 50000;
