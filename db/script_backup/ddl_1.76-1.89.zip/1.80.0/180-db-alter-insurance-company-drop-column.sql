ALTER TABLE `insurance_company`
DROP COLUMN `non_auto_insurance`,
DROP COLUMN `alipay_support`,
DROP COLUMN `renew_support`,
DROP COLUMN `type`,
DROP COLUMN `disable`;
