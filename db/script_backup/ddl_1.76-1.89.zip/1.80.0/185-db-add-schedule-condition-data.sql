INSERT INTO schedule_condition (id, name, description) VALUES (129, 'ANSWERN_SUSPEND_BILL', '安心停驶返钱账单短信发送');
