update insurance_company set tag =(tag + 8192+16384) where id = 50000;
