UPDATE insurance_company SET description = '赔款极速到账,简单快赔,电话直赔' WHERE id = 50000;
