INSERT INTO `resource` (`id`, `name`, `parent`, `resource_type`, `level`) VALUES ('103', '小财神对账系统', '27', '1', '2');
INSERT INTO `resource` (`id`, `name`, `parent`, `resource_type`, `level`) VALUES ('104', '导入数据查询', '103', '1', '3');
INSERT INTO `resource` (`id`, `name`, `parent`, `resource_type`, `level`) VALUES ('105', '财务数据查询', '103', '1', '3');

INSERT INTO `permission` (`id`, `description`, `name`, `type`, `permission_type`, `code`, `level`) VALUES ('188', '出单中心/小财神对账系统/导入数据查询', '导入数据查询', '2', '1', 'or1301', '0');
INSERT INTO `permission` (`id`, `description`, `name`, `type`, `permission_type`, `code`, `level`) VALUES ('189', '出单中心/小财神对账系统/财务数据查询', '财务数据查询', '2', '1', 'or1302', '0');

INSERT INTO `permission_resource` (`id`, `permission`, `resource`) VALUES ('174', '188', '104');
INSERT INTO `permission_resource` (`id`, `permission`, `resource`) VALUES ('175', '189', '105');
