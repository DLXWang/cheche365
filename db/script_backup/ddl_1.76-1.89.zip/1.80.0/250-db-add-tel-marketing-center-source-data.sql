INSERT INTO `tel_marketing_center_source` (`id`, `description`, `name`, `enable`, `type`) VALUES ('186', '账单分享活动', 'MARKETING_201712006', '1', '2');
