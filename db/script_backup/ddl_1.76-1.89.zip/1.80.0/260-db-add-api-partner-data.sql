INSERT INTO `api_partner` (`id`, `code`, `app_id`, `app_secret`, `tag`, `description`) VALUES ('45', 'huolala', '', '', '2', '货拉拉');

INSERT INTO `channel` (`id`, `name`, `tag`, `parent`, `api_partner`, `icon`, `description`) VALUES ('204', 'PARTNER_HUOLALA', '2', '204', '45', 'huolala.png', '货拉拉');
INSERT INTO `channel` (`id`, `name`, `tag`, `parent`, `api_partner`, `icon`, `description`) VALUES ('205', 'ORDER_CENTER_HUOLALA', NULL, '204', '45', 'huolala.png', '货拉拉-出单中心');


