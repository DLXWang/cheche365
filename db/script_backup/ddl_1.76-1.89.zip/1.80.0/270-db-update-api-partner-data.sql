UPDATE api_partner SET tag = 16 WHERE id = 45;
