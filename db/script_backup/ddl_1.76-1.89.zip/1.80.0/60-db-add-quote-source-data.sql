INSERT INTO `quote_source` (`id`, `name`, `description`) VALUES ('9', 'AgentParser', 'AgentParser');
