UPDATE `marketing` SET `tag`='2' WHERE `id`='114';
