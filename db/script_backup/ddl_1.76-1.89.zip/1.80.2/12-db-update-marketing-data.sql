UPDATE `marketing` SET `end_date`='2018-02-11 00:00:00',`gift_expire_date`='2018-02-11 00:00:00' WHERE `id`='114';
