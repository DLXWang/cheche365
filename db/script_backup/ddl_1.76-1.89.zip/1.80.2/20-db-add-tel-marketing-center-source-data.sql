INSERT INTO `tel_marketing_center_source` (`id`, `description`, `name`, `enable`, `type`) VALUES ('187', '2018年1月抽奖活动', 'MARKETING_201801001', '1', '2');
