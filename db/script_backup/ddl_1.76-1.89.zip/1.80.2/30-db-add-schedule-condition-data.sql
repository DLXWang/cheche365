INSERT INTO `schedule_condition` (`id`, `name`, `description`) VALUES ('130', 'LUCKY_DRAW_GIFT', '2018年1月专享活动');
INSERT INTO `message_variable` (`id`, `code`, `name`, `type`, `placeholder`, `length`, `parameter`, `model_class`, `model_method`) VALUES ('38', '${gift}', '抽奖礼物', 'varchar', '请输入抽奖礼物', '18', 'gift', '', '');
