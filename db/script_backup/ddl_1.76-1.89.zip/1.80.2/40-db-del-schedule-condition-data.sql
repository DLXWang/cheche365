DELETE FROM `schedule_condition` WHERE id = 130;
DELETE FROM `message_variable` WHERE id = 38;
