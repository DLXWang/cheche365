DROP TABLE IF EXISTS `ping_plus_app`;
CREATE TABLE `ping_plus_app` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `app_id` varchar(50) DEFAULT NULL,
  `display_name` varchar(50) DEFAULT NULL,
  `user` varchar(50) DEFAULT NULL,
  `parent_app` varchar(50) DEFAULT NULL,
  `metadata` varchar(500) DEFAULT NULL,
  `description` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

DROP TABLE IF EXISTS `ping_plus_app_support`;
CREATE TABLE `ping_plus_app_support` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ping_id` varchar(50) DEFAULT NULL,
  `area` bigint(20) DEFAULT NULL,
  `insurance_company` bigint(20) DEFAULT NULL,
  `royalty_mode` varchar(50) DEFAULT NULL,
  `royalty_value`  decimal(6,2) DEFAULT '0.00',
  `refund_mode` varchar(50) DEFAULT NULL,
  `refund_value`  decimal(6,2) DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


ALTER TABLE `payment` ADD COLUMN `sub_channel`  bigint(20)  DEFAULT NULL AFTER `channel`;
ALTER TABLE `payment_channel` ADD COLUMN `parent_id`  bigint(20)  DEFAULT NULL;
INSERT INTO `payment_channel` (`id`, `name`, `customer_pay`,`description`) VALUES ('21','pingplus','1','ping++' );

INSERT INTO `payment_channel` (`name`, `customer_pay`,`description`,`parent_id`) VALUES ( 'alipay','1','支付宝','21' );
INSERT INTO `payment_channel` (`name`, `customer_pay`,`description`,`parent_id`) VALUES ( 'alipay_wap','1','支付宝','21' );
INSERT INTO `payment_channel` (`name`, `customer_pay`,`description`,`parent_id`) VALUES ( 'alipay_qr','1','支付宝','21' );
INSERT INTO `payment_channel` (`name`, `customer_pay`,`description`,`parent_id`) VALUES ( 'alipay_scan','1','支付宝','21' );
INSERT INTO `payment_channel` (`name`, `customer_pay`,`description`,`parent_id`) VALUES ( 'alipay_pc_direct','1','支付宝','21' );
INSERT INTO `payment_channel` (`name`, `customer_pay`,`description`,`parent_id`) VALUES ( 'wx','1','微信','21' );
INSERT INTO `payment_channel` (`name`, `customer_pay`,`description`,`parent_id`) VALUES ( 'wx_pub','1','微信','21' );
INSERT INTO `payment_channel` (`name`, `customer_pay`,`description`,`parent_id`) VALUES ( 'wx_wap','1','微信','21' );
INSERT INTO `payment_channel` (`name`, `customer_pay`,`description`,`parent_id`) VALUES ( 'wx_lite','1','微信','21' );
INSERT INTO `payment_channel` (`name`, `customer_pay`,`description`,`parent_id`) VALUES ( 'wx_pub_qr','1','微信','21' );
INSERT INTO `payment_channel` (`name`, `customer_pay`,`description`,`parent_id`) VALUES ( 'wx_pub_scan','1','微信','21' );
INSERT INTO `payment_channel` (`name`, `customer_pay`,`description`,`parent_id`) VALUES ( 'qpay','1','QQ','21' );
INSERT INTO `payment_channel` (`name`, `customer_pay`,`description`,`parent_id`) VALUES ( 'qpay_pub','1','QQ','21' );
INSERT INTO `payment_channel` (`name`, `customer_pay`,`description`,`parent_id`) VALUES ( 'upacp','1','银联','21' );
INSERT INTO `payment_channel` (`name`, `customer_pay`,`description`,`parent_id`) VALUES ( 'upacp_pc','1','银联','21' );
INSERT INTO `payment_channel` (`name`, `customer_pay`,`description`,`parent_id`) VALUES ( 'upacp_wap','1','银联','21' );
INSERT INTO `payment_channel` (`name`, `customer_pay`,`description`,`parent_id`) VALUES ( 'cp_b2b','1','银联','21' );
INSERT INTO `payment_channel` (`name`, `customer_pay`,`description`,`parent_id`) VALUES ( 'applepay_upacp','1','Apple Pay','21' );
INSERT INTO `payment_channel` (`name`, `customer_pay`,`description`,`parent_id`) VALUES ( 'bfb','1','百度','21' );
INSERT INTO `payment_channel` (`name`, `customer_pay`,`description`,`parent_id`) VALUES ( 'bfb_wap','1','百度','21' );
INSERT INTO `payment_channel` (`name`, `customer_pay`,`description`,`parent_id`) VALUES ( 'jdpay_wap','1','京东','21' );
INSERT INTO `payment_channel` (`name`, `customer_pay`,`description`,`parent_id`) VALUES ( 'yeepay_wap','1','易宝','21' );
INSERT INTO `payment_channel` (`name`, `customer_pay`,`description`,`parent_id`) VALUES ( 'cmb_wallet','1','招行一网通','21' );
INSERT INTO `payment_channel` (`name`, `customer_pay`,`description`,`parent_id`) VALUES ( 'isv_qr','1','线下扫码（主扫）','21' );
INSERT INTO `payment_channel` (`name`, `customer_pay`,`description`,`parent_id`) VALUES ( 'isv_scan','1','线下扫码（被扫）','21' );
INSERT INTO `payment_channel` (`name`, `customer_pay`,`description`,`parent_id`) VALUES ( 'isv_wap','1','线下扫码（固定码）','21' );
INSERT INTO `payment_channel` (`name`, `customer_pay`,`description`,`parent_id`) VALUES ( 'balance','1','余额','21' );
