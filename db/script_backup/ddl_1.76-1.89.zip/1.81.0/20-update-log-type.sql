UPDATE log_type SET `name`='order_related', `description`='订单相关日志' WHERE `id`='3';
