alter table payment_channel add COLUMN logo_url VARCHAR(100);

update payment_channel set logo_url='paymentChannel/alipay.png' where id in ('1','22','23','24','25','26');
update payment_channel set logo_url='paymentChannel/ipay.png' where id in ('14','39');
update payment_channel set logo_url='paymentChannel/offline.png' where id in ('5','6','19','45','46','47');
update payment_channel set logo_url='paymentChannel/umf.png' where id in ('17');
update payment_channel set logo_url='paymentChannel/union.png' where id in ('3','35','36','37','38');
update payment_channel set logo_url='paymentChannel/wechat.png' where id in ('4','27','28','29','30','31','32');
