UPDATE insurance_company set tag = tag + 256 where id in (45000, 50000, 55000, 65000);
