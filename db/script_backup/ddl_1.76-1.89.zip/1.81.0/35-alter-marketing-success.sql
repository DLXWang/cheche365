alter table marketing_success add owner VARCHAR(45) DEFAULT null AFTER source_channel;
