INSERT INTO `identity_type` (`id`, `description`, `name`) VALUES ('14', '港澳通行证', '港澳通行证');
INSERT INTO `identity_type` (`id`, `description`, `name`) VALUES ('15', '台湾通行证', '台湾通行证');
