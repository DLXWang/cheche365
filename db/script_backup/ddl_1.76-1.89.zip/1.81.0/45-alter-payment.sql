alter table payment drop COLUMN sub_channel;
