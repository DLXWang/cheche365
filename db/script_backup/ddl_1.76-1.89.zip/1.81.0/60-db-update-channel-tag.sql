update channel set tag = tag + 4096 where id in (67,68);
