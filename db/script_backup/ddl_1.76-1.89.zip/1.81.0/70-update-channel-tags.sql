update channel set tag = (tag | (1<<6)) where id in (23,48,61,88);
update channel set tag = 1 where id = 5;
