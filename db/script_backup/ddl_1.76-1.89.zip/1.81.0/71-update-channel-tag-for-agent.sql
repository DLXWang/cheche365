update channel set tag = (tag | (1<<6)) where id in (63,65);
