update channel set tag = (tag | (1<<6)) where parent in (9,10,13,19,23,27,29,30,33,35,37,44,45,48,50,61,63,65,71,72,73,83,88,94) and tag is not null;
update channel set tag = (1<<6) where parent in (9,10,13,19,23,27,29,30,33,35,37,44,45,48,50,61,63,65,71,72,73,83,88,94) and tag is  null;
