update channel set tag= (1<<3) where id=87
