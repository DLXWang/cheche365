INSERT INTO `quote_source` (`id`, `name`, `description`) VALUES ('10', 'PLANTFORM_BX_V2', '泛华先核保');
UPDATE `quote_source` SET `name`='PLANTFORM_BX_V1', `description`='泛华先支付' WHERE `id`='6';
