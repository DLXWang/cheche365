DELETE FROM `quote_source` WHERE `id`='10';
UPDATE `quote_source` SET `name`='PLANTFORM_BX', `description`='泛华报价' WHERE `id`='6';
