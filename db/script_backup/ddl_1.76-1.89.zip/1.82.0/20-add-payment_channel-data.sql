INSERT INTO `payment_channel` (`id`, `name`, `customer_pay`, `description`, `parent_id`, `logo_url`) VALUES (49, 'sinosafe', 1, '华安', 49, NULL);
