CREATE TABLE `mobile_source_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

INSERT INTO mobile_source_type(id,description)  VALUES('1','第三方跳转链接带过来的手机号');

ALTER TABLE user_login_info add mobile_source_type BIGINT(20);
ALTER TABLE user_login_info ADD CONSTRAINT mobile_source_type FOREIGN KEY (mobile_source_type) REFERENCES mobile_source_type(id);

