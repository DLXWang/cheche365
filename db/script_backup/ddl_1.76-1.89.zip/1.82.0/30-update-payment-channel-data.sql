DELETE from payment_channel where parent_id =21 and id not in ('22','27','35');
update payment_channel set id =23 where id =27;
update payment_channel set id =24 where id =35;

CREATE TABLE `ping_plus_channel_name` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `payment_channel` bigint(20) NOT NULL,
  `channel` bigint(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_PP_PC_ID` (`payment_channel`),
  KEY `FK_PP_CHANNEL_ID` (`channel`),
  CONSTRAINT `FK_PP_PC_ID` FOREIGN KEY (`channel`) REFERENCES `channel` (`id`),
  CONSTRAINT `FK_PP_CHANNEL_ID` FOREIGN KEY (`payment_channel`) REFERENCES `payment_channel` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


INSERT into ping_plus_channel_name(payment_channel,channel,name) VALUES('23','3','wx_pub');
INSERT into ping_plus_channel_name(payment_channel,channel,name) VALUES('24','3','upacp_wap');
INSERT into ping_plus_channel_name(payment_channel,channel,name) VALUES('22','4','alipay');
INSERT into ping_plus_channel_name(payment_channel,channel,name) VALUES('23','4','wx');
INSERT into ping_plus_channel_name(payment_channel,channel,name) VALUES('24','4','upacp');
INSERT into ping_plus_channel_name(payment_channel,channel,name) VALUES('22','6','alipay');
INSERT into ping_plus_channel_name(payment_channel,channel,name) VALUES('23','6','wx');
INSERT into ping_plus_channel_name(payment_channel,channel,name) VALUES('24','6','upacp');
INSERT into ping_plus_channel_name(payment_channel,channel,name) VALUES('22','8','alipay_wap');
INSERT into ping_plus_channel_name(payment_channel,channel,name) VALUES('23','8','wx_wap');
INSERT into ping_plus_channel_name(payment_channel,channel,name) VALUES('24','8','upacp_wap');
INSERT into ping_plus_channel_name(payment_channel,channel,name) VALUES('22','21','alipay_wap');
INSERT into ping_plus_channel_name(payment_channel,channel,name) VALUES('23','39','wx_lite');
