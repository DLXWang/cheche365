UPDATE insurance_company SET logo = 'sinosafe.png', mobile = '10100111', website_url = 'https://www.sinosafe.com.cn/', description = '5千以下当天赔付,30分钟到理赔现场,先付款再修车', rank = 22 WHERE id = 205000;
