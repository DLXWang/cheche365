alter table marketing_success add column status tinyint(4);
