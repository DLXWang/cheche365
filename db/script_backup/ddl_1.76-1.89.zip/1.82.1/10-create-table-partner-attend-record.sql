create table `partner_user_extend`(
	 `id` BIGINT(20) not null AUTO_INCREMENT,
	 `partner_user` BIGINT(20) not null,
	 `object_table` VARCHAR(30) not null,
	 `object_id` BIGINT(20) not null,
	  PRIMARY KEY (`id`),
	  CONSTRAINT `PAR_PAR_ID` FOREIGN KEY (`partner_user`) REFERENCES `partner_user` (`id`)

)ENGINE = INNODB DEFAULT CHARSET = utf8mb4;
