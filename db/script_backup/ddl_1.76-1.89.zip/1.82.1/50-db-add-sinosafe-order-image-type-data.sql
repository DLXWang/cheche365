INSERT INTO `purchase_order_image_scene` (`id`, `name`, `cs_ignore`) VALUES
('7', '华安核保', '1');

INSERT INTO `purchase_order_image_type` (`id`, `name`, `parent_id`,  `sample_url`, `reusable`, `external_type`) VALUES
('5000', '华安验车照片', '0', NULL, 0, NULL);

INSERT INTO `purchase_order_image_scene_type` (`image_scene`, `image_type`) VALUES
('7', '5000');

INSERT INTO `purchase_order_image_type` (`id`, `name`, `parent_id`,  `sample_url`, `reusable`, `external_type`) VALUES
('5001', '车辆前左45°', 5000, 'sampleUrl/car_forward_left.png', 0, NULL);
INSERT INTO `purchase_order_image_type` (`id`, `name`, `parent_id`,  `sample_url`, `reusable`, `external_type`) VALUES
('5002', '车辆前右45°', 5000, 'sampleUrl/car_forward_rigth.png', 0, NULL);
INSERT INTO `purchase_order_image_type` (`id`, `name`, `parent_id`,  `sample_url`, `reusable`, `external_type`) VALUES
('5003', '车辆后左45°', 5000, 'sampleUrl/car_back_left.png', 0, NULL);
INSERT INTO `purchase_order_image_type` (`id`, `name`, `parent_id`,  `sample_url`, `reusable`, `external_type`) VALUES
('5004', '车辆后右45°', 5000, 'sampleUrl/car_back_rigth.png', 0, NULL);
INSERT INTO `purchase_order_image_type` (`id`, `name`, `parent_id`,  `sample_url`, `reusable`, `external_type`) VALUES
('5005', '车架号与带日期报纸或小票合照', 5000, 'sampleUrl/car_no.png', 0, NULL);
INSERT INTO `purchase_order_image_type` (`id`, `name`, `parent_id`,  `sample_url`, `reusable`, `external_type`) VALUES
('5006', '人、车、地标建筑物合影', 5000, 'sampleUrl/car_owner_building.png', 0, NULL);
