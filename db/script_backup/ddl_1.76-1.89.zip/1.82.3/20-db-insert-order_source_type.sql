INSERT INTO `order_source_type` (`id`, `name`, `description`) VALUES ('7', '泛华接口', '泛华接口');
