UPDATE `insurance_company` SET `logo`='answern7.png' WHERE `id`='65000';
