INSERT INTO `quote_source` (`id`, `name`, `description`) VALUES ('10', 'PLATFORM_BIHU', '壁虎报价');
