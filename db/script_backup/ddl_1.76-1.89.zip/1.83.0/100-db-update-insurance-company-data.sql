update insurance_company set rank = 22, slogan = '先赔款再修车', description = '快易赔,万元以下八小时赔付,全国通赔,修车无差价' where id = 30000;
update insurance_company set rank = 24, logo = 'ccic.png', slogan = '365天×24小时非事故道路救援', description = '全国通赔就近理赔,万元以下当天赔付,酒后代驾' where id = 240000;
update insurance_company set rank = 26 where id = 55000;
update insurance_company set rank = 28, slogan = '免上门,免等待,免垫付', description = '免理赔纸质资料,资料齐全当日赔付,免除垫付修车费用' where id = 85000;
update insurance_company set rank = 30, slogan = '7×24小时道路救援,全国通赔', description = '7×24小时道路救援,万元以下当天赔付' where id = 95000;
update insurance_company set rank = 32 where id = 205000;
update insurance_company set rank = 34, logo = 'zking.png', slogan = '7×24小时服务受理', description = '7×24小时服务受理,快查勘' where id = 165000;

update insurance_company set tag = tag + 1 where tag&(1<<0) <= 0 and id in (30000,240000,55000,85000,95000,205000,165000) ;
update insurance_company set tag = tag + 2 where tag&(1<<1) <= 0 and id in (30000,240000,55000,85000,95000,205000,165000) ;
