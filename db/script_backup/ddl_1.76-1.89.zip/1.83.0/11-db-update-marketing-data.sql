UPDATE `marketing` SET `code`='201802001' WHERE `id`='115';
