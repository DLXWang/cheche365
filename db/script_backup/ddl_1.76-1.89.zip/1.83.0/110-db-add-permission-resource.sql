INSERT INTO `permission` (`id`, `description`, `name`, `type`, `permission_type`, `code`, `level`) VALUES ('190', '出单中心/订单管理/订单列表/线下支付', '线下支付', '2', '1', 'or010101', '0');
INSERT INTO `resource` (id, name, parent, resource_type, level) VALUES (106, '线下支付', 28, 1, 3);
INSERT INTO `permission_resource` (`id`, `permission`, `resource`) VALUES ('176', '190', '106');
