update insurance_company set tag = tag - 512 where tag&(1<<9) > 0 and id in (30000,240000,55000,85000,95000,205000,165000) ;

update insurance_company set tag = tag + 4096 where tag&(1<<12) <= 0 and id in (30000,240000,55000,85000,95000,205000,165000) ;

update insurance_company set slogan = '7×24小时道路救援', description = '全国通赔,7×24小时道路救援,万元以下当天赔付' where id = 95000;
