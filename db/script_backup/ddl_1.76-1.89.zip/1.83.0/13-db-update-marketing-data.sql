UPDATE `marketing` SET `name`='新年送你888元大红包，快来翻牌拼手气！', `short_name`='新年送你888元大红包，快来翻牌拼手气！' WHERE `id`='115';
