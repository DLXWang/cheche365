INSERT INTO `payment_channel` VALUES ('50', 'alipayoffline', '1', '支付宝线下支付', '19', null);
INSERT INTO `payment_channel` VALUES ('51', 'accountoffline', '1', '公户转账线下支付', '19', null);
