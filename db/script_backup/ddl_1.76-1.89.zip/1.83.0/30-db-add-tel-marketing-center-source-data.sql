INSERT INTO `tel_marketing_center_source` (`id`, `description`, `name`, `enable`, `type`) VALUES ('188', '新年送你888元大红包', 'MARKETING_201802001', '1', '2');
