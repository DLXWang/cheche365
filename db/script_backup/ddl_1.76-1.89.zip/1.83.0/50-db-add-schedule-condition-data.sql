INSERT INTO schedule_condition (id, name, description) VALUES (130, 'RENEWAL_ORDER_REMIND', '续保订单提醒短信');
