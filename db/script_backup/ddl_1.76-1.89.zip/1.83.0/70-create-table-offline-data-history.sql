CREATE TABLE `offline_data_history` (
`id` bigint (20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
`purchase_order_id` bigint(20) DEFAULT NULL COMMENT '订单Id',
`policy_no` varchar(45) DEFAULT NULL COMMENT '保单号',
`data_source` tinyint(1) NOT NULL COMMENT '数据来源 1:泛华,2:保险公司,3:泛华补充',
`history_id` BIGINT(20) not NULL COMMENT '上传批次Id',
`source_id` varchar(20) not NULL COMMENT '数据来源Id',
`data_version` char(32) DEFAULT NULL COMMENT '数据版本',
`comment` varchar(200) DEFAULT NULL COMMENT '备注',
PRIMARY KEY (`id`),
KEY `FK_PURCHASE_ORDER_ID_INDEX` (`purchase_order_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET =utf8;
