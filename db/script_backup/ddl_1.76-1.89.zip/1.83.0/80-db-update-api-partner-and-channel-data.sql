UPDATE `api_partner` SET `code`='chebaoyi' WHERE `id`='27';
UPDATE `channel` SET `name`='PARTNER_CHEBAOYI' WHERE `id`='67';
UPDATE `channel` SET `name`='ORDER_CENTER_CHEBAOYI' WHERE `id`='68';
