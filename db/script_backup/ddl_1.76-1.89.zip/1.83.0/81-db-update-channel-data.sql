UPDATE `channel` SET `tag`=(`tag` - (1 << 1) + (1 << 0)) WHERE `id`='67';
