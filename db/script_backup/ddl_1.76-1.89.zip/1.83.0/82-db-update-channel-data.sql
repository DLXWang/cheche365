UPDATE `channel` SET `tag`=(`tag` + (1 << 0)) WHERE `id`='68';
