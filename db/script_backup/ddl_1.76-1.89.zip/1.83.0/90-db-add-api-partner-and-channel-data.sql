INSERT INTO `api_partner` (`id`, `code`, `tag`, `description`) VALUES ('48', 'renrenche', '2', '人人车');
INSERT INTO `channel` (`id`, `name`, `tag`, `parent`, `api_partner`, `icon`, `description`) VALUES ('210', 'PARTNER_RENRENCHE', '4106', '210', '48', 'renrenche.png', '人人车');
INSERT INTO `channel` (`id`, `name`, `tag`, `parent`, `api_partner`, `icon`, `description`) VALUES ('211', 'ORDER_CENTER_RENRENCHE', '4104', '210', '48', 'renrenche.png', '人人车-出单中心');
