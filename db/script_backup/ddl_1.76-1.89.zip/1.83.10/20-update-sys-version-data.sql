UPDATE sys_version SET update_advice = 'option' where channel = 6 and version = '2.2.5';

