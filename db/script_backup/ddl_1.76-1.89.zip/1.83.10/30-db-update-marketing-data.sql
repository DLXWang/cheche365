UPDATE `marketing` SET `tag`=NULL WHERE `id`='118';
