INSERT INTO `api_partner` (`id`, `code`, `tag`, `description`) VALUES ('49', 'kunlun', '2', '昆仑经纪');
INSERT INTO `channel` (`id`, `name`, `tag`, `parent`, `api_partner`, `icon`, `description`) VALUES ('212', 'PARTNER_KUNLUN', '4234', '212', '49', 'kunlun.png', '昆仑经纪');
INSERT INTO `channel` (`id`, `name`, `tag`, `parent`, `api_partner`, `icon`, `description`) VALUES ('213', 'ORDER_CENTER_KUNLUN', '4232', '212', '49', 'kunlun.png', '昆仑经纪-出单中心');
