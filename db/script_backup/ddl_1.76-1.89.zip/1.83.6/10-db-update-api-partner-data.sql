UPDATE `api_partner` SET `tag`='4' WHERE `id`='49';
