UPDATE `api_partner` SET `tag`='2' WHERE `id`='49';
