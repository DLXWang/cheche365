update area set short_code = '鲁B,鲁U' where id = 370200;
update area set short_code = '鲁F,鲁Y' where id = 370600;
update area set short_code = '鲁G,鲁V' where id = 370700;
