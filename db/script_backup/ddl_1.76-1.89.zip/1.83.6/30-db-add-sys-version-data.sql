INSERT INTO `sys_version` (`channel`, `version`, `update_advice`, `reason`) VALUES
('6', '2.2.4', 'required', '有新版本上线啦！为了您投保更快捷、安全，请去更新最新版本。');
