update insurance_company set rank = 36, logo = 'ydth.png', slogan = '5千以下即时赔付', description = '小额案件快处快赔,5千以下即时赔付' where id = 220000;
