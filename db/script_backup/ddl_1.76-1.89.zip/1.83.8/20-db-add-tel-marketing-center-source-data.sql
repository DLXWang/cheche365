INSERT INTO `tel_marketing_center_source` (`id`, `description`, `name`, `enable`, `type`) VALUES ('189', '3.15来了7家大牌车险买贵必赔', 'MARKETING_201803001', '1', '2');
INSERT INTO `tel_marketing_center_source` (`id`, `description`, `name`, `enable`, `type`) VALUES ('190', '途虎3月活动', 'MARKETING_201803002', '1', '2');
