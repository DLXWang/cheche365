UPDATE `api_partner_properties` SET `value`='http://qmtest.sinopaypal.cn/carSteward/cheche/callback' WHERE `partner` = '42' AND `key`='sync.order.url';
UPDATE `api_partner_properties` SET `value`='http://chesuixing.sinopaypal.cn/carSteward/cheche/callback' WHERE `partner` = '42' AND `key`='production.sync.order.url';
