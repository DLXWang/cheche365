INSERT INTO `order_source_type` (`id`, `name`, `description`) VALUES (8, '金斗云', '金斗云');
