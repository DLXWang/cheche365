INSERT INTO `payment_channel` (`id`, `name`, `customer_pay`, `description`, `parent_id`, `logo_url`) VALUES (52, 'botpy', 1, '金斗云', NULL, NULL);
INSERT INTO `payment_channel` (`id`, `name`, `customer_pay`, `description`, `parent_id`, `logo_url`) VALUES (53,'alipay',1,'支付宝',52,'paymentChannel/alipay.png');
INSERT INTO `payment_channel` (`id`, `name`, `customer_pay`, `description`, `parent_id`, `logo_url`) VALUES (54,'weixin',1,'微信',52,'paymentChannel/wechat.png');
