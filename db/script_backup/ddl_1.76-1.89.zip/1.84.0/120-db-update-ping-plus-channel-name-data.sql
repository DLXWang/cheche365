update ping_plus_channel_name
set name = 'wx_wap'
where payment_channel = 23
and channel in (4,6);
