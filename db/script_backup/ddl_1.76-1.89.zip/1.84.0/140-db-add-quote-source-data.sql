INSERT INTO `quote_source` (`id`, `name`, `description`) VALUES ('11', 'PLATFORM_BOTPY', '金斗云报价');
