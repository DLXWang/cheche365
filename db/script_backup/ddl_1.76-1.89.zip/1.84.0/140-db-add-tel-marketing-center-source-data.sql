INSERT INTO `tel_marketing_center_source` (`id`, `description`, `name`, `enable`, `type`) VALUES ('191', '300元代金券活动', 'MARKETING_201803003', '1', '2');
INSERT INTO `tel_marketing_center_source` (`id`, `description`, `name`, `enable`, `type`) VALUES ('192', '渠道意外险活动', 'MARKETING_201803004', '1', '2');
INSERT INTO `tel_marketing_center_source` (`id`, `description`, `name`, `enable`, `type`) VALUES ('193', '快钱3月活动', 'MARKETING_201803005', '1', '2');
