update ping_plus_channel_name
set name = 'alipay_wap'
where payment_channel = 22
and channel in (4,6);
