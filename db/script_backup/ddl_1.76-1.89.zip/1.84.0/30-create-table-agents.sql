create table agent_level (
	id BIGINT(20) NOT NULL AUTO_INCREMENT,
	is_leaf TINYINT(1),
  description varchar(10),
	PRIMARY KEY(`id`)
) ENGINE=InnoDB DEFAULT CHARSET = utf8;

create table `channel_agent`(
	`id` BIGINT(20) NOT NULL AUTO_INCREMENT,
	`user` BIGINT(20) not NULL,
	`parent` BIGINT(20),
	`channel` BIGINT(20) NOT NULL,
	`agent_level` BIGINT(20) NOT NULL,
  `agent_code` VARCHAR(100) COMMENT '如果当前是三级代理 parentId.parentId 表示 一级代理.二级代理',
	`invite_code` VARCHAR(10) NOT NULL,
	`create_time` datetime,
	`update_time` datetime,
	 PRIMARY KEY (`id`),
	 UNIQUE KEY `CHANNEL_AGENT_INVITE_CODE_UNIQUE` (`invite_code`),
	 CONSTRAINT `CHANNEL_AGENT_USER` FOREIGN KEY (`user`) REFERENCES `user` (`id`),
	 CONSTRAINT `CHANNEL_AGENT_PARENT_AGENT` FOREIGN KEY (`parent`) REFERENCES `channel_agent` (`id`),
	 CONSTRAINT `CHANNEL_AGENT_CHANNEL` FOREIGN KEY (`channel`) REFERENCES `channel` (`id`),
	 CONSTRAINT `CHANNEL_AGENT_AGENT_LEVEL` FOREIGN KEY (`agent_level`) REFERENCES `agent_level` (`id`)
)ENGINE=InnoDB DEFAULT CHARSET = utf8 COMMENT='代理人渠道关系表,不能重用agent原因是agent有许多旧数据';

create table `cheche_agent_invite_code`(
 `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
	`channel` BIGINT(20) NOT NULL,
	`invite_code` VARCHAR(20) NOT NULL,
	`channel_agent` BIGINT(20) NOT NULL,
	`create_time` datetime ,
	`enable` TINYINT(1) NOT NULL,
   PRIMARY KEY (`id`),
	UNIQUE KEY `CHECHE_AGENT_INVITE_CODE_UNIQUE` (`invite_code`),
	CONSTRAINT `CHECHE_AGENT_INVITE_CODE_CHANNEL` FOREIGN KEY (`channel`) REFERENCES `channel` (`id`),
	CONSTRAINT `CHECHE_AGENT_INVITE_CODE_CHANNEL_AGENT` FOREIGN KEY (`channel_agent`) REFERENCES `channel_agent` (`id`)
)ENGINE=InnoDB DEFAULT CHARSET = utf8;

create TABLE `channel_agent_rebate`(
		`id` BIGINT(20) NOT NULL AUTO_INCREMENT,
		`area` BIGINT(20) NOT NULL,
		`insurance_company` BIGINT(20) NOT NULL,
		`channel_agent` BIGINT(20) NOT NULL,
		`commercial_rebate` DECIMAL(18,2),
		`compulsory_rebate` DECIMAL(18,2),
		`user_commercial_rebate` DECIMAL(18,2),
		`user_compulsory_rebate` DECIMAL(18,2),
		PRIMARY KEY (`id`),
		CONSTRAINT `CHANNEL_AGENT_REBATE_AREA` FOREIGN KEY (`area`) REFERENCES `area` (`id`),
		CONSTRAINT `CHANNEL_AGENT_REBATE_INSURANCE_COMPANY` FOREIGN KEY (`insurance_company`) REFERENCES `insurance_company` (`id`),
    CONSTRAINT `CHANNEL_AGENT_REBATE_CHANNEL_AGENT` FOREIGN KEY (`channel_agent`) REFERENCES `channel_agent` (`id`)
)ENGINE=InnoDB DEFAULT CHARSET = utf8;

create TABLE `channel_agent_rebate_history`(
		`id` BIGINT(20) NOT NULL AUTO_INCREMENT,
		`area` BIGINT(20) NOT NULL,
		`insurance_company` BIGINT(20) NOT NULL,
		`channel_agent` BIGINT(20) NOT NULL,
		`commercial_rebate` DECIMAL(18,2),
		`compulsory_rebate` DECIMAL(18,2),
		`user_commercial_rebate` DECIMAL(18,2),
		`user_compulsory_rebate` DECIMAL(18,2),
		`create_time` datetime ,
		PRIMARY KEY (`id`),
		CONSTRAINT `CHANNEL_AGENT_REBATE_HISTORY_AREA` FOREIGN KEY (`area`) REFERENCES `area` (`id`),
		CONSTRAINT `CHANNEL_AGENT_REBATE_HISTORY_INSURANCE_COMPANY` FOREIGN KEY (`insurance_company`) REFERENCES `insurance_company` (`id`),
    CONSTRAINT `CHANNEL_AGENT_REBATE_HISTORY_CHANNEL_AGENT` FOREIGN KEY (`channel_agent`) REFERENCES `channel_agent` (`id`)
)ENGINE=InnoDB DEFAULT CHARSET = utf8;

create table `channel_agent_purchase_order_rebate`(
		`id` BIGINT(20) NOT NULL AUTO_INCREMENT,
		`purchase_order` BIGINT(20) NOT NULL,
		`channel_agent` BIGINT(20) NOT NULL,
		`commercial_amount` DECIMAL(18,2),
		`compulsory_amount` DECIMAL(18,2),
		`commercial_rebate` DECIMAL(18,2),
    `compulsory_rebate` DECIMAL(18,2),
		`create_time` datetime,
	  `update_time` datetime,
		`description` VARCHAR(2000),
	   PRIMARY KEY (`id`),
		 CONSTRAINT `CHANNEL_AGENT_PURCHASE_ORDER_REBATE_PURCHASE_ORDER` FOREIGN KEY (`purchase_order`) REFERENCES `purchase_order` (`id`),
		 CONSTRAINT `CHANNEL_AGENT_PURCHASE_ORDER_REBATE_CHANNEL_AGENT` FOREIGN KEY (`channel_agent`) REFERENCES `channel_agent` (`id`)
)ENGINE=INNODB DEFAULT CHARSET = utf8 COMMENT='该表是给代理人 三级代理结算的点位表 区别于 insurance_purchase_order_rebate直接都channel_rebate结算';
