insert into agent_level(`id`,`is_leaf`,`description`) VALUES(1,'0','销售总监');
insert into agent_level(`id`,`is_leaf`,`description`) VALUES(2,'0','销售经理');
insert into agent_level(`id`,`is_leaf`,`description`) VALUES(3,'1','业务员');
