INSERT INTO `payment_channel` (`id`, `name`, `customer_pay`,`description`,`parent_id`,`logo_url`) VALUES (25, 'bfb','1','百度钱包','21', 'paymentChannel/bfb.png');
INSERT into ping_plus_channel_name(payment_channel,channel,name) VALUES('25','8','bfb_wap');
