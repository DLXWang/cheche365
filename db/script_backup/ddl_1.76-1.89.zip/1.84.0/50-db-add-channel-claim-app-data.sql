INSERT INTO `channel` (`id`, `name`, `tag`, `parent`, `api_partner`, `icon`, `description`) VALUES ('214', 'CLAIM_APP', '3073', '214', NULL, NULL, '要不要赔小程序');
