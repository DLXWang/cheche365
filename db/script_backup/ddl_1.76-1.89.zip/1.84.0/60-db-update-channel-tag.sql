update channel set tag = tag - 2048 where tag & 1<<11 >0 and id = 3;
update channel set tag = tag - 1 where tag & 1<<0 >0 and id = 214;
