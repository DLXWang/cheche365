alter table cheche_agent_invite_code modify channel_agent bigint(20) null;
alter table cheche_agent_invite_code modify invite_code VARCHAR(8) not null;
alter table channel_agent modify invite_code VARCHAR(8) not null;
