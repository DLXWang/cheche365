CREATE TABLE `developer_type` (
  `id` BIGINT(20) NOT NULL,
  `name` VARCHAR(45) NOT NULL,
  `description` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET = utf8;

INSERT INTO `developer_type` (`id`, `name`, `description`) VALUES ('1', '公司', '公司');
INSERT INTO `developer_type` (`id`, `name`, `description`) VALUES ('2', '个人', '个人');

CREATE TABLE `developer_business_type` (
  `id` BIGINT(20) NOT NULL,
  `parent` BIGINT(20) NULL,
  `description` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET = utf8;

ALTER TABLE `developer_business_type`
ADD INDEX `DEVELOPER_BUSINESS_TYPE_PARENT_idx` (`parent` ASC);
ALTER TABLE `developer_business_type`
ADD CONSTRAINT `DEVELOPER_BUSINESS_TYPE_PARENT`
  FOREIGN KEY (`parent`)
  REFERENCES `developer_business_type` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

INSERT INTO `developer_business_type` (`id`, `description`) VALUES ('1', '线上');
INSERT INTO `developer_business_type` (`id`, `description`) VALUES ('2', '线下');
INSERT INTO `developer_business_type` (`id`, `parent`, `description`) VALUES ('3', '1', '金融');
INSERT INTO `developer_business_type` (`id`, `parent`, `description`) VALUES ('4', '1', '电商');
INSERT INTO `developer_business_type` (`id`, `parent`, `description`) VALUES ('5', '1', '汽车生活');
INSERT INTO `developer_business_type` (`id`, `parent`, `description`) VALUES ('6', '1', '汽车资讯');
INSERT INTO `developer_business_type` (`id`, `parent`, `description`) VALUES ('7', '1', '汽车交易');
INSERT INTO `developer_business_type` (`id`, `parent`, `description`) VALUES ('8', '1', '汽车修理');
INSERT INTO `developer_business_type` (`id`, `parent`, `description`) VALUES ('9', '1', '其他');
INSERT INTO `developer_business_type` (`id`, `parent`, `description`) VALUES ('10', '2', '金融');
INSERT INTO `developer_business_type` (`id`, `parent`, `description`) VALUES ('11', '2', '汽车生活');
INSERT INTO `developer_business_type` (`id`, `parent`, `description`) VALUES ('12', '2', '汽车资讯');
INSERT INTO `developer_business_type` (`id`, `parent`, `description`) VALUES ('13', '2', '汽车交易');
INSERT INTO `developer_business_type` (`id`, `parent`, `description`) VALUES ('14', '2', '汽车修理');
INSERT INTO `developer_business_type` (`id`, `parent`, `description`) VALUES ('15', '2', '其他');


CREATE TABLE `developer_info` (
  `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
  `developer_type` BIGINT(20) NOT NULL,
  `developer_business_type` BIGINT(20) NOT NULL,
  `company` VARCHAR(500) NULL,
  `mobile` VARCHAR(20) NOT NULL,
  `contact_name` VARCHAR(20) NOT NULL,
  `email` VARCHAR(500) NOT NULL,
  `address` VARCHAR(500) NOT NULL,
  `create_time` DATETIME NOT NULL,
  `update_time` DATETIME NULL,
  PRIMARY KEY (`id`))  ENGINE=InnoDB DEFAULT CHARSET = utf8;

ALTER TABLE `developer_info`
ADD INDEX `DEV_INFO_REF_DEV_TYPE_idx` (`developer_type` ASC),
ADD INDEX `DEV_INFO_REF_DEV_BUS_TYPE_idx` (`developer_business_type` ASC);
ALTER TABLE `developer_info`
ADD CONSTRAINT `DEV_INFO_REF_DEV_TYPE`
  FOREIGN KEY (`developer_type`)
  REFERENCES `developer_type` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION,
ADD CONSTRAINT `DEV_INFO_REF_DEV_BUS_TYPE`
  FOREIGN KEY (`developer_business_type`)
  REFERENCES `developer_business_type` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

ALTER TABLE `developer_info`
ADD COLUMN `description` VARCHAR(2000) NULL AFTER `update_time`;

