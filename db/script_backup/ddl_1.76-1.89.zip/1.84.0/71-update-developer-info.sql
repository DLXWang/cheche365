ALTER TABLE `developer_info`
DROP FOREIGN KEY `DEV_INFO_REF_DEV_BUS_TYPE`;
ALTER TABLE `developer_info`
CHANGE COLUMN `developer_business_type` `developer_business_type` BIGINT(20) NULL ;
ALTER TABLE `developer_info`
ADD CONSTRAINT `DEV_INFO_REF_DEV_BUS_TYPE`
  FOREIGN KEY (`developer_business_type`)
  REFERENCES `developer_business_type` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;
