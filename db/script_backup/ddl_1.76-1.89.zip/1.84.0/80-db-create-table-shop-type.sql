

CREATE TABLE `shop_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `shop_type` VALUES ('1', '个人', '个人');
INSERT INTO `shop_type` VALUES ('2', '洗车店', '洗车店');
INSERT INTO `shop_type` VALUES ('3', '维修中心', '维修中心');


ALTER TABLE `channel_agent`
MODIFY COLUMN `invite_code`  varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci NULL AFTER `agent_code`,
ADD COLUMN `shop_type`  bigint(20) NULL COMMENT '代理人所在渠道' AFTER `update_time`,
ADD COLUMN `shop`  varchar(255) NULL COMMENT '门店名称，当用户选择渠道为“个人”时，此字段隐藏，无需填写，当用户选择洗车店或汽车维修中心时，此为必填字段' AFTER `shop_type`;

ALTER TABLE `channel_agent` ADD CONSTRAINT `CHANNEL_AGENT_SHOP_TYPE` FOREIGN KEY (`shop_type`) REFERENCES `shop_type` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


