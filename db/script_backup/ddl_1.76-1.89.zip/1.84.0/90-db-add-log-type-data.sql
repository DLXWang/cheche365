INSERT INTO `log_type` (`id`, `name`, `description`) VALUES (56, 'BOTPY', '金斗云');
