update payment set app_id = 'wxa466422d960d9fa6', mch_id = '1493948852'
where channel  = 23 and payment_type in (1,2,7);
