INSERT INTO `api_partner` (`id`, `code`, `tag`, `description`) VALUES ('51', 'kunlunbz', '2', '昆仑经济滨州');
INSERT INTO `channel` (`id`, `name`, `tag`, `parent`, `api_partner`, `icon`, `description`) VALUES ('217', 'PARTNER_KUNLUN_BZ', '4234', '217', '51', 'kunlunbz.png', '昆仑经济滨州');
INSERT INTO `channel` (`id`, `name`, `tag`, `parent`, `api_partner`, `icon`, `description`) VALUES ('218', 'ORDER_CENTER_KUNLUN_BZ', '4232', '217', '51', 'kunlunbz.png', '昆仑经济滨州-出单中心');
