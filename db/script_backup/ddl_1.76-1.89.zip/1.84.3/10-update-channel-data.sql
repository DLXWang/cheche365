UPDATE `channel` SET `description`='昆仑经纪(滨州)' WHERE (`id`='217');
UPDATE `channel` SET `description`='昆仑经纪(滨州)-出单中心' WHERE (`id`='218');
