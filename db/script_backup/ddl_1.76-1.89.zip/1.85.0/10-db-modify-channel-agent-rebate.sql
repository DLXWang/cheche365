ALTER TABLE channel_agent_rebate change commercial_rebate parent_detain_commercial_rebate decimal(18,2);

ALTER TABLE channel_agent_rebate change compulsory_rebate parent_detain_compulsory_rebate decimal(18,2);
