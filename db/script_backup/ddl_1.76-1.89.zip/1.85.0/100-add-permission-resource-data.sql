INSERT INTO `permission_resource` ( `permission`, `resource`) VALUES ( '191', '108');
