INSERT INTO `role_permission` (`id`, `permission`, `role`) VALUES ('5160', '191', '8');
