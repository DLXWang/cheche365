INSERT INTO `wallet_trade_source` (`id`, `source`, `description`) VALUES ('6', '订单奖励金', '订单奖励金');
ALTER TABLE wallet_trade add description VARCHAR(20);
