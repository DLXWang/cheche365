UPDATE `marketing` SET `begin_date`='2018-03-28 00:00:00' WHERE (`id`='121');
UPDATE `marketing` SET `begin_date`='2018-03-28 00:00:00' WHERE (`id`='122');
UPDATE `marketing` SET `begin_date`='2018-03-28 00:00:00' WHERE (`id`='123');
