update channel set tag = tag - 8192 where id in (210,211);
