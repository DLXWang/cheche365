create table `purchase_order_image_custom` (
	`id` bigint(20) NOT NULL AUTO_INCREMENT,
	`purchase_order` bigint(20) NOT NULL,
    `description` varchar(500),
    `need_upload` tinyint(1) DEFAULT 1,
    `create_time` datetime DEFAULT NULL,
    `update_time` datetime DEFAULT NULL,
	PRIMARY KEY(`id`),
    CONSTRAINT `FK_IMAGE_CUSTOM_REF_ORDER` FOREIGN KEY (`purchase_order`) REFERENCES `purchase_order` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET = utf8;

INSERT INTO `purchase_order_image_scene` (`id`, `name`, `cs_ignore`) VALUES
('8', '泛华核保', '1');

update purchase_order_image poi,purchase_order po
set poi.image_scene = 8
where poi.obj_id = po.id and po.order_source_type = 5 and poi.image_scene is null;

INSERT INTO `purchase_order_image_scene` (`id`, `name`, `cs_ignore`) VALUES
('9', '自定义', '1');

INSERT INTO `purchase_order_image_type` (`id`, `name`, `parent_id`,  `sample_url`, `reusable`, `external_type`) VALUES
('6000', 'API-自定义类型', '0', NULL, 0, NULL);

INSERT INTO `purchase_order_image_scene_type` (`image_scene`, `image_type`) VALUES
('9', '6000');

INSERT INTO `purchase_order_image_type` (`id`, `name`, `parent_id`,  `sample_url`, `reusable`, `external_type`) VALUES
('6001', '自定义类型', 6000, NULL, 0, NULL);

