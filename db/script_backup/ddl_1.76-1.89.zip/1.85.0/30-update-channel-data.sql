UPDATE channel SET tag=tag|(1<<13) WHERE tag&(1<<12);
