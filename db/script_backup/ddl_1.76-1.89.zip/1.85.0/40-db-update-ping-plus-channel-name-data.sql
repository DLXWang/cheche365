update ping_plus_channel_name
set name = 'upacp_wap'
where payment_channel = 24
and channel in (4,6);
