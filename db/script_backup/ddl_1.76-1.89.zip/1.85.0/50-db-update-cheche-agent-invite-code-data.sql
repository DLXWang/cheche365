ALTER TABLE `cheche_agent_invite_code`
MODIFY COLUMN `channel`  bigint(20) NULL AFTER `id`;
