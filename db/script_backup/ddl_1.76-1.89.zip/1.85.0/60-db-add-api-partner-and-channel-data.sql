INSERT INTO `channel` (`id`, `name`, `parent`, `icon`, `description`) VALUES ('219', 'ORDER_CENTER_LUBI', '219', 'lubi.png', '鼎然科技-出单中心');
