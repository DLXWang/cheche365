INSERT INTO `channel` (`id`, `name`, `parent`, `icon`, `description`) VALUES ('220', 'PARTNER_LUBI', '220', 'lubi.png', '鼎然科技');
UPDATE `channel` SET `parent`='220' WHERE (`id`='219');
