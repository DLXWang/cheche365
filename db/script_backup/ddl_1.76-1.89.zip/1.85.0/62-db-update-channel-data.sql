UPDATE `channel` SET `tag`='2' WHERE (`id`='220');
