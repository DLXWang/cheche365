INSERT INTO `api_partner` (`id`, `code`, `tag`, `description`) VALUES ('52', 'lubi', '2', '鼎然科技');
UPDATE `channel` SET `api_partner`='52' WHERE (`id`='219');
UPDATE `channel` SET `api_partner`='52' WHERE (`id`='220');
