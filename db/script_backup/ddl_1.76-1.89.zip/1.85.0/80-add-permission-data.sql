INSERT INTO `permission` (`id`, `description`, `name`, `type`, `permission_type`, `code`, `level`) VALUES ('191', '运营中心/用户管理/用户信息管理', '用户信息管理', '2', '1', 'op1001', '0');


