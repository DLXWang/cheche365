INSERT INTO `resource` (`id`, `name`, `parent`, `resource_type`, `level`) VALUES ('107', '用户管理', '1', '1', '2');
INSERT INTO `resource` (`id`, `name`, `parent`, `resource_type`, `level`) VALUES ('108', '用户信息管理', '107', '1', '3');
