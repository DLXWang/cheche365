INSERT INTO `marketing` (`id`, `name`, `code`, `tag`, `begin_date`, `end_date`, `gift_expire_date`, `channel`, `amount`, `full_limit`, `gift_class`, `marketing_type`, `quote_support`, `short_name`, `marketing_service`, `description`, `activity_type`, `create_time`, `update_time`) VALUES
('124', '百度SEM第二期1', '201804010', '2', '2018-04-04 00:00:00', '2022-12-04 00:00:00', '2022-12-04 00:00:00', NULL, NULL, NULL, NULL, 'm', '0', '百度SEM第二期1', NULL, NULL, '1', NULL, NULL),
('125', '百度SEM第二期2', '201804011', '2', '2018-04-04 00:00:00', '2022-12-04 00:00:00', '2022-12-04 00:00:00', NULL, NULL, NULL, NULL, 'm', '0', '百度SEM第二期2', NULL, NULL, '1', NULL, NULL),
('126', '百度SEM第二期3', '201804012', '2', '2018-04-04 00:00:00', '2022-12-04 00:00:00', '2022-12-04 00:00:00', NULL, NULL, NULL, NULL, 'm', '0', '百度SEM第二期3', NULL, NULL, '1', NULL, NULL),
('127', '百度SEM第二期4', '201804013', '2', '2018-04-04 00:00:00', '2022-12-04 00:00:00', '2022-12-04 00:00:00', NULL, NULL, NULL, NULL, 'm', '0', '百度SEM第二期4', NULL, NULL, '1', NULL, NULL),
('128', '百度SEM第二期5', '201804014', '2', '2018-04-04 00:00:00', '2022-12-04 00:00:00', '2022-12-04 00:00:00', NULL, NULL, NULL, NULL, 'm', '0', '百度SEM第二期5', NULL, NULL, '1', NULL, NULL);



