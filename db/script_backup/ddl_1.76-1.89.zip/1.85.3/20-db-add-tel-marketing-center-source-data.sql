INSERT INTO `tel_marketing_center_source` (`id`, `description`, `name`, `enable`, `type`) VALUES ('197', '百度SEM第二期1', 'MARKETING_201804010', '1', '2');
INSERT INTO `tel_marketing_center_source` (`id`, `description`, `name`, `enable`, `type`) VALUES ('198', '百度SEM第二期2', 'MARKETING_201804011', '1', '2');
INSERT INTO `tel_marketing_center_source` (`id`, `description`, `name`, `enable`, `type`) VALUES ('199', '百度SEM第二期3', 'MARKETING_201804012', '1', '2');
INSERT INTO `tel_marketing_center_source` (`id`, `description`, `name`, `enable`, `type`) VALUES ('200', '百度SEM第二期4', 'MARKETING_201804013', '1', '2');
INSERT INTO `tel_marketing_center_source` (`id`, `description`, `name`, `enable`, `type`) VALUES ('201', '百度SEM第二期5', 'MARKETING_201804014', '1', '2');
