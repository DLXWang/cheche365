insert into channel(id,name,tag,parent,api_partner,icon,description) VALUE(221,'IOS_CHEBAOYI','12457',221,null,null,'车保易IOS');
insert into channel(id,name,tag,parent,api_partner,icon,description) VALUE(222,'ANDROID_CHEBAOYI','12457',222,null,null,'车保易ANDROID');
