INSERT INTO `tel_marketing_center_source` (`id`, `description`, `name`, `enable`, `type`) VALUES ('202', '车车意外险活动页面', 'MARKETING_201804004', '1', '2');
INSERT INTO `tel_marketing_center_source` (`id`, `description`, `name`, `enable`, `type`) VALUES ('203', '四月续保活动', 'MARKETING_201804005', '1', '2');
