INSERT INTO `message_type` (`id`, `type`, `description`, `name`) VALUES ('32', 'ACTIVITY_MENU', '车主福利', '车主福利');
