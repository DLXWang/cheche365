CREATE TABLE `user_remit_trade_history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL,
  `merchant_seq_no` varchar(40) DEFAULT NULL,
  `request_no` varchar(40) DEFAULT NULL,
  `wallet_remit_trade_id` bigint(20) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_remit_trade_history_request_no_index` (`request_no`),
  UNIQUE KEY `user_remit_trade_history_merchant_seq_no_index` (`merchant_seq_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8