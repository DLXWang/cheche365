CREATE TABLE `wallet_remit_upload_history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `operator` bigint(20) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '0',
  `file_name` varchar(40) DEFAULT NULL,
  `error_file_name` bigint(20) DEFAULT NULL,
  `success_size` datetime DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  `file_path` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_WALLET_REMIT_UPLOAD_HISTORY_REF_INTERNAL_USER` (`operator`),
  CONSTRAINT `FK_WALLET_REMIT_UPLOAD_HISTORY_REF_INTERNAL_USER` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;