UPDATE `api_partner_properties` SET `value`='https://supergwtest.baifubao.com/public/ins/batch' WHERE `partner` = '50' AND `key` = 'sync.order.url';
