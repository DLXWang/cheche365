ALTER TABLE `insurance_package`
CHANGE COLUMN `unique_string` `unique_string` VARCHAR(30) NULL DEFAULT NULL ;

ALTER TABLE `insurance_package`
DROP INDEX `idx_u_insurance_package` ,
ADD INDEX `idx_u_insurance_package` USING BTREE (`unique_string` ASC);
