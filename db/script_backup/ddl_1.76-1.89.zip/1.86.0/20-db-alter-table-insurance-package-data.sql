alter table insurance_package add column designated_repair_shop tinyint(1) default 0;

update insurance_package set designated_repair_shop = 0,unique_string = CONCAT(unique_string, '0');

alter table quote_record add column designated_repair_shop_premium decimal(18,2) default 0.0;

alter table insurance add column designated_repair_shop_premium decimal(18,2) default 0.0;

