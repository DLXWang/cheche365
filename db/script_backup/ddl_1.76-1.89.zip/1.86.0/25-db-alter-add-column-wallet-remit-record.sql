ALTER TABLE `wallet_remit_record` add COLUMN `channel` BIGINT(20);
ALTER TABLE `wallet_remit_record` ADD CONSTRAINT `WALLET_REMIT_RECORD_CHANNEL_FK` FOREIGN KEY (`channel`) REFERENCES `channel` (`id`);
