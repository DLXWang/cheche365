update insurance_company set tag = tag - 8192 where tag&(1<<13) > 0;
update insurance_company set tag = tag - 16384 where tag&(1<<14) > 0;
