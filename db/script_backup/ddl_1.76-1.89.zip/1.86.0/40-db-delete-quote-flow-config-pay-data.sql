delete from quote_flow_config where config_type = 2 or config_type = 3;
