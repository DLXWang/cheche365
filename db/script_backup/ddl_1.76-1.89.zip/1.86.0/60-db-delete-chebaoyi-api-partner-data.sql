update channel set api_partner = null where id = 67 or id = 68;
delete from partner_user where partner = 27;
delete from partner_order where partner_third = 27;
delete from api_partner where id = 27;
