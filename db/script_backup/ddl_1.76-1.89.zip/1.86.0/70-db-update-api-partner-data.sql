UPDATE `api_partner` SET `tag`='1132'-(1 << 3) WHERE (`id`='50');
