INSERT INTO `marketing` (`id`, `name`, `code`, `tag`, `begin_date`, `end_date`, `gift_expire_date`, `channel`, `amount`, `full_limit`, `gift_class`, `marketing_type`, `quote_support`, `short_name`, `marketing_service`, `description`, `activity_type`, `create_time`, `update_time`) VALUES
('129', '汽车金融-通过车车车险引流获客', '201804015', '6', '2018-04-05 00:00:00', '2023-04-05 00:00:00', '2023-04-05 00:00:00', NULL, NULL, NULL, NULL, 'm', '0', '汽车金融-通过车车车险引流获客', NULL, NULL, '1', NULL, NULL);

INSERT INTO `marketing` (`id`, `name`, `code`, `tag`, `begin_date`, `end_date`, `gift_expire_date`, `channel`, `amount`, `full_limit`, `gift_class`, `marketing_type`, `quote_support`, `short_name`, `marketing_service`, `description`, `activity_type`, `create_time`, `update_time`) VALUES
('130', '车车意外险活动页面', '201804004', '6', '2018-04-08 00:00:00', '2023-04-08 00:00:00', '2023-04-08 00:00:00', '', NULL, NULL, NULL, 'm', '0', '车车意外险活动页面', NULL, NULL, '1', NULL, NULL);

