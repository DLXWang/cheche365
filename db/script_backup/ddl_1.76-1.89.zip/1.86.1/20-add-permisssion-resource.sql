-- permisson
INSERT INTO permission (description, name, type, permission_type, code, level) VALUES ('出单中心/钱包管理/钱包列表/回传打款结果', '回传打款结果', 2, 1, 'or110101', 0);

-- resource
INSERT INTO resource (name, parent, resource_type, level) VALUES ('回传打款结果', 87, 1, 3);

-- permission_resource
INSERT INTO permission_resource (permission, resource) VALUES (192, 109);

