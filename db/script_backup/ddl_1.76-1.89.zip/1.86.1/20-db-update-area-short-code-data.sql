update area set short_code = '粤E,粤X,粤Y' where id = 440600;
