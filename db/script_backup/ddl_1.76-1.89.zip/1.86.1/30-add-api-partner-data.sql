INSERT INTO `api_partner_properties` (`partner`, `key`, `value`) VALUES ('50', 'ftp.url', 'insur_1000000012@123.125.115.22');
INSERT INTO `api_partner_properties` (`partner`, `key`, `value`) VALUES ('50', 'ftp.pwd', 'DEsa_1000000012');
INSERT INTO `api_partner_properties` (`partner`, `key`, `value`) VALUES ('50', 'ftp.port', '2223');
INSERT INTO `api_partner_properties` (`partner`, `key`, `value`) VALUES ('50', 'ftp.directory', '/insur_1000000012/1000000012/upload/');

INSERT INTO `api_partner_properties` (`partner`, `key`, `value`) VALUES ('50', 'production.ftp.url', 'insur_1000000012@123.125.115.224');
INSERT INTO `api_partner_properties` (`partner`, `key`, `value`) VALUES ('50', 'production.ftp.pwd', 'DEsa_1000000012');
INSERT INTO `api_partner_properties` (`partner`, `key`, `value`) VALUES ('50', 'production.ftp.port', '2223');
INSERT INTO `api_partner_properties` (`partner`, `key`, `value`) VALUES ('50', 'production.ftp.directory', '/insur_1000000012/1000000012/upload/');
