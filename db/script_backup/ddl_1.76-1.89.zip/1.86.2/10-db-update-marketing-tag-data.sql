update marketing set tag = tag - 2 where code = '201707004' and (tag & 1<<1) > 0;
