-- 删除c端渠道api接入配置，并下线三家api渠道
update channel set tag = tag - 4 + 64 where tag & (1<<2) > 0;

-- 车保易改名字 去掉partner
update channel set name = 'CHEBAOYI' where id = 67;
