update purchase_order_image_scene set cs_ignore = 0 where id = 7;
UPDATE `purchase_order_image_type` SET `name` = '验车照片'  WHERE `id` = '5000';

INSERT INTO `purchase_order_image_type` (`id`, `name`, `parent_id`,  `sample_url`, `reusable`, `external_type`) VALUES
('5100', '身份证', '0', NULL, 0, NULL);
INSERT INTO `purchase_order_image_scene_type` (`image_scene`, `image_type`) VALUES
('7', '5100');
INSERT INTO `purchase_order_image_type` (`id`, `name`, `parent_id`,  `sample_url`, `reusable`, `external_type`) VALUES
('5101', '身份证正面', 5100, NULL, 0, NULL);
INSERT INTO `purchase_order_image_type` (`id`, `name`, `parent_id`,  `sample_url`, `reusable`, `external_type`) VALUES
('5102', '身份证反面', 5100, NULL, 0, NULL);

INSERT INTO `purchase_order_image_type` (`id`, `name`, `parent_id`,  `sample_url`, `reusable`, `external_type`) VALUES
('5200', '行驶证', '0', NULL, 0, NULL);
INSERT INTO `purchase_order_image_scene_type` (`image_scene`, `image_type`) VALUES
('7', '5200');
INSERT INTO `purchase_order_image_type` (`id`, `name`, `parent_id`,  `sample_url`, `reusable`, `external_type`) VALUES
('5201', '行驶证正本', 5200, NULL, 0, NULL);
INSERT INTO `purchase_order_image_type` (`id`, `name`, `parent_id`,  `sample_url`, `reusable`, `external_type`) VALUES
('5202', '行驶证正本', 5200, NULL, 0, NULL);
