UPDATE `purchase_order_image_type` SET `name` = '行驶证副本' WHERE `id` = '5202';

DELETE FROM `purchase_order_image_scene_type` WHERE `image_scene` = 7 AND `image_type` = '5000';

INSERT INTO `purchase_order_image_type` (`id`, `name`, `parent_id`,  `sample_url`, `reusable`, `external_type`) VALUES
('5203', '行驶证年审页照', 5200, NULL, 0, NULL);

