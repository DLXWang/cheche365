INSERT INTO `permission` (`id`, `description`, `name`, `type`, `permission_type`, `code`, `level`) VALUES ('196', '运营中心/第三方合作/ToA合作管理', 'ToA合作管理', '2', '1', 'op1103', '0');
INSERT INTO `permission` (`id`, `description`, `name`, `type`, `permission_type`, `code`, `level`) VALUES ('195', '运营中心/第三方合作/ToC合作管理', 'ToC合作管理', '2', '1', 'op1102', '0');
INSERT INTO `permission` (`id`, `description`, `name`, `type`, `permission_type`, `code`, `level`) VALUES ('194', '运营中心/第三方合作/合作商管理', '合作商管理', '2', '1', 'op1101', '0');
