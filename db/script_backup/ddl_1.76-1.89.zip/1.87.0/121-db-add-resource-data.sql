INSERT INTO `resource` (`id`, `name`, `parent`, `resource_type`, `level`) VALUES ('110', '第三方合作', '1', '1', '2');
INSERT INTO `resource` (`id`, `name`, `parent`, `resource_type`, `level`) VALUES ('113', 'ToA合作管理', '110', '1', '3');
INSERT INTO `resource` (`id`, `name`, `parent`, `resource_type`, `level`) VALUES ('112', 'ToC合作管理', '110', '1', '3');
INSERT INTO `resource` (`id`, `name`, `parent`, `resource_type`, `level`) VALUES ('111', '合作商管理', '110', '1', '3');
INSERT INTO `permission_resource` (`id`, `permission`, `resource`) VALUES ('182', '196', '113');
INSERT INTO `permission_resource` (`id`, `permission`, `resource`) VALUES ('181', '195', '112');
INSERT INTO `permission_resource` (`id`, `permission`, `resource`) VALUES ('180', '194', '111');
