ALTER TABLE `insurance`
	ADD COLUMN `special_agreement` VARCHAR(1000) NULL COMMENT '特约信息' AFTER `designated_repair_shop_premium`;
