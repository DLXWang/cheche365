ALTER TABLE `channel` ADD COLUMN `create_time` datetime DEFAULT NULL,ADD COLUMN `update_time` datetime DEFAULT NULL;
ALTER TABLE `api_partner` ADD COLUMN `create_time` datetime DEFAULT NULL,ADD COLUMN `update_time` datetime DEFAULT NULL;
