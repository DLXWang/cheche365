CREATE TABLE `tide_platform` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(60) DEFAULT NULL COMMENT '操作员姓名',
  `mobile` varchar(20) DEFAULT NULL COMMENT '操作员手机号',
  `email` varchar(60) DEFAULT NULL COMMENT '操作员邮箱',
  `name` varchar(60) DEFAULT NULL COMMENT '平台机构名称',
  `status` tinyint(1) DEFAULT NULL COMMENT '状态',
  `operator` bigint(20) DEFAULT NULL COMMENT '操作员关联的用户',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_TIDE_PLATEFORM_REF_INTERNAL_USER` (`operator`) USING BTREE,
  CONSTRAINT `TIDE_PLATFORM_OPERATOR` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='潮汐系统 平台机构';