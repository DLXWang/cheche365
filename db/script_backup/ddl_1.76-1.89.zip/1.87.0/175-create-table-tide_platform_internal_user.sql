CREATE TABLE `tide_platform_internal_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) DEFAULT NULL,
  `internal_user` bigint(20) DEFAULT NULL,
  `tide_platform` bigint(20) DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `PLATFORM_INTERNAL_USER_UNIQUE` (`internal_user`,`tide_platform`),
  KEY `TIDE_PLATFORM_INTERNAL_USER_REF_INTERNAL_USER_FK` (`internal_user`),
  KEY `TIDE_PLATFORM_INTERNAL_USER_REF_TIDE_PLATFORM_FK` (`tide_platform`),
  CONSTRAINT `TIDE_PLATFORM_INTERNAL_USER_REF_INTERNAL_USER_FK` FOREIGN KEY (`internal_user`) REFERENCES `internal_user` (`id`),
  CONSTRAINT `TIDE_PLATFORM_INTERNAL_USER_REF_TIDE_PLATFORM_FK` FOREIGN KEY (`tide_platform`) REFERENCES `tide_platform` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;