CREATE TABLE `tide_institution` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tide_branch` bigint(20) DEFAULT NULL COMMENT '营业部',
  `institution_name` varchar(60) DEFAULT NULL COMMENT '分支机构保险公司名称',
  `status` tinyint(1) DEFAULT NULL COMMENT '状态',
  `operator` bigint(20) DEFAULT NULL COMMENT '操作人',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `BRANCH_INSTITUTION_NAME_UNIQUE` (`tide_branch`,`institution_name`),
  KEY `FK_TIDE_INSTITUTION_REF_INTERNAL_USER` (`operator`) USING BTREE,
  KEY `FK_TIDE_INSTITUTION_REF_TIDE_BRANCH` (`tide_branch`),
  CONSTRAINT `FK_TIDE_INSTITUTION_REF_INTERNAL_USER` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`),
  CONSTRAINT `FK_TIDE_INSTITUTION_REF_TIDE_BRANCH` FOREIGN KEY (`tide_branch`) REFERENCES `tide_branch` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='潮汐系统 营业部(拍照)'