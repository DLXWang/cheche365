CREATE TABLE `upload_file` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `file_path` varchar (200) default  null comment '文件路径',
  `file_name` varchar (60) default  null comment '文件名称',
  `source_type` varchar (60) default  null comment '文件来源',
  `source_id` bigint (20) default  null comment '关联表id',
  `status` tinyint(1) default null comment '状态',
  `operator` bigint(20) DEFAULT NULL COMMENT '操作人',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `KEY_UPLOAD_FILE_OPERATOR` (`operator`) USING BTREE,
  CONSTRAINT `FK_UPLOAD_FILE_REF_INTERNAL_USER` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='文件上传表'