
-- insert 导入线下提供的平台
INSERT INTO tide_platform (user_name, mobile, email, name, status, create_time, update_time, description) VALUES ('徐吉敏', '15864793703', '15864793703@cheche365.com', '山东平台', 0, now(), now(), '初始化导入');
INSERT INTO tide_platform (user_name, mobile, email, name, status, create_time, update_time, description) VALUES ('魏芳玲', '15829205884', '15829205884@cheche365.com', '陕西平台', 0, now(), now(), '初始化导入');
INSERT INTO tide_platform (user_name, mobile, email, name, status, create_time, update_time, description) VALUES ('朱沙', '18252020250', '18252020250@cheche365.com', '江苏平台', 0, now(), now(), '初始化导入');


-- insert 为线下平台的负责人建立internal_user
INSERT INTO internal_user (email, mobile, name, password, disable, create_time, update_time, internal_user_type)
  ( select tp.email,tp.mobile,tp.user_name,md5('12345678'),0, now(), now(), 1 from tide_platform tp where tp.status = 0);

-- update 平台和internal_user关系更新
update tide_platform tp join internal_user iu on tp.email = iu.email set tp.operator = iu.id ,tp.status = 1;

-- insert internal 和 platform中间表数据插入
insert into tide_platform_internal_user (email, internal_user, tide_platform, status)
  (select tp.email,tp.operator, tp.id, 5 from tide_platform tp where tp.status = 1);

-- insert 插入线下要新增的营业部
-- INSERT INTO tide_branch (platform_name, branch_name, branch_type, branch_no, source_create_time, status, create_time, update_time) VALUES ('辽宁平台', '泛华时代保险销售服务有限公司鞍山海城营业部', '保险专业代理机构', '202111210000802', '2018-01-23 00:00:00', 5, now(), now());


-- update 给营业部上的平台名称拼接完整名称
-- update tide_branch tb set tb.platform_name = concat(tb.platform_name,"平台");


-- 更新branch和platform的关联
update tide_branch tb join tide_platform tp  on tb.platform_name = tp.name and tp.status = 1
set tb.status = 5, tb.tide_platform = tp.id ,tb.operator = tp.operator ,tb.create_time = now(),tb.update_time = now(),tb.description = '已关联';


-- 更新platform数据状态为生效中
update tide_platform tp join internal_user iu on tp.email = iu.email and tp.status = 1
 set tp.operator = iu.id, tp.status = 5, tp.description = '已关联';
