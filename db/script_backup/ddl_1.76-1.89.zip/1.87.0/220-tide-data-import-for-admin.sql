
-- insert 为线下平台的负责人建立internal_user
INSERT INTO internal_user (email, mobile, name, user_id, gender, password, disable, create_time, update_time, internal_user_type)
VALUES ('tide@cheche365.com', '13088889999', '合约管理员', null, null, md5('12345678'), 0, now(), now(), 1);

-- insert internal 和 platform中间表数据插入
insert into tide_platform_internal_user (email, internal_user, tide_platform, status)
  (select 'tide@cheche365.com',null, tp.id, 0 from tide_platform tp);

-- 更新关系中间表与user的关系
update tide_platform_internal_user tu join internal_user iu on tu.email = iu.email and tu.email = 'tide@cheche365.com'
set tu.internal_user = iu.id, tu.status = 5;
