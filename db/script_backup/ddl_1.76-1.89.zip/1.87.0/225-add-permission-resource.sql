INSERT INTO resource (id, name, parent, resource_type, level) VALUES (120, '点位管理', 1, 1, 2);
INSERT INTO resource (id, name, parent, resource_type, level) VALUES (121, '合约管理', 120, 1, 3);
INSERT INTO resource (id, name, parent, resource_type, level) VALUES (122, '原始点位管理', 120, 1, 3);

INSERT INTO permission (id, description, name, type, permission_type, code, level) VALUES (200, '运营中心/点位管理/合约管理', '合约管理', 2, 1, 'op1201', 0);
INSERT INTO permission (id, description, name, type, permission_type, code, level) VALUES (201, '运营中心/点位管理/原始点位管理', '原始点位管理', 2, 1, 'op1202', 0);

INSERT INTO permission_resource (id, permission, resource) VALUES (190, 200, 121);
INSERT INTO permission_resource (id, permission, resource) VALUES (191, 201, 122);
