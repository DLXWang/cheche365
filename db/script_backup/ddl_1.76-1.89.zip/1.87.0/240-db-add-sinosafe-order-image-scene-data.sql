update purchase_order_image_scene set cs_ignore = 1 where id = 7;
