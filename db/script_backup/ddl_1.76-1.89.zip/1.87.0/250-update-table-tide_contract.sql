alter table tide_contract drop index BRANCH_CONTRACT_NAME_UNIQUE;
alter table tide_contract add column `contract_code` varchar (40) default null  comment '合约编号';