INSERT INTO `api_partner` (`id`, `code`, `tag`, `description`) VALUES ('53', 'nvchezhu', '0', '女车主');
INSERT INTO `channel` (`id`, `name`, `tag`, `parent`, `api_partner`, `icon`, `description`) VALUES ('223', 'PARTNER_NVCHEZHU', 1 << 1, '223', '53', 'nvchezhu.png', '女车主');
INSERT INTO `channel` (`id`, `name`, `tag`, `parent`, `api_partner`, `icon`, `description`) VALUES ('224', 'ORDER_CENTER_NVCHEZHU', 1 << 2, '223', '53', 'nvchezhu.png', '女车主-出单中心');
