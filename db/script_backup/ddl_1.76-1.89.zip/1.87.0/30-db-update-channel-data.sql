update channel set icon = 'ordercenter-baidu.png' where `name` = 'ORDER_CENTER_BAIDU';
update channel set icon = 'ordercenter-bdinsur.png' where `name` = 'ORDER_CENTER_BDINSUR';
