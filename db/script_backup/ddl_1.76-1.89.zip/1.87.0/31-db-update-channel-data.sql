update channel set icon = 'ordercenter-baidu.png' where `name` = 'PARTNER_BAIDU';
update channel set icon = 'ordercenter-bdinsur.png' where `name` = 'PARTNER_BDINSUR';
