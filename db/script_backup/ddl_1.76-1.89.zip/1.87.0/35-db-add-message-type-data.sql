INSERT INTO `message_type` (`id`, `type`, `description`, `name`) VALUES ('33', 'SHARE_LINK', 'APP下载链接页', 'APP下载链接页');
