INSERT INTO `payment_channel` (`id`, `name`, `customer_pay`, `description`, `parent_id`, `logo_url`) VALUES (55, 'tk', 1, '泰康在线', NULL, NULL);
INSERT INTO `payment_channel` (`id`, `name`, `customer_pay`, `description`, `parent_id`, `logo_url`) VALUES (56, 'alipay', 1, '支付宝', 55, 'paymentChannel/alipay.png');
INSERT INTO `payment_channel` (`id`, `name`, `customer_pay`, `description`, `parent_id`, `logo_url`) VALUES (57, 'wechat', 1, '微信', 55, 'paymentChannel/wechat.png');
INSERT INTO `payment_channel` (`id`, `name`, `customer_pay`, `description`, `parent_id`, `logo_url`) VALUES (58, 'wechats', 1, '微信扫码', 55, 'paymentChannel/wechat.png');

