INSERT INTO `message_type` (`id`, `type`, `description`, `name`) VALUES ('34', 'A_HOME_TOP_IMAGE', 'A端首页背景图', 'A端首页背景图');
