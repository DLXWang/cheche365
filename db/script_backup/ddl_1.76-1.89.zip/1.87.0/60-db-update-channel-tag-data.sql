-- 添加出单中心tag值
update channel set tag = tag + 4 where (tag & (1<<2) <=0) and name like 'ORDER_CENTER%';
