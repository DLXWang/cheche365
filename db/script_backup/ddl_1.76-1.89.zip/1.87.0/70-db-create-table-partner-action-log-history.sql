/*
Navicat MySQL Data Transfer

Source Server         : 250w
Source Server Version : 50638
Source Host           : 124.65.149.30:33666
Source Database       : cheche

Target Server Type    : MYSQL
Target Server Version : 50638
File Encoding         : 65001

Date: 2018-04-20 23:13:57
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for partner_action_log_history
-- ----------------------------
CREATE TABLE `partner_action_log_history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_time` datetime DEFAULT NULL,
  `operation_content` varchar(2000) DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `operator` bigint(20) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  `channel` bigint(20) DEFAULT NULL,
  `partner` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_PARTNER_ACTION_LOG_HISTORY_REF_INTERNAL_USER` (`operator`) USING BTREE,
  KEY `FK_PARTNER_ACTION_LOG_HISTORY_REF_CHANNEL` (`channel`),
  KEY `FK_PARTNER_ACTION_LOG_HISTORY_REF_PARTNER` (`partner`),
  CONSTRAINT `FK_PARTNER_ACTION_LOG_HISTORY_REF_CHANNEL` FOREIGN KEY (`channel`) REFERENCES `channel` (`id`),
  CONSTRAINT `FK_PARTNER_ACTION_LOG_HISTORY_REF_INTERNAL_USER` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`),
  CONSTRAINT `FK_PARTNER_ACTION_LOG_HISTORY_REF_PARTNER` FOREIGN KEY (`partner`) REFERENCES `partner` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
