update address set mobile = replace(mobile,' ','');
