ALTER TABLE `purchase_order`
ADD INDEX `idx_po_status_and_source` USING BTREE (`audit` ASC, `order_source_type` ASC, `status` ASC);
