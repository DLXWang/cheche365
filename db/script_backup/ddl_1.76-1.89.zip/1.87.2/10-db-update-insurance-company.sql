update insurance_company set logo = 'pingan4.png' where id =20000;
