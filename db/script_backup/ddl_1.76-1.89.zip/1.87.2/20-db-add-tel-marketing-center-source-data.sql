INSERT INTO `tel_marketing_center_source` (`id`, `description`, `name`, `enable`, `type`) VALUES ('206', '续保数据', 'RENEWAL_INSURANCE', '1', '2');
