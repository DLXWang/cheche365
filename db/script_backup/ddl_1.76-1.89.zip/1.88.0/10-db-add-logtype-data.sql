INSERT INTO `log_type` (`id`, `name`, `description`) VALUES (57, 'taikang', '泰康');
