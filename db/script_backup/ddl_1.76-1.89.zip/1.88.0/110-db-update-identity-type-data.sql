INSERT INTO `use_character` (`id`, `code`, `description`) VALUES ('21','A1', '家庭自用');
INSERT INTO `use_character` (`id`, `code`, `description`) VALUES ('22','A2', '企业非营业');
INSERT INTO `use_character` (`id`, `code`, `description`) VALUES ('23','A3', '机关非营业');
