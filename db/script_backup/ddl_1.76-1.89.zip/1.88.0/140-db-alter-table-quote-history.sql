ALTER TABLE `quote_history`
ADD COLUMN `area` BIGINT(20) DEFAULT NULL AFTER `auto`;

ALTER TABLE `quote_history`
ADD CONSTRAINT `FK_QUOTE_HIS_REF_AREA`
FOREIGN KEY (`area`) REFERENCES `area` (`id`);

update quote_history qh, auto a set qh.area = a.area
where qh.auto = a.id and qh.area is null and a.area is not null;
