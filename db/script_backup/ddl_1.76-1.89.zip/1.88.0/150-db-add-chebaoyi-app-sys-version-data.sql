INSERT INTO `sys_version` (`channel`, `version`, `update_advice`, `reason`) VALUES
('221', '1.2.0', 'required', '有新版本上线啦！为了您投保更快捷、安全，请去更新最新版本。');

INSERT INTO `sys_version` (`channel`, `version`, `update_advice`, `reason`) VALUES
('222', '1.1.0', 'required', '有新版本上线啦！为了您投保更快捷、安全，请去更新最新版本。');
