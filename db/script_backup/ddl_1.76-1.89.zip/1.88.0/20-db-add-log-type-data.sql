INSERT INTO `log_type` (`id`, `name`, `description`) VALUES (59, 'partner_sync', '第三方同步');
