CREATE TABLE `tide_rebate_record` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `rebate` bigint(20) NOT NULL,
  `contract_rebate_code` varchar(20) DEFAULT NULL COMMENT '点位编号',
  `tide_contract` bigint(20) DEFAULT NULL COMMENT '合约',
  `support_area` bigint(20) DEFAULT NULL COMMENT '支持投保城市',
  `insurance_type` varchar(60) DEFAULT NULL COMMENT '投保类型',
  `car_type` varchar(60) DEFAULT NULL COMMENT '使用性质',
  `choose_condition` varchar(1000) DEFAULT NULL COMMENT '条件',
  `original_commecial_rate` decimal(18,4) DEFAULT NULL COMMENT '商业险原始点位',
  `original_compulsory_rate` decimal(18,4) DEFAULT NULL COMMENT '交强险原始点位',
  `auto_tax_return_type` tinyint(1) DEFAULT NULL COMMENT '车船税退税情况(比例/绝对值)',
  `auto_tax_return_value` decimal(18,4) DEFAULT NULL COMMENT '车船税退税情况具体值',
  `market_commercial_rate` decimal(18,4) DEFAULT NULL COMMENT '商业险市场投放点位',
  `market_compulsory_rate` decimal(18,4) DEFAULT NULL COMMENT '交强险市场投放点位',
  `market_auto_tax_return_type` tinyint(1) DEFAULT NULL COMMENT '车船税退税市场投放情况(比例/绝对值)',
  `market_auto_tax_return_value` decimal(18,4) DEFAULT NULL COMMENT '车船税退税市场投放情况',
  `effective_date` datetime DEFAULT NULL COMMENT '生效日期',
  `expire_date` datetime DEFAULT NULL COMMENT '失效日期',
  `status` tinyint(1) DEFAULT NULL COMMENT '状态',
  `create_time` datetime DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_REBATE_RECORD_REF_REBATE` (`rebate`),
  KEY `FK_REBATE_RECORD_REF_CONTRACT` (`tide_contract`),
  KEY `FK_REBATE_RECORD_REF_AREA` (`support_area`),
  KEY `INDEX_REBATE_RECORD_CREATE_TIME` (`create_time`),
  CONSTRAINT `FK_REBATE_RECORD_REF_AREA` FOREIGN KEY (`support_area`) REFERENCES `area` (`id`),
  CONSTRAINT `FK_REBATE_RECORD_REF_CONTRACT` FOREIGN KEY (`tide_contract`) REFERENCES `tide_contract` (`id`),
  CONSTRAINT `FK_REBATE_RECORD_REF_REBATE` FOREIGN KEY (`rebate`) REFERENCES `tide_contract_rebate` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='点位记录';

CREATE TABLE `tide_rebate_draft_box` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL COMMENT '草稿箱名称',
  `operator` bigint(20) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL COMMENT '状态',
  PRIMARY KEY (`id`),
  KEY `FK_REBATE_DRAFT_REF_OPERATOR` (`operator`),
  CONSTRAINT `FK_REBATE_DRAFT_REF_OPERATOR` FOREIGN KEY (`operator`) REFERENCES `internal_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='草稿箱';

CREATE TABLE `tide_draft_ref_rebate` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `draft_id` bigint(20) DEFAULT NULL,
  `rebate_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_DRAFTREFREBATE_REF_DRAFT` (`draft_id`),
  KEY `FK_DRAFTREFREBATE_REF_REBATE` (`rebate_id`),
  CONSTRAINT `FK_DRAFTREFREBATE_REF_DRAFT` FOREIGN KEY (`draft_id`) REFERENCES `tide_rebate_draft_box` (`id`),
  CONSTRAINT `FK_DRAFTREFREBATE_REF_REBATE` FOREIGN KEY (`rebate_id`) REFERENCES `tide_contract_rebate` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='草稿点位关联';
