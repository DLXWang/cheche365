alter table tide_contract_support_area drop foreign key FK_TIDE_CONTRACT_SUPPORT_AREA_REF_INTERNAL_USER;
alter table tide_contract_support_area drop index KEY_TIDE_CONTRACT_SUPPORT_AREA_OF_OPERATOR;

alter table tide_contract_support_area drop COLUMN effective_date;
alter table tide_contract_support_area drop COLUMN expire_date;
alter table tide_contract_support_area drop COLUMN operator;
alter table tide_contract_support_area drop COLUMN create_time;
alter table tide_contract_support_area drop COLUMN update_time;
alter table tide_contract_support_area drop COLUMN description;
alter table tide_contract_support_area CHANGE status disable tinyint(1) default '0' comment '状态 启用/禁用';
