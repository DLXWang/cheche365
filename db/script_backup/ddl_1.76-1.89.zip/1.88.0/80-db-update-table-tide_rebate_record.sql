alter table tide_rebate_record add (disable tinyint(1));
