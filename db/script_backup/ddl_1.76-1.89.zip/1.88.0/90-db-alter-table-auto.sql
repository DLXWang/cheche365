-- 燃油类型(fuel_type) ：汽油  电  柴油  天然气
CREATE TABLE IF NOT EXISTS `fuel_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
INSERT INTO `fuel_type` (`id`, `name`, `description`) VALUES(1, '汽油', '汽油');
INSERT INTO `fuel_type` (`id`, `name`, `description`) VALUES(2, '电', '电');
INSERT INTO `fuel_type` (`id`, `name`, `description`) VALUES(3, '柴油', '柴油');
INSERT INTO `fuel_type` (`id`, `name`, `description`) VALUES(4, '天然气', '天然气');

-- 老数据没有初始化
ALTER TABLE `auto` ADD COLUMN `fuel_type` BIGINT(20) DEFAULT NULL AFTER `identity_type`;
ALTER TABLE `auto` ADD CONSTRAINT `FK_AUTO_REF_FUEL_TYPE` FOREIGN KEY (`fuel_type`) REFERENCES `fuel_type` (`id`);

-- use_character
ALTER TABLE `auto` ADD COLUMN `use_character` BIGINT(20) DEFAULT NULL AFTER `fuel_type`;
ALTER TABLE `auto` ADD CONSTRAINT `FK_AUTO_REF_USE_CHARACTER` FOREIGN KEY (`use_character`) REFERENCES `use_character` (`id`);

-- 所属人类型(parent_identity_type): 个人  ，团体
CREATE TABLE IF NOT EXISTS `parent_identity_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
INSERT INTO `parent_identity_type` (`id`, `name`, `description`) VALUES(1, '个人', '个人');
INSERT INTO `parent_identity_type` (`id`, `name`, `description`) VALUES(2, '团体', '团体');

ALTER TABLE `identity_type` ADD COLUMN `parent` BIGINT(20) DEFAULT NULL AFTER `name`;
ALTER TABLE `identity_type` ADD CONSTRAINT `FK_IDENTITY_TYPE_REF_PARENT`FOREIGN KEY (`parent`) REFERENCES `parent_identity_type` (`id`);
-- 初始化所属人父类型
UPDATE `identity_type` SET `parent` = 1 WHERE id in (1,2,3,4,5,6,7,8,14,15);
UPDATE `identity_type` SET `parent` = 2 WHERE id in (9,10,11,12,13);

-- vehicle_license
ALTER TABLE `vehicle_license` ADD COLUMN `identity_type` BIGINT(20) DEFAULT NULL AFTER `vehicle_type`;
ALTER TABLE `vehicle_license` ADD CONSTRAINT `FK_VL_REF_IDENTITY_TYPE` FOREIGN KEY (`identity_type`) REFERENCES `identity_type` (`id`);
ALTER TABLE `vehicle_license` ADD COLUMN `fuel_type` BIGINT(20) DEFAULT NULL AFTER `identity_type`;
ALTER TABLE `vehicle_license` ADD CONSTRAINT `FK_VL_REF_FUEL_TYPE`FOREIGN KEY (`fuel_type`) REFERENCES `fuel_type` (`id`);

