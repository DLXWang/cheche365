update api_partner_properties set `value`= "/1000000012/upload/" where partner = 50 and `key` = 'ftp.directory'
