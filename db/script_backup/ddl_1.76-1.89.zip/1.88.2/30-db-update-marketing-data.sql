UPDATE marketing SET begin_date = '2018-05-29 00:00:00' WHERE id = 134;
