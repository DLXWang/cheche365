delete from sys_version where channel = '221' and version = '1.2.2';
delete from sys_version where channel = '4' and version = '2.3.2';
