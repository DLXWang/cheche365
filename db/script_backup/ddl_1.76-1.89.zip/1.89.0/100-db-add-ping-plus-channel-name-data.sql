INSERT into ping_plus_channel_name(payment_channel,channel,name) VALUES('23','5','wx_pub_qr');
