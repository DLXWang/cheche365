INSERT INTO `order_source_type` (`id`, `name`, `description`) VALUES (9, '小鳄鱼', '小鳄鱼');
