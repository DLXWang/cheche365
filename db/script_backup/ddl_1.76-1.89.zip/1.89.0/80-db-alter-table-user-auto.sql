ALTER TABLE `user_auto` ADD COLUMN `create_time` datetime DEFAULT NULL,ADD COLUMN `update_time` datetime DEFAULT NULL;
