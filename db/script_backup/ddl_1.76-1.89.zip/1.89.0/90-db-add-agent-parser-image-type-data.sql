INSERT INTO `purchase_order_image_scene` (`id`, `name`, `cs_ignore`) VALUES
('10', '小鳄鱼核保', '1');

INSERT INTO `purchase_order_image_type` (`id`, `name`, `parent_id`,  `sample_url`, `reusable`, `external_type`) VALUES
('7000', '小鳄鱼验车照片', '0', NULL, 0, NULL);

INSERT INTO `purchase_order_image_scene_type` (`image_scene`, `image_type`) VALUES
('10', '7000');

INSERT INTO `purchase_order_image_type` (`id`, `name`, `parent_id`,  `sample_url`, `reusable`, `external_type`) VALUES
('7001', '车辆前左45°', 7000, 'sampleUrl/car_forward_left.png', 0, NULL);
INSERT INTO `purchase_order_image_type` (`id`, `name`, `parent_id`,  `sample_url`, `reusable`, `external_type`) VALUES
('7002', '车辆前右45°', 7000, 'sampleUrl/car_forward_rigth.png', 0, NULL);
INSERT INTO `purchase_order_image_type` (`id`, `name`, `parent_id`,  `sample_url`, `reusable`, `external_type`) VALUES
('7003', '车辆后左45°', 7000, 'sampleUrl/car_back_left.png', 0, NULL);
INSERT INTO `purchase_order_image_type` (`id`, `name`, `parent_id`,  `sample_url`, `reusable`, `external_type`) VALUES
('7004', '车辆后右45°', 7000, 'sampleUrl/car_back_rigth.png', 0, NULL);
INSERT INTO `purchase_order_image_type` (`id`, `name`, `parent_id`,  `sample_url`, `reusable`, `external_type`) VALUES
('7005', '车架号与带日期报纸或小票合照', 7000, 'sampleUrl/car_no.png', 0, NULL);
INSERT INTO `purchase_order_image_type` (`id`, `name`, `parent_id`,  `sample_url`, `reusable`, `external_type`) VALUES
('7006', '人、车、地标建筑物合影', 7000, 'sampleUrl/car_owner_building.png', 0, NULL);
