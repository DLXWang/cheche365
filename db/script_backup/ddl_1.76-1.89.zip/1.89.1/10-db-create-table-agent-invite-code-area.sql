create table `agent_invite_code_area` (
		`id` BIGINT(20) NOT NULL AUTO_INCREMENT,
		`area` BIGINT(20) NOT NULL ,
		`cheche_agent_invite_code` BIGINT(20),
		PRIMARY KEY (`id`),
		CONSTRAINT `AGENT_INVITE_CODE_AREA_ID` FOREIGN KEY (`area`) REFERENCES `area` (`id`),
		CONSTRAINT `AGENT_INVITE_CODE_CAIC_ID` FOREIGN KEY (`cheche_agent_invite_code`) REFERENCES `cheche_agent_invite_code` (`id`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;
