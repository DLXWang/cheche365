alter table agent_invite_code_area add unique index(area,cheche_agent_invite_code);
