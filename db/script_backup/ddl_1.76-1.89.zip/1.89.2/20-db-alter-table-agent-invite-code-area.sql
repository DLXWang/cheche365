ALTER TABLE `agent_invite_code_area` DROP FOREIGN KEY `AGENT_INVITE_CODE_AREA_ID`;
ALTER TABLE `agent_invite_code_area` CHANGE COLUMN `area` `area` BIGINT(20) NULL ;
ALTER TABLE `agent_invite_code_area` ADD CONSTRAINT `AGENT_INVITE_CODE_AREA_ID` FOREIGN KEY (`area`) REFERENCES `area` (`id`);
update `agent_invite_code_area` set area = null where cheche_agent_invite_code = (select id from cheche_agent_invite_code where invite_code = '42573823');
