-- 18510080654 13581538623 13521066791 13910569027 四个手机号的邀请码开通全国
update `agent_invite_code_area` set area = null where cheche_agent_invite_code = (select id from cheche_agent_invite_code where invite_code = '95692402');

insert into agent_invite_code_area(area,cheche_agent_invite_code)  (select null , (select id from cheche_agent_invite_code where invite_code = '55578005'));
insert into agent_invite_code_area(area,cheche_agent_invite_code)  (select null , (select id from cheche_agent_invite_code where invite_code = '64029463'));
insert into agent_invite_code_area(area,cheche_agent_invite_code)  (select null , (select id from cheche_agent_invite_code where invite_code = '67292745'));
