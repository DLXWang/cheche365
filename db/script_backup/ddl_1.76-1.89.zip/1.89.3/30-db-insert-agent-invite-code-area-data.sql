-- 47574165 成都 95256481 济南 13911983937 北京
insert into agent_invite_code_area(area,cheche_agent_invite_code)  (select 510100 , (select id from cheche_agent_invite_code where invite_code = '47574165'));
insert into agent_invite_code_area(area,cheche_agent_invite_code)  (select 370100 , (select id from cheche_agent_invite_code where invite_code = '95256481'));

update agent_invite_code_area aica,cheche_agent_invite_code caic,channel_agent ca ,user u
set aica.area = 110000
where ca.user = u.id and caic.channel_agent = ca.id and caic.id = aica.cheche_agent_invite_code and u.mobile = '13911983937' and ca.channel = 67;
