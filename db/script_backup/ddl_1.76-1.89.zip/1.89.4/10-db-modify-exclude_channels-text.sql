ALTER TABLE `tel_marketing_center_channel_filter` MODIFY COLUMN `exclude_channels` text;
