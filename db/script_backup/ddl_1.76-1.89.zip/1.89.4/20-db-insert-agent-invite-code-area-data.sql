-- 13127175883 潍坊
update agent_invite_code_area aica,cheche_agent_invite_code caic,channel_agent ca ,user u
set aica.area = 370700
where ca.user = u.id and caic.channel_agent = ca.id and caic.id = aica.cheche_agent_invite_code and u.mobile = '13127175883' and ca.channel = 67;
