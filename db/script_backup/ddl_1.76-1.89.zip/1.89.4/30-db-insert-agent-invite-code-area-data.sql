-- 13570972418   绑定地区改为广州
update agent_invite_code_area aica,cheche_agent_invite_code caic,channel_agent ca ,user u
set aica.area = 440100
where ca.user = u.id and caic.channel_agent = ca.id and caic.id = aica.cheche_agent_invite_code and u.mobile = '13570972418' and ca.channel = 67;
