UPDATE api_partner SET tag = tag | (1<<13) WHERE `code` = 'jd';
